import Lean
import Formalism.LocalToGlobal.SiegelLatticeTheory.FlagStabilizerTensors.RootLatticeThresholds.AllRowsTr
import Formalism.LocalToGlobal.SiegelLatticeTheory.FlagStabilizerTensors.RootLatticeThresholds.LastDiagMulVec
import Formalism.LocalToGlobal.SiegelLatticeTheory.FlagStabilizerTensors.RootLatticeThresholds.ThresholdBounds
import Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.PoincareSeriesSquareIntegrable
import Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.UnitaryHaarProducts.LatExistsDiff
import Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.UnitaryHaarProducts.LatExistsSat
import Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.UnitaryHaarProducts.UnipLatPf
import Formalism.LocalToGlobal.SiegelLatticeTheory.SiegelMassRatios.ClassAct
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsBasic
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsDefs
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsFolnerConv
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsSchur
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.SchurTensRep
import Formalism.LocalToGlobal.TorsionIntegrality.CMGoodModels.CM4
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.Legendre
import Formalism.LocalToGlobal.TorsionIntegrality.GaussianEigenFrames.GramFrameComposition.Tensor
import Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.IsSemiChar
import Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.ChordSecondLogDeriv
import Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.IntBinomScalar
import Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.IsotropicVanish
import Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.VeluIntegral
import Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.ExistsUnitVec
import Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.FrobStep
import Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.Inert57
import Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.LocPad
import Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.MkLeOfDenseRange
import Formalism.LocalToGlobal.TorsionIntegrality.WeierstrassTwoTorsion.WeierstrassSubstitution.FlowBasic
import Formalism.LocalToGlobal.TorsionIntegrality.WeierstrassTwoTorsion.WeierstrassSubstitution.FlowTrans
import Formalism.LocalToGlobal.TorsionIntegrality.WeierstrassTwoTorsion.WeierstrassSubstitution.FlowTwo
import Formalism.LogFactorialBounds.LocalFactorSplitDv
import Formalism.LogFactorialIndices.SignedSubspaceIndex.IdxBase
import Formalism.LogFactorialIndices.SignedSubspaceIndex.IdxDet
import Formalism.LogFactorialIndices.SignedSubspaceIndex.LogProductFormula
import Formalism.LogFactorialIndices.SignedSubspaceIndex.SubspaceLatticeIndex
import Formalism.LogFactorialIndices.SignedSubspaceIndex.SumInterlacedBoundFails
import Formalism.LogFactorialIndices.SubspaceIndexSigned
import Formalism.LogSumExpBounds.CharacterSumPhase.DescEquivLiftEquiv
import Formalism.LogSumExpBounds.CharacterSumPhase.KappaModulusHolds
import Formalism.LogSumExpBounds.CharacterSumPhase.LatSum
import Formalism.LogSumExpBounds.CharacterSumPhase.ZLiftAsm
import Formalism.LogSumExpBounds.NuclearBound
import Formalism.LogVandermondeBounds.GaussOperatorProductFormula
import Formalism.LogVandermondeBounds.LogRatioUpperBound
import Formalism.LogVandermondeBounds.LogVandermondeProofs.BlockDimensionIdentities
import Formalism.LogVandermondeBounds.LogVandermondeProofs.CardStabilizerVector
import Formalism.LogVandermondeBounds.LogVandermondeProofs.GammaIntegralPolynomialBound
import Formalism.LogVandermondeBounds.LogVandermondeProofs.InertPrimeCountBound
import Formalism.LogVandermondeBounds.LogVandermondeProofs.InterlacingSeparation
import Formalism.LogVandermondeBounds.LogVandermondeProofs.LogVandermondeVariationUnbounded
import Formalism.LogVandermondeBounds.LogVandermondeProofs.MulSingleMulApplySelf
import Formalism.LogVandermondeBounds.LogVandermondeProofs.PrimePowerSubgroupTrivial
import Formalism.LogVandermondeBounds.LogVandermondeProofs.RamifiedLatticeOperatorIdentity
import Formalism.LogVandermondeBounds.LogVandermondeProofs.TaylorLogMetric
import Formalism.LogVandermondeBounds.VandPlace
import Formalism.MahlerMeasure.GoodCount
import Formalism.MahlerMeasure.MahlerMeasureProofs.DeterminantBlockLeadingTerm
import Formalism.MahlerMeasure.MahlerMeasureProofs.LevelAct
import Formalism.MahlerMeasure.MahlerMeasureProofs.LevelSum
import Formalism.MahlerMeasure.MahlerMeasureProofs.TrueRing
import Formalism.MahlerMeasure.StatementB
import Formalism.MeanHeightDescent.CombinedAverageDegreeBound
import Formalism.MeanHeightDescent.FlatDefect
import Formalism.NormUnitaryBounds.DetPolynomialWeights.CoefficientBoundHolds
import Formalism.NormUnitaryBounds.DetPolynomialWeights.IntegralExpInt

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.LocalToGlobal.SiegelLatticeTheory.FlagStabilizerTensors.RootLatticeThresholds.AllRowsTr, `Formalism.LocalToGlobal.SiegelLatticeTheory.FlagStabilizerTensors.RootLatticeThresholds.LastDiagMulVec, `Formalism.LocalToGlobal.SiegelLatticeTheory.FlagStabilizerTensors.RootLatticeThresholds.ThresholdBounds, `Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.PoincareSeriesSquareIntegrable, `Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.UnitaryHaarProducts.LatExistsDiff, `Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.UnitaryHaarProducts.LatExistsSat, `Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.UnitaryHaarProducts.UnipLatPf, `Formalism.LocalToGlobal.SiegelLatticeTheory.SiegelMassRatios.ClassAct, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsBasic, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsDefs, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsFolnerConv, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsSchur, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.SchurTensRep, `Formalism.LocalToGlobal.TorsionIntegrality.CMGoodModels.CM4, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.Legendre, `Formalism.LocalToGlobal.TorsionIntegrality.GaussianEigenFrames.GramFrameComposition.Tensor, `Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.IsSemiChar, `Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.ChordSecondLogDeriv, `Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.IntBinomScalar, `Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.IsotropicVanish, `Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.VeluIntegral, `Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.ExistsUnitVec, `Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.FrobStep, `Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.Inert57, `Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.LocPad, `Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.MkLeOfDenseRange, `Formalism.LocalToGlobal.TorsionIntegrality.WeierstrassTwoTorsion.WeierstrassSubstitution.FlowBasic, `Formalism.LocalToGlobal.TorsionIntegrality.WeierstrassTwoTorsion.WeierstrassSubstitution.FlowTrans, `Formalism.LocalToGlobal.TorsionIntegrality.WeierstrassTwoTorsion.WeierstrassSubstitution.FlowTwo, `Formalism.LogFactorialBounds.LocalFactorSplitDv, `Formalism.LogFactorialIndices.SignedSubspaceIndex.IdxBase, `Formalism.LogFactorialIndices.SignedSubspaceIndex.IdxDet, `Formalism.LogFactorialIndices.SignedSubspaceIndex.LogProductFormula, `Formalism.LogFactorialIndices.SignedSubspaceIndex.SubspaceLatticeIndex, `Formalism.LogFactorialIndices.SignedSubspaceIndex.SumInterlacedBoundFails, `Formalism.LogFactorialIndices.SubspaceIndexSigned, `Formalism.LogSumExpBounds.CharacterSumPhase.DescEquivLiftEquiv, `Formalism.LogSumExpBounds.CharacterSumPhase.KappaModulusHolds, `Formalism.LogSumExpBounds.CharacterSumPhase.LatSum, `Formalism.LogSumExpBounds.CharacterSumPhase.ZLiftAsm, `Formalism.LogSumExpBounds.NuclearBound, `Formalism.LogVandermondeBounds.GaussOperatorProductFormula, `Formalism.LogVandermondeBounds.LogRatioUpperBound, `Formalism.LogVandermondeBounds.LogVandermondeProofs.BlockDimensionIdentities, `Formalism.LogVandermondeBounds.LogVandermondeProofs.CardStabilizerVector, `Formalism.LogVandermondeBounds.LogVandermondeProofs.GammaIntegralPolynomialBound, `Formalism.LogVandermondeBounds.LogVandermondeProofs.InertPrimeCountBound, `Formalism.LogVandermondeBounds.LogVandermondeProofs.InterlacingSeparation, `Formalism.LogVandermondeBounds.LogVandermondeProofs.LogVandermondeVariationUnbounded, `Formalism.LogVandermondeBounds.LogVandermondeProofs.MulSingleMulApplySelf, `Formalism.LogVandermondeBounds.LogVandermondeProofs.PrimePowerSubgroupTrivial, `Formalism.LogVandermondeBounds.LogVandermondeProofs.RamifiedLatticeOperatorIdentity, `Formalism.LogVandermondeBounds.LogVandermondeProofs.TaylorLogMetric, `Formalism.LogVandermondeBounds.VandPlace, `Formalism.MahlerMeasure.GoodCount, `Formalism.MahlerMeasure.MahlerMeasureProofs.DeterminantBlockLeadingTerm, `Formalism.MahlerMeasure.MahlerMeasureProofs.LevelAct, `Formalism.MahlerMeasure.MahlerMeasureProofs.LevelSum, `Formalism.MahlerMeasure.MahlerMeasureProofs.TrueRing, `Formalism.MahlerMeasure.StatementB, `Formalism.MeanHeightDescent.CombinedAverageDegreeBound, `Formalism.MeanHeightDescent.FlatDefect, `Formalism.NormUnitaryBounds.DetPolynomialWeights.CoefficientBoundHolds, `Formalism.NormUnitaryBounds.DetPolynomialWeights.IntegralExpInt]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

