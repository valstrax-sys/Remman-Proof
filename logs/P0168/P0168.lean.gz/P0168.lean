import Lean
import ReciprocityTheory.DualLattices.CharTableIsUnit
import ReciprocityTheory.DualLattices.CotangentSurjective
import ReciprocityTheory.DualLattices.CyclicRecursion
import ReciprocityTheory.DualLattices.DetPolyMulCayleyOmegaPow
import ReciprocityTheory.DualLattices.DualHopfOrderStatement
import ReciprocityTheory.DualLattices.DvdOfCoeffZero
import ReciprocityTheory.DualLattices.EigPowEqOne
import ReciprocityTheory.DualLattices.ExistsPrimitiveRoot
import ReciprocityTheory.DualLattices.ExistsSmulMemOfMemSpan
import ReciprocityTheory.DualLattices.FischerSmulRight
import ReciprocityTheory.DualLattices.InstAddCommMonoidFibreFst
import ReciprocityTheory.DualLattices.MapSmulOneMulVec
import ReciprocityTheory.DualLattices.MapTensorSpan
import ReciprocityTheory.DualLattices.MulIterateRootEqZero
import ReciprocityTheory.DualLattices.QExpansionMonoWCoeffZero
import ReciprocityTheory.DualLattices.SeriesState
import ReciprocityTheory.DualLattices.SubgroupFreenessStatement
import ReciprocityTheory.DualLattices.SubgroupQuotientStatement
import ReciprocityTheory.DualLattices.SumInvMulTrace
import ReciprocityTheory.DualLattices.SumLambdaWeight
import ReciprocityTheory.DualLattices.TransposeMulSelf
import ReciprocityTheory.DualLattices.VDetEqOneOfIntegral
import ReciprocityTheory.DualLattices.ValUntiltESubOne
import ReciprocityTheory.DualLattices.ValuationDetEqOfSpanEq
import ReciprocityTheory.DualLattices.ValuationDetLeOneOfEntriesIntegral
import ReciprocityTheory.DualLattices.WedgeNeZeroOfLinearIndependent
import ReciprocityTheory.EigenFrames.EigenPf
import ReciprocityTheory.GaloisValuations.ContinuousConstSMulQuotient
import ReciprocityTheory.GaloisValuations.GlobalB
import ReciprocityTheory.GeneralLinearIntegers.AlgebraMapIntMemOint
import ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.DegStA
import ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.EllipsoidSt
import ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.HadZSt
import ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.BergmanSt
import ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.PolydiscSt
import ReciprocityTheory.GeometryOfNumbers.SphericalMonomials.ChiPSt
import ReciprocityTheory.GeometryOfNumbers.SphericalMonomials.GaussSt
import ReciprocityTheory.L2DbarEstimates.BasicIdentity.BasicIdentityStatement
import ReciprocityTheory.L2DbarEstimates.JacobianInterpolationStatement
import ReciprocityTheory.L2DbarEstimates.LeviForms.EventuallyDifferentiableAtOfContDiffAt
import ReciprocityTheory.L2DbarEstimates.MinimalSolutions.CvxOfConvex
import ReciprocityTheory.L2DbarEstimates.MinimalSolutions.MinimalSolution
import ReciprocityTheory.L2DbarEstimates.Mollifiers.HasCompactSupport
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.FamilyLeCoords
import ReciprocityTheory.L2DbarEstimates.SymmetricSections.HoloSectionStatement
import ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.Circle
import ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.ExtCutA
import ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.ExtWeakA
import ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.HoloContDiffStatement
import ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.ImportsAlt
import ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.IntegralBumpProfOnePos
import ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.MvDivIntegrand
import ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.RegGlue
import ReciprocityTheory.NeutralLocalFields.Duality
import ReciprocityTheory.NeutralLocalFields.LocalFieldComparison.ExistsPrimeAbsNormOfHasDirichletDensity
import ReciprocityTheory.NeutralLocalFields.LocalFieldComparison.HCFFromRecipA
import ReciprocityTheory.ReducedBases.ExistsBoundedBasis
import ReciprocityTheory.ReducedBases.TBInjective
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.IdxAssembleStA
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.ProjDefs
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.JetsPf
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.TrdegPf
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.UpperBounds.CountPf
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.UpperBounds.IntegralStatementPfA

open Lean Elab Command

def auditTargets : Array Name := #[`ReciprocityTheory.DualLattices.CharTableIsUnit, `ReciprocityTheory.DualLattices.CotangentSurjective, `ReciprocityTheory.DualLattices.CyclicRecursion, `ReciprocityTheory.DualLattices.DetPolyMulCayleyOmegaPow, `ReciprocityTheory.DualLattices.DualHopfOrderStatement, `ReciprocityTheory.DualLattices.DvdOfCoeffZero, `ReciprocityTheory.DualLattices.EigPowEqOne, `ReciprocityTheory.DualLattices.ExistsPrimitiveRoot, `ReciprocityTheory.DualLattices.ExistsSmulMemOfMemSpan, `ReciprocityTheory.DualLattices.FischerSmulRight, `ReciprocityTheory.DualLattices.InstAddCommMonoidFibreFst, `ReciprocityTheory.DualLattices.MapSmulOneMulVec, `ReciprocityTheory.DualLattices.MapTensorSpan, `ReciprocityTheory.DualLattices.MulIterateRootEqZero, `ReciprocityTheory.DualLattices.QExpansionMonoWCoeffZero, `ReciprocityTheory.DualLattices.SeriesState, `ReciprocityTheory.DualLattices.SubgroupFreenessStatement, `ReciprocityTheory.DualLattices.SubgroupQuotientStatement, `ReciprocityTheory.DualLattices.SumInvMulTrace, `ReciprocityTheory.DualLattices.SumLambdaWeight, `ReciprocityTheory.DualLattices.TransposeMulSelf, `ReciprocityTheory.DualLattices.VDetEqOneOfIntegral, `ReciprocityTheory.DualLattices.ValUntiltESubOne, `ReciprocityTheory.DualLattices.ValuationDetEqOfSpanEq, `ReciprocityTheory.DualLattices.ValuationDetLeOneOfEntriesIntegral, `ReciprocityTheory.DualLattices.WedgeNeZeroOfLinearIndependent, `ReciprocityTheory.EigenFrames.EigenPf, `ReciprocityTheory.GaloisValuations.ContinuousConstSMulQuotient, `ReciprocityTheory.GaloisValuations.GlobalB, `ReciprocityTheory.GeneralLinearIntegers.AlgebraMapIntMemOint, `ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.DegStA, `ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.EllipsoidSt, `ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.HadZSt, `ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.BergmanSt, `ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.PolydiscSt, `ReciprocityTheory.GeometryOfNumbers.SphericalMonomials.ChiPSt, `ReciprocityTheory.GeometryOfNumbers.SphericalMonomials.GaussSt, `ReciprocityTheory.L2DbarEstimates.BasicIdentity.BasicIdentityStatement, `ReciprocityTheory.L2DbarEstimates.JacobianInterpolationStatement, `ReciprocityTheory.L2DbarEstimates.LeviForms.EventuallyDifferentiableAtOfContDiffAt, `ReciprocityTheory.L2DbarEstimates.MinimalSolutions.CvxOfConvex, `ReciprocityTheory.L2DbarEstimates.MinimalSolutions.MinimalSolution, `ReciprocityTheory.L2DbarEstimates.Mollifiers.HasCompactSupport, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.FamilyLeCoords, `ReciprocityTheory.L2DbarEstimates.SymmetricSections.HoloSectionStatement, `ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.Circle, `ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.ExtCutA, `ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.ExtWeakA, `ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.HoloContDiffStatement, `ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.ImportsAlt, `ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.IntegralBumpProfOnePos, `ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.MvDivIntegrand, `ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.RegGlue, `ReciprocityTheory.NeutralLocalFields.Duality, `ReciprocityTheory.NeutralLocalFields.LocalFieldComparison.ExistsPrimeAbsNormOfHasDirichletDensity, `ReciprocityTheory.NeutralLocalFields.LocalFieldComparison.HCFFromRecipA, `ReciprocityTheory.ReducedBases.ExistsBoundedBasis, `ReciprocityTheory.ReducedBases.TBInjective, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.IdxAssembleStA, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.ProjDefs, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.JetsPf, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.TrdegPf, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.UpperBounds.CountPf, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.UpperBounds.IntegralStatementPfA]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

