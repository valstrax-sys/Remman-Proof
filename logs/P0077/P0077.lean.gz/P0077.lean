import Lean
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.UnimodularLocalStandard.RepRepModl
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.UnipotentCost.ZIterA
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ValuationLocalVolumes.ProdInertClosed
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ValuationLocalVolumes.QuadRoot
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeakApproximationDVR.SmOneOfNotIsUnit
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeightDualUniqueness.SelfInjective
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.CosDens
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.HenselCount
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.LBSubm
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.LocDensFF
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.LocDensSAChar
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.TopoPolish
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.UnfoldAbs
import Formalism.PeriodIntegrals.UpqRep
import Formalism.PeriodIntegrals.VacEntire
import Formalism.PeriodIntegrals.WeakApproxDVR
import Formalism.PeriodIntegrals.WedgeDetNz
import Formalism.PeriodIntegrals.WeilQuotMeas
import Formalism.PeriodIntegrals.WeylProd
import Formalism.PeriodIntegrals.WittExtension
import Formalism.PeriodIntegrals.WittUnram
import Formalism.PeriodIntegrals.WwCauchyBinet
import Formalism.PeriodIntegrals.WwEval
import Formalism.PeriodIntegrals.WwInjective
import Formalism.PeriodIntegrals.WwMain
import Formalism.PeriodIntegrals.WwMinorExpand
import Formalism.PeriodIntegrals.ZerosWindow
import Formalism.PeriodIntegrals.ZerosWindowIn
import Formalism.PieriBlockIdeals.CapelliCentralEnveloping
import Formalism.PieriBlockIdeals.Statement
import Formalism.PieriBlockIdeals.StatementLW
import Formalism.PieriBlockIdeals.StatementW
import Formalism.PolynomialDimension.FrameSum
import Formalism.PolynomialDimension.StatementHar
import Formalism.PolynomialDimension.WeylDim
import Formalism.RankGapBounds.CloudMinFalse
import Formalism.RankGapBounds.ConjInOrbit
import Formalism.RankGapBounds.LargePrimeFactor
import Formalism.RankGapBounds.MeanBoundSecondForm
import Formalism.RankGapBounds.RandomSubsetCounterexample
import Formalism.RankGapBounds.RankAndGapBounds
import Formalism.RealPlaceAnalysis.Complexify
import Formalism.RealPlaceAnalysis.StatementA
import Formalism.ResultantValuation.BoundedCubic
import Formalism.ResultantValuation.KoszulSecondDifferential
import Formalism.ResultantValuation.ResultantConjugate
import Formalism.ResultantValuation.WindowValuation
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.SatakeComb
import Formalism.SatakeDualWeyl.Statement
import Formalism.SharpRestriction.AdmissibleParameterJoins.GandSo
import Formalism.SharpRestriction.AdmissibleParameterJoins.SfromGLt
import Formalism.SharpRestriction.CuspSpanNormBounds.BridgeLevelGenA
import Formalism.SharpRestriction.CuspSpanNormBounds.BridgeNGLQ
import Formalism.SharpRestriction.CuspSpanNormBounds.CayleyDegreeNondegeneracy.MassPowLeExpRpow
import Formalism.SharpRestriction.CuspSpanNormBounds.CayleyDegreeNondegeneracy.RowsNum
import Formalism.SharpRestriction.CuspSpanNormBounds.CayleyDegreeNondegeneracy.RowsOneA
import Formalism.SharpRestriction.CuspSpanNormBounds.Point
import Formalism.SharpRestriction.CuspSpanNormBounds.SArith
import Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.PjDensUpper
import Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrExistsMeasRep
import Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrcTendstoVec
import Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrdStronglyMeasurable
import Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrkDiag
import Formalism.SharpRestriction.CuspSpanNormBounds.WeightedLatticeSum

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.PeriodIntegrals.UnitaryGroupMassFormula.UnimodularLocalStandard.RepRepModl, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.UnipotentCost.ZIterA, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ValuationLocalVolumes.ProdInertClosed, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ValuationLocalVolumes.QuadRoot, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeakApproximationDVR.SmOneOfNotIsUnit, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeightDualUniqueness.SelfInjective, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.CosDens, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.HenselCount, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.LBSubm, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.LocDensFF, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.LocDensSAChar, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.TopoPolish, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.UnfoldAbs, `Formalism.PeriodIntegrals.UpqRep, `Formalism.PeriodIntegrals.VacEntire, `Formalism.PeriodIntegrals.WeakApproxDVR, `Formalism.PeriodIntegrals.WedgeDetNz, `Formalism.PeriodIntegrals.WeilQuotMeas, `Formalism.PeriodIntegrals.WeylProd, `Formalism.PeriodIntegrals.WittExtension, `Formalism.PeriodIntegrals.WittUnram, `Formalism.PeriodIntegrals.WwCauchyBinet, `Formalism.PeriodIntegrals.WwEval, `Formalism.PeriodIntegrals.WwInjective, `Formalism.PeriodIntegrals.WwMain, `Formalism.PeriodIntegrals.WwMinorExpand, `Formalism.PeriodIntegrals.ZerosWindow, `Formalism.PeriodIntegrals.ZerosWindowIn, `Formalism.PieriBlockIdeals.CapelliCentralEnveloping, `Formalism.PieriBlockIdeals.Statement, `Formalism.PieriBlockIdeals.StatementLW, `Formalism.PieriBlockIdeals.StatementW, `Formalism.PolynomialDimension.FrameSum, `Formalism.PolynomialDimension.StatementHar, `Formalism.PolynomialDimension.WeylDim, `Formalism.RankGapBounds.CloudMinFalse, `Formalism.RankGapBounds.ConjInOrbit, `Formalism.RankGapBounds.LargePrimeFactor, `Formalism.RankGapBounds.MeanBoundSecondForm, `Formalism.RankGapBounds.RandomSubsetCounterexample, `Formalism.RankGapBounds.RankAndGapBounds, `Formalism.RealPlaceAnalysis.Complexify, `Formalism.RealPlaceAnalysis.StatementA, `Formalism.ResultantValuation.BoundedCubic, `Formalism.ResultantValuation.KoszulSecondDifferential, `Formalism.ResultantValuation.ResultantConjugate, `Formalism.ResultantValuation.WindowValuation, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.SatakeComb, `Formalism.SatakeDualWeyl.Statement, `Formalism.SharpRestriction.AdmissibleParameterJoins.GandSo, `Formalism.SharpRestriction.AdmissibleParameterJoins.SfromGLt, `Formalism.SharpRestriction.CuspSpanNormBounds.BridgeLevelGenA, `Formalism.SharpRestriction.CuspSpanNormBounds.BridgeNGLQ, `Formalism.SharpRestriction.CuspSpanNormBounds.CayleyDegreeNondegeneracy.MassPowLeExpRpow, `Formalism.SharpRestriction.CuspSpanNormBounds.CayleyDegreeNondegeneracy.RowsNum, `Formalism.SharpRestriction.CuspSpanNormBounds.CayleyDegreeNondegeneracy.RowsOneA, `Formalism.SharpRestriction.CuspSpanNormBounds.Point, `Formalism.SharpRestriction.CuspSpanNormBounds.SArith, `Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.PjDensUpper, `Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrExistsMeasRep, `Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrcTendstoVec, `Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrdStronglyMeasurable, `Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrkDiag, `Formalism.SharpRestriction.CuspSpanNormBounds.WeightedLatticeSum]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

