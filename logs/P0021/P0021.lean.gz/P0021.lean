import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingHomExtTensor
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingHomExtTensorAlt
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingHomExtendOfIsIntegralIsAlgClosed
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingHomExtendsAlgHomOfSpanOfFinrankEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingKrullDimFiberStalkEqQuotient
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingOfIntegersTraceMulLeftNondegenerate
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RootModelPointHeightDegree
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RowBlockIndicatorFromLtIff
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ScalarOfIntertwinesUpToScalar
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ScaleInto
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchemeHomExtOfJointlyInjective
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchemeTheoreticallyDominantOfGermInjective
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzClosureStableLinearFormFourier
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzContinuousAtOfPointwiseOfBounded
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzContinuousOfSeminormBounds
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzDensityTransportLinearEquivChirp
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzDoubleIntegralExists
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzFamilyPairingIntegralCommute
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzFourierRepresentation
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzFourierSuperposition
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzInnerProductContinuous
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzIntegralEqOfBounds
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzIntegralSuperposition
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzIteratedFDerivTendstoZeroCocompact
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzLogDerivativeGaussian
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzPairingContinuousFunctional
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzSeminormSmulLeftLinearPhaseLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzSeminormTranslateSubLineDerivLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzShiftIteratedFDerivBound
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzTaylorPartialSumDerivBound
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzTaylorSeriesConverges
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzValuedIntegralLinear
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzVanishingDecomposition
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzWeightedSobolevOfFinrankZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SectionsFiniteFlatRankOfFiniteFlat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SemilinearFixedSpan
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SemilinearRankComparison
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SemisimpleAnnihilatorSpanEndomorphisms
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SemisimpleEndomorphismsConjOfCharpoly
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SemisimpleEquivariantProjection
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SetIntegralEqZeroOfFibre
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SetIntegralLeOfExpanding
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SevenMulHeightBoundLeHalfOfParameters
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ShellInt
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ShiftZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ShortExactMulPrimeZmodTensorComplex
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SiegelWeilOrbitalMeasure
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SimultaneousEigenbasisIntegral
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SkewFamilyEqOfStrictLowerOfDiagIm
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SkewFamilyInnerReEqStrictLowerAddDiagIm
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SkewHermitianPerturbIdempotentDetNeZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmoothBoundedGradientOnHalfBall
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmoothIntegralOverUnitCube
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmoothRangeOfIdempotentAlgHom
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmulMemOfMaximalIdealPowOfLocallySurjective
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmulRegularTensorOfQuotientFlat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SndEqSum
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanBaseChangeOfAnnihilator
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanCoeffProdLinear
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanEqTopIffDense
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanEvalEqTop
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanFiniteDimensionalOfBoundedForms
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanOneTmulEqTop
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanOneTmulEqTopAlt

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingHomExtTensor, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingHomExtTensorAlt, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingHomExtendOfIsIntegralIsAlgClosed, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingHomExtendsAlgHomOfSpanOfFinrankEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingKrullDimFiberStalkEqQuotient, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingOfIntegersTraceMulLeftNondegenerate, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RootModelPointHeightDegree, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RowBlockIndicatorFromLtIff, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ScalarOfIntertwinesUpToScalar, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ScaleInto, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchemeHomExtOfJointlyInjective, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchemeTheoreticallyDominantOfGermInjective, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzClosureStableLinearFormFourier, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzContinuousAtOfPointwiseOfBounded, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzContinuousOfSeminormBounds, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzDensityTransportLinearEquivChirp, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzDoubleIntegralExists, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzFamilyPairingIntegralCommute, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzFourierRepresentation, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzFourierSuperposition, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzInnerProductContinuous, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzIntegralEqOfBounds, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzIntegralSuperposition, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzIteratedFDerivTendstoZeroCocompact, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzLogDerivativeGaussian, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzPairingContinuousFunctional, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzSeminormSmulLeftLinearPhaseLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzSeminormTranslateSubLineDerivLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzShiftIteratedFDerivBound, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzTaylorPartialSumDerivBound, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzTaylorSeriesConverges, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzValuedIntegralLinear, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzVanishingDecomposition, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzWeightedSobolevOfFinrankZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SectionsFiniteFlatRankOfFiniteFlat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SemilinearFixedSpan, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SemilinearRankComparison, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SemisimpleAnnihilatorSpanEndomorphisms, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SemisimpleEndomorphismsConjOfCharpoly, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SemisimpleEquivariantProjection, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SetIntegralEqZeroOfFibre, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SetIntegralLeOfExpanding, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SevenMulHeightBoundLeHalfOfParameters, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ShellInt, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ShiftZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ShortExactMulPrimeZmodTensorComplex, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SiegelWeilOrbitalMeasure, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SimultaneousEigenbasisIntegral, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SkewFamilyEqOfStrictLowerOfDiagIm, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SkewFamilyInnerReEqStrictLowerAddDiagIm, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SkewHermitianPerturbIdempotentDetNeZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmoothBoundedGradientOnHalfBall, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmoothIntegralOverUnitCube, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmoothRangeOfIdempotentAlgHom, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmulMemOfMaximalIdealPowOfLocallySurjective, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmulRegularTensorOfQuotientFlat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SndEqSum, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanBaseChangeOfAnnihilator, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanCoeffProdLinear, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanEqTopIffDense, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanEvalEqTop, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanFiniteDimensionalOfBoundedForms, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanOneTmulEqTop, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanOneTmulEqTopAlt]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

