import Lean
import ReciprocityTheory.Chebotarev.LatSum
import ReciprocityTheory.Chebotarev.NZIdeal
import ReciprocityTheory.Chebotarev.NoWind
import ReciprocityTheory.Chebotarev.NormCongr
import ReciprocityTheory.Chebotarev.SplitF
import ReciprocityTheory.ClassFieldTheory.GlobalClassField.SUnitGalois.GalSmulAsIdeal
import ReciprocityTheory.ClassFieldTheory.LocalClassField.HerbrandA
import ReciprocityTheory.ClassFieldTheory.LocalClassField.UnitsHerbrandA
import ReciprocityTheory.ClassFieldTheory.PadicCompatibleSequences.ExistsPadicIntOfCompatibleSeq
import ReciprocityTheory.CommutativeAlgebra.ChainConnInDim
import ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.RegGensA
import ReciprocityTheory.CommutativeAlgebra.MaximalIdealSquares.RingKrullDimQuotientSpanSingletonAddOne
import ReciprocityTheory.DualLattices.BadStatement
import ReciprocityTheory.DualLattices.CyclicRecursionStatement
import ReciprocityTheory.DualLattices.Eisenstein4CoeffBound
import ReciprocityTheory.DualLattices.FischerAdjointStatement
import ReciprocityTheory.DualLattices.FrobEqOfLe
import ReciprocityTheory.DualLattices.HasSumNormalizedDeriv
import ReciprocityTheory.DualLattices.IsAdicCompleteOfBasis
import ReciprocityTheory.DualLattices.IsUnitDetOfSpanEq
import ReciprocityTheory.DualLattices.IsUnitOfNotMem
import ReciprocityTheory.DualLattices.NearIdentityColengthStatement
import ReciprocityTheory.DualLattices.ProdEraseUpdate
import ReciprocityTheory.DualLattices.RankMapLeRank
import ReciprocityTheory.DualLattices.RidConvolutionDerivation
import ReciprocityTheory.DualLattices.SmallLevelClassSet
import ReciprocityTheory.DualLattices.SqZeroOfSpan
import ReciprocityTheory.DualLattices.TensorSpan
import ReciprocityTheory.DualLattices.VEqZeroOfPowEqOne
import ReciprocityTheory.DualLattices.VIntCastLtOneOfDvd
import ReciprocityTheory.EigenFrames.EigenSt
import ReciprocityTheory.GaloisValuations.GlobalA
import ReciprocityTheory.GaloisValuations.SeparatedDvrSecondCohomologyMem
import ReciprocityTheory.GeometryOfNumbers.AsymptoticSequences.SimplexSumSt
import ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.ConjSymm
import ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.CountZSt
import ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.EllipsoidStA
import ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.GramSt
import ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.HadZStA
import ReciprocityTheory.GeometryOfNumbers.MatrixArithmetic.WeakMatSt
import ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.BergmanDefs
import ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.DiscSt
import ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.LogDetSt
import ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.MorseGenStA
import ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.TaylorLeviSt
import ReciprocityTheory.GeometryOfNumbers.SphericalMonomials.MonoNormSq
import ReciprocityTheory.GroupCohomology.ChiRkA
import ReciprocityTheory.GroupCohomology.CofinA
import ReciprocityTheory.GroupCohomology.EqZeroOfLe
import ReciprocityTheory.GroupCohomology.IsTowerLim
import ReciprocityTheory.GroupCohomology.MemZpowersQuot
import ReciprocityTheory.GroupCohomology.RankLenA
import ReciprocityTheory.GroupCohomology.ReverseA
import ReciprocityTheory.L2DbarEstimates.BasicIdentity.HalfSumNormSubSq
import ReciprocityTheory.L2DbarEstimates.IsLocalHomeomorph
import ReciprocityTheory.L2DbarEstimates.MinimalSolutions.MinimalSolutionStatement
import ReciprocityTheory.L2DbarEstimates.Mollifiers.MollifierL2LocTendsto
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.UniLatA
import ReciprocityTheory.L2DbarEstimates.SkodaWeights.Matrix
import ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.HoloWeakStatement
import ReciprocityTheory.NeutralLocalFields.GrunwaldWang
import ReciprocityTheory.NeutralLocalFields.HilbertClassField
import ReciprocityTheory.NeutralLocalFields.LocalFieldComparison.HilbertClassFieldA
import ReciprocityTheory.NeutralLocalFields.LocalFieldComparison.TendstoPrimeIdealZetaSumUniv

open Lean Elab Command

def auditTargets : Array Name := #[`ReciprocityTheory.Chebotarev.LatSum, `ReciprocityTheory.Chebotarev.NZIdeal, `ReciprocityTheory.Chebotarev.NoWind, `ReciprocityTheory.Chebotarev.NormCongr, `ReciprocityTheory.Chebotarev.SplitF, `ReciprocityTheory.ClassFieldTheory.GlobalClassField.SUnitGalois.GalSmulAsIdeal, `ReciprocityTheory.ClassFieldTheory.LocalClassField.HerbrandA, `ReciprocityTheory.ClassFieldTheory.LocalClassField.UnitsHerbrandA, `ReciprocityTheory.ClassFieldTheory.PadicCompatibleSequences.ExistsPadicIntOfCompatibleSeq, `ReciprocityTheory.CommutativeAlgebra.ChainConnInDim, `ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.RegGensA, `ReciprocityTheory.CommutativeAlgebra.MaximalIdealSquares.RingKrullDimQuotientSpanSingletonAddOne, `ReciprocityTheory.DualLattices.BadStatement, `ReciprocityTheory.DualLattices.CyclicRecursionStatement, `ReciprocityTheory.DualLattices.Eisenstein4CoeffBound, `ReciprocityTheory.DualLattices.FischerAdjointStatement, `ReciprocityTheory.DualLattices.FrobEqOfLe, `ReciprocityTheory.DualLattices.HasSumNormalizedDeriv, `ReciprocityTheory.DualLattices.IsAdicCompleteOfBasis, `ReciprocityTheory.DualLattices.IsUnitDetOfSpanEq, `ReciprocityTheory.DualLattices.IsUnitOfNotMem, `ReciprocityTheory.DualLattices.NearIdentityColengthStatement, `ReciprocityTheory.DualLattices.ProdEraseUpdate, `ReciprocityTheory.DualLattices.RankMapLeRank, `ReciprocityTheory.DualLattices.RidConvolutionDerivation, `ReciprocityTheory.DualLattices.SmallLevelClassSet, `ReciprocityTheory.DualLattices.SqZeroOfSpan, `ReciprocityTheory.DualLattices.TensorSpan, `ReciprocityTheory.DualLattices.VEqZeroOfPowEqOne, `ReciprocityTheory.DualLattices.VIntCastLtOneOfDvd, `ReciprocityTheory.EigenFrames.EigenSt, `ReciprocityTheory.GaloisValuations.GlobalA, `ReciprocityTheory.GaloisValuations.SeparatedDvrSecondCohomologyMem, `ReciprocityTheory.GeometryOfNumbers.AsymptoticSequences.SimplexSumSt, `ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.ConjSymm, `ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.CountZSt, `ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.EllipsoidStA, `ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.GramSt, `ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.HadZStA, `ReciprocityTheory.GeometryOfNumbers.MatrixArithmetic.WeakMatSt, `ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.BergmanDefs, `ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.DiscSt, `ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.LogDetSt, `ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.MorseGenStA, `ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.TaylorLeviSt, `ReciprocityTheory.GeometryOfNumbers.SphericalMonomials.MonoNormSq, `ReciprocityTheory.GroupCohomology.ChiRkA, `ReciprocityTheory.GroupCohomology.CofinA, `ReciprocityTheory.GroupCohomology.EqZeroOfLe, `ReciprocityTheory.GroupCohomology.IsTowerLim, `ReciprocityTheory.GroupCohomology.MemZpowersQuot, `ReciprocityTheory.GroupCohomology.RankLenA, `ReciprocityTheory.GroupCohomology.ReverseA, `ReciprocityTheory.L2DbarEstimates.BasicIdentity.HalfSumNormSubSq, `ReciprocityTheory.L2DbarEstimates.IsLocalHomeomorph, `ReciprocityTheory.L2DbarEstimates.MinimalSolutions.MinimalSolutionStatement, `ReciprocityTheory.L2DbarEstimates.Mollifiers.MollifierL2LocTendsto, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.UniLatA, `ReciprocityTheory.L2DbarEstimates.SkodaWeights.Matrix, `ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.HoloWeakStatement, `ReciprocityTheory.NeutralLocalFields.GrunwaldWang, `ReciprocityTheory.NeutralLocalFields.HilbertClassField, `ReciprocityTheory.NeutralLocalFields.LocalFieldComparison.HilbertClassFieldA, `ReciprocityTheory.NeutralLocalFields.LocalFieldComparison.TendstoPrimeIdealZetaSumUniv]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

