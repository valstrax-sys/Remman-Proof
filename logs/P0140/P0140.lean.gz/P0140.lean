import Lean
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LeftCommLTensorNatural
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LieAlgebraFunctionCalculusStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LieAlgebraOfTangentCurve
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LieAlgebraStarClosedBracketStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LiftIdempotentAdicComplete
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LinearMapZeroOfInjectiveFullRankStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralEnormRpowTwoNeTop
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralUniformNearParameterStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralWeightedSqLe
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalContinuousSectionVecMulOrbitStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalFreeKernelSplittingStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalSplittingKernelBaseChangeStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalUniqueSquareRootNearOneStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalizationPreservesClosedness
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LtOneOfPowerBoundStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MapWithDensityEqOfScale
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MeasureComplementImageEqZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MeasureUnitImage
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MemIdempotentComplementIff
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MemRiemannRochSpaceIffRegularAtEverywhere
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MemTwKerIffAverage
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MonicFactorCoefficientsIntegralStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MonomialCoefficientComparison
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MulProdCongr
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicativeCharacterOnConeStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicativityFinitePlaces
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicativityInfinitePlaces
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultisetAntitoneEnumerationStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NewtonPolygonSlopeExistence
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NoetherNormalizationHomogeneous
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NotMemLpOfGrowthStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NullCOfInvM
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.OneTmulMemRangeIff
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.OntoFormLaws
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PairingBoundFinitePlaces
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PairingBoundInfinitePlaces
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicFundamentalDomainSplit
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicFundamentalDomainVolume
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicHaarDecomposition
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicIntegralUnfolding
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicLeviIntegralFormula
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicQuotientMeasure
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionCoefficientSigns
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionDiagonalIdentity
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PfFacts
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PieceMeasureLtTop
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PointEqTranslate
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PolynomialRootsOfClosedQuotient
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PolynomialTimesGaussianBoundedStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PositiveOnSubspaceOpen
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PowerDivisibilityRootExtraction
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdLeRevEqProdGeStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdPairSumsEqSumPowersetScore
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdRelIndexNeZeroStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProductNeighbourhoodsShrinkCompactOpenStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProductSubsetSumVanishesStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.QuadraticBoxIntegralSmallBall
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.QuadraticBoxVolumeBound
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.QuotientMeasureByInvariantSubgroupStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationAdd
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationCupProduct
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationFunctorial
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationSmul
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationUnique

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LeftCommLTensorNatural, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LieAlgebraFunctionCalculusStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LieAlgebraOfTangentCurve, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LieAlgebraStarClosedBracketStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LiftIdempotentAdicComplete, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LinearMapZeroOfInjectiveFullRankStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralEnormRpowTwoNeTop, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralUniformNearParameterStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralWeightedSqLe, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalContinuousSectionVecMulOrbitStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalFreeKernelSplittingStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalSplittingKernelBaseChangeStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalUniqueSquareRootNearOneStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalizationPreservesClosedness, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LtOneOfPowerBoundStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MapWithDensityEqOfScale, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MeasureComplementImageEqZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MeasureUnitImage, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MemIdempotentComplementIff, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MemRiemannRochSpaceIffRegularAtEverywhere, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MemTwKerIffAverage, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MonicFactorCoefficientsIntegralStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MonomialCoefficientComparison, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MulProdCongr, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicativeCharacterOnConeStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicativityFinitePlaces, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicativityInfinitePlaces, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultisetAntitoneEnumerationStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NewtonPolygonSlopeExistence, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NoetherNormalizationHomogeneous, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NotMemLpOfGrowthStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NullCOfInvM, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.OneTmulMemRangeIff, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.OntoFormLaws, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PairingBoundFinitePlaces, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PairingBoundInfinitePlaces, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicFundamentalDomainSplit, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicFundamentalDomainVolume, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicHaarDecomposition, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicIntegralUnfolding, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicLeviIntegralFormula, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicQuotientMeasure, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionCoefficientSigns, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionDiagonalIdentity, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PfFacts, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PieceMeasureLtTop, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PointEqTranslate, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PolynomialRootsOfClosedQuotient, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PolynomialTimesGaussianBoundedStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PositiveOnSubspaceOpen, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PowerDivisibilityRootExtraction, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdLeRevEqProdGeStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdPairSumsEqSumPowersetScore, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdRelIndexNeZeroStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProductNeighbourhoodsShrinkCompactOpenStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProductSubsetSumVanishesStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.QuadraticBoxIntegralSmallBall, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.QuadraticBoxVolumeBound, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.QuotientMeasureByInvariantSubgroupStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationAdd, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationCupProduct, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationFunctorial, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationSmul, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationUnique]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

