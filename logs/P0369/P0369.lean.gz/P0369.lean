import Lean
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticePointCountScaling
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LimitDivisibleOfVanishingLevel
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalFactorSandwichApprox
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LseqOfLevelIsosStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MackeyInnerProduct
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MapHCompEqSmul
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MatrixGaussSumCongrInvarianceStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MatrixGaussSumDiagonalFactorStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MeasurableEmbeddingOfInjectiveProper
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultipliableLocalFactors
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicityReductionDiagonalProdStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultisetConjugateNegOfProd
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NewtonApproximationOfDichotomy
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapThirdProperty
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormThetaMulStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PatternGroupStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PerfectTensorGeneratedLiftStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PermutationMatrixProperties
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.QuantumDetOppositeNeg
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RelIndexAnnihilatorsDuality
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SamePartitionStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ScalingMeasureProductArchimedean
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SimpleIffIrreducible
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TailSumOverPlacesSmall
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TubeTransformHorizontalInvarianceStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TubeTransformVerticalInvarianceStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnimodularHermitianRepsCountSucc
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.CycNumIntAndComb
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.CycleListPermInvariant
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.ExistsMixedDifferenceExpansion
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FibreComponentDivisorProperties
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreeLinearFunctionalsStatement
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagShiftTotalPowerSum
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.HermitianDarbouxSplitProductStatement
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.HomogeneousPowerSumDecompositionStatement
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.LocalPairSplitSum
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.PowerSumMixedExpansion
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.SumPrimeLogDivLe
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.UniformizerDivisorCycleNumber
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.BtOrderValueEval
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.CharacterSectionMultiplicative
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ChartBundleLatticeGeneratorsStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ChartBundleLocalGenerationStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ComplexPointConjugate
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ComplexPointExistsUniqueEmbedding
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.CoordOverIntOfFiniteOrder
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.DominatesOfCoordsRegularStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.DominatingModelChartCompat
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsCechNerveDiagonalIsoZeroOverBase
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsDenominatorBtOrderStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsTwistedGenerators
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsUniqueSection
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FiniteOpenHopfOrder
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FiniteSchemeMapFromSpecialFibre
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FirstOrderPointsCommute
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FlagBasisChangeIntegral
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FlagChartGenericField
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FlagCoefficientRatioIntegralStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FlatOfFlatSpecialFibre
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrameChangeByUnitMatrix
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrameCoeffsRegularInChart
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrameMatrixChartRatios
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrameNearGenericPoint
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrameViaTwistedGenerators

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticePointCountScaling, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LimitDivisibleOfVanishingLevel, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalFactorSandwichApprox, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LseqOfLevelIsosStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MackeyInnerProduct, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MapHCompEqSmul, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MatrixGaussSumCongrInvarianceStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MatrixGaussSumDiagonalFactorStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MeasurableEmbeddingOfInjectiveProper, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultipliableLocalFactors, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicityReductionDiagonalProdStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultisetConjugateNegOfProd, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NewtonApproximationOfDichotomy, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapThirdProperty, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormThetaMulStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PatternGroupStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PerfectTensorGeneratedLiftStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PermutationMatrixProperties, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.QuantumDetOppositeNeg, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RelIndexAnnihilatorsDuality, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SamePartitionStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ScalingMeasureProductArchimedean, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SimpleIffIrreducible, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TailSumOverPlacesSmall, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TubeTransformHorizontalInvarianceStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TubeTransformVerticalInvarianceStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnimodularHermitianRepsCountSucc, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.CycNumIntAndComb, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.CycleListPermInvariant, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.ExistsMixedDifferenceExpansion, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FibreComponentDivisorProperties, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreeLinearFunctionalsStatement, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagShiftTotalPowerSum, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.HermitianDarbouxSplitProductStatement, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.HomogeneousPowerSumDecompositionStatement, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.LocalPairSplitSum, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.PowerSumMixedExpansion, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.SumPrimeLogDivLe, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.UniformizerDivisorCycleNumber, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.BtOrderValueEval, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.CharacterSectionMultiplicative, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ChartBundleLatticeGeneratorsStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ChartBundleLocalGenerationStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ComplexPointConjugate, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ComplexPointExistsUniqueEmbedding, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.CoordOverIntOfFiniteOrder, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.DominatesOfCoordsRegularStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.DominatingModelChartCompat, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsCechNerveDiagonalIsoZeroOverBase, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsDenominatorBtOrderStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsTwistedGenerators, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsUniqueSection, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FiniteOpenHopfOrder, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FiniteSchemeMapFromSpecialFibre, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FirstOrderPointsCommute, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FlagBasisChangeIntegral, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FlagChartGenericField, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FlagCoefficientRatioIntegralStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FlatOfFlatSpecialFibre, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrameChangeByUnitMatrix, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrameCoeffsRegularInChart, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrameMatrixChartRatios, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrameNearGenericPoint, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrameViaTwistedGenerators]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

