import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaProjectionIntertwining
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionPointOfLatticeTauLatticeMembershipStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionPointRowSumEqQExpansionSeries
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsorTrivialClosedPointsOfOriginClosedFibreStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsorTrivialGenericFibreOfStrictHenselClosedFibStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorusFundamentalDomainCovers
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TotallyDisconnectedProductLocallyCompact
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TraceEqSumEigenMultiplicitiesStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TraceLsmulEqFinrankMulTraceStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TraceOpen
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslateOpenSubgroupsFiniteStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationCharacterInvariantForm
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationInvariantFunctionalLinearZeroStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationPreservesFlatForm
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TripSizesSum
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TruncatedGaussianIntegralUniformPosSemidef
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TsumLatticePairUnitQuotientRegroupStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TsumResidueClassSplitBySignStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TwistedHarishChandraInductionGLIsTwistedClassFunStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnfoldingIntegralCountableStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnipotentPolynomialInLogStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitEqMulPowOnEtaleExcisionNbhdZeroLocus
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitLogarithmSpanningStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitPowerOnExcisionNeighbourhood
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryDetIsTAStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryPQContinuousCharacterEqDetPowProd
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UpperHalfPlaneProductProdImRpowContDiffOnStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValuesMemOfLocal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.VandermondeDerivativeRatioBoundStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.VanishAt
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.VolumePeriodTorusEqDetImaginary
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WEMulNUMulTD
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WallSetCompactDominant
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WedgePowerEqFactorialDet
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeierstrassConstantQExpansionStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeierstrassEisensteinNonholomorphicIdentityStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeightedOrbitSumEqPairOrbitSum
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeilObjectsInhabited
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WinSet
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.XSubXDvdOfVanishOnOpenHyperplane
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.AlgebraMapMemO
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.CardHermitianQuadricAffineSubspaceResidueRing
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.CumulantLowerBoundOfBoundedCentredStatement
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.DetGramTwoFrames
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.EichlerIsometry
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsIsometryOfLinearIndependent
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsMemFractionalIdealPrimitiveLocalGeneratorAStatement
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExpandByConductor
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.IndexMeasureIntegralEqOfFineSubgroup
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.IndexMeasureIntegralProdFubini
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.IndexMeasureIntegralTransportAndChange
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.InvVolMulPosLeConj
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.IsIntegralValIntegerIff
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.IsPrincipalIdealRingOfHenselian
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.PrimitiveTuplesWithGramMatrixHenselCountStatement
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.SameBlockAppend
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.T2SpaceOfIsNonarchimedeanLocalFieldFlagMeasures
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.TwoGeometricSumsIndexBound
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.WittFreeTuplesFin
import Development.AbelianVarietyTheory.Proofs.FormalGroupCharts.AlgHomDualNumberExt
import Development.AbelianVarietyTheory.Proofs.FormalGroupCharts.FormalEvSecondPointOfXZero
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.AdjacentSelfDualLatticesIndexSimpleStatement
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.AdmissibleOfSl2ActionStatement
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.BesselJUnitaryEquivariant

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaProjectionIntertwining, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionPointOfLatticeTauLatticeMembershipStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionPointRowSumEqQExpansionSeries, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsorTrivialClosedPointsOfOriginClosedFibreStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsorTrivialGenericFibreOfStrictHenselClosedFibStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorusFundamentalDomainCovers, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TotallyDisconnectedProductLocallyCompact, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TraceEqSumEigenMultiplicitiesStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TraceLsmulEqFinrankMulTraceStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TraceOpen, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslateOpenSubgroupsFiniteStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationCharacterInvariantForm, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationInvariantFunctionalLinearZeroStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationPreservesFlatForm, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TripSizesSum, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TruncatedGaussianIntegralUniformPosSemidef, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TsumLatticePairUnitQuotientRegroupStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TsumResidueClassSplitBySignStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TwistedHarishChandraInductionGLIsTwistedClassFunStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnfoldingIntegralCountableStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnipotentPolynomialInLogStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitEqMulPowOnEtaleExcisionNbhdZeroLocus, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitLogarithmSpanningStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitPowerOnExcisionNeighbourhood, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryDetIsTAStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryPQContinuousCharacterEqDetPowProd, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UpperHalfPlaneProductProdImRpowContDiffOnStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValuesMemOfLocal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.VandermondeDerivativeRatioBoundStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.VanishAt, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.VolumePeriodTorusEqDetImaginary, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WEMulNUMulTD, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WallSetCompactDominant, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WedgePowerEqFactorialDet, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeierstrassConstantQExpansionStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeierstrassEisensteinNonholomorphicIdentityStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeightedOrbitSumEqPairOrbitSum, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeilObjectsInhabited, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WinSet, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.XSubXDvdOfVanishOnOpenHyperplane, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.AlgebraMapMemO, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.CardHermitianQuadricAffineSubspaceResidueRing, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.CumulantLowerBoundOfBoundedCentredStatement, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.DetGramTwoFrames, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.EichlerIsometry, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsIsometryOfLinearIndependent, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsMemFractionalIdealPrimitiveLocalGeneratorAStatement, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExpandByConductor, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.IndexMeasureIntegralEqOfFineSubgroup, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.IndexMeasureIntegralProdFubini, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.IndexMeasureIntegralTransportAndChange, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.InvVolMulPosLeConj, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.IsIntegralValIntegerIff, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.IsPrincipalIdealRingOfHenselian, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.PrimitiveTuplesWithGramMatrixHenselCountStatement, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.SameBlockAppend, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.T2SpaceOfIsNonarchimedeanLocalFieldFlagMeasures, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.TwoGeometricSumsIndexBound, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.WittFreeTuplesFin, `Development.AbelianVarietyTheory.Proofs.FormalGroupCharts.AlgHomDualNumberExt, `Development.AbelianVarietyTheory.Proofs.FormalGroupCharts.FormalEvSecondPointOfXZero, `Development.AbelianVarietyTheory.Proofs.FoundationProofs.AdjacentSelfDualLatticesIndexSimpleStatement, `Development.AbelianVarietyTheory.Proofs.FoundationProofs.AdmissibleOfSl2ActionStatement, `Development.AbelianVarietyTheory.Proofs.FoundationProofs.BesselJUnitaryEquivariant]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

