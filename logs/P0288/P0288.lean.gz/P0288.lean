import Lean
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchPowerSumAtRootsOfUnity
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchPowerSumHomWeighted
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchProdOneSubRootsOfUnity
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchResidueCount
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchRootOfUnityBialternant
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchRootOfUnityRowsEq
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchRootOfUnityRowsPerm
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchRootOfUnityVandermondeNe
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchSchurAtRootsOfUnity
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchSchurEvalMatrix
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchSchurHomogeneous
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchSchurRowsToK
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchSmallBlockProduct
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchStrictAntiSplit
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchWeightedPreimage
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchurPowerSumCoefficient
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.StatementsComb
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.TenNinthsLe
import GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.WeightedUnfolding
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.ComapMaximalIdealParDVR
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.Inhabitants
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.IsChowFormCMul
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PChowSecDegree
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PFiniteOrd
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PGaussDVR
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PGaussEq
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PNormFormLocalization
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.POrdEq
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PParAlgIndep
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PParDVRIsDVR
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PPrimitiveScale
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSecBFinite
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSecBGeneric
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSecBLinInj
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSecBTorsionFree
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSecLinNZD
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PVertSpec
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PVertTermEq
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.StatementsChart
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.StatementsSecIdealOfPrime
import GroundTheory.HeightsAndTheta.Heights.WeightedHomogeneous.SectionInjectivityHypothesesProjectiveLine
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.DiscrNegAndAbsNormMul
import GroundTheory.LocalFields.AbstractLocalReciprocity.NormFormula
import GroundTheory.LocalFields.AbstractLocalReciprocity.Valuation
import GroundTheory.LocalFields.BrauerInductionMonomial
import GroundTheory.LocalFields.BrauerInductionSpan
import GroundTheory.LocalFields.Eisenstein
import GroundTheory.LocalFields.ExistsUnitFiltrationUnitsLeRangeNormUnits
import GroundTheory.LocalFields.FormalGroups.Basics
import GroundTheory.LocalFields.PadicLogSeries
import GroundTheory.LocalFields.Ramification
import GroundTheory.LocalFields.SeparableClosure
import GroundTheory.LocalFields.UnramifiedDefs
import GroundTheory.LocalFields.UnramifiedRootsOfUnity
import GroundTheory.PAdicHodge.AInfTopology
import GroundTheory.PAdicHodge.AInfXi
import GroundTheory.PAdicHodge.BCrisNewtonLift
import GroundTheory.PAdicHodge.BdRAlg
import GroundTheory.PAdicHodge.BdRLattice
import GroundTheory.PAdicHodge.CyclotomicTower
import GroundTheory.PAdicHodge.ExtRobbaDMRankOne
import GroundTheory.PAdicHodge.ExtRobbaGamma
import GroundTheory.PAdicHodge.ExtRobbaUntilt
import GroundTheory.PAdicHodge.NormalizedTraceTower

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchPowerSumAtRootsOfUnity, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchPowerSumHomWeighted, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchProdOneSubRootsOfUnity, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchResidueCount, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchRootOfUnityBialternant, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchRootOfUnityRowsEq, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchRootOfUnityRowsPerm, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchRootOfUnityVandermondeNe, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchSchurAtRootsOfUnity, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchSchurEvalMatrix, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchSchurHomogeneous, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchSchurRowsToK, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchSmallBlockProduct, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchStrictAntiSplit, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchWeightedPreimage, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchurPowerSumCoefficient, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.StatementsComb, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.TenNinthsLe, `GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.WeightedUnfolding, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.ComapMaximalIdealParDVR, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.Inhabitants, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.IsChowFormCMul, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PChowSecDegree, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PFiniteOrd, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PGaussDVR, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PGaussEq, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PNormFormLocalization, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.POrdEq, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PParAlgIndep, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PParDVRIsDVR, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PPrimitiveScale, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSecBFinite, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSecBGeneric, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSecBLinInj, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSecBTorsionFree, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSecLinNZD, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PVertSpec, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PVertTermEq, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.StatementsChart, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.StatementsSecIdealOfPrime, `GroundTheory.HeightsAndTheta.Heights.WeightedHomogeneous.SectionInjectivityHypothesesProjectiveLine, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.DiscrNegAndAbsNormMul, `GroundTheory.LocalFields.AbstractLocalReciprocity.NormFormula, `GroundTheory.LocalFields.AbstractLocalReciprocity.Valuation, `GroundTheory.LocalFields.BrauerInductionMonomial, `GroundTheory.LocalFields.BrauerInductionSpan, `GroundTheory.LocalFields.Eisenstein, `GroundTheory.LocalFields.ExistsUnitFiltrationUnitsLeRangeNormUnits, `GroundTheory.LocalFields.FormalGroups.Basics, `GroundTheory.LocalFields.PadicLogSeries, `GroundTheory.LocalFields.Ramification, `GroundTheory.LocalFields.SeparableClosure, `GroundTheory.LocalFields.UnramifiedDefs, `GroundTheory.LocalFields.UnramifiedRootsOfUnity, `GroundTheory.PAdicHodge.AInfTopology, `GroundTheory.PAdicHodge.AInfXi, `GroundTheory.PAdicHodge.BCrisNewtonLift, `GroundTheory.PAdicHodge.BdRAlg, `GroundTheory.PAdicHodge.BdRLattice, `GroundTheory.PAdicHodge.CyclotomicTower, `GroundTheory.PAdicHodge.ExtRobbaDMRankOne, `GroundTheory.PAdicHodge.ExtRobbaGamma, `GroundTheory.PAdicHodge.ExtRobbaUntilt, `GroundTheory.PAdicHodge.NormalizedTraceTower]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

