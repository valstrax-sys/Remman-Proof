import Lean
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationUnitClass
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RegularizedExponentialSum
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RelIndexOpenCompactNeZeroStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RemoveNthSuccVecCons
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ResAlgSplitTwo
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RetractBaseChangeKernelCompatibleStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RowIntOfKerBasic
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchurOpOfSchurL
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzFourierTransformMatrix
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzLinearChangeStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ScoreRigidityPermEqOne
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ScoreTZeroEqLevelCount
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionInvarianceCosetSum
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionLawHolds
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionOrthogonalIdempotentSum
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionOverIdempotentProperties
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemidirectProductHomeomorphOfClosedComplementStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemistableGenericFibreLocalizationStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemistableModelRingIsDomainStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemistableSpecialFibrePropertyStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SesquilinearEqZeroOfDiagZeroStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShuffleOfPerm
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShufflePermFlatten
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShuffleWeightSquareLengthLt
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SmoothSpreadsOut
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SmulEqZeroOfLTensorSubtypeEqZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SmulSmulMemRange
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SolvAtStage
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SolveUnitriangular
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SplitQuadraticOrderPrincipalStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.StagedEstimateHolds
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableOfLatticeDecayStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableTwistedSquareCoefficientsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SurjectivePreservesClosednessComparability
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorEvalFixedOfFixed
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorPrimeLocalizationCriterionStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorPrimeOverIdealCompletionStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorSumAnnihilatorStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TmulEqZeroOfMemSpan
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TraceDiagonalBlockConjugateFormula
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingBasisEval
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingFrobeniusCompat
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingGaloisEquivariant
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingLTensorNaturality
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingSmulDual
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingSmulLeft
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TupCoordApply
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TwKerEqMapOfSurjective
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UniformLowerBoundNearInjectiveStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitaryExtensionOfBlockStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitaryFramesPreserveNormSqSumStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitaryLiftCommutingInvolutionStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedQuadraticOrderPrincipalStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ValThree
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ValuationPowerIff
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VandermondeSquares
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WallLawOfSectionLaw
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WedgeBoundFinitePlaces
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WedgeBoundInfinitePlaces
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WedgeSubspaceBound
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WeylDenominatorProduct
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WpHomotopy
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagShiftTotalLinRootPower
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.SumLogDivNSqLeTwoStatement

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationUnitClass, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RegularizedExponentialSum, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RelIndexOpenCompactNeZeroStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RemoveNthSuccVecCons, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ResAlgSplitTwo, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RetractBaseChangeKernelCompatibleStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RowIntOfKerBasic, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchurOpOfSchurL, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzFourierTransformMatrix, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzLinearChangeStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ScoreRigidityPermEqOne, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ScoreTZeroEqLevelCount, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionInvarianceCosetSum, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionLawHolds, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionOrthogonalIdempotentSum, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionOverIdempotentProperties, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemidirectProductHomeomorphOfClosedComplementStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemistableGenericFibreLocalizationStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemistableModelRingIsDomainStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemistableSpecialFibrePropertyStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SesquilinearEqZeroOfDiagZeroStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShuffleOfPerm, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShufflePermFlatten, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShuffleWeightSquareLengthLt, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SmoothSpreadsOut, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SmulEqZeroOfLTensorSubtypeEqZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SmulSmulMemRange, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SolvAtStage, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SolveUnitriangular, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SplitQuadraticOrderPrincipalStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.StagedEstimateHolds, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableOfLatticeDecayStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableTwistedSquareCoefficientsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SurjectivePreservesClosednessComparability, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorEvalFixedOfFixed, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorPrimeLocalizationCriterionStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorPrimeOverIdealCompletionStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorSumAnnihilatorStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TmulEqZeroOfMemSpan, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TraceDiagonalBlockConjugateFormula, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingBasisEval, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingFrobeniusCompat, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingGaloisEquivariant, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingLTensorNaturality, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingSmulDual, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingSmulLeft, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TupCoordApply, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TwKerEqMapOfSurjective, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UniformLowerBoundNearInjectiveStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitaryExtensionOfBlockStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitaryFramesPreserveNormSqSumStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitaryLiftCommutingInvolutionStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedQuadraticOrderPrincipalStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ValThree, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ValuationPowerIff, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VandermondeSquares, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WallLawOfSectionLaw, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WedgeBoundFinitePlaces, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WedgeBoundInfinitePlaces, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WedgeSubspaceBound, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WeylDenominatorProduct, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WpHomotopy, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagShiftTotalLinRootPower, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.SumLogDivNSqLeTwoStatement]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

