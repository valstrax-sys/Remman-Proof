import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorusIntegralChangeOfParametrization
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TotalDegreeAevalLeOfDegLeOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TotalDegreeLeOfIntegralAtInfinity
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TraceEqSumMultMulRe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TraceMonicOverMvPolynomial
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TraceMulEqZeroImp
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslateFiniteDimMatrixCoefficient
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationIsometrySchwartzOperator
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TrdegComplexBaseChangeEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TrdegCompositumLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TruncatedMonomialsLinearIndependentOverConstants
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TsumExpNegAbsIntLtTop
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TwistOkAll
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TwistedFixedCosetDecomposition
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TwistedNormFixedDecomposition
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TwistedTraceEquivariantAndInjectiveOfGroupDet
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UltrametricRootLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnfoldIntegralFundamentalDomain
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnfoldPoincareSeriesLatticeFourier
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnfoldSumInvariantLeviConj
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnfoldingFundamentalDomainIntegral
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnfoldingIntegralCosetRepresentatives
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UniformBoundedRightInverse
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UniformDerivativeApprox
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UniformScalar
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UniformizerEqPowRamificationIdxMulUnitIntegralCl
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnimodularOfIsFundamentalDomainFinite
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnipMat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnipotentMatrixCoefficientsMem
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitBallEqOfIntegralDvr
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitLogSpanTraceZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitPowerInOrder
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitRealOfCongrOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryCocycleCoboundaryOfTrivialOnStabilisers
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryCocycleRepresentation
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryConjugateMatrixFamily
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryGroupSecondKindCoordinatesNearOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryInvariantHermitianFormSymmEqSmulTrace
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryLieAlgebraSpanned
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryLieAlgebraVectorDecomposition
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryTensorPlacesSlots
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UniversallyClosedOfClosedCoverInUniversallyClose
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnramSub
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnramifiedEmbeddingsSeparatingCombination
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UpperTriangularNearUnitDiagonalOfTwistedGramNear
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.VacFn
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValuationCloseMatricesQuotientIntegral
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValuationLeExpNegCardInertiaOfInertiaFixed
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValuationNatCastEqOneOfCoprime
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValuationRingRootOfUnityLiftReduce
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValuationUniformizerIntegralClosureEqExpNegRamif
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValueAtZeroEqSumIntegralKernelIteratedDeriv
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.VanishingOfProjectionSupport
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.VolumeHermitianEllipsoid
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeaklyConvergentSchwartzBounded
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeightAbelDecomposition
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeightSpaceIffIdempotentFixed
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeightSpaceTensorRingHomFinrankPos
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WhiskerLeftLeftIsPullbackSnd
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WirtConst
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WittVectorExistsUniqueSubMatrixFrobeniusEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ZetaTermTsumLeTwo
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.AbsIntegralSubConstMulLeOfSplit
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.AbsOpIntIntegrable

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorusIntegralChangeOfParametrization, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TotalDegreeAevalLeOfDegLeOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TotalDegreeLeOfIntegralAtInfinity, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TraceEqSumMultMulRe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TraceMonicOverMvPolynomial, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TraceMulEqZeroImp, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslateFiniteDimMatrixCoefficient, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationIsometrySchwartzOperator, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TrdegComplexBaseChangeEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TrdegCompositumLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TruncatedMonomialsLinearIndependentOverConstants, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TsumExpNegAbsIntLtTop, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TwistOkAll, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TwistedFixedCosetDecomposition, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TwistedNormFixedDecomposition, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TwistedTraceEquivariantAndInjectiveOfGroupDet, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UltrametricRootLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnfoldIntegralFundamentalDomain, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnfoldPoincareSeriesLatticeFourier, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnfoldSumInvariantLeviConj, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnfoldingFundamentalDomainIntegral, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnfoldingIntegralCosetRepresentatives, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UniformBoundedRightInverse, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UniformDerivativeApprox, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UniformScalar, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UniformizerEqPowRamificationIdxMulUnitIntegralCl, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnimodularOfIsFundamentalDomainFinite, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnipMat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnipotentMatrixCoefficientsMem, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitBallEqOfIntegralDvr, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitLogSpanTraceZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitPowerInOrder, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitRealOfCongrOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryCocycleCoboundaryOfTrivialOnStabilisers, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryCocycleRepresentation, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryConjugateMatrixFamily, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryGroupSecondKindCoordinatesNearOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryInvariantHermitianFormSymmEqSmulTrace, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryLieAlgebraSpanned, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryLieAlgebraVectorDecomposition, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryTensorPlacesSlots, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UniversallyClosedOfClosedCoverInUniversallyClose, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnramSub, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnramifiedEmbeddingsSeparatingCombination, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UpperTriangularNearUnitDiagonalOfTwistedGramNear, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.VacFn, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValuationCloseMatricesQuotientIntegral, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValuationLeExpNegCardInertiaOfInertiaFixed, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValuationNatCastEqOneOfCoprime, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValuationRingRootOfUnityLiftReduce, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValuationUniformizerIntegralClosureEqExpNegRamif, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValueAtZeroEqSumIntegralKernelIteratedDeriv, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.VanishingOfProjectionSupport, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.VolumeHermitianEllipsoid, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeaklyConvergentSchwartzBounded, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeightAbelDecomposition, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeightSpaceIffIdempotentFixed, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeightSpaceTensorRingHomFinrankPos, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WhiskerLeftLeftIsPullbackSnd, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WirtConst, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WittVectorExistsUniqueSubMatrixFrobeniusEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ZetaTermTsumLeTwo, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.AbsIntegralSubConstMulLeOfSplit, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.AbsOpIntIntegrable]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

