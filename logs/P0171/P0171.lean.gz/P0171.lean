import Lean
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.Imports
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.PlanarKernelBound
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.PolynomialGrowthIntegrals
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.SlowWeightBound
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.AntiEIsGlRep
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.CarSumSqZeroOfAnti
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.DecompA
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.Gelfand
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.KernelLemma
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.TensorV
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TraceGap.BlockAnti
import ReciprocityTheory.ReductiveGroups.LatticeEmbeddings.IotaPlace
import ReciprocityTheory.ReductiveGroups.SymplecticTraces.WeylCharacters.AntitoneOfMemInterl
import ReciprocityTheory.ReductiveGroups.SymplecticTraces.WeylCharacters.SqCharA
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.Interface
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.KurDefs
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModDefs
import ReciprocityTheory.ResidueCardinality.ArtinOntoB
import ReciprocityTheory.SemistableReduction.AeBlockSphereEvalNeZero
import ReciprocityTheory.SemistableReduction.AevalIsWeightedHomogeneous
import ReciprocityTheory.SemistableReduction.ApproxBasisA
import ReciprocityTheory.SemistableReduction.ApproxGraphA
import ReciprocityTheory.SemistableReduction.BWPolyB
import ReciprocityTheory.SemistableReduction.BWPolyC
import ReciprocityTheory.SemistableReduction.BalancedSchwarz
import ReciprocityTheory.SemistableReduction.DetSubtypeCompAssociatedProd
import ReciprocityTheory.SemistableReduction.ExistsDualDerivations
import ReciprocityTheory.SemistableReduction.ExistsTorusPointOneLeNormSum
import ReciprocityTheory.SemistableReduction.ExpTorusMeanLeL2OfLex
import ReciprocityTheory.SemistableReduction.FinrankRestrictTotalDegree
import ReciprocityTheory.SemistableReduction.GaussAbsMulOfMonomialOrder
import ReciprocityTheory.SemistableReduction.GaussValExists
import ReciprocityTheory.SemistableReduction.IntCoresA
import ReciprocityTheory.SemistableReduction.IntegralClosureRankAndResidueTrdegLe
import ReciprocityTheory.SemistableReduction.LatSemiSt
import ReciprocityTheory.SemistableReduction.LemmaH
import ReciprocityTheory.SemistableReduction.MeasurePreservingSphereMap
import ReciprocityTheory.SemistableReduction.NormValuationEqFactorization
import ReciprocityTheory.SemistableReduction.OnePolyGrowth
import ReciprocityTheory.SemistableReduction.RankEqualityHolds
import ReciprocityTheory.SemistableReduction.SJCoreB
import ReciprocityTheory.SemistableReduction.SemiDegCB
import ReciprocityTheory.SemistableReduction.SphereTorusA
import ReciprocityTheory.SemistableReduction.SphereTorusC
import ReciprocityTheory.SemistableReduction.TorsionNonvanish
import ReciprocityTheory.SemistableReduction.TorusLexA
import ReciprocityTheory.SemistableReduction.TorusLexB
import ReciprocityTheory.SemistableReduction.TorusMeanB
import ReciprocityTheory.ThetaQuasiPeriods.ThetaQuasiPeriodStatement
import ReciprocityTheory.ThetaSummability.RealCoinvariants.CoinvSubLeComap
import ReciprocityTheory.ThetaSummability.TailSumEstimates.ConeChange

open Lean Elab Command

def auditTargets : Array Name := #[`ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.Imports, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.PlanarKernelBound, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.PolynomialGrowthIntegrals, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.SlowWeightBound, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.AntiEIsGlRep, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.CarSumSqZeroOfAnti, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.DecompA, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.Gelfand, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.KernelLemma, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.TensorV, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TraceGap.BlockAnti, `ReciprocityTheory.ReductiveGroups.LatticeEmbeddings.IotaPlace, `ReciprocityTheory.ReductiveGroups.SymplecticTraces.WeylCharacters.AntitoneOfMemInterl, `ReciprocityTheory.ReductiveGroups.SymplecticTraces.WeylCharacters.SqCharA, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.Interface, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.KurDefs, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModDefs, `ReciprocityTheory.ResidueCardinality.ArtinOntoB, `ReciprocityTheory.SemistableReduction.AeBlockSphereEvalNeZero, `ReciprocityTheory.SemistableReduction.AevalIsWeightedHomogeneous, `ReciprocityTheory.SemistableReduction.ApproxBasisA, `ReciprocityTheory.SemistableReduction.ApproxGraphA, `ReciprocityTheory.SemistableReduction.BWPolyB, `ReciprocityTheory.SemistableReduction.BWPolyC, `ReciprocityTheory.SemistableReduction.BalancedSchwarz, `ReciprocityTheory.SemistableReduction.DetSubtypeCompAssociatedProd, `ReciprocityTheory.SemistableReduction.ExistsDualDerivations, `ReciprocityTheory.SemistableReduction.ExistsTorusPointOneLeNormSum, `ReciprocityTheory.SemistableReduction.ExpTorusMeanLeL2OfLex, `ReciprocityTheory.SemistableReduction.FinrankRestrictTotalDegree, `ReciprocityTheory.SemistableReduction.GaussAbsMulOfMonomialOrder, `ReciprocityTheory.SemistableReduction.GaussValExists, `ReciprocityTheory.SemistableReduction.IntCoresA, `ReciprocityTheory.SemistableReduction.IntegralClosureRankAndResidueTrdegLe, `ReciprocityTheory.SemistableReduction.LatSemiSt, `ReciprocityTheory.SemistableReduction.LemmaH, `ReciprocityTheory.SemistableReduction.MeasurePreservingSphereMap, `ReciprocityTheory.SemistableReduction.NormValuationEqFactorization, `ReciprocityTheory.SemistableReduction.OnePolyGrowth, `ReciprocityTheory.SemistableReduction.RankEqualityHolds, `ReciprocityTheory.SemistableReduction.SJCoreB, `ReciprocityTheory.SemistableReduction.SemiDegCB, `ReciprocityTheory.SemistableReduction.SphereTorusA, `ReciprocityTheory.SemistableReduction.SphereTorusC, `ReciprocityTheory.SemistableReduction.TorsionNonvanish, `ReciprocityTheory.SemistableReduction.TorusLexA, `ReciprocityTheory.SemistableReduction.TorusLexB, `ReciprocityTheory.SemistableReduction.TorusMeanB, `ReciprocityTheory.ThetaQuasiPeriods.ThetaQuasiPeriodStatement, `ReciprocityTheory.ThetaSummability.RealCoinvariants.CoinvSubLeComap, `ReciprocityTheory.ThetaSummability.TailSumEstimates.ConeChange]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

