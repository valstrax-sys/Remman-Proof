import Lean
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LogGaussNormSupportFinite
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LogIntCircle
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PKernelProjMeasurable
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PPiQuotCokerFiniteLength
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PTrdegAdjoinLe
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PTrdegBaseAlgebraic
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PZeroLocusDimH
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.RenameProdMapMul
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.SphereMeanCalc
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.SphereMeanVol
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StDominantPrimitiveFibres
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsAreaFormulaInj
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsAreaFormulaInjSet
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsAreaFormulaLocal
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsBaseChange
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChartGram
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChowDegreeClosedPoint
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsConeFibre
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsFundCycleBaseChange
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsMinimalPrimeComap
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsPrimePairMeetImage
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsPrimeQuasiFiniteSheets
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsProjDegreeChow
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsQuasiFiniteSheets
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSectionLengthSum
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PLinearFormPrime
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PMapDvdDescent
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PNormFormDvd
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PNormFormEmbeddings
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PNormFormEval
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PNormOfDividedForm
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PPrimeMapFractionRing
import GroundTheory.HeightsAndTheta.Heights.ChowForms.Statements
import GroundTheory.HeightsAndTheta.Heights.ChowForms.StatementsLocalMultOrd
import GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.DeltaIntSeries
import GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.IntSeriesInv
import GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.IntSeriesNorm
import GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.IntSeriesRing
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.CutOffNear
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.IsClosedComplexSubmanifoldIn
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.LocalParametrisation
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.NormalModelGraph
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAnalyticImplicitChart
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAnalyticSimpleRootBranch
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAreaGraphPartition
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAreaMultiplicity
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAuslanderBuchsbaumDepthLower
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PBadSetSmaller
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PBrouwerFixedPoint
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PChangeOfVariablesDegree
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PCircleArgumentPrinciple
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PCompactHolomorphicFibreFinite
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PConeScaling
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PContinuousRootHolomorphic
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PCriticalImageNull
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PExtensionQuotientLength
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFibreBound
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteCoverPuncturedPolydisc
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFlatDimFormula
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGeneralProjection
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericFibreRadical
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericFibreRadicalPrime
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericFibreTor
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericFreeness

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LogGaussNormSupportFinite, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LogIntCircle, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PKernelProjMeasurable, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PPiQuotCokerFiniteLength, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PTrdegAdjoinLe, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PTrdegBaseAlgebraic, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PZeroLocusDimH, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.RenameProdMapMul, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.SphereMeanCalc, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.SphereMeanVol, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StDominantPrimitiveFibres, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsAreaFormulaInj, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsAreaFormulaInjSet, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsAreaFormulaLocal, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsBaseChange, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChartGram, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChowDegreeClosedPoint, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsConeFibre, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsFundCycleBaseChange, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsMinimalPrimeComap, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsPrimePairMeetImage, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsPrimeQuasiFiniteSheets, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsProjDegreeChow, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsQuasiFiniteSheets, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSectionLengthSum, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PLinearFormPrime, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PMapDvdDescent, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PNormFormDvd, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PNormFormEmbeddings, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PNormFormEval, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PNormOfDividedForm, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PPrimeMapFractionRing, `GroundTheory.HeightsAndTheta.Heights.ChowForms.Statements, `GroundTheory.HeightsAndTheta.Heights.ChowForms.StatementsLocalMultOrd, `GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.DeltaIntSeries, `GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.IntSeriesInv, `GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.IntSeriesNorm, `GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.IntSeriesRing, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.CutOffNear, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.IsClosedComplexSubmanifoldIn, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.LocalParametrisation, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.NormalModelGraph, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAnalyticImplicitChart, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAnalyticSimpleRootBranch, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAreaGraphPartition, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAreaMultiplicity, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAuslanderBuchsbaumDepthLower, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PBadSetSmaller, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PBrouwerFixedPoint, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PChangeOfVariablesDegree, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PCircleArgumentPrinciple, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PCompactHolomorphicFibreFinite, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PConeScaling, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PContinuousRootHolomorphic, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PCriticalImageNull, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PExtensionQuotientLength, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFibreBound, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteCoverPuncturedPolydisc, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFlatDimFormula, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGeneralProjection, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericFibreRadical, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericFibreRadicalPrime, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericFibreTor, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericFreeness]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

