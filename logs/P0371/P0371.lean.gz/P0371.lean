import Lean
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.ThetaDistributionNonzeroAdmissible
import Development.AutomorphicSpectrum.Proofs.MetricProofs.AnalyticAtMobiusDetJacobianEqStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.FibreTwistEqUnionEmbeddings
import Development.AutomorphicSpectrum.Proofs.MetricProofs.FlagDomainUnitaryTriangular
import Development.AutomorphicSpectrum.Proofs.MetricProofs.HorizontalDivSuppTwistStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.IntegralNormSqMobDMulCompMobStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LocalUnitaryNormalFrame2x2Statement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.MixedDiscriminantCofactorExpansion
import Development.AutomorphicSpectrum.Proofs.MetricProofs.MobiusChangeOfVariablesPairStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.MobiusPairAnalyticDetJacobianEqStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.MongeAmpereChartDensityIntegral
import Development.AutomorphicSpectrum.Proofs.MetricProofs.MongeAmpereDensityDiagonalLevi
import Development.AutomorphicSpectrum.Proofs.MetricProofs.MongeAmpereIntegralCongrPotentialsStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.PolydiscPoissonReproducesHarmonicStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.RingKrullDimTwistSuccStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.SectionBoundaryClosedAndCodense
import Development.AutomorphicSpectrum.Proofs.MetricProofs.SmoothInCompatibleChartStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.TwLineSmoothConjInvariantGlueStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.TwistIsMultiHomogIdealStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.TwistIsPrimeStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.XiPotentialHessianDecomposition
import Development.AutomorphicSpectrum.PublishedTheorems.Algebra₂.FarguesExact
import Development.AutomorphicSpectrum.PublishedTheorems.Algebra₂.FarguesHodgeTate
import Development.AutomorphicSpectrum.PublishedTheorems.Algebra₂.QuotientByFiniteFlatStatement
import Development.AutomorphicSpectrum.PublishedTheorems.Algebra₂.ZarhinStatement
import Development.AutomorphicSpectrum.Statements.AlgebraStatements.HodgeTateDatumStatement
import Development.AutomorphicSpectrum.Statements.AlgebraStatements.OrdinaryCurveStatement
import Development.AutomorphicSpectrum.Statements.AlgebraStatements.TrivFlagKills
import Development.AutomorphicSpectrum.Statements.GeometryStatements.FlagModelStatement
import Development.AutomorphicSpectrum.Statements.GeometryStatements.HTChartExists
import Development.AutomorphicSpectrum.Statements.GeometryStatements.PropZ
import Development.DiscreteGroups.GlobalIrreducibility.DzGenCpt
import Development.DiscreteGroups.GlobalIrreducibility.DzGenVec
import Development.DiscreteGroups.GlobalIrreducibility.DzPinA
import Development.EtaleCohomology.DivisorCycles.CycSpecQzkPf
import Development.EtaleCohomology.DivisorCycles.FinBigCorner
import Development.EtaleCohomology.DivisorCycles.FinDegAll
import Development.EtaleCohomology.DivisorCycles.FinDenseAlg
import Development.EtaleCohomology.DivisorCycles.FinFinDense
import Development.EtaleCohomology.DivisorCycles.FinFinEmbed
import Development.EtaleCohomology.DivisorCycles.FinFinPoly
import Development.EtaleCohomology.DivisorCycles.FinFinSub
import Development.EtaleCohomology.DivisorCycles.FinKey
import Development.EtaleCohomology.DivisorCycles.FinMatUnits
import Development.EtaleCohomology.DivisorCycles.FinRep
import Development.EtaleCohomology.DivisorCycles.FinSemis
import Development.EtaleCohomology.DivisorCycles.FixScalOf
import Development.EtaleCohomology.DivisorCycles.Imports
import Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.DerivBalancedOrderLocus
import Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.OrderPullback
import Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.PartialDerivativeIdeal
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.CoordinateDivisorSmoothness
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.CoordinatePolynomialRing
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.IdealSheafOpenRestriction
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.SmoothCenterChart
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.SmoothHypersurfaceLocalCoordinates
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.StalkKrullDimension
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.StrictNormalCrossingsOpenImmersion
import Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.KrullDimClosedSubset
import Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.MarkedBlowupSequence.BlowupSequenceData
import Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.MarkedBlowupSequence.SmoothComponentsDisjoint
import Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.MonomialCase.LocallyBoundedOrder
import Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.OrderReduction.BlowupChartCongruence
import Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.OrderReductionProperties

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.MembershipProofs.ThetaDistributionNonzeroAdmissible, `Development.AutomorphicSpectrum.Proofs.MetricProofs.AnalyticAtMobiusDetJacobianEqStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.FibreTwistEqUnionEmbeddings, `Development.AutomorphicSpectrum.Proofs.MetricProofs.FlagDomainUnitaryTriangular, `Development.AutomorphicSpectrum.Proofs.MetricProofs.HorizontalDivSuppTwistStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.IntegralNormSqMobDMulCompMobStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LocalUnitaryNormalFrame2x2Statement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.MixedDiscriminantCofactorExpansion, `Development.AutomorphicSpectrum.Proofs.MetricProofs.MobiusChangeOfVariablesPairStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.MobiusPairAnalyticDetJacobianEqStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.MongeAmpereChartDensityIntegral, `Development.AutomorphicSpectrum.Proofs.MetricProofs.MongeAmpereDensityDiagonalLevi, `Development.AutomorphicSpectrum.Proofs.MetricProofs.MongeAmpereIntegralCongrPotentialsStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.PolydiscPoissonReproducesHarmonicStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.RingKrullDimTwistSuccStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.SectionBoundaryClosedAndCodense, `Development.AutomorphicSpectrum.Proofs.MetricProofs.SmoothInCompatibleChartStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.TwLineSmoothConjInvariantGlueStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.TwistIsMultiHomogIdealStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.TwistIsPrimeStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.XiPotentialHessianDecomposition, `Development.AutomorphicSpectrum.PublishedTheorems.Algebra₂.FarguesExact, `Development.AutomorphicSpectrum.PublishedTheorems.Algebra₂.FarguesHodgeTate, `Development.AutomorphicSpectrum.PublishedTheorems.Algebra₂.QuotientByFiniteFlatStatement, `Development.AutomorphicSpectrum.PublishedTheorems.Algebra₂.ZarhinStatement, `Development.AutomorphicSpectrum.Statements.AlgebraStatements.HodgeTateDatumStatement, `Development.AutomorphicSpectrum.Statements.AlgebraStatements.OrdinaryCurveStatement, `Development.AutomorphicSpectrum.Statements.AlgebraStatements.TrivFlagKills, `Development.AutomorphicSpectrum.Statements.GeometryStatements.FlagModelStatement, `Development.AutomorphicSpectrum.Statements.GeometryStatements.HTChartExists, `Development.AutomorphicSpectrum.Statements.GeometryStatements.PropZ, `Development.DiscreteGroups.GlobalIrreducibility.DzGenCpt, `Development.DiscreteGroups.GlobalIrreducibility.DzGenVec, `Development.DiscreteGroups.GlobalIrreducibility.DzPinA, `Development.EtaleCohomology.DivisorCycles.CycSpecQzkPf, `Development.EtaleCohomology.DivisorCycles.FinBigCorner, `Development.EtaleCohomology.DivisorCycles.FinDegAll, `Development.EtaleCohomology.DivisorCycles.FinDenseAlg, `Development.EtaleCohomology.DivisorCycles.FinFinDense, `Development.EtaleCohomology.DivisorCycles.FinFinEmbed, `Development.EtaleCohomology.DivisorCycles.FinFinPoly, `Development.EtaleCohomology.DivisorCycles.FinFinSub, `Development.EtaleCohomology.DivisorCycles.FinKey, `Development.EtaleCohomology.DivisorCycles.FinMatUnits, `Development.EtaleCohomology.DivisorCycles.FinRep, `Development.EtaleCohomology.DivisorCycles.FinSemis, `Development.EtaleCohomology.DivisorCycles.FixScalOf, `Development.EtaleCohomology.DivisorCycles.Imports, `Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.DerivBalancedOrderLocus, `Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.OrderPullback, `Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.PartialDerivativeIdeal, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.CoordinateDivisorSmoothness, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.CoordinatePolynomialRing, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.IdealSheafOpenRestriction, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.SmoothCenterChart, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.SmoothHypersurfaceLocalCoordinates, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.StalkKrullDimension, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.StrictNormalCrossingsOpenImmersion, `Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.KrullDimClosedSubset, `Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.MarkedBlowupSequence.BlowupSequenceData, `Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.MarkedBlowupSequence.SmoothComponentsDisjoint, `Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.MonomialCase.LocallyBoundedOrder, `Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.OrderReduction.BlowupChartCongruence, `Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.OrderReductionProperties]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

