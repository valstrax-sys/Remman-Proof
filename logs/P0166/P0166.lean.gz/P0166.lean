import Lean
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.StatementsCoinv
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.StatementsElem
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.StatementsTop
import GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.PNormCountBound
import GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.PPrimeLogSum
import GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.PowLeSqrtDetGram
import GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.RecordEigen
import GroundTheory.HeightsAndTheta.Heights.ThetaKeyFormula.ThetaThreeFamLinearIndependent
import GroundTheory.HeightsAndTheta.Heights.ThetaKeyFormula.ZeroSetFinite
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PFibreClosedComponent
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.Statements
import GroundTheory.HeightsAndTheta.Theta.CMDatum
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.CfunOmClassReducedParamsNonemptyPf
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.CfunOmEtaLogPeriodNegConjPf
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.CfunOmEtaPeriodLatticeClassPf
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.QuadraticFieldSqrtNegSeven
import GroundTheory.HeightsAndTheta.Theta.LieCoordinates.SecondKindStatements
import GroundTheory.HeightsAndTheta.Theta.SplitLinear.RankMinors
import GroundTheory.LocalFields.AbstractLocalReciprocity.ExistsEqNsmulOfProjEqZero
import GroundTheory.LocalFields.AbstractLocalReciprocity.ExistsOpenSubgroupMemFixedModule
import GroundTheory.LocalFields.BrauerInductionInduced
import GroundTheory.LocalFields.CompleteTrivial
import GroundTheory.LocalFields.ExamplesCharZero
import GroundTheory.LocalFields.ExamplesLaurent
import GroundTheory.LocalFields.FiniteExtension
import GroundTheory.LocalFields.FormalGroups.FrobeniusTwist
import GroundTheory.LocalFields.FormalGroups.Truncation
import GroundTheory.LocalFields.NormalLattice
import GroundTheory.LocalFields.Uniqueness
import GroundTheory.LocalFields.UnitsPowers
import GroundTheory.PAdicHodge.AdmissibleField
import GroundTheory.PAdicHodge.AxLemma
import GroundTheory.PAdicHodge.ExtRobbaBounded
import GroundTheory.PAdicHodge.HighIndexSingleZeroOne
import GroundTheory.PAdicHodge.KerTheta
import GroundTheory.PAdicHodge.LogMul
import GroundTheory.PAdicHodge.NormalizedTrace
import GroundTheory.PAdicHodge.NormalizedTraceClosure
import GroundTheory.PAdicHodge.PerfectoidCharP
import GroundTheory.PAdicHodge.PerfectoidCriterion
import GroundTheory.PAdicHodge.SlopeCauchyBinet
import GroundTheory.PAdicHodge.SlopePhiSub
import GroundTheory.PAdicHodge.TateCpTwist
import GroundTheory.PAdicHodge.TiltValuation
import GroundTheory.PAdicHodge.UnramifiedClosure
import GroundTheory.PAdicHodge.WittLift
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.ExistsCover
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.ExistsSmulMemHermitianLattice
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.TiltCountableNeighbourhoods
import GroundTheory.ProfiniteCohomology.CharactersDefs
import GroundTheory.ProfiniteCohomology.DiscreteModules.IsDiscreteRepIffForallExistsOpenNormalSubgroup
import GroundTheory.ProfiniteCohomology.Factor
import GroundTheory.ProfiniteCohomology.GaloisModules.Discrete
import GroundTheory.ProfiniteCohomology.GaloisModules.FixedField
import GroundTheory.ProfiniteCohomology.GlobalClassFormation.IdeleCohomology.Product
import GroundTheory.ProfiniteCohomology.InflationRestriction.Section
import GroundTheory.ProfiniteCohomology.KummerFinite
import GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.AdditiveInvariants
import GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.AdditiveSnake
import GroundTheory.ProfiniteCohomology.OfNatRelIndexSupAntitone
import GroundTheory.ProfiniteCohomology.TorsionDualFinite
import GroundTheory.TateCohomology.CupProduct
import GroundTheory.TateCohomology.HerbrandRep
import GroundTheory.TateCohomology.InducedNorm

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.RemainderTerms.StatementsCoinv, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.StatementsElem, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.StatementsTop, `GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.PNormCountBound, `GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.PPrimeLogSum, `GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.PowLeSqrtDetGram, `GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.RecordEigen, `GroundTheory.HeightsAndTheta.Heights.ThetaKeyFormula.ThetaThreeFamLinearIndependent, `GroundTheory.HeightsAndTheta.Heights.ThetaKeyFormula.ZeroSetFinite, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PFibreClosedComponent, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.Statements, `GroundTheory.HeightsAndTheta.Theta.CMDatum, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.CfunOmClassReducedParamsNonemptyPf, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.CfunOmEtaLogPeriodNegConjPf, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.CfunOmEtaPeriodLatticeClassPf, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.QuadraticFieldSqrtNegSeven, `GroundTheory.HeightsAndTheta.Theta.LieCoordinates.SecondKindStatements, `GroundTheory.HeightsAndTheta.Theta.SplitLinear.RankMinors, `GroundTheory.LocalFields.AbstractLocalReciprocity.ExistsEqNsmulOfProjEqZero, `GroundTheory.LocalFields.AbstractLocalReciprocity.ExistsOpenSubgroupMemFixedModule, `GroundTheory.LocalFields.BrauerInductionInduced, `GroundTheory.LocalFields.CompleteTrivial, `GroundTheory.LocalFields.ExamplesCharZero, `GroundTheory.LocalFields.ExamplesLaurent, `GroundTheory.LocalFields.FiniteExtension, `GroundTheory.LocalFields.FormalGroups.FrobeniusTwist, `GroundTheory.LocalFields.FormalGroups.Truncation, `GroundTheory.LocalFields.NormalLattice, `GroundTheory.LocalFields.Uniqueness, `GroundTheory.LocalFields.UnitsPowers, `GroundTheory.PAdicHodge.AdmissibleField, `GroundTheory.PAdicHodge.AxLemma, `GroundTheory.PAdicHodge.ExtRobbaBounded, `GroundTheory.PAdicHodge.HighIndexSingleZeroOne, `GroundTheory.PAdicHodge.KerTheta, `GroundTheory.PAdicHodge.LogMul, `GroundTheory.PAdicHodge.NormalizedTrace, `GroundTheory.PAdicHodge.NormalizedTraceClosure, `GroundTheory.PAdicHodge.PerfectoidCharP, `GroundTheory.PAdicHodge.PerfectoidCriterion, `GroundTheory.PAdicHodge.SlopeCauchyBinet, `GroundTheory.PAdicHodge.SlopePhiSub, `GroundTheory.PAdicHodge.TateCpTwist, `GroundTheory.PAdicHodge.TiltValuation, `GroundTheory.PAdicHodge.UnramifiedClosure, `GroundTheory.PAdicHodge.WittLift, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.ExistsCover, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.ExistsSmulMemHermitianLattice, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.TiltCountableNeighbourhoods, `GroundTheory.ProfiniteCohomology.CharactersDefs, `GroundTheory.ProfiniteCohomology.DiscreteModules.IsDiscreteRepIffForallExistsOpenNormalSubgroup, `GroundTheory.ProfiniteCohomology.Factor, `GroundTheory.ProfiniteCohomology.GaloisModules.Discrete, `GroundTheory.ProfiniteCohomology.GaloisModules.FixedField, `GroundTheory.ProfiniteCohomology.GlobalClassFormation.IdeleCohomology.Product, `GroundTheory.ProfiniteCohomology.InflationRestriction.Section, `GroundTheory.ProfiniteCohomology.KummerFinite, `GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.AdditiveInvariants, `GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.AdditiveSnake, `GroundTheory.ProfiniteCohomology.OfNatRelIndexSupAntitone, `GroundTheory.ProfiniteCohomology.TorsionDualFinite, `GroundTheory.TateCohomology.CupProduct, `GroundTheory.TateCohomology.HerbrandRep, `GroundTheory.TateCohomology.InducedNorm]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

