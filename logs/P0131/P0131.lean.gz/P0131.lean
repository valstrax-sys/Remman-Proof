import Lean
import Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.CokLen
import Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.DetFactor
import Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.Helly
import Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.Imports
import Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.ImportsBis
import Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.NilLen
import Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.NormVal
import Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.PowIn
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCotExtend
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCotOfSpan
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCplMap
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaDetAdj
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaDetChartCot
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CocycleTraceZero
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeEqDet
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.IrrOpen
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.SignLemma
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DualLattice
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.EqOneOfStrictMono
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.FiniteHomOfTopFG
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.FlagCharsUnique
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.FreeProf
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.GenExt
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HidaCompleteRings.Component
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HidaCompleteRings.ExtendPt
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HidaCompleteRings.MaxIdem
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HidaCompleteRings.OrdBasic
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HidaCompleteRings.TopLeCopiesSelf
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HkDdSpec
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HkDedekind
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HkDualEx
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.InducedAutomorphicForms.IndSymp
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.InducedAutomorphicForms.IndTwo
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.InducedAutomorphicForms.MackeyTwo
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.LagCoi
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.LagMap
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.LemmaB
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.LimElt
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.LimKer
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.LimOut
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.LocFactor
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.MonomialRepresentations.IdCompMat
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.MonomialRepresentations.RegOfDim
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.MonomialRepresentations.TwistOfRed
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.OrthonormalLocal
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.ProLUnits
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.ProdMap
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.QuotProf
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.ResMap
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.ResNormal
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.SpStep
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.StCoiLift
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.SubgroupQuot
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.TnAlgMapSmulMem
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.TrinvBaseChange
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.UltraDefs
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.UltraFin
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.UnitsBasic
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.UnitsExist
import Development.AutomorphicArithmetic.AutomorphicVarieties.BuildingsResidueChars.ExistsValuationExtensionIntegral
import Development.AutomorphicArithmetic.AutomorphicVarieties.CommutativeAlgebra.Carver
import Development.AutomorphicArithmetic.AutomorphicVarieties.CommutativeAlgebra.CoEvLow
import Development.AutomorphicArithmetic.AutomorphicVarieties.CommutativeAlgebra.CoExt
import Development.AutomorphicArithmetic.AutomorphicVarieties.CommutativeAlgebra.CoFinite

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.CokLen, `Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.DetFactor, `Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.Helly, `Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.Imports, `Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.ImportsBis, `Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.NilLen, `Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.NormVal, `Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.PowIn, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCotExtend, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCotOfSpan, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCplMap, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaDetAdj, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaDetChartCot, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CocycleTraceZero, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeEqDet, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.IrrOpen, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.SignLemma, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DualLattice, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.EqOneOfStrictMono, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.FiniteHomOfTopFG, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.FlagCharsUnique, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.FreeProf, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.GenExt, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HidaCompleteRings.Component, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HidaCompleteRings.ExtendPt, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HidaCompleteRings.MaxIdem, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HidaCompleteRings.OrdBasic, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HidaCompleteRings.TopLeCopiesSelf, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HkDdSpec, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HkDedekind, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.HkDualEx, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.InducedAutomorphicForms.IndSymp, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.InducedAutomorphicForms.IndTwo, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.InducedAutomorphicForms.MackeyTwo, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.LagCoi, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.LagMap, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.LemmaB, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.LimElt, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.LimKer, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.LimOut, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.LocFactor, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.MonomialRepresentations.IdCompMat, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.MonomialRepresentations.RegOfDim, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.MonomialRepresentations.TwistOfRed, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.OrthonormalLocal, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.ProLUnits, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.ProdMap, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.QuotProf, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.ResMap, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.ResNormal, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.SpStep, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.StCoiLift, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.SubgroupQuot, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.TnAlgMapSmulMem, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.TrinvBaseChange, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.UltraDefs, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.UltraFin, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.UnitsBasic, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.UnitsExist, `Development.AutomorphicArithmetic.AutomorphicVarieties.BuildingsResidueChars.ExistsValuationExtensionIntegral, `Development.AutomorphicArithmetic.AutomorphicVarieties.CommutativeAlgebra.Carver, `Development.AutomorphicArithmetic.AutomorphicVarieties.CommutativeAlgebra.CoEvLow, `Development.AutomorphicArithmetic.AutomorphicVarieties.CommutativeAlgebra.CoExt, `Development.AutomorphicArithmetic.AutomorphicVarieties.CommutativeAlgebra.CoFinite]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

