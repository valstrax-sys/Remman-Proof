import Lean
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardDivisorsSqLeTwoMulStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardPreimageHom
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CartanDecompositionLieAlgebraStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CellFormulaOfInvM
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CellSumOfCntBasic
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CentralizerRegularCommutesStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CntBasicOfKerBasic
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CoarseLipschitzExponentialEstimate
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CoeFnSumAe
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CofaceRel
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ColOp
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ColSqOfKerBasic
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ComapMulVecCompactOpenStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CommutantAnnihilatingVectorZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CommutatorCoerciveOnAnnihilator
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CommutingHermitianSimultaneousDiag
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CompInsertNthEq
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CompKey
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CompactScaledIntoNhdsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ComparableQuotientOfValuation
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CompletionComplete
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousBlkM
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousIteratedDerivHolomorphicFamilyStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousSeminormDiffSLe
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousSmulQuot
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContourShiftParametrisedIntegral
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContourShiftTubeDomainStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CorrESymmCoe
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetSeriesSummableShifted
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetSumTranslateInvariantStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CountLeOfDvd
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CovOfAlgHom
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DWedgeExists
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DensityOfFourierPairingIntegrable
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DerivationCommutesWithTraceStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DetSqNormEqHermitianBlockFormulaStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DifferentiableAffLine
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DifferentiableOnLaplaceIntegralRightHalfStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DirectedSystemTrR
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DividedPowerIdealTorsionFree
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DividedPowerMorphismCompatible
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DividedPowerStructureExists
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DivisibilityChainPowerFactorization
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EigenvectorLiftOfSurjectionStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EqCOfToLaurentEqInvert
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EventuallyHaarDetEqOneNearOne
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsBumpWithNonzeroIntegralStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCompactOpenSubgroupMemStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsContinuousSectionQuotient
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCosetRepsOpenInCompactStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsDependentColumn
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsFiniteCosetRepresentativesStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsFiniteSupport
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsGLLastBasisVecMulEqStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsGLVecMulEqLastBasisStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsGlGD
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsIsWP
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsJointEigenvectorNonzeroStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsMaximalAbelianHermitianStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsOpenCompactLatticeContainingStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsOrderedForm
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsPQ
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsRealizationOfCompatible
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsRegularElementAbelianStatement

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardDivisorsSqLeTwoMulStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardPreimageHom, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CartanDecompositionLieAlgebraStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CellFormulaOfInvM, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CellSumOfCntBasic, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CentralizerRegularCommutesStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CntBasicOfKerBasic, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CoarseLipschitzExponentialEstimate, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CoeFnSumAe, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CofaceRel, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ColOp, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ColSqOfKerBasic, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ComapMulVecCompactOpenStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CommutantAnnihilatingVectorZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CommutatorCoerciveOnAnnihilator, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CommutingHermitianSimultaneousDiag, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CompInsertNthEq, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CompKey, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CompactScaledIntoNhdsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ComparableQuotientOfValuation, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CompletionComplete, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousBlkM, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousIteratedDerivHolomorphicFamilyStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousSeminormDiffSLe, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousSmulQuot, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContourShiftParametrisedIntegral, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContourShiftTubeDomainStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CorrESymmCoe, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetSeriesSummableShifted, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetSumTranslateInvariantStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CountLeOfDvd, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CovOfAlgHom, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DWedgeExists, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DensityOfFourierPairingIntegrable, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DerivationCommutesWithTraceStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DetSqNormEqHermitianBlockFormulaStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DifferentiableAffLine, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DifferentiableOnLaplaceIntegralRightHalfStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DirectedSystemTrR, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DividedPowerIdealTorsionFree, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DividedPowerMorphismCompatible, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DividedPowerStructureExists, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DivisibilityChainPowerFactorization, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EigenvectorLiftOfSurjectionStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EqCOfToLaurentEqInvert, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EventuallyHaarDetEqOneNearOne, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsBumpWithNonzeroIntegralStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCompactOpenSubgroupMemStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsContinuousSectionQuotient, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCosetRepsOpenInCompactStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsDependentColumn, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsFiniteCosetRepresentativesStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsFiniteSupport, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsGLLastBasisVecMulEqStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsGLVecMulEqLastBasisStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsGlGD, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsIsWP, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsJointEigenvectorNonzeroStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsMaximalAbelianHermitianStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsOpenCompactLatticeContainingStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsOrderedForm, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsPQ, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsRealizationOfCompatible, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsRegularElementAbelianStatement]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

