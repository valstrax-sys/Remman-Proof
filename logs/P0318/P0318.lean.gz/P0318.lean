import Lean
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsValueBasis
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HaarConstOfHaarExists
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SphericalZetaCosets
import Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.Action
import Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.Coefficients
import Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.CrisTheta
import Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.DeRhamLog
import Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.Period
import Development.AutomorphicArithmetic.LocalEmbeddings.ArchSz
import Development.AutomorphicArithmetic.OrbitLabellings.ExistsNonnegDualFnumSubLeOfDemandNearMul
import Development.AutomorphicArithmetic.QuadraticCharacters.FieldOf
import Development.AutomorphicArithmetic.ResidueCharacters.FiniteRoots
import Development.AutomorphicArithmetic.ShortNorms.ShortNorm
import Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.Abstract
import Development.AutomorphicArithmetic.ThickFrames.SharesOfCounts
import Development.AutomorphicArithmetic.ThickFrames.expectationSpec
import Development.AutomorphicArithmetic.ThickFrames.orbitSum
import Development.AutomorphicArithmetic.ThickFrames.select
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.CoeffSyGauge
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.IsCompactUnitaryPointsAtPlaceFstMemCompact
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.IsFinFlatSub
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.TrivFlagMod
import Development.AutomorphicSpectrum.Definitions.DivisibilityTowers.BundleChernComparison
import Development.AutomorphicSpectrum.Definitions.DivisibilityTowers.Proportional
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.GlueApplyOfNotInFibre
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.IsHTFormOver
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.LevelSectionsExactKernelLocusOpen
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.LocalComponentsSurjective
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.NotIsGenericFlagSelf
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.UnitAtOfIsLineGenOn
import Development.AutomorphicSpectrum.Definitions.MetricPeriods.HasMultiplier
import Development.AutomorphicSpectrum.Definitions.MetricPeriods.SimilitudeFactorFormGroupBoundedOfTestSupport
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.ExistsExtensionEmbeddingAlgClosedStatement
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.IdealNormPrincipalInExtensionStatement
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.LogIdealMulSpanMap
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.LogIdealSupportFinite
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.LogNormsExtDegreeAdelic
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.LogNormsOfNonzeroAdelicStatement
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.PadicEmbeddingDiscreteValuationRingStatement
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.PadicLogIdealMaxElement
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.RatProductFormula
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.SumEmbeddingsBaseChange
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.CharacterIdealPrincipalEigen
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DifferentGeneratorDualIntegralStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DualFamilyIsBasisStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DualLatticeDegreeNegStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsTotallyRealEvenNegPlacesLocalNorm
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FrobeniusLatticeDegreeMulPStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderInductionId
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderInductionInjectiveStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderScalarExtension
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.IdealDescendingOneDimQuotientStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.IntegralClosurePlaceRingsDataStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.KernelGraphBaseChangeHoldsStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeBaseChangeQuotientStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeBaseChangeSummandStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeOfShortExactStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeSummandCriterionStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeTestPointMembership
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyOfFinitePresentationOfCancelStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ModuleBasisLatticeBundleFreeStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ModuleFlatOfFlatAndFibreFlatStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.NegDefBlockOfPosDef
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SubAndQuotientBundlesStatement

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsValueBasis, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HaarConstOfHaarExists, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SphericalZetaCosets, `Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.Action, `Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.Coefficients, `Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.CrisTheta, `Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.DeRhamLog, `Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.Period, `Development.AutomorphicArithmetic.LocalEmbeddings.ArchSz, `Development.AutomorphicArithmetic.OrbitLabellings.ExistsNonnegDualFnumSubLeOfDemandNearMul, `Development.AutomorphicArithmetic.QuadraticCharacters.FieldOf, `Development.AutomorphicArithmetic.ResidueCharacters.FiniteRoots, `Development.AutomorphicArithmetic.ShortNorms.ShortNorm, `Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.Abstract, `Development.AutomorphicArithmetic.ThickFrames.SharesOfCounts, `Development.AutomorphicArithmetic.ThickFrames.expectationSpec, `Development.AutomorphicArithmetic.ThickFrames.orbitSum, `Development.AutomorphicArithmetic.ThickFrames.select, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.CoeffSyGauge, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.IsCompactUnitaryPointsAtPlaceFstMemCompact, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.IsFinFlatSub, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.TrivFlagMod, `Development.AutomorphicSpectrum.Definitions.DivisibilityTowers.BundleChernComparison, `Development.AutomorphicSpectrum.Definitions.DivisibilityTowers.Proportional, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.GlueApplyOfNotInFibre, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.IsHTFormOver, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.LevelSectionsExactKernelLocusOpen, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.LocalComponentsSurjective, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.NotIsGenericFlagSelf, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.UnitAtOfIsLineGenOn, `Development.AutomorphicSpectrum.Definitions.MetricPeriods.HasMultiplier, `Development.AutomorphicSpectrum.Definitions.MetricPeriods.SimilitudeFactorFormGroupBoundedOfTestSupport, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.ExistsExtensionEmbeddingAlgClosedStatement, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.IdealNormPrincipalInExtensionStatement, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.LogIdealMulSpanMap, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.LogIdealSupportFinite, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.LogNormsExtDegreeAdelic, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.LogNormsOfNonzeroAdelicStatement, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.PadicEmbeddingDiscreteValuationRingStatement, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.PadicLogIdealMaxElement, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.RatProductFormula, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.SumEmbeddingsBaseChange, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.CharacterIdealPrincipalEigen, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DifferentGeneratorDualIntegralStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DualFamilyIsBasisStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DualLatticeDegreeNegStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsTotallyRealEvenNegPlacesLocalNorm, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FrobeniusLatticeDegreeMulPStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderInductionId, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderInductionInjectiveStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderScalarExtension, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.IdealDescendingOneDimQuotientStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.IntegralClosurePlaceRingsDataStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.KernelGraphBaseChangeHoldsStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeBaseChangeQuotientStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeBaseChangeSummandStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeOfShortExactStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeSummandCriterionStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeTestPointMembership, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyOfFinitePresentationOfCancelStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ModuleBasisLatticeBundleFreeStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ModuleFlatOfFlatAndFibreFlatStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.NegDefBlockOfPosDef, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SubAndQuotientBundlesStatement]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

