import Lean
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AbEval
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AbsolutelyIrreducibleSpan
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AddGapLe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AddPowNsmul
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AdjoinForm
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AdjoinSqrtEqRatSpan
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AdmissibleSchurLemma
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AdmissibleSmoothRepresentations
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AeFundamentalDomain
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AeTranslateEq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalComm
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalEig
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalInter
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalInterAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalIntertwining
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalMemInvariantSubmodule
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalMulHomog
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalMulOfIsHomogeneous
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AgreeOfAdjoin
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AlgebraSmulCommClassComplex
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AlgebraicPointIntegral
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AlternatingSumZero
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AntidiagonalConjugation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AntidiagonalTranspose
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ArithmeticCylinders
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Artin
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AuxiliaryNormPrimes
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BallRing
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BallSubgroup
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BiHomSum
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BlkB
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BlockConjugation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BlockDiagonalLeviEmbedding
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BlockFourMatrices
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BlockHomomorphism
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BorelApproximation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BoxBounds
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BurnsideEnd
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaA
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaB
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaC
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaD
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaE
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaH
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaI
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaJ
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaK
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaL
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaM
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaN
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaO
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.GeneralBFact
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.GeneralBFactAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.GeneralBFactThird
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.ProductIdentities
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CardCount
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CardEmbeddingsRestrict
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CardFiber
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CardLe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CardPow
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CardQuotPow
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CardinalityOfBand
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CasimirElement
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CayleyForm

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AbEval, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AbsolutelyIrreducibleSpan, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AddGapLe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AddPowNsmul, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AdjoinForm, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AdjoinSqrtEqRatSpan, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AdmissibleSchurLemma, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AdmissibleSmoothRepresentations, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AeFundamentalDomain, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AeTranslateEq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalComm, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalEig, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalInter, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalInterAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalIntertwining, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalMemInvariantSubmodule, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalMulHomog, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AevalMulOfIsHomogeneous, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AgreeOfAdjoin, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AlgebraSmulCommClassComplex, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AlgebraicPointIntegral, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AlternatingSumZero, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AntidiagonalConjugation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AntidiagonalTranspose, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ArithmeticCylinders, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Artin, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AuxiliaryNormPrimes, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BallRing, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BallSubgroup, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BiHomSum, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BlkB, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BlockConjugation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BlockDiagonalLeviEmbedding, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BlockFourMatrices, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BlockHomomorphism, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BorelApproximation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BoxBounds, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BurnsideEnd, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaA, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaB, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaC, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaD, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaE, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaH, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaI, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaJ, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaK, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaL, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaM, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaN, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaO, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.GeneralBFact, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.GeneralBFactAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.GeneralBFactThird, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.ProductIdentities, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CardCount, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CardEmbeddingsRestrict, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CardFiber, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CardLe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CardPow, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CardQuotPow, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CardinalityOfBand, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CasimirElement, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CayleyForm]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

