import Lean
import Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.InertiaGaloisSymmetry.RdBound
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.EulerAdditivityDegreeZero
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.EulerAdditivityExactSequence
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.EulerAdditivityInSection
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.EulerIndependenceOfOrder
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleDev
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleFin
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleGr
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleIso
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleNzd
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleShift
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.VanishingBelowDimensionRule
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.ScaledValuations.ValuationApplyLtOneIff
import Formalism.SizeWindowBrackets.ChainSlopeWindows.IntersectionFailsForSubmodule
import Formalism.SizeWindowBrackets.ChainSlopeWindows.TraceConjTransposeMulSelf
import Formalism.SizeWindowBrackets.ChainSlopeWindows.WeightedMeanLemmaNeedsDegree
import Formalism.SizeWindowBrackets.ChainSlopeWindows.WeightedSlopeExcessDecomposition
import Formalism.SizeWindowBrackets.QuotientSlopeBoundsWith
import Formalism.SizeWindowBrackets.SlopeExcessBoundExponentZero
import Formalism.SmithDeterminants.DefsDVR
import Formalism.SmithDeterminants.DefsGram
import Formalism.SobolevGaussianKernels.GaussianKernelBounds.EichlerEquivalenceHolds
import Formalism.SobolevGaussianKernels.GaussianKernelBounds.HasDerivAtSphereChartLast
import Formalism.SobolevGaussianKernels.GaussianKernelBounds.LfProd
import Formalism.SobolevGaussianKernels.StatementFU
import Formalism.StatementOC
import Formalism.SubspaceCounting.DetQuotVal
import Formalism.SubspaceCounting.StatementC
import Formalism.SubspaceCounting.StatementD
import Formalism.SubspaceCounting.SubspaceCountingProofs.CramerCofactor
import Formalism.SubspaceCounting.SubspaceCountingProofs.DetDivides
import Formalism.SubspaceCounting.SubspaceCountingProofs.DetVal
import Formalism.SubspaceCounting.SubspaceCountingProofs.LengthLayers
import Formalism.SubspaceCounting.SubspaceCountingProofs.QVandermonde
import Formalism.SubspaceCounting.SubspaceCountingProofs.SaturatedMember
import Formalism.SubspaceCounting.SubspaceCountingProofs.SubspaceCount
import Formalism.SubspaceCounting.SubspaceCountingProofs.TailConcavity
import Formalism.SubspaceCounting.SubspaceCountingProofs.WalkSharp
import Formalism.SubspaceCounting.TopsChoiceSecondBound
import Formalism.SuccessiveMinima.DefsMink
import Formalism.SuccessiveMinima.DefsNP
import Formalism.SuccessiveMinima.SuccessiveMinimaProofs.NewtonSlope
import Formalism.TameInertiaTowers.CentralOrderTwo.Groups
import Formalism.TameInertiaTowers.CentralOrderTwo.MemDecompositionSubgroupIff
import Formalism.TameInertiaTowers.CentralOrderTwo.TwoAdic
import Formalism.TameInertiaTowers.InvLength
import Formalism.TameInertiaTowers.StatementField
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.DefsMod
import Formalism.ThetaLogCoordinates.JacobiPathWeights.LiftWord
import Formalism.ThetaLogCoordinates.JacobiPathWeights.StatementB
import Formalism.ThetaLogCoordinates.JacobiPathWeights.StatementE
import Formalism.ThetaLogCoordinates.ProductIdealMonotone.ProductIdealProofs.LePowOddOfFloorLogbLe
import Formalism.ThetaLogCoordinates.ResidueClassEstimates.StatementT
import Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.AdmissibleSmallRatio
import Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.LDigits
import Formalism.ThetaLogCoordinates.TraceIsometryWeights.StatementA
import Formalism.ThetaLogCoordinates.UniformThetaSubstitution.StatementC
import Formalism.ThetaSupremumBounds.StatementA
import Formalism.ThetaSupremumBounds.StatementB
import Formalism.ThetaSupremumBounds.StatementC
import Formalism.TowerValuationBounds.TowerValuationProofs.SumAdditiveCharacterEqZero
import Formalism.TranslateCocycles.TranslateCocycleProofs.HcBlockSumBounds
import Formalism.TranslateCocycles.TranslateCocycleProofs.TranslateScale
import Formalism.TruncatedSeriesCounting.RamifiedValuationInequality

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.InertiaGaloisSymmetry.RdBound, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.EulerAdditivityDegreeZero, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.EulerAdditivityExactSequence, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.EulerAdditivityInSection, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.EulerIndependenceOfOrder, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleDev, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleFin, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleGr, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleIso, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleNzd, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleShift, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.VanishingBelowDimensionRule, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.ScaledValuations.ValuationApplyLtOneIff, `Formalism.SizeWindowBrackets.ChainSlopeWindows.IntersectionFailsForSubmodule, `Formalism.SizeWindowBrackets.ChainSlopeWindows.TraceConjTransposeMulSelf, `Formalism.SizeWindowBrackets.ChainSlopeWindows.WeightedMeanLemmaNeedsDegree, `Formalism.SizeWindowBrackets.ChainSlopeWindows.WeightedSlopeExcessDecomposition, `Formalism.SizeWindowBrackets.QuotientSlopeBoundsWith, `Formalism.SizeWindowBrackets.SlopeExcessBoundExponentZero, `Formalism.SmithDeterminants.DefsDVR, `Formalism.SmithDeterminants.DefsGram, `Formalism.SobolevGaussianKernels.GaussianKernelBounds.EichlerEquivalenceHolds, `Formalism.SobolevGaussianKernels.GaussianKernelBounds.HasDerivAtSphereChartLast, `Formalism.SobolevGaussianKernels.GaussianKernelBounds.LfProd, `Formalism.SobolevGaussianKernels.StatementFU, `Formalism.StatementOC, `Formalism.SubspaceCounting.DetQuotVal, `Formalism.SubspaceCounting.StatementC, `Formalism.SubspaceCounting.StatementD, `Formalism.SubspaceCounting.SubspaceCountingProofs.CramerCofactor, `Formalism.SubspaceCounting.SubspaceCountingProofs.DetDivides, `Formalism.SubspaceCounting.SubspaceCountingProofs.DetVal, `Formalism.SubspaceCounting.SubspaceCountingProofs.LengthLayers, `Formalism.SubspaceCounting.SubspaceCountingProofs.QVandermonde, `Formalism.SubspaceCounting.SubspaceCountingProofs.SaturatedMember, `Formalism.SubspaceCounting.SubspaceCountingProofs.SubspaceCount, `Formalism.SubspaceCounting.SubspaceCountingProofs.TailConcavity, `Formalism.SubspaceCounting.SubspaceCountingProofs.WalkSharp, `Formalism.SubspaceCounting.TopsChoiceSecondBound, `Formalism.SuccessiveMinima.DefsMink, `Formalism.SuccessiveMinima.DefsNP, `Formalism.SuccessiveMinima.SuccessiveMinimaProofs.NewtonSlope, `Formalism.TameInertiaTowers.CentralOrderTwo.Groups, `Formalism.TameInertiaTowers.CentralOrderTwo.MemDecompositionSubgroupIff, `Formalism.TameInertiaTowers.CentralOrderTwo.TwoAdic, `Formalism.TameInertiaTowers.InvLength, `Formalism.TameInertiaTowers.StatementField, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.DefsMod, `Formalism.ThetaLogCoordinates.JacobiPathWeights.LiftWord, `Formalism.ThetaLogCoordinates.JacobiPathWeights.StatementB, `Formalism.ThetaLogCoordinates.JacobiPathWeights.StatementE, `Formalism.ThetaLogCoordinates.ProductIdealMonotone.ProductIdealProofs.LePowOddOfFloorLogbLe, `Formalism.ThetaLogCoordinates.ResidueClassEstimates.StatementT, `Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.AdmissibleSmallRatio, `Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.LDigits, `Formalism.ThetaLogCoordinates.TraceIsometryWeights.StatementA, `Formalism.ThetaLogCoordinates.UniformThetaSubstitution.StatementC, `Formalism.ThetaSupremumBounds.StatementA, `Formalism.ThetaSupremumBounds.StatementB, `Formalism.ThetaSupremumBounds.StatementC, `Formalism.TowerValuationBounds.TowerValuationProofs.SumAdditiveCharacterEqZero, `Formalism.TranslateCocycles.TranslateCocycleProofs.HcBlockSumBounds, `Formalism.TranslateCocycles.TranslateCocycleProofs.TranslateScale, `Formalism.TruncatedSeriesCounting.RamifiedValuationInequality]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

