import Lean
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PAssociatedMultiHomogPrime
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PBlockAdjoinPrime
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PColonMultiHomog
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PConservationOfNumber
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PCutByForm
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PCutPieces
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PDegLTClosure
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PDegLTEventuallyConst
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PDegLTOfUnitSteps
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PDiffStepExpansion
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PDimStrictDrop
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PEventualValueFacts
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PFiltrationStepHilb
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PFiltrationStepLength
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PGenericDimGe
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PGenericPieceRank
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PGradedPieceFree
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PGradedPieceQuot
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PHilbDegBound
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PHilbFnCut
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PHilbFnVanishBlock
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PIntNumAssoc
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PIntNumOfFiltration
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PIntNumVanish
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PMixedDiffLinear
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PMultAtPrimeAtMinimal
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PMultiHomogPrimeCriterion
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PPrimeFiltration
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PRelevantDimGe
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialCycleEval
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialDimBound
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialIdealCorresp
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialIdealMultiHomog
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialIdealSurj
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialMultAt
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialPieceRank
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PTopDimMinimal
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsComponentDim
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsFibreVar
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PShare
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PDifferentNormsX
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.StFrameGraphGeneric
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.StFrameJacobianGeneric
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.StFramePlaneGraph
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.AddBlockVarEquivFst
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.HilbEventuallyPolyQualified
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.HomFracDegZeroEqFunField
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PCutRational
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PExistsForm
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PGradedFinite
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PIntNumAdd
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PIntNumSymm
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PIntNumZeroSlot
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PMixedDiffConst
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PNoetherIntegralClosure
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PPFContractedDim
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PPolyOfDiffs
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PPrimeFiltration
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsAddBlock
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsExamples
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsRename
import GroundTheory.HeightsAndTheta.Heights.FinrankFibreAtOfIsInvertibleSheaf
import GroundTheory.HeightsAndTheta.Heights.HeightComparison.IsMultiHomogIdealIff
import GroundTheory.HeightsAndTheta.Heights.HeightComparison.PPlacesRingQuot

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PAssociatedMultiHomogPrime, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PBlockAdjoinPrime, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PColonMultiHomog, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PConservationOfNumber, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PCutByForm, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PCutPieces, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PDegLTClosure, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PDegLTEventuallyConst, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PDegLTOfUnitSteps, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PDiffStepExpansion, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PDimStrictDrop, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PEventualValueFacts, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PFiltrationStepHilb, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PFiltrationStepLength, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PGenericDimGe, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PGenericPieceRank, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PGradedPieceFree, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PGradedPieceQuot, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PHilbDegBound, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PHilbFnCut, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PHilbFnVanishBlock, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PIntNumAssoc, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PIntNumOfFiltration, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PIntNumVanish, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PMixedDiffLinear, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PMultAtPrimeAtMinimal, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PMultiHomogPrimeCriterion, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PPrimeFiltration, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PRelevantDimGe, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialCycleEval, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialDimBound, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialIdealCorresp, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialIdealMultiHomog, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialIdealSurj, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialMultAt, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialPieceRank, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PTopDimMinimal, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsComponentDim, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsFibreVar, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PShare, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PDifferentNormsX, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.StFrameGraphGeneric, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.StFrameJacobianGeneric, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.StFramePlaneGraph, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.AddBlockVarEquivFst, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.HilbEventuallyPolyQualified, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.HomFracDegZeroEqFunField, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PCutRational, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PExistsForm, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PGradedFinite, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PIntNumAdd, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PIntNumSymm, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PIntNumZeroSlot, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PMixedDiffConst, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PNoetherIntegralClosure, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PPFContractedDim, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PPolyOfDiffs, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PPrimeFiltration, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsAddBlock, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsExamples, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsRename, `GroundTheory.HeightsAndTheta.Heights.FinrankFibreAtOfIsInvertibleSheaf, `GroundTheory.HeightsAndTheta.Heights.HeightComparison.IsMultiHomogIdealIff, `GroundTheory.HeightsAndTheta.Heights.HeightComparison.PPlacesRingQuot]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

