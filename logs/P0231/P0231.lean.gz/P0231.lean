import Lean
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PHomogeneousComponentMul
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PHookCharacterSumIdentity
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PHookSumBound
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.POtherFactorBound
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestBound
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestInnerTsumBound
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestKSumBound
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestPolynomialDecomposes
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestPolynomialHomogeneous
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestPolynomialHomogeneousDecomposition
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestPrimeBound
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestPrimeBoundOfFactor
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSameFactorBound
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchurSignCoefficient
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PShiftSumRule
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PVandermondeOfHomogeneous
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PrimeWeightEqZeroOfLt
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.StatementsFlag
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.StatementsSchur
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.VandermondeEqVandermondeOf
import GroundTheory.HeightsAndTheta.Heights.Slopes.StatementsSupInf
import GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.PDifferentExtNorm
import GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.StPshLocal
import GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.WeightedScaling
import GroundTheory.HeightsAndTheta.Heights.ThetaKeyFormula.RigSymFormTauIIsBasisOf
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.IntToFracInjective
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PChartTorsion
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PIncidenceNull
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PLengthDecomp
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PNormFormEval
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PNormLength
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PPrimitiveUnit
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.StatementsOrd
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.StatementsSpecFirst
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.DedekindZetaSeries.SummableDedekindZetaTerm
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.CfunOmClassPeriodInvConj
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.HsInnerSelfEqSumSq
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.RealEisensteinNonneg
import GroundTheory.HeightsAndTheta.Theta.GaussianExample
import GroundTheory.HeightsAndTheta.Theta.Signature
import GroundTheory.LocalFields.AbstractLocalReciprocity.UniqueQuotientSubgroupOfSelf
import GroundTheory.LocalFields.BrauerInductionClifford
import GroundTheory.LocalFields.BrauerInductionIntegral
import GroundTheory.LocalFields.CompleteTrivialLocal
import GroundTheory.LocalFields.ExistsUnitFiltrationUnitsLeAndRangePowLe
import GroundTheory.LocalFields.FormalGroups.Inverse
import GroundTheory.LocalFields.HerbrandCyclic
import GroundTheory.LocalFields.HilbertCyclic
import GroundTheory.LocalFields.Integers
import GroundTheory.LocalFields.IntermediateField
import GroundTheory.LocalFields.LocalAxiomTransport
import GroundTheory.LocalFields.UnitsGalois
import GroundTheory.PAdicHodge.CyclotomicField
import GroundTheory.PAdicHodge.ExtRobbaCohen
import GroundTheory.PAdicHodge.ExtRobbaFrob
import GroundTheory.PAdicHodge.ExtRobbaLimit
import GroundTheory.PAdicHodge.KerFontaineThetaCompFrobeniusEquivSymmPow
import GroundTheory.PAdicHodge.RobbaBounded
import GroundTheory.PAdicHodge.SenTateCharClosure
import GroundTheory.PAdicHodge.ThetaPlus
import GroundTheory.PAdicHodge.TiltField
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.PSectionBoundedCountable
import GroundTheory.ProfiniteCohomology.BridgeDefs
import GroundTheory.ProfiniteCohomology.CoinducedModules

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PHomogeneousComponentMul, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PHookCharacterSumIdentity, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PHookSumBound, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.POtherFactorBound, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestBound, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestInnerTsumBound, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestKSumBound, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestPolynomialDecomposes, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestPolynomialHomogeneous, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestPolynomialHomogeneousDecomposition, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestPrimeBound, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestPrimeBoundOfFactor, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSameFactorBound, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchurSignCoefficient, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PShiftSumRule, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PVandermondeOfHomogeneous, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PrimeWeightEqZeroOfLt, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.StatementsFlag, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.StatementsSchur, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.VandermondeEqVandermondeOf, `GroundTheory.HeightsAndTheta.Heights.Slopes.StatementsSupInf, `GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.PDifferentExtNorm, `GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.StPshLocal, `GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.WeightedScaling, `GroundTheory.HeightsAndTheta.Heights.ThetaKeyFormula.RigSymFormTauIIsBasisOf, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.IntToFracInjective, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PChartTorsion, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PIncidenceNull, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PLengthDecomp, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PNormFormEval, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PNormLength, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PPrimitiveUnit, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.StatementsOrd, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.StatementsSpecFirst, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.DedekindZetaSeries.SummableDedekindZetaTerm, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.CfunOmClassPeriodInvConj, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.HsInnerSelfEqSumSq, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.RealEisensteinNonneg, `GroundTheory.HeightsAndTheta.Theta.GaussianExample, `GroundTheory.HeightsAndTheta.Theta.Signature, `GroundTheory.LocalFields.AbstractLocalReciprocity.UniqueQuotientSubgroupOfSelf, `GroundTheory.LocalFields.BrauerInductionClifford, `GroundTheory.LocalFields.BrauerInductionIntegral, `GroundTheory.LocalFields.CompleteTrivialLocal, `GroundTheory.LocalFields.ExistsUnitFiltrationUnitsLeAndRangePowLe, `GroundTheory.LocalFields.FormalGroups.Inverse, `GroundTheory.LocalFields.HerbrandCyclic, `GroundTheory.LocalFields.HilbertCyclic, `GroundTheory.LocalFields.Integers, `GroundTheory.LocalFields.IntermediateField, `GroundTheory.LocalFields.LocalAxiomTransport, `GroundTheory.LocalFields.UnitsGalois, `GroundTheory.PAdicHodge.CyclotomicField, `GroundTheory.PAdicHodge.ExtRobbaCohen, `GroundTheory.PAdicHodge.ExtRobbaFrob, `GroundTheory.PAdicHodge.ExtRobbaLimit, `GroundTheory.PAdicHodge.KerFontaineThetaCompFrobeniusEquivSymmPow, `GroundTheory.PAdicHodge.RobbaBounded, `GroundTheory.PAdicHodge.SenTateCharClosure, `GroundTheory.PAdicHodge.ThetaPlus, `GroundTheory.PAdicHodge.TiltField, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.PSectionBoundedCountable, `GroundTheory.ProfiniteCohomology.BridgeDefs, `GroundTheory.ProfiniteCohomology.CoinducedModules]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

