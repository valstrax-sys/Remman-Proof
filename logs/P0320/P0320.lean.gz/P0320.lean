import Lean
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MeasurableZeroCountStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MemPowSmulTopIff
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicityReductionDiagonalProd
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NewtonApproximationLocalToGlobalStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormInvGammaLeReflect
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormThetaMul
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicLawOfBlockDetStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionOffDiagonalIdentityStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionSquareIdentityStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialIntegralMemSchwartzBruhatStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PerfectTensorGeneratedLift
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProjMemFixedPiN
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzBruhatProdSpanTensorsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzQuadraticPhaseMultiplicationStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShuffleWeightAntisymmetricEqStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SiegelInductionFromGalleryStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SigmaCompactDisjointRefinementStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SubquotientOfEigencharacter
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SumHyperplanesComplementFlags
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorPunitEqZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TruncSum
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TubeTransformHorizontalInvariance
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TubeTransformVerticalInvariance
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TwistedIwahoriContractionHolds
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnimodularHaarRightInvariantStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnipotentConvergenceOfParabolicStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedDictionaryPartBStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WeaklyRegularOfCotangentIndepStatement
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreeLinearFunctionals
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreePowerSumMulZeroStatement
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.HermitianDarbouxSplitProduct
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.HomogeneousPowerSumDecomposition
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.AlgebraicApproximationCompleteDvrStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.AlgebraicElementHomogRelationStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ChartBundleLatticeGenerators
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ChartBundleLocalGeneration
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ChartLatticeNormMembershipStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.CoordTieCompEquiv
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.DominatesOfCoordsRegular
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.EtaleSpaceCohomologyEqZeroOfSimplicialRowExact
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsDenominatorBtOrder
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsIntegralAdeleLimitCompatibleIntSystem
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsReversedDualBasisStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FiniteOpenLeClosedFibreStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FlagCoefficientRatioIntegral
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenMapFromSpecStalk
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericFlagTrdegFormula
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericFlagTriangularChange
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GluedLatticeFiniteIndex
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GluedLatticeLocalization
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GrGenOfIsFlagVBOn
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GrIsGenAt
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.HomAddMulOfUnitSectionStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsExcisionNbhdAway
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeEigenVectorBundle
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeGlueOverPrimesStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeTensorPowerDegree
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeTensorPowerLineBundle
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeVectorBundlePullback
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieChart
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieModelPullbackEquivalence
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalIndexAtSinglePlace
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrincipalExtensionProjectiveModule
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegAtFractionNoetherianClosed

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MeasurableZeroCountStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MemPowSmulTopIff, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicityReductionDiagonalProd, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NewtonApproximationLocalToGlobalStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormInvGammaLeReflect, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormThetaMul, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicLawOfBlockDetStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionOffDiagonalIdentityStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionSquareIdentityStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialIntegralMemSchwartzBruhatStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PerfectTensorGeneratedLift, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProjMemFixedPiN, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzBruhatProdSpanTensorsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzQuadraticPhaseMultiplicationStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShuffleWeightAntisymmetricEqStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SiegelInductionFromGalleryStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SigmaCompactDisjointRefinementStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SubquotientOfEigencharacter, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SumHyperplanesComplementFlags, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorPunitEqZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TruncSum, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TubeTransformHorizontalInvariance, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TubeTransformVerticalInvariance, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TwistedIwahoriContractionHolds, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnimodularHaarRightInvariantStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnipotentConvergenceOfParabolicStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedDictionaryPartBStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WeaklyRegularOfCotangentIndepStatement, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreeLinearFunctionals, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreePowerSumMulZeroStatement, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.HermitianDarbouxSplitProduct, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.HomogeneousPowerSumDecomposition, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.AlgebraicApproximationCompleteDvrStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.AlgebraicElementHomogRelationStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ChartBundleLatticeGenerators, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ChartBundleLocalGeneration, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ChartLatticeNormMembershipStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.CoordTieCompEquiv, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.DominatesOfCoordsRegular, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.EtaleSpaceCohomologyEqZeroOfSimplicialRowExact, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsDenominatorBtOrder, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsIntegralAdeleLimitCompatibleIntSystem, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsReversedDualBasisStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FiniteOpenLeClosedFibreStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FlagCoefficientRatioIntegral, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenMapFromSpecStalk, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericFlagTrdegFormula, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericFlagTriangularChange, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GluedLatticeFiniteIndex, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GluedLatticeLocalization, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GrGenOfIsFlagVBOn, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GrIsGenAt, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.HomAddMulOfUnitSectionStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsExcisionNbhdAway, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeEigenVectorBundle, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeGlueOverPrimesStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeTensorPowerDegree, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeTensorPowerLineBundle, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeVectorBundlePullback, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieChart, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieModelPullbackEquivalence, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalIndexAtSinglePlace, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrincipalExtensionProjectiveModule, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegAtFractionNoetherianClosed]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

