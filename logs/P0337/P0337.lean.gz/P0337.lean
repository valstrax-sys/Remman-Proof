import Lean
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StVarMassNearSmall
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StVarWirtinger
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StVarietyMassLower
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StatementsGreenReg
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StatementsLocalBranches
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StatementsSheetMeasurable
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.CutIdentityRightSideCongrOfSubMem
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.DivisorIdealBotUniformiser
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.ImportsAlt
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.ImportsBisRest
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.ImportsBisTer
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.ImportsMoreFurther
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.ImportsTerBis
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.Inhabit
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.InhabitFurther
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.InhabitLine
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.InhabitMore
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.InhabitTer
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.IsVerticalDivOfIsVerticalDivisorAlt
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.JoinCoordAssocVar
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.JoinCoordMidVar
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.Length
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PCutByFormField
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PIntNumIsFieldIntersection
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PIntNumPoint
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PIntNumRatSection
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PPairCocycle
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PPowSpanFinrankBounded
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PScalarQuotient
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSubQuotient
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PVocabDivCycle
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PVocabMultiHomog
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PVocabMultiHomogIdeal
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.ScaledRankOneLeStandardRankOne
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsConeTrdegFnField
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsFlagBundle
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsFlagIndependence
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsPointIdealMultiProj
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsTwistedDualGensSpan
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsVerticalDivisorJoinPullback
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.TrivBundleIsTwistedForms
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PExtNonIntChart
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.Statements
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PFrameGraphGeneric
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PFrameImplicitGraph
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PGramDetSandwich
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PNumberFieldBoxCountX
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PPointIntegral
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PPullbackMulMem
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PTorsAvgDescends
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.ResidueChartTransport
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.ResidueFiniteModel
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.StConormalGenerationGeneric
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.TorsionAverageBasics
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.IntNumRelabel
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PContractRelDimLe
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PDivPrincipalDegree
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PEventuallyPolyShift
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PEventuallyPolyUnique
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PHilbAddBlock
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PHilbDegreeBound
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PHilbIrrelevantZero
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PIntNumUnique
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PMultEqualsCoeff

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StVarMassNearSmall, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StVarWirtinger, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StVarietyMassLower, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StatementsGreenReg, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StatementsLocalBranches, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StatementsSheetMeasurable, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.CutIdentityRightSideCongrOfSubMem, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.DivisorIdealBotUniformiser, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.ImportsAlt, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.ImportsBisRest, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.ImportsBisTer, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.ImportsMoreFurther, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.ImportsTerBis, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.Inhabit, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.InhabitFurther, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.InhabitLine, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.InhabitMore, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.InhabitTer, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.IsVerticalDivOfIsVerticalDivisorAlt, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.JoinCoordAssocVar, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.JoinCoordMidVar, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.Length, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PCutByFormField, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PIntNumIsFieldIntersection, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PIntNumPoint, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PIntNumRatSection, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PPairCocycle, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PPowSpanFinrankBounded, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PScalarQuotient, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSubQuotient, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PVocabDivCycle, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PVocabMultiHomog, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PVocabMultiHomogIdeal, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.ScaledRankOneLeStandardRankOne, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsConeTrdegFnField, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsFlagBundle, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsFlagIndependence, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsPointIdealMultiProj, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsTwistedDualGensSpan, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsVerticalDivisorJoinPullback, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.TrivBundleIsTwistedForms, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PExtNonIntChart, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.Statements, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PFrameGraphGeneric, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PFrameImplicitGraph, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PGramDetSandwich, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PNumberFieldBoxCountX, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PPointIntegral, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PPullbackMulMem, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PTorsAvgDescends, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.ResidueChartTransport, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.ResidueFiniteModel, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.StConormalGenerationGeneric, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.TorsionAverageBasics, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.IntNumRelabel, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PContractRelDimLe, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PDivPrincipalDegree, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PEventuallyPolyShift, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PEventuallyPolyUnique, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PHilbAddBlock, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PHilbDegreeBound, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PHilbIrrelevantZero, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PIntNumUnique, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PMultEqualsCoeff]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

