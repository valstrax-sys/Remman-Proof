import Lean
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PLeviFSInvariant
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PLeviHolPerturb
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PLeviLogFlat
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PMixedNumberPolynomial
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PRankOfSections
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.SectionL2NormSq
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsComplexFormsOnPoints
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsDegLTGrowth
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsDegreePositive
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsEventualPolynomial
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsFiltrationHilbSum
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsPrimeZariskiDense
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.WeightedHomogeneousSubmoduleBlockWeightIntEqRing
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PBlocksLeadSandwich
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PFlagIntMuDegree
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PFlagIntMuProd
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PFsPotLaplacian
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PLaplacianLogGrowth
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.ChartGlueLoc
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.ChartGlueSat
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.IsIsoPullbackObjUnitToUnit
import GroundTheory.HeightsAndTheta.Heights.Intersections.AvoidRing
import GroundTheory.HeightsAndTheta.Heights.Intersections.PChartNormPtsA
import GroundTheory.HeightsAndTheta.Heights.Intersections.StatementsOrbitCompNonvanish
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.AmpleRingFiniteSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.AmpleRingFiniteTypeSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.AmpleRingIntegralSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CoordIdealIsMultiProjPrime
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.QuotGraded
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.Statements
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsAmple
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsAmpleAffine
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsCechDSq
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsTwistSections
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StepTwoFiltGraded
import GroundTheory.HeightsAndTheta.Heights.LocalDensities.PIntegralPointThroughPrime
import GroundTheory.HeightsAndTheta.Heights.LocalDensities.StatementsChartPartition
import GroundTheory.HeightsAndTheta.Heights.MatrixCharts.IsOpenKappaOpenNeighbourhood
import GroundTheory.HeightsAndTheta.Heights.MatrixCharts.Statements
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PPrimesLogSum
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.Statements
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PProjPotDensLevi
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsInvertibleIndexMul
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsLatticeImageZLattice
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsPushForwardOpen
import GroundTheory.HeightsAndTheta.Heights.Regularisation.PRiemannExtensionSlices
import GroundTheory.HeightsAndTheta.Heights.Regularisation.RegMaxReindex
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.BlockValue
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.InhabitantsElem
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.Lattice
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.NumStandardTableEqCardMonotone
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.NumStandardTablePos
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvAboveTop
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvAboveTopGeneral
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvAtTop
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvAtTopGeneral
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvIdealComponent
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvIdealRepresentation
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvMonomialReduction
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvPolynomialReduction
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvStaircaseComponent
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvStaircaseDegree
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvStepReduction
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvariantTopDegree

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PLeviFSInvariant, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PLeviHolPerturb, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PLeviLogFlat, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PMixedNumberPolynomial, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PRankOfSections, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.SectionL2NormSq, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsComplexFormsOnPoints, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsDegLTGrowth, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsDegreePositive, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsEventualPolynomial, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsFiltrationHilbSum, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsPrimeZariskiDense, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.WeightedHomogeneousSubmoduleBlockWeightIntEqRing, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PBlocksLeadSandwich, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PFlagIntMuDegree, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PFlagIntMuProd, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PFsPotLaplacian, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PLaplacianLogGrowth, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.ChartGlueLoc, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.ChartGlueSat, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.IsIsoPullbackObjUnitToUnit, `GroundTheory.HeightsAndTheta.Heights.Intersections.AvoidRing, `GroundTheory.HeightsAndTheta.Heights.Intersections.PChartNormPtsA, `GroundTheory.HeightsAndTheta.Heights.Intersections.StatementsOrbitCompNonvanish, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.AmpleRingFiniteSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.AmpleRingFiniteTypeSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.AmpleRingIntegralSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CoordIdealIsMultiProjPrime, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.QuotGraded, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.Statements, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsAmple, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsAmpleAffine, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsCechDSq, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsTwistSections, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StepTwoFiltGraded, `GroundTheory.HeightsAndTheta.Heights.LocalDensities.PIntegralPointThroughPrime, `GroundTheory.HeightsAndTheta.Heights.LocalDensities.StatementsChartPartition, `GroundTheory.HeightsAndTheta.Heights.MatrixCharts.IsOpenKappaOpenNeighbourhood, `GroundTheory.HeightsAndTheta.Heights.MatrixCharts.Statements, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PPrimesLogSum, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.Statements, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PProjPotDensLevi, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsInvertibleIndexMul, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsLatticeImageZLattice, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsPushForwardOpen, `GroundTheory.HeightsAndTheta.Heights.Regularisation.PRiemannExtensionSlices, `GroundTheory.HeightsAndTheta.Heights.Regularisation.RegMaxReindex, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.BlockValue, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.InhabitantsElem, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.Lattice, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.NumStandardTableEqCardMonotone, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.NumStandardTablePos, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvAboveTop, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvAboveTopGeneral, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvAtTop, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvAtTopGeneral, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvIdealComponent, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvIdealRepresentation, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvMonomialReduction, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvPolynomialReduction, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvStaircaseComponent, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvStaircaseDegree, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvStepReduction, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCoinvariantTopDegree]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

