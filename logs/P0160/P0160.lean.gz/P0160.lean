import Lean
import GroundTheory.AutomorphicForms.GKModules.LieAlgebra
import GroundTheory.AutomorphicForms.GL2.GJGlobalUnfoldRank
import GroundTheory.AutomorphicForms.GL2.InnerProductParamHolo
import GroundTheory.AutomorphicForms.GLnLocal
import GroundTheory.AutomorphicForms.GeometricLemmaCount
import GroundTheory.AutomorphicForms.HarishChandraCentre.Capelli
import GroundTheory.AutomorphicForms.HarishChandraCentre.Fischer
import GroundTheory.AutomorphicForms.HarishChandraCentre.MemOfMemSupportToFinsupp
import GroundTheory.AutomorphicForms.HarishChandraCentre.RhoOneEqZeroOfRhoZeroEqZero
import GroundTheory.AutomorphicForms.HermitianSpaces
import GroundTheory.AutomorphicForms.HilbertSchmidtCompact
import GroundTheory.AutomorphicForms.HilbertSchmidtKernel
import GroundTheory.AutomorphicForms.LocallyConstantCompact
import GroundTheory.AutomorphicForms.PartialDifferential.SobolevDuality
import GroundTheory.AutomorphicForms.PartialDifferential.SobolevEmbedding
import GroundTheory.AutomorphicForms.QuotientMeasure
import GroundTheory.AutomorphicForms.RealGroupsPolar
import GroundTheory.AutomorphicForms.RestrictedAddHaarProduct
import GroundTheory.AutomorphicForms.SatakeSymmetric
import GroundTheory.AutomorphicForms.SmoothRep
import GroundTheory.AutomorphicForms.TensorProductTheorem.GenWindow
import GroundTheory.AutomorphicForms.TensorProductTheorem.TotallyDisconnectedSpaceRestrictedProduct
import GroundTheory.AutomorphicForms.TraceClass
import GroundTheory.AutomorphicForms.UnitaryRepresentations.DirectSum
import GroundTheory.AutomorphicForms.UnitaryRepresentations.ExistsEqAlgebraMapOfIsSelfAdjoint
import GroundTheory.AutomorphicForms.UnitaryRepresentations.Integrated
import GroundTheory.Brauer.BaseChangeCSA
import GroundTheory.Brauer.CrossedProductSimple
import GroundTheory.Brauer.IsBrauerEquivalentIffNonemptyAlgEquiv
import GroundTheory.Brauer.SkolemNoether
import GroundTheory.FunctionField.PlaceBasic
import GroundTheory.GlobalFields.Adele.Approximation
import GroundTheory.GlobalFields.Adele.WeakApproxUnits
import GroundTheory.GlobalFields.Artin.MemInvariantsCompSubtypeIff
import GroundTheory.GlobalFields.Artin.RelativeDiscriminant
import GroundTheory.GlobalFields.ComplexMultiplication.AutCFixed
import GroundTheory.GlobalFields.ComplexMultiplication.EllipticConstant
import GroundTheory.GlobalFields.ComplexMultiplication.GoodReductionAlmostAll
import GroundTheory.GlobalFields.ComplexMultiplication.ResidueTheorem
import GroundTheory.GlobalFields.ComplexMultiplication.WeberFunction
import GroundTheory.GlobalFields.CyclotomicCharacters.Character
import GroundTheory.GlobalFields.HerbrandQuotients.CycTate
import GroundTheory.GlobalFields.HerbrandQuotients.Cyclic
import GroundTheory.GlobalFields.IdeleGroups.ClassGroup
import GroundTheory.GlobalFields.IdeleGroups.IdeleNorms
import GroundTheory.GlobalFields.IdeleGroups.Restricted
import GroundTheory.GlobalFields.KummerTheory.LocalIndex
import GroundTheory.GlobalFields.LocalFieldAtPlace
import GroundTheory.GlobalFields.SUnits
import GroundTheory.GlobalFields.SemilocalAlgebras.InfiniteAdele
import GroundTheory.GlobalFields.SemilocalAlgebras.LocalDegree
import GroundTheory.GlobalFields.TateThesis.ArchCharsUnits
import GroundTheory.GlobalFields.TateThesis.GaussianComplex
import GroundTheory.GlobalFields.TateThesis.LatticePoisson
import GroundTheory.GlobalFields.TateThesis.LocalConductor
import GroundTheory.GlobalFields.TateThesis.PrimeZetaPole
import GroundTheory.GlobalFields.TateThesis.TracePairing
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.Characterised
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ChartGramHess
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ChartGramPolar
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ConeBall
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.Imports
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LineInhabitant
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LocalMultRadical

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.AutomorphicForms.GKModules.LieAlgebra, `GroundTheory.AutomorphicForms.GL2.GJGlobalUnfoldRank, `GroundTheory.AutomorphicForms.GL2.InnerProductParamHolo, `GroundTheory.AutomorphicForms.GLnLocal, `GroundTheory.AutomorphicForms.GeometricLemmaCount, `GroundTheory.AutomorphicForms.HarishChandraCentre.Capelli, `GroundTheory.AutomorphicForms.HarishChandraCentre.Fischer, `GroundTheory.AutomorphicForms.HarishChandraCentre.MemOfMemSupportToFinsupp, `GroundTheory.AutomorphicForms.HarishChandraCentre.RhoOneEqZeroOfRhoZeroEqZero, `GroundTheory.AutomorphicForms.HermitianSpaces, `GroundTheory.AutomorphicForms.HilbertSchmidtCompact, `GroundTheory.AutomorphicForms.HilbertSchmidtKernel, `GroundTheory.AutomorphicForms.LocallyConstantCompact, `GroundTheory.AutomorphicForms.PartialDifferential.SobolevDuality, `GroundTheory.AutomorphicForms.PartialDifferential.SobolevEmbedding, `GroundTheory.AutomorphicForms.QuotientMeasure, `GroundTheory.AutomorphicForms.RealGroupsPolar, `GroundTheory.AutomorphicForms.RestrictedAddHaarProduct, `GroundTheory.AutomorphicForms.SatakeSymmetric, `GroundTheory.AutomorphicForms.SmoothRep, `GroundTheory.AutomorphicForms.TensorProductTheorem.GenWindow, `GroundTheory.AutomorphicForms.TensorProductTheorem.TotallyDisconnectedSpaceRestrictedProduct, `GroundTheory.AutomorphicForms.TraceClass, `GroundTheory.AutomorphicForms.UnitaryRepresentations.DirectSum, `GroundTheory.AutomorphicForms.UnitaryRepresentations.ExistsEqAlgebraMapOfIsSelfAdjoint, `GroundTheory.AutomorphicForms.UnitaryRepresentations.Integrated, `GroundTheory.Brauer.BaseChangeCSA, `GroundTheory.Brauer.CrossedProductSimple, `GroundTheory.Brauer.IsBrauerEquivalentIffNonemptyAlgEquiv, `GroundTheory.Brauer.SkolemNoether, `GroundTheory.FunctionField.PlaceBasic, `GroundTheory.GlobalFields.Adele.Approximation, `GroundTheory.GlobalFields.Adele.WeakApproxUnits, `GroundTheory.GlobalFields.Artin.MemInvariantsCompSubtypeIff, `GroundTheory.GlobalFields.Artin.RelativeDiscriminant, `GroundTheory.GlobalFields.ComplexMultiplication.AutCFixed, `GroundTheory.GlobalFields.ComplexMultiplication.EllipticConstant, `GroundTheory.GlobalFields.ComplexMultiplication.GoodReductionAlmostAll, `GroundTheory.GlobalFields.ComplexMultiplication.ResidueTheorem, `GroundTheory.GlobalFields.ComplexMultiplication.WeberFunction, `GroundTheory.GlobalFields.CyclotomicCharacters.Character, `GroundTheory.GlobalFields.HerbrandQuotients.CycTate, `GroundTheory.GlobalFields.HerbrandQuotients.Cyclic, `GroundTheory.GlobalFields.IdeleGroups.ClassGroup, `GroundTheory.GlobalFields.IdeleGroups.IdeleNorms, `GroundTheory.GlobalFields.IdeleGroups.Restricted, `GroundTheory.GlobalFields.KummerTheory.LocalIndex, `GroundTheory.GlobalFields.LocalFieldAtPlace, `GroundTheory.GlobalFields.SUnits, `GroundTheory.GlobalFields.SemilocalAlgebras.InfiniteAdele, `GroundTheory.GlobalFields.SemilocalAlgebras.LocalDegree, `GroundTheory.GlobalFields.TateThesis.ArchCharsUnits, `GroundTheory.GlobalFields.TateThesis.GaussianComplex, `GroundTheory.GlobalFields.TateThesis.LatticePoisson, `GroundTheory.GlobalFields.TateThesis.LocalConductor, `GroundTheory.GlobalFields.TateThesis.PrimeZetaPole, `GroundTheory.GlobalFields.TateThesis.TracePairing, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.Characterised, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ChartGramHess, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ChartGramPolar, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ConeBall, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.Imports, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LineInhabitant, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LocalMultRadical]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

