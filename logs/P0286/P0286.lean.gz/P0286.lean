import Lean
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartEnergyInvariant
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartEnergySwap
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartEnergySymm
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartIbpSteps
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsGrassHeight
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.ThetaGauss
import GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.FiniteSupportHeight
import GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.NoCommonZeroComplex
import GroundTheory.HeightsAndTheta.Heights.HermitianTensor
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.BergmanNorms
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.HolLineBundleToAltTransition
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.LengthLocalizedQuotientEqZero
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PComplexFormsOnPoints
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PDegLTGrowth
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PEventualPolyLine
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PEventualPolynomial
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PFiltrationHilbSum
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PPrimeZariskiDense
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PolydiscMean
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsChartBergman
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsMetricChangeDimZero
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsMultiDegreePositive
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.AssemblyLaplacianLogGrowth
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.CoordinateIdeals
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.CoordinateIdeals.FubiniLevi
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.IsVerticalCartier
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.Statements
import GroundTheory.HeightsAndTheta.Heights.Intersections.StTorusInvLevi
import GroundTheory.HeightsAndTheta.Heights.Intersections.Statements
import GroundTheory.HeightsAndTheta.Heights.Intersections.StatementsChartRankAdjoin
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.AlgebraMapMemChartRingLine
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CellMeets
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CoordIdealXgen
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.EqZeroOrIsHomogeneousOfMemPolyPiece
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PAmpleCover
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PAmpleTwistLocal
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCechDSq
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCechFlat
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCechTop
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PExtension
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PGenerated
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PGeneratedAmple
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PPrimeFiltrationExists
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PPrimeFiltrationPoint
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerreFree
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerreOnto
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerreTail
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PTwistSections
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsDegLocExact
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsDegreePos
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsPres
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsSerrePoly
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.TwistFiniteness.PsiOfIsHomogeneous
import GroundTheory.HeightsAndTheta.Heights.MatrixCharts.BoundsY
import GroundTheory.HeightsAndTheta.Heights.MatrixCharts.CovolumeLeadingEqGramCovolFirstBlock
import GroundTheory.HeightsAndTheta.Heights.MatrixCharts.DetIneq
import GroundTheory.HeightsAndTheta.Heights.MatrixCharts.HermValueIsLeast
import GroundTheory.HeightsAndTheta.Heights.MatrixCharts.Period
import GroundTheory.HeightsAndTheta.Heights.MatrixCharts.PshCore
import GroundTheory.HeightsAndTheta.Heights.MatrixCharts.StatementsPsh
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PPolarisationBound
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PPolarisationCoeff
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PShOfPower
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PTotOfPower

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartEnergyInvariant, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartEnergySwap, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartEnergySymm, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartIbpSteps, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsGrassHeight, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.ThetaGauss, `GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.FiniteSupportHeight, `GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.NoCommonZeroComplex, `GroundTheory.HeightsAndTheta.Heights.HermitianTensor, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.BergmanNorms, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.HolLineBundleToAltTransition, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.LengthLocalizedQuotientEqZero, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PComplexFormsOnPoints, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PDegLTGrowth, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PEventualPolyLine, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PEventualPolynomial, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PFiltrationHilbSum, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PPrimeZariskiDense, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PolydiscMean, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsChartBergman, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsMetricChangeDimZero, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsMultiDegreePositive, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.AssemblyLaplacianLogGrowth, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.CoordinateIdeals, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.CoordinateIdeals.FubiniLevi, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.IsVerticalCartier, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.Statements, `GroundTheory.HeightsAndTheta.Heights.Intersections.StTorusInvLevi, `GroundTheory.HeightsAndTheta.Heights.Intersections.Statements, `GroundTheory.HeightsAndTheta.Heights.Intersections.StatementsChartRankAdjoin, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.AlgebraMapMemChartRingLine, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CellMeets, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CoordIdealXgen, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.EqZeroOrIsHomogeneousOfMemPolyPiece, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PAmpleCover, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PAmpleTwistLocal, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCechDSq, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCechFlat, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCechTop, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PExtension, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PGenerated, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PGeneratedAmple, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PPrimeFiltrationExists, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PPrimeFiltrationPoint, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerreFree, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerreOnto, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerreTail, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PTwistSections, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsDegLocExact, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsDegreePos, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsPres, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsSerrePoly, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.TwistFiniteness.PsiOfIsHomogeneous, `GroundTheory.HeightsAndTheta.Heights.MatrixCharts.BoundsY, `GroundTheory.HeightsAndTheta.Heights.MatrixCharts.CovolumeLeadingEqGramCovolFirstBlock, `GroundTheory.HeightsAndTheta.Heights.MatrixCharts.DetIneq, `GroundTheory.HeightsAndTheta.Heights.MatrixCharts.HermValueIsLeast, `GroundTheory.HeightsAndTheta.Heights.MatrixCharts.Period, `GroundTheory.HeightsAndTheta.Heights.MatrixCharts.PshCore, `GroundTheory.HeightsAndTheta.Heights.MatrixCharts.StatementsPsh, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PPolarisationBound, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PPolarisationCoeff, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PShOfPower, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PTotOfPower]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

