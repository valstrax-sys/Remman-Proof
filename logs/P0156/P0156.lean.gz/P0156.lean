import Lean
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.LocDensSAInt
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.MeasureEqOfCos
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeylProduct.WeylProd
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittCoefficients.CoeffEqOfSubMem
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittDecomposition.Anisotropic
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittUnramified.GhostComponentG
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittUnramified.PsiStep
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ZeroWindow.RightHalfWith
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.projection2.KappaZero
import Formalism.PeriodIntegrals.W2pair
import Formalism.PeriodIntegrals.WeierUnif
import Formalism.PeriodIntegrals.WeylForK
import Formalism.PeriodIntegrals.WfRing
import Formalism.PeriodIntegrals.WfSubst
import Formalism.PieriBlockIdeals.ContentDistanceBounds
import Formalism.PieriBlockIdeals.ParamsWindow
import Formalism.PieriBlockIdeals.PieriColumnMinors.ContentLinkageHolds
import Formalism.PieriBlockIdeals.PieriColumnMinors.CountLeftInvSeqAlternatingWordEven
import Formalism.PieriBlockIdeals.PieriColumnMinors.HeightDescentMinors
import Formalism.PieriBlockIdeals.PieriColumnMinors.LabelSumNeedsLeFalse
import Formalism.PieriBlockIdeals.PieriColumnMinors.MinorValuationBoundHolds
import Formalism.PieriBlockIdeals.PieriColumnMinors.PadicValIntProdElevenMultiples
import Formalism.PieriBlockIdeals.PieriColumnMinors.SharperSizeNeedsMleKFalse
import Formalism.PieriBlockIdeals.PieriColumnMinors.WeightExchangeBoundHolds
import Formalism.PieriBlockIdeals.StatementC
import Formalism.PieriBlockIdeals.WEChain
import Formalism.PolynomialDimension.ApolarComparisonExponent
import Formalism.PolynomialDimension.DigitClassSize
import Formalism.PolynomialDimension.MultinomialDepth.DiagLaplacianDivPowMemSqrtFockLattice
import Formalism.PolynomialDimension.MultinomialDepth.ExistsNonzeroExchangedMinorHolds
import Formalism.PolynomialDimension.MultinomialDepth.FockGaussComparisonHolds
import Formalism.PolynomialDimension.MultinomialDepth.FrobeniusDetVanishingHolds
import Formalism.PolynomialDimension.MultinomialDepth.HarmonicDecompositionHolds
import Formalism.PolynomialDimension.MultinomialDepth.PairingAdjointLaplacianHolds
import Formalism.PolynomialDimension.StatementNum
import Formalism.PrimeAboveExistence.LenEqPlaces
import Formalism.RankGapBounds.GridNumericalHypotheses
import Formalism.RankGapBounds.RankGapProofs.CardLargePrimeFactorsLeOneHolds
import Formalism.RankGapBounds.RankGapProofs.FourNotDvdOddSqAddOne
import Formalism.RankGapBounds.RankGapProofs.PmModulusFacts
import Formalism.RankGapBounds.RankGapProofs.RandomSubsetLemmaCounterexample
import Formalism.RankGapBounds.RankGapProofs.WeightedMeanData
import Formalism.RankGapBounds.TheoremALocOfLemmaA
import Formalism.RankGapBounds.UniformMeanBound
import Formalism.RealPlaceAnalysis.FockPairGl
import Formalism.RealPlaceAnalysis.LminorPos
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.CasKHW
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.ComplexificationHolds
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.HalfSumRootsStandard
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.IndefiniteUnitaryPreservesForm
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.MemUnitaryGroupIffMulConjTranspose
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.QuadraticInequalityBoundHolds
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.SumOfSquaresIdentityHolds
import Formalism.RealPlaceAnalysis.SmoothOnG
import Formalism.RealPlaceAnalysis.StatementB
import Formalism.RealPlaceAnalysis.StatementD
import Formalism.RealPlaceAnalysis.StatementKT
import Formalism.RealPlaceAnalysis.UJLocCompact
import Formalism.ResultantValuation.PrimePairDisjointBB
import Formalism.ResultantValuation.ResultantAdjugateProofs.Adjugate
import Formalism.ResultantValuation.ResultantAdjugateProofs.Koszul
import Formalism.ResultantValuation.ResultantAdjugateProofs.Laplace
import Formalism.ResultantValuation.ResultantAdjugateProofs.Window
import Formalism.ResultantValuation.SubspaceCount

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.LocDensSAInt, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeilStabilizerVolume.MeasureEqOfCos, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WeylProduct.WeylProd, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittCoefficients.CoeffEqOfSubMem, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittDecomposition.Anisotropic, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittUnramified.GhostComponentG, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittUnramified.PsiStep, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ZeroWindow.RightHalfWith, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.projection2.KappaZero, `Formalism.PeriodIntegrals.W2pair, `Formalism.PeriodIntegrals.WeierUnif, `Formalism.PeriodIntegrals.WeylForK, `Formalism.PeriodIntegrals.WfRing, `Formalism.PeriodIntegrals.WfSubst, `Formalism.PieriBlockIdeals.ContentDistanceBounds, `Formalism.PieriBlockIdeals.ParamsWindow, `Formalism.PieriBlockIdeals.PieriColumnMinors.ContentLinkageHolds, `Formalism.PieriBlockIdeals.PieriColumnMinors.CountLeftInvSeqAlternatingWordEven, `Formalism.PieriBlockIdeals.PieriColumnMinors.HeightDescentMinors, `Formalism.PieriBlockIdeals.PieriColumnMinors.LabelSumNeedsLeFalse, `Formalism.PieriBlockIdeals.PieriColumnMinors.MinorValuationBoundHolds, `Formalism.PieriBlockIdeals.PieriColumnMinors.PadicValIntProdElevenMultiples, `Formalism.PieriBlockIdeals.PieriColumnMinors.SharperSizeNeedsMleKFalse, `Formalism.PieriBlockIdeals.PieriColumnMinors.WeightExchangeBoundHolds, `Formalism.PieriBlockIdeals.StatementC, `Formalism.PieriBlockIdeals.WEChain, `Formalism.PolynomialDimension.ApolarComparisonExponent, `Formalism.PolynomialDimension.DigitClassSize, `Formalism.PolynomialDimension.MultinomialDepth.DiagLaplacianDivPowMemSqrtFockLattice, `Formalism.PolynomialDimension.MultinomialDepth.ExistsNonzeroExchangedMinorHolds, `Formalism.PolynomialDimension.MultinomialDepth.FockGaussComparisonHolds, `Formalism.PolynomialDimension.MultinomialDepth.FrobeniusDetVanishingHolds, `Formalism.PolynomialDimension.MultinomialDepth.HarmonicDecompositionHolds, `Formalism.PolynomialDimension.MultinomialDepth.PairingAdjointLaplacianHolds, `Formalism.PolynomialDimension.StatementNum, `Formalism.PrimeAboveExistence.LenEqPlaces, `Formalism.RankGapBounds.GridNumericalHypotheses, `Formalism.RankGapBounds.RankGapProofs.CardLargePrimeFactorsLeOneHolds, `Formalism.RankGapBounds.RankGapProofs.FourNotDvdOddSqAddOne, `Formalism.RankGapBounds.RankGapProofs.PmModulusFacts, `Formalism.RankGapBounds.RankGapProofs.RandomSubsetLemmaCounterexample, `Formalism.RankGapBounds.RankGapProofs.WeightedMeanData, `Formalism.RankGapBounds.TheoremALocOfLemmaA, `Formalism.RankGapBounds.UniformMeanBound, `Formalism.RealPlaceAnalysis.FockPairGl, `Formalism.RealPlaceAnalysis.LminorPos, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.CasKHW, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.ComplexificationHolds, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.HalfSumRootsStandard, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.IndefiniteUnitaryPreservesForm, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.MemUnitaryGroupIffMulConjTranspose, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.QuadraticInequalityBoundHolds, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.SumOfSquaresIdentityHolds, `Formalism.RealPlaceAnalysis.SmoothOnG, `Formalism.RealPlaceAnalysis.StatementB, `Formalism.RealPlaceAnalysis.StatementD, `Formalism.RealPlaceAnalysis.StatementKT, `Formalism.RealPlaceAnalysis.UJLocCompact, `Formalism.ResultantValuation.PrimePairDisjointBB, `Formalism.ResultantValuation.ResultantAdjugateProofs.Adjugate, `Formalism.ResultantValuation.ResultantAdjugateProofs.Koszul, `Formalism.ResultantValuation.ResultantAdjugateProofs.Laplace, `Formalism.ResultantValuation.ResultantAdjugateProofs.Window, `Formalism.ResultantValuation.SubspaceCount]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

