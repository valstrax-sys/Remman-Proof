import Lean
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TwoNeZeroNat
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UlZero
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UniAMulDiag
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnipotentExponentialSurjective
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnipotentFundamentalDomain
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnitBall
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnitBallSubring
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnitaryAnnihilator
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnitaryGroupStatement
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnitaryRootEmbedding
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnopSMul
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnramifiedAntiInvariantLocal
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UpDiagMul
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UpUMul
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UpperTriangular
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UpperTriangularMul
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ValPrimeOfLt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.VandermondeOfEqDet
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.VecStab
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.VectorStabilizer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.VolumePreservingUncurry
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.WeightComponentsMemInvariant
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.WeightedHomogeneousMap
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.WeightedSumBis
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.WeightsCompactStabilizer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.WithBotEqOfLeOfAddOneLe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.WtGeProd
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ZariskiNoetherianInduction
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ZeroContDiffOnSupported
import Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.SpanNatCastLeComap
import Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.UniformContinuousConstSMulOfIsIsometricSMul
import Development.AutomorphicArithmetic.IntegralCasts.TransposeInverse.TransposeInv
import Development.AutomorphicArithmetic.KaehlerVanishing.DerivationEqOfFormallyEtaleOfEvaluationEq
import Development.AutomorphicArithmetic.KaehlerVanishing.KaehlerFunctionalVanishingOfLocalizationAtPrime
import Development.AutomorphicArithmetic.LocalEmbeddings.ConeBDefs
import Development.AutomorphicArithmetic.LocalEmbeddings.ValCount
import Development.AutomorphicArithmetic.OrbitLabellings.SumLogDivCubeLeOfTwoPowDvd
import Development.AutomorphicArithmetic.QuadraticCharacters.LogDerivAtOne
import Development.AutomorphicArithmetic.ResidueCharacters.SumLogDivSqModPmOneLe
import Development.AutomorphicArithmetic.Splittings.ExistsCyclicGaloisTensorAlgEquivPi
import Development.AutomorphicArithmetic.ThetaCorrespondence.GeneralLinearGroups.Imports
import Development.AutomorphicArithmetic.ThetaCorrespondence.HoweDuality.FactorApply
import Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.IsBand
import Development.AutomorphicArithmetic.ThetaCorrespondence.ThetaPairLifts.HodgeBundleWeights.TamagawaNumberSpecialUnitary
import Development.AutomorphicArithmetic.ThetaCorrespondence.ThetaPairLifts.ThirdPlaceSeries.CohomologicalCsdTempered
import Development.AutomorphicArithmetic.TwistedTraces.ExistsAlgHomEndIntertwiningMemAdjoin
import Development.AutomorphicArithmetic.TwistedTraces.LinearFormEqMulTraceOfTwistedInvariant
import Development.AutomorphicArithmetic.TwistedTraces.ListOfFnProdEqMulUpdateOneOfPairwiseCommute
import Development.AutomorphicArithmetic.TwistedTraces.TracePairingSeparatesEndomorphisms
import Development.AutomorphicArithmetic.WeightCongruences.ProdNegOneZpow
import Development.AutomorphicArithmetic.WeightCongruences.TorsionOrderLeTwoMulFinrankSq
import Development.AutomorphicArithmetic.WhittakerHecke.EqZeroAtOneOfFourierIntegralEqZero
import Development.AutomorphicArithmetic.WhittakerHecke.EqZeroOfOrthogonalEvenHomogeneousTrig
import Development.AutomorphicArithmetic.WhittakerHecke.IntegrableAndContinuousMellinIntegralOfRapidDeca
import Development.AutomorphicArithmetic.WhittakerHecke.IsAffineOpenImagePullbackOpenImmersionChart
import Development.AutomorphicArithmetic.WhittakerHecke.SummableTsumInvOneAddHeightPowLe
import Development.AutomorphicSpectrum.Definitions.AdelicLattices.FactPrimes
import Development.AutomorphicSpectrum.Definitions.AdelicLattices.IsSelfDualLat
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.FlagMinor
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.GapCondExample
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.IsSplitGaussChars
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.ProIsoAt
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.TranslateMemIndOrder
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.ValNeBot

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TwoNeZeroNat, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UlZero, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UniAMulDiag, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnipotentExponentialSurjective, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnipotentFundamentalDomain, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnitBall, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnitBallSubring, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnitaryAnnihilator, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnitaryGroupStatement, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnitaryRootEmbedding, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnopSMul, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UnramifiedAntiInvariantLocal, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UpDiagMul, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UpUMul, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UpperTriangular, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.UpperTriangularMul, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ValPrimeOfLt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.VandermondeOfEqDet, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.VecStab, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.VectorStabilizer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.VolumePreservingUncurry, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.WeightComponentsMemInvariant, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.WeightedHomogeneousMap, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.WeightedSumBis, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.WeightsCompactStabilizer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.WithBotEqOfLeOfAddOneLe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.WtGeProd, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ZariskiNoetherianInduction, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ZeroContDiffOnSupported, `Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.SpanNatCastLeComap, `Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.UniformContinuousConstSMulOfIsIsometricSMul, `Development.AutomorphicArithmetic.IntegralCasts.TransposeInverse.TransposeInv, `Development.AutomorphicArithmetic.KaehlerVanishing.DerivationEqOfFormallyEtaleOfEvaluationEq, `Development.AutomorphicArithmetic.KaehlerVanishing.KaehlerFunctionalVanishingOfLocalizationAtPrime, `Development.AutomorphicArithmetic.LocalEmbeddings.ConeBDefs, `Development.AutomorphicArithmetic.LocalEmbeddings.ValCount, `Development.AutomorphicArithmetic.OrbitLabellings.SumLogDivCubeLeOfTwoPowDvd, `Development.AutomorphicArithmetic.QuadraticCharacters.LogDerivAtOne, `Development.AutomorphicArithmetic.ResidueCharacters.SumLogDivSqModPmOneLe, `Development.AutomorphicArithmetic.Splittings.ExistsCyclicGaloisTensorAlgEquivPi, `Development.AutomorphicArithmetic.ThetaCorrespondence.GeneralLinearGroups.Imports, `Development.AutomorphicArithmetic.ThetaCorrespondence.HoweDuality.FactorApply, `Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.IsBand, `Development.AutomorphicArithmetic.ThetaCorrespondence.ThetaPairLifts.HodgeBundleWeights.TamagawaNumberSpecialUnitary, `Development.AutomorphicArithmetic.ThetaCorrespondence.ThetaPairLifts.ThirdPlaceSeries.CohomologicalCsdTempered, `Development.AutomorphicArithmetic.TwistedTraces.ExistsAlgHomEndIntertwiningMemAdjoin, `Development.AutomorphicArithmetic.TwistedTraces.LinearFormEqMulTraceOfTwistedInvariant, `Development.AutomorphicArithmetic.TwistedTraces.ListOfFnProdEqMulUpdateOneOfPairwiseCommute, `Development.AutomorphicArithmetic.TwistedTraces.TracePairingSeparatesEndomorphisms, `Development.AutomorphicArithmetic.WeightCongruences.ProdNegOneZpow, `Development.AutomorphicArithmetic.WeightCongruences.TorsionOrderLeTwoMulFinrankSq, `Development.AutomorphicArithmetic.WhittakerHecke.EqZeroAtOneOfFourierIntegralEqZero, `Development.AutomorphicArithmetic.WhittakerHecke.EqZeroOfOrthogonalEvenHomogeneousTrig, `Development.AutomorphicArithmetic.WhittakerHecke.IntegrableAndContinuousMellinIntegralOfRapidDeca, `Development.AutomorphicArithmetic.WhittakerHecke.IsAffineOpenImagePullbackOpenImmersionChart, `Development.AutomorphicArithmetic.WhittakerHecke.SummableTsumInvOneAddHeightPowLe, `Development.AutomorphicSpectrum.Definitions.AdelicLattices.FactPrimes, `Development.AutomorphicSpectrum.Definitions.AdelicLattices.IsSelfDualLat, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.FlagMinor, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.GapCondExample, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.IsSplitGaussChars, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.ProIsoAt, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.TranslateMemIndOrder, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.ValNeBot]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

