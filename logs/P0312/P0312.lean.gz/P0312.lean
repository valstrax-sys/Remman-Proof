import Lean
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.FiniteOfIsClosedSplitTorusOfPowEqOne
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.IsOpenImmersionSpMapOfIsDiscreteValuationRing
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.IsUnitNatCastSections
import Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.ChainLemmaMultivariatePowerSeriesCoordinateFormStatement
import Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.DeterminantPairingQuotientValuationLowerBoundStatement
import Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.DropLevelsBasic
import Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.EvSelfTwo
import Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.LeWeightOfCoeffPow
import Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.MulFlowValLe
import Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.ParametersSmallBound
import Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.WeightNonnegExpOfWeightGeInvPrimeSubOneStatement
import Development.AbelianVarietyTheory.PublishedTheorems.AdelicLattices₂.ExistsFiniteRepresentatives
import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.ExistsUniqueHcharOfFiniteOrder
import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.ExplChi
import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.ExplZeta
import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.IsExcRat
import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.Jutila
import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.LogDerOne
import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.PageThm
import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.QuadraticHeckeZeroEstimates
import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.ZeroCount
import Development.AbelianVarietyTheory.PublishedTheorems.Divisors₂.CmCurveGoodOutsidePrimePremises
import Development.AbelianVarietyTheory.PublishedTheorems.Divisors₂.FormalAlgebraisation
import Development.AbelianVarietyTheory.PublishedTheorems.Divisors₂.IrreducibleAdmissibleGL
import Development.AbelianVarietyTheory.PublishedTheorems.Divisors₂.StandardFunctorsFiniteLength
import Development.AbelianVarietyTheory.PublishedTheorems.Divisors₂.TranslationInv
import Development.AbelianVarietyTheory.PublishedTheorems.GaloisGeometry₂.HoweDualityGL
import Development.AbelianVarietyTheory.PublishedTheorems.GaloisGeometry₂.HypothesesAbsDet
import Development.AbelianVarietyTheory.PublishedTheorems.PublishedFoundations.GreenSeriesSt
import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.HasFiniteLengthOfFiniteDimensional
import Development.AbelianVarietyTheory.Statements.PlaceShiftStatements.SpecGood
import Development.AutomorphicArithmetic.AdelicQuotients.AdelicGLSplitEquiv
import Development.AutomorphicArithmetic.AdelicQuotients.CentralizerCommutativeOfSeparableCharpoly
import Development.AutomorphicArithmetic.AdelicQuotients.CharpolySeparableUnitSmul
import Development.AutomorphicArithmetic.AdelicQuotients.EulerProductOfQuotientPushforwardSupport
import Development.AutomorphicArithmetic.AdelicQuotients.EulerProductSupportFinite
import Development.AutomorphicArithmetic.AdelicQuotients.ExistsHaarMeasureAdelicGL
import Development.AutomorphicArithmetic.AdelicQuotients.GeometricSideAbsolutelyConvergentOfEulerFubini
import Development.AutomorphicArithmetic.AdelicQuotients.HaarUnimodularCriterion
import Development.AutomorphicArithmetic.AdelicQuotients.LocalUnimodularOfExistsHaarMeasure
import Development.AutomorphicArithmetic.AdelicQuotients.OrbitalIntegralFubini
import Development.AutomorphicArithmetic.AdelicQuotients.QuotientHaarMeasurePushforward
import Development.AutomorphicArithmetic.AdelicQuotients.QuotientMeasureSplit
import Development.AutomorphicArithmetic.AdelicQuotients.RestrictedProductCentralizerAdelicGL
import Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.DetBound
import Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.ImportsMore
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCmPatch
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCotLoc
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCotOfQuot
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCplFin
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCplFlat
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCplReg
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaDetChartPrime
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaDetDim
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaDvrIc
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaMvpsCot
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.ConnectedPrimeFields.Adjoin
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.ConnectedPrimeFields.LimitPowMem
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.Expand
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.FormRep
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.InjTest
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.IrrOpenDet
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.OElRep
import Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.StarDet

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.UnitaryExistence.FiniteOfIsClosedSplitTorusOfPowEqOne, `Development.AbelianVarietyTheory.Proofs.UnitaryExistence.IsOpenImmersionSpMapOfIsDiscreteValuationRing, `Development.AbelianVarietyTheory.Proofs.UnitaryExistence.IsUnitNatCastSections, `Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.ChainLemmaMultivariatePowerSeriesCoordinateFormStatement, `Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.DeterminantPairingQuotientValuationLowerBoundStatement, `Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.DropLevelsBasic, `Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.EvSelfTwo, `Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.LeWeightOfCoeffPow, `Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.MulFlowValLe, `Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.ParametersSmallBound, `Development.AbelianVarietyTheory.Proofs.UnramifiedDepth.WeightNonnegExpOfWeightGeInvPrimeSubOneStatement, `Development.AbelianVarietyTheory.PublishedTheorems.AdelicLattices₂.ExistsFiniteRepresentatives, `Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.ExistsUniqueHcharOfFiniteOrder, `Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.ExplChi, `Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.ExplZeta, `Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.IsExcRat, `Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.Jutila, `Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.LogDerOne, `Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.PageThm, `Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.QuadraticHeckeZeroEstimates, `Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.ZeroCount, `Development.AbelianVarietyTheory.PublishedTheorems.Divisors₂.CmCurveGoodOutsidePrimePremises, `Development.AbelianVarietyTheory.PublishedTheorems.Divisors₂.FormalAlgebraisation, `Development.AbelianVarietyTheory.PublishedTheorems.Divisors₂.IrreducibleAdmissibleGL, `Development.AbelianVarietyTheory.PublishedTheorems.Divisors₂.StandardFunctorsFiniteLength, `Development.AbelianVarietyTheory.PublishedTheorems.Divisors₂.TranslationInv, `Development.AbelianVarietyTheory.PublishedTheorems.GaloisGeometry₂.HoweDualityGL, `Development.AbelianVarietyTheory.PublishedTheorems.GaloisGeometry₂.HypothesesAbsDet, `Development.AbelianVarietyTheory.PublishedTheorems.PublishedFoundations.GreenSeriesSt, `Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.HasFiniteLengthOfFiniteDimensional, `Development.AbelianVarietyTheory.Statements.PlaceShiftStatements.SpecGood, `Development.AutomorphicArithmetic.AdelicQuotients.AdelicGLSplitEquiv, `Development.AutomorphicArithmetic.AdelicQuotients.CentralizerCommutativeOfSeparableCharpoly, `Development.AutomorphicArithmetic.AdelicQuotients.CharpolySeparableUnitSmul, `Development.AutomorphicArithmetic.AdelicQuotients.EulerProductOfQuotientPushforwardSupport, `Development.AutomorphicArithmetic.AdelicQuotients.EulerProductSupportFinite, `Development.AutomorphicArithmetic.AdelicQuotients.ExistsHaarMeasureAdelicGL, `Development.AutomorphicArithmetic.AdelicQuotients.GeometricSideAbsolutelyConvergentOfEulerFubini, `Development.AutomorphicArithmetic.AdelicQuotients.HaarUnimodularCriterion, `Development.AutomorphicArithmetic.AdelicQuotients.LocalUnimodularOfExistsHaarMeasure, `Development.AutomorphicArithmetic.AdelicQuotients.OrbitalIntegralFubini, `Development.AutomorphicArithmetic.AdelicQuotients.QuotientHaarMeasurePushforward, `Development.AutomorphicArithmetic.AdelicQuotients.QuotientMeasureSplit, `Development.AutomorphicArithmetic.AdelicQuotients.RestrictedProductCentralizerAdelicGL, `Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.DetBound, `Development.AutomorphicArithmetic.AutomorphicVarieties.AdditiveValuationNorms.ImportsMore, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCmPatch, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCotLoc, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCotOfQuot, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCplFin, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCplFlat, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaCplReg, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaDetChartPrime, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaDetDim, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaDvrIc, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.CaMvpsCot, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.ConnectedPrimeFields.Adjoin, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.ConnectedPrimeFields.LimitPowMem, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.Expand, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.FormRep, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.InjTest, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.IrrOpenDet, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.OElRep, `Development.AutomorphicArithmetic.AutomorphicVarieties.AlgebraTools.DeterminantRepresentations.StarDet]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

