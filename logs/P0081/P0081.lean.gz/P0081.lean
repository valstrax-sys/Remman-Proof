import Lean
import GroundTheory.AutomorphicForms.HarishChandraCentre.Symmetric
import GroundTheory.AutomorphicForms.HilbertSchmidt
import GroundTheory.AutomorphicForms.LocallyProfinite
import GroundTheory.AutomorphicForms.PartialDifferential.AnalyticHypoSeries
import GroundTheory.AutomorphicForms.PartialDifferential.Sobolev
import GroundTheory.AutomorphicForms.QuadraticConj
import GroundTheory.AutomorphicForms.RealGroupsHaar
import GroundTheory.AutomorphicForms.RealGroupsLie
import GroundTheory.AutomorphicForms.ReductionBlock
import GroundTheory.AutomorphicForms.RestrictedHaarProduct
import GroundTheory.AutomorphicForms.SphericalLaurent
import GroundTheory.AutomorphicForms.StableConjCyclic
import GroundTheory.AutomorphicForms.StrongApproximationSLElementary
import GroundTheory.AutomorphicForms.TensorProductTheorem.MatrixCoeff
import GroundTheory.AutomorphicForms.TensorProductTheorem.Operators
import GroundTheory.AutomorphicForms.TensorProductTheorem.PeterssonComplement
import GroundTheory.AutomorphicForms.UnitaryRepresentations.IsInvariantIffCommuteStarProjection
import GroundTheory.AutomorphicForms.WhittakerRelevance
import GroundTheory.Brauer.CrossedProduct
import GroundTheory.Brauer.MulDistribMulActionQuotientFixedPoints
import GroundTheory.Brauer.TensorSimple
import GroundTheory.FunctionField.PlaceDefs
import GroundTheory.GlobalFields.Adele.IntegersLattice
import GroundTheory.GlobalFields.Adele.WeakApprox
import GroundTheory.GlobalFields.AnalyticClassNumber.QuadraticHurwitzZero
import GroundTheory.GlobalFields.Artin.IsProjEigenspaceNegOneOfMulSelfEqOne
import GroundTheory.GlobalFields.Artin.LogCharpoly
import GroundTheory.GlobalFields.ComplexMultiplication.AnalyticAlgebraicGerm
import GroundTheory.GlobalFields.ComplexMultiplication.EllipticFunctions
import GroundTheory.GlobalFields.ComplexMultiplication.ExistsRingEquivExtendOfIsTranscendenceBasis
import GroundTheory.GlobalFields.ComplexMultiplication.PrimeLocalization
import GroundTheory.GlobalFields.ComplexMultiplication.RectangleIntegral
import GroundTheory.GlobalFields.ComplexMultiplication.Residue
import GroundTheory.GlobalFields.ComplexMultiplication.VariableChangePoints
import GroundTheory.GlobalFields.CyclotomicCharacters.Frobenius
import GroundTheory.GlobalFields.HerbrandQuotients.RationalForm
import GroundTheory.GlobalFields.IdeleGroups.IndexProductFormula
import GroundTheory.GlobalFields.IdeleGroups.InfiniteProjInfiniteEmbeddingOfNe
import GroundTheory.GlobalFields.KummerTheory.Unramified
import GroundTheory.GlobalFields.LocalAtPlace
import GroundTheory.GlobalFields.SUnitsKernel
import GroundTheory.GlobalFields.SemilocalAlgebras.Approximation
import GroundTheory.GlobalFields.SemilocalAlgebras.ContinuousCompletionMap
import GroundTheory.GlobalFields.SemilocalAlgebras.Infinite
import GroundTheory.GlobalFields.TateThesis.AdeleMeasurable
import GroundTheory.GlobalFields.TateThesis.ArchChars
import GroundTheory.GlobalFields.TateThesis.DegreeOnePrimes
import GroundTheory.GlobalFields.TateThesis.Gaussian
import GroundTheory.GlobalFields.TateThesis.GaussianSchwartz
import GroundTheory.GlobalFields.TateThesis.LatticePoissonBasic
import GroundTheory.GlobalFields.TateThesis.NoSmallSubgroups
import GroundTheory.HeightsAndTheta.Heights.Antisymmetric.Statements
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ChartGramSchur
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ReducedTensorPerfect
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.Statements
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsAreaMultiplicityWeight
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsKernelProjMeasurable
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsLocalSectionLengthSum
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsPiQuotCokerFiniteLength
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsTrdegAdjoinLe
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsTrdegBaseAlgebraic
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsZeroLocusDimH
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ZeroLocusDimHAlg
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ZeroLocusDimHGeo

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.AutomorphicForms.HarishChandraCentre.Symmetric, `GroundTheory.AutomorphicForms.HilbertSchmidt, `GroundTheory.AutomorphicForms.LocallyProfinite, `GroundTheory.AutomorphicForms.PartialDifferential.AnalyticHypoSeries, `GroundTheory.AutomorphicForms.PartialDifferential.Sobolev, `GroundTheory.AutomorphicForms.QuadraticConj, `GroundTheory.AutomorphicForms.RealGroupsHaar, `GroundTheory.AutomorphicForms.RealGroupsLie, `GroundTheory.AutomorphicForms.ReductionBlock, `GroundTheory.AutomorphicForms.RestrictedHaarProduct, `GroundTheory.AutomorphicForms.SphericalLaurent, `GroundTheory.AutomorphicForms.StableConjCyclic, `GroundTheory.AutomorphicForms.StrongApproximationSLElementary, `GroundTheory.AutomorphicForms.TensorProductTheorem.MatrixCoeff, `GroundTheory.AutomorphicForms.TensorProductTheorem.Operators, `GroundTheory.AutomorphicForms.TensorProductTheorem.PeterssonComplement, `GroundTheory.AutomorphicForms.UnitaryRepresentations.IsInvariantIffCommuteStarProjection, `GroundTheory.AutomorphicForms.WhittakerRelevance, `GroundTheory.Brauer.CrossedProduct, `GroundTheory.Brauer.MulDistribMulActionQuotientFixedPoints, `GroundTheory.Brauer.TensorSimple, `GroundTheory.FunctionField.PlaceDefs, `GroundTheory.GlobalFields.Adele.IntegersLattice, `GroundTheory.GlobalFields.Adele.WeakApprox, `GroundTheory.GlobalFields.AnalyticClassNumber.QuadraticHurwitzZero, `GroundTheory.GlobalFields.Artin.IsProjEigenspaceNegOneOfMulSelfEqOne, `GroundTheory.GlobalFields.Artin.LogCharpoly, `GroundTheory.GlobalFields.ComplexMultiplication.AnalyticAlgebraicGerm, `GroundTheory.GlobalFields.ComplexMultiplication.EllipticFunctions, `GroundTheory.GlobalFields.ComplexMultiplication.ExistsRingEquivExtendOfIsTranscendenceBasis, `GroundTheory.GlobalFields.ComplexMultiplication.PrimeLocalization, `GroundTheory.GlobalFields.ComplexMultiplication.RectangleIntegral, `GroundTheory.GlobalFields.ComplexMultiplication.Residue, `GroundTheory.GlobalFields.ComplexMultiplication.VariableChangePoints, `GroundTheory.GlobalFields.CyclotomicCharacters.Frobenius, `GroundTheory.GlobalFields.HerbrandQuotients.RationalForm, `GroundTheory.GlobalFields.IdeleGroups.IndexProductFormula, `GroundTheory.GlobalFields.IdeleGroups.InfiniteProjInfiniteEmbeddingOfNe, `GroundTheory.GlobalFields.KummerTheory.Unramified, `GroundTheory.GlobalFields.LocalAtPlace, `GroundTheory.GlobalFields.SUnitsKernel, `GroundTheory.GlobalFields.SemilocalAlgebras.Approximation, `GroundTheory.GlobalFields.SemilocalAlgebras.ContinuousCompletionMap, `GroundTheory.GlobalFields.SemilocalAlgebras.Infinite, `GroundTheory.GlobalFields.TateThesis.AdeleMeasurable, `GroundTheory.GlobalFields.TateThesis.ArchChars, `GroundTheory.GlobalFields.TateThesis.DegreeOnePrimes, `GroundTheory.GlobalFields.TateThesis.Gaussian, `GroundTheory.GlobalFields.TateThesis.GaussianSchwartz, `GroundTheory.GlobalFields.TateThesis.LatticePoissonBasic, `GroundTheory.GlobalFields.TateThesis.NoSmallSubgroups, `GroundTheory.HeightsAndTheta.Heights.Antisymmetric.Statements, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ChartGramSchur, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ReducedTensorPerfect, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.Statements, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsAreaMultiplicityWeight, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsKernelProjMeasurable, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsLocalSectionLengthSum, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsPiQuotCokerFiniteLength, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsTrdegAdjoinLe, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsTrdegBaseAlgebraic, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsZeroLocusDimH, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ZeroLocusDimHAlg, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ZeroLocusDimHGeo]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

