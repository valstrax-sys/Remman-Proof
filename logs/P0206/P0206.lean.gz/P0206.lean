import Lean
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeSumDecayBoundStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LaurentEqToLaurentSubInvert
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LevelSquareCongruenceConjugation
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LieAlgebraOfTangentCurveStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralComplexPowerFinite
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralLinearChangeVariablesComplex
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralPowerLineScaling
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalFiniteAlgebraJacobsonRadical
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalizationPreservesClosednessStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MeetOverHypersurfaceOfGerm
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MemIdempotentComplementIffStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MonomialCoefficientComparisonStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MulEqZeroOfCPowMemSpan
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicativityFinitePlacesStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicativityInfinitePlacesStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NatCardDualEq
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NewtonPolygonSlopeExistenceStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NoetherNormalizationHomogeneousStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormCentralizerIdentification
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormCommutesSeparableHolds
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormFibreCardNonzero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormFibreCardZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapCongruence
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapFirstProperty
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapIntegralProperty
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapSecondProperty
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapTorusSurjective
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.OneLeDetW
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.OntoFormLawsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PairingBoundFinitePlacesStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PairingBoundInfinitePlacesStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicDoubleCosetOfEqualCorank
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicFundamentalDomainSplitStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicFundamentalDomainVolumeStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicHaarDecompositionStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicIntegralUnfoldingStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicLeviIntegralFormulaStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicQuotientMeasureStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionCoefficientSignsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionDiagonalIdentityStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PerfectFrobeniusRootSolution
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PerfectTensorProduct
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PfOfIsCompl
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PolynomialRootsOfClosedQuotientStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PositivityStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PowerDivisibilityRootExtractionStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PqLift
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdLeftEqRTensor
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdPairSumsEqSumPowersetScoreStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.QuadraticBoxIntegralSmallBallStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.QuadraticBoxVolumeBoundStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationAddStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationCupProductStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationFunctorialStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationSmulStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationUniqueStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationUnitClassStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ReductionCorankEqRankLowerLeft
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ReductionUniqueUpToParabolic
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RegularizedExponentialSumStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ResidueAlgebraUnramified
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ResidueUpperUnipotentLift
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzFourierTransformMatrixStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ScoreRigidityPermEqOneStatement

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeSumDecayBoundStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LaurentEqToLaurentSubInvert, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LevelSquareCongruenceConjugation, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LieAlgebraOfTangentCurveStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralComplexPowerFinite, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralLinearChangeVariablesComplex, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralPowerLineScaling, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalFiniteAlgebraJacobsonRadical, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalizationPreservesClosednessStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MeetOverHypersurfaceOfGerm, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MemIdempotentComplementIffStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MonomialCoefficientComparisonStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MulEqZeroOfCPowMemSpan, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicativityFinitePlacesStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicativityInfinitePlacesStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NatCardDualEq, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NewtonPolygonSlopeExistenceStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NoetherNormalizationHomogeneousStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormCentralizerIdentification, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormCommutesSeparableHolds, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormFibreCardNonzero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormFibreCardZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapCongruence, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapFirstProperty, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapIntegralProperty, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapSecondProperty, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapTorusSurjective, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.OneLeDetW, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.OntoFormLawsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PairingBoundFinitePlacesStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PairingBoundInfinitePlacesStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicDoubleCosetOfEqualCorank, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicFundamentalDomainSplitStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicFundamentalDomainVolumeStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicHaarDecompositionStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicIntegralUnfoldingStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicLeviIntegralFormulaStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicQuotientMeasureStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionCoefficientSignsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionDiagonalIdentityStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PerfectFrobeniusRootSolution, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PerfectTensorProduct, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PfOfIsCompl, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PolynomialRootsOfClosedQuotientStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PositivityStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PowerDivisibilityRootExtractionStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PqLift, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdLeftEqRTensor, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdPairSumsEqSumPowersetScoreStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.QuadraticBoxIntegralSmallBallStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.QuadraticBoxVolumeBoundStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationAddStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationCupProductStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationFunctorialStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationSmulStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationUniqueStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RealizationUnitClassStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ReductionCorankEqRankLowerLeft, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ReductionUniqueUpToParabolic, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RegularizedExponentialSumStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ResidueAlgebraUnramified, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ResidueUpperUnipotentLift, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzFourierTransformMatrixStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ScoreRigidityPermEqOneStatement]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

