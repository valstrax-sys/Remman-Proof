import Lean
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PMultAtOfSaturated
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PRepresentative
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialQuotDim
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSupSpanMultiHomog
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PVerticalDivisorsCommute
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.SpanTwoIsPrimeRelevant
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsBridge
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsBundles
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsPairNumberRelabel
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsVerticalComponentFibre
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.Objects
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.SymbolExtensionProperty
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PDegPolyEvalX
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PFramePlaneGraph
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PMassBound
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.ResidueChartModel
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.StFrameImplicitGraph
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.StJacobianRankGeneric
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.TorsionAverage
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.VanishingCechMultInvariants
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.VanishingCechResidue
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.ContractBlocksSplitPrime
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PHilbExactDivide
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PIntNumBase
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PIntNumBaseChange
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PPFContracted
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PPNProduct
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PRenameIntNum
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PRenameMultiHomog
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PRenameMultiProjPrime
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsContractRelDimLe
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsDegreeBound
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsDivPushForward
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsDivSupport
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsNegDimZero
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.AssemblySympl
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.ImportsExtra
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.ImportsRest
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PLocallyPrincipalCoprime
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutCaseCompare
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutCaseDecomp
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutCaseSharp
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutCompare
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutCompareReal
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutFlagKillsIdeal
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutHomDecomp
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutIKillsIdeal
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutIdealSum
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutLieFirst
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutLieLast
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutPrimeEq
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutPsiFlag
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutRealSyzygy
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutRestHom
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutStairHom
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutStairNonzero
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutTermEq
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutTransportFirst
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutTransportLast
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutTransportPsum
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestTop
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartEnergyCocycle
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartEnergyDiagonal
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartEnergyIntegrable

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PMultAtOfSaturated, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PRepresentative, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialQuotDim, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSupSpanMultiHomog, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PVerticalDivisorsCommute, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.SpanTwoIsPrimeRelevant, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsBridge, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsBundles, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsPairNumberRelabel, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsVerticalComponentFibre, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.Objects, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.SymbolExtensionProperty, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PDegPolyEvalX, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PFramePlaneGraph, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PMassBound, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.ResidueChartModel, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.StFrameImplicitGraph, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.StJacobianRankGeneric, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.TorsionAverage, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.VanishingCechMultInvariants, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.VanishingCechResidue, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.ContractBlocksSplitPrime, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PHilbExactDivide, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PIntNumBase, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PIntNumBaseChange, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PPFContracted, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PPNProduct, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PRenameIntNum, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PRenameMultiHomog, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PRenameMultiProjPrime, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsContractRelDimLe, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsDegreeBound, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsDivPushForward, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsDivSupport, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsNegDimZero, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.AssemblySympl, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.ImportsExtra, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.ImportsRest, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PLocallyPrincipalCoprime, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutCaseCompare, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutCaseDecomp, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutCaseSharp, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutCompare, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutCompareReal, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutFlagKillsIdeal, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutHomDecomp, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutIKillsIdeal, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutIdealSum, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutLieFirst, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutLieLast, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutPrimeEq, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutPsiFlag, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutRealSyzygy, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutRestHom, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutStairHom, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutStairNonzero, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutTermEq, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutTransportFirst, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutTransportLast, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestCutTransportPsum, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRestTop, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartEnergyCocycle, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartEnergyDiagonal, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartEnergyIntegrable]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

