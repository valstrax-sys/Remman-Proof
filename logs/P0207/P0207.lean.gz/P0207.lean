import Lean
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ScoreTZeroEqLevelCountStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionInvarianceCosetSumStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionLawHoldsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionOrthogonalIdempotentSumStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionOverIdempotentPropertiesStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SeparableNormCommuting
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShuffleOfPermStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShufflePermFlattenStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShuffleWeightSquareLengthLtStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SmoothSpreadsOutStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SmulMemRangeLTensorOfLTensorEqZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.StagedEstimateHoldsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SurjectivePreservesClosednessComparabilityStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorEvalFixedOfFixedStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorIdealMapInjective
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TorsQuot
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TraceDiagonalBlockConjugateFormulaStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingBasisEvalStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingFrobeniusCompatStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingGaloisEquivariantStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingLTensorNaturalityStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingSmulDualStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingSmulLeftStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TransferOfSectionAndWallLaws
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TwistOfSectionLaw
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TwistedJacquetExactSmooth
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TwoUnif
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UniformBoundednessStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnipotentHeckeFourthProperty
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitFundamentalLemmaFirstHolds
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitFundamentalLemmaSecondHolds
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedDualFamilyHolds
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedExtensionIntegralBasis
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedQuotientCard
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ValuationOfLocalDichotomy
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ValuationPowerIffStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VandermondeSquaresStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VecCloseOfKerBasicColSq
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VecInnerOfKerBasic
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VecLimOf
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VecNormOfVecClose
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WallLawOfSectionLawStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WedgeBoundFinitePlacesStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WedgeBoundInfinitePlacesStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WedgeSubspaceBoundStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WeylDenominatorProductStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WpPf
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.ArithFunctionalLipschitzWeights
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.DominantPartialSumBounds
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.ExistsFlagDegreeOnePolys
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreeSymmetries
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreeWeightFormula
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagShiftTotalLinRootPowerStatement
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.PolarizationPolynomialCoeffBound
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.AntisymmetricPerturbationHolds
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.BaseChangePointsCompat
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.BtOrderComapHom
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.BtOrderEqTopOfEtale
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.DerRingInjective
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.DiscriminantValuationDifferent
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.EigenComponentMapCompat
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.EpiRingHomFieldClosureStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsDenominatorRegular
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsLieModelStatement

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ScoreTZeroEqLevelCountStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionInvarianceCosetSumStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionLawHoldsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionOrthogonalIdempotentSumStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SectionOverIdempotentPropertiesStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SeparableNormCommuting, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShuffleOfPermStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShufflePermFlattenStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShuffleWeightSquareLengthLtStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SmoothSpreadsOutStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SmulMemRangeLTensorOfLTensorEqZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.StagedEstimateHoldsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SurjectivePreservesClosednessComparabilityStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorEvalFixedOfFixedStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorIdealMapInjective, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TorsQuot, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TraceDiagonalBlockConjugateFormulaStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingBasisEvalStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingFrobeniusCompatStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingGaloisEquivariantStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingLTensorNaturalityStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingSmulDualStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TracePairingSmulLeftStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TransferOfSectionAndWallLaws, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TwistOfSectionLaw, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TwistedJacquetExactSmooth, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TwoUnif, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UniformBoundednessStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnipotentHeckeFourthProperty, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitFundamentalLemmaFirstHolds, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitFundamentalLemmaSecondHolds, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedDualFamilyHolds, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedExtensionIntegralBasis, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedQuotientCard, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ValuationOfLocalDichotomy, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ValuationPowerIffStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VandermondeSquaresStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VecCloseOfKerBasicColSq, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VecInnerOfKerBasic, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VecLimOf, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VecNormOfVecClose, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WallLawOfSectionLawStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WedgeBoundFinitePlacesStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WedgeBoundInfinitePlacesStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WedgeSubspaceBoundStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WeylDenominatorProductStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WpPf, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.ArithFunctionalLipschitzWeights, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.DominantPartialSumBounds, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.ExistsFlagDegreeOnePolys, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreeSymmetries, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreeWeightFormula, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagShiftTotalLinRootPowerStatement, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.PolarizationPolynomialCoeffBound, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.AntisymmetricPerturbationHolds, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.BaseChangePointsCompat, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.BtOrderComapHom, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.BtOrderEqTopOfEtale, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.DerRingInjective, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.DiscriminantValuationDifferent, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.EigenComponentMapCompat, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.EpiRingHomFieldClosureStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsDenominatorRegular, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsLieModelStatement]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

