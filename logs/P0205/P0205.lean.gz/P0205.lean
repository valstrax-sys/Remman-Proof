import Lean
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetSeriesSummableShiftedStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CvAdjEqAvg
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DetWBlockMatrixFormula
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DetWEqNormSqDetOneAddI
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DichotomyOfComparableModSquare
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DisintegrationInjectiveOpenMap
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DividedPowerMorphismCompatibleStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DividedPowerQuotientExists
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DominantComponentsOfGerm
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EisensteinScalingLaw
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EqZeroOfLeSmall
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EventuallyHaarDetEqOneNearOneStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsBaseChangeEquiv
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCommonOrderedForm
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsConstOfRhoEq
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsPderivNotDvd
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsRealizationOfCompatibleStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsScaledNontrivialCharacter
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExponentialDecayByMidpoints
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExponentialFourierIntegralBound
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExteriorPowerSplit
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteDimensionalFixedTensor
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteModuleAdicComplete
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteSupportConvolutionTriple
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteSupportProductQuotient
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FinsumCosetSmulLinear
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FixedNondeg
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FourierInversionProd
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FrobeniusPowerSolutionLiftStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FundamentalDomainFibrationVolumeStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussianTubeTransformBound
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussianTubeTransformContinuous
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HaarMeasureIwasawaModularCharacter
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HaarMeasureSemidirectProductFormula
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HasDerivAtTwistHomotopyKernel
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HeckeSumInvariant
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HeckeThirdProperty
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HeightBoundStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HeightLipschitzHoldsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HenselPolynomialRefinement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianCountFromHyperplanes
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianHaarBlockDecomposition
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianMatricesCard
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianSpaceAnisotropicUnit
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HilbertSchmidtNormSubmultiplicativeStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HolomorphicParameterIntegralGaussianBoundStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HolomorphicSeriesUniformTubeStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IdempotentLocalInductionStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IdempotentLocalizationDichotomy
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IdentityTubeHoldsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IntegersBoundedArchimedeanCountStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IntegralLocalizationAwayInRingStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InverseTransformContinuous
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsOpenCharacterAnnihilator
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsOpenIsCompactPrincipal
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsProperSpreadsOutStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsUnitOneAddJacobsonTensor
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IteratedDerivIntegralGaussianExponentialStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IwahoriOrbitalComparison
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IwasawaDecompositionStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.KerClose
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeFirstProperty
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeFourthProperty
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeSecondProperty

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetSeriesSummableShiftedStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CvAdjEqAvg, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DetWBlockMatrixFormula, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DetWEqNormSqDetOneAddI, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DichotomyOfComparableModSquare, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DisintegrationInjectiveOpenMap, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DividedPowerMorphismCompatibleStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DividedPowerQuotientExists, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DominantComponentsOfGerm, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EisensteinScalingLaw, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EqZeroOfLeSmall, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EventuallyHaarDetEqOneNearOneStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsBaseChangeEquiv, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCommonOrderedForm, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsConstOfRhoEq, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsPderivNotDvd, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsRealizationOfCompatibleStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsScaledNontrivialCharacter, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExponentialDecayByMidpoints, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExponentialFourierIntegralBound, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExteriorPowerSplit, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteDimensionalFixedTensor, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteModuleAdicComplete, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteSupportConvolutionTriple, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteSupportProductQuotient, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FinsumCosetSmulLinear, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FixedNondeg, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FourierInversionProd, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FrobeniusPowerSolutionLiftStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FundamentalDomainFibrationVolumeStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussianTubeTransformBound, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussianTubeTransformContinuous, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HaarMeasureIwasawaModularCharacter, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HaarMeasureSemidirectProductFormula, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HasDerivAtTwistHomotopyKernel, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HeckeSumInvariant, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HeckeThirdProperty, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HeightBoundStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HeightLipschitzHoldsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HenselPolynomialRefinement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianCountFromHyperplanes, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianHaarBlockDecomposition, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianMatricesCard, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianSpaceAnisotropicUnit, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HilbertSchmidtNormSubmultiplicativeStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HolomorphicParameterIntegralGaussianBoundStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HolomorphicSeriesUniformTubeStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IdempotentLocalInductionStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IdempotentLocalizationDichotomy, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IdentityTubeHoldsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IntegersBoundedArchimedeanCountStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IntegralLocalizationAwayInRingStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InverseTransformContinuous, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsOpenCharacterAnnihilator, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsOpenIsCompactPrincipal, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsProperSpreadsOutStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsUnitOneAddJacobsonTensor, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IteratedDerivIntegralGaussianExponentialStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IwahoriOrbitalComparison, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IwasawaDecompositionStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.KerClose, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeFirstProperty, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeFourthProperty, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeSecondProperty]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

