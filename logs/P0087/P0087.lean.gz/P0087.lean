import Lean
import GroundTheory.ProfiniteCohomology.RestrictedRamification.SPicDefs
import GroundTheory.ProfiniteCohomology.RestrictedRamification.ValuationTransport
import GroundTheory.ProfiniteCohomology.Supernatural
import GroundTheory.ProfiniteCohomology.TorsionDualDefs
import GroundTheory.TateCohomology.CoindOne
import GroundTheory.TateCohomology.ConjAction
import GroundTheory.TateCohomology.CupCochains
import GroundTheory.TateCohomology.DeltaMap
import GroundTheory.TateCohomology.DiagonalSuccIsoFreeInvSingle
import GroundTheory.TateCohomology.DoubleCosetSum
import GroundTheory.TateCohomology.HerbrandAbstract
import GroundTheory.TateCohomology.Induced
import GroundTheory.TateCohomology.ModuleHomologyData
import GroundTheory.TateCohomology.PGroupFixed
import GroundTheory.TateCohomology.TateAddEquivAbelianizationTateClass
import Lemmata.AddValuationProducts.AddValProd
import Lemmata.B110.ExistsMoved
import Lemmata.B1962s.FreeLat
import Lemmata.Cancellation.EnnrealVolumeRatioStepCancel
import Lemmata.CofiniteContinuousBounds.LeOfCofinite
import Lemmata.ComplementLifts.ComplLift
import Lemmata.CurryModusPonens.CurryMp
import Lemmata.Denominators.Denom
import Lemmata.DiscreteValuationQuotients.LenQuotSpan
import Lemmata.FiberEquations.FiberEq
import Lemmata.FirstBlockLemmaA.Imports
import Lemmata.FirstBlockLemmaB.Imports
import Lemmata.FirstBlockLemmaC.Imports
import Lemmata.FirstBlockLemmaD.Imports
import Lemmata.FirstBlockLemmaE.Imports
import Lemmata.FirstBlockLemmaF.Imports
import Lemmata.FirstBlockLemmaG.Imports
import Lemmata.FirstBlockLemmaH.Imports
import Lemmata.FirstBlockLemmaI.Imports
import Lemmata.FirstBlockLemmaJ.Imports
import Lemmata.FirstBlockLemmaK.Imports
import Lemmata.FirstBlockLemmaL.Imports
import Lemmata.FunctionAtZero.FZero
import Lemmata.GeneralBFact.Imports
import Lemmata.GeneralBFactAltForm.Imports
import Lemmata.GeneralBFactBis.Imports
import Lemmata.GeneralBFactBisAlt.Imports
import Lemmata.GeneralBFactBisForm.Imports
import Lemmata.GeneralBFactExtra.Imports
import Lemmata.GeneralBFactForm.Imports
import Lemmata.GeneralBFactFurther.Imports
import Lemmata.GeneralBFactLast.Imports
import Lemmata.GeneralBFactLeft.Imports
import Lemmata.GeneralBFactLeftBis.Imports
import Lemmata.GeneralBFactLeftBisAlt.Imports
import Lemmata.GeneralBFactLeftExtra.Imports
import Lemmata.GeneralBFactLeftForm.Imports
import Lemmata.GeneralBFactLeftLast.Pz
import Lemmata.GeneralBFactLeftMore.Imports
import Lemmata.GeneralBFactLeftRest.Imports
import Lemmata.GeneralBFactLeftSide.Imports
import Lemmata.GeneralBFactLeftTail.Imports
import Lemmata.GeneralBFactLeftTer.Imports
import Lemmata.GeneralBFactLeftTerForm.Imports
import Lemmata.GeneralBFactLeftVariant.Imports
import Lemmata.GeneralBFactMore.Imports
import Lemmata.GeneralBFactRest.Imports
import Lemmata.GeneralBFactRight.Imports
import Lemmata.GeneralBFactRightAlt.Imports

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.ProfiniteCohomology.RestrictedRamification.SPicDefs, `GroundTheory.ProfiniteCohomology.RestrictedRamification.ValuationTransport, `GroundTheory.ProfiniteCohomology.Supernatural, `GroundTheory.ProfiniteCohomology.TorsionDualDefs, `GroundTheory.TateCohomology.CoindOne, `GroundTheory.TateCohomology.ConjAction, `GroundTheory.TateCohomology.CupCochains, `GroundTheory.TateCohomology.DeltaMap, `GroundTheory.TateCohomology.DiagonalSuccIsoFreeInvSingle, `GroundTheory.TateCohomology.DoubleCosetSum, `GroundTheory.TateCohomology.HerbrandAbstract, `GroundTheory.TateCohomology.Induced, `GroundTheory.TateCohomology.ModuleHomologyData, `GroundTheory.TateCohomology.PGroupFixed, `GroundTheory.TateCohomology.TateAddEquivAbelianizationTateClass, `Lemmata.AddValuationProducts.AddValProd, `Lemmata.B110.ExistsMoved, `Lemmata.B1962s.FreeLat, `Lemmata.Cancellation.EnnrealVolumeRatioStepCancel, `Lemmata.CofiniteContinuousBounds.LeOfCofinite, `Lemmata.ComplementLifts.ComplLift, `Lemmata.CurryModusPonens.CurryMp, `Lemmata.Denominators.Denom, `Lemmata.DiscreteValuationQuotients.LenQuotSpan, `Lemmata.FiberEquations.FiberEq, `Lemmata.FirstBlockLemmaA.Imports, `Lemmata.FirstBlockLemmaB.Imports, `Lemmata.FirstBlockLemmaC.Imports, `Lemmata.FirstBlockLemmaD.Imports, `Lemmata.FirstBlockLemmaE.Imports, `Lemmata.FirstBlockLemmaF.Imports, `Lemmata.FirstBlockLemmaG.Imports, `Lemmata.FirstBlockLemmaH.Imports, `Lemmata.FirstBlockLemmaI.Imports, `Lemmata.FirstBlockLemmaJ.Imports, `Lemmata.FirstBlockLemmaK.Imports, `Lemmata.FirstBlockLemmaL.Imports, `Lemmata.FunctionAtZero.FZero, `Lemmata.GeneralBFact.Imports, `Lemmata.GeneralBFactAltForm.Imports, `Lemmata.GeneralBFactBis.Imports, `Lemmata.GeneralBFactBisAlt.Imports, `Lemmata.GeneralBFactBisForm.Imports, `Lemmata.GeneralBFactExtra.Imports, `Lemmata.GeneralBFactForm.Imports, `Lemmata.GeneralBFactFurther.Imports, `Lemmata.GeneralBFactLast.Imports, `Lemmata.GeneralBFactLeft.Imports, `Lemmata.GeneralBFactLeftBis.Imports, `Lemmata.GeneralBFactLeftBisAlt.Imports, `Lemmata.GeneralBFactLeftExtra.Imports, `Lemmata.GeneralBFactLeftForm.Imports, `Lemmata.GeneralBFactLeftLast.Pz, `Lemmata.GeneralBFactLeftMore.Imports, `Lemmata.GeneralBFactLeftRest.Imports, `Lemmata.GeneralBFactLeftSide.Imports, `Lemmata.GeneralBFactLeftTail.Imports, `Lemmata.GeneralBFactLeftTer.Imports, `Lemmata.GeneralBFactLeftTerForm.Imports, `Lemmata.GeneralBFactLeftVariant.Imports, `Lemmata.GeneralBFactMore.Imports, `Lemmata.GeneralBFactRest.Imports, `Lemmata.GeneralBFactRight.Imports, `Lemmata.GeneralBFactRightAlt.Imports]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

