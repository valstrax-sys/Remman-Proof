import Lean
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PrecompleteOfPowLe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PreservedCoefficient
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProdE
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProdMemPow
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProdMulMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProdPrimesDvd
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProductFirstParts
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProductMap
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProjTrans
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProjectionCompact
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProjectiveCharts
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProjectiveLineOf
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PseudoDivision
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PzIffPos
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Qminor
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.QuantumMinorsCasimir
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.QuotientBasisFiniteDimensional
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.QuotientBasisFiniteModule
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RadFinAdjoinStable
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RayPrimeSpan
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RealCharacter
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RealDiff
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RegularUnitPoints
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ReprMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Reps
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RepsProd
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ResAlgClosed
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ResidueHomNorm
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RestrictedProductMeasureSet
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RieszRepresentationSesquilinear
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RightCosetSpaceCompact
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RingSec
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RootEqOne
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RootOrbit
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Saturation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SaturationByPowers
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchurIrreducible
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchurScalar
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchurTwistHolds
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.BlockTriangularLevi
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.CongruenceSubgroupHecke
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.DoubleSumReduceSecond
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.EigenvectorsSumZeroEqZero
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.EnnrealRpowTwoEqSq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.ExistsEquivInnerOfNondegenerate
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.Imports
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.IntegerSmulEqAlgebraMapSmul
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.InvNormSmulMemSphere
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.LargePrimeDivisors
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.OneAddPowMulExpLe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.PowMulExpLeHalfExp
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.PowTwoPowSubOneGrowth
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.QuotientOutRightInvariant
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzFunctionGeneration
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SectionLift
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SelectionLemmas
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SemilinearLatticeMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SeparableOfNewtonPolygon
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SeqEx
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SesquilinearFlipConj
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SetIntegralDifferentiability
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ShiftMap
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SignActionTheta
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SignatureBlockDiagonal

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PrecompleteOfPowLe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PreservedCoefficient, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProdE, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProdMemPow, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProdMulMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProdPrimesDvd, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProductFirstParts, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProductMap, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProjTrans, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProjectionCompact, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProjectiveCharts, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProjectiveLineOf, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PseudoDivision, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PzIffPos, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Qminor, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.QuantumMinorsCasimir, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.QuotientBasisFiniteDimensional, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.QuotientBasisFiniteModule, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RadFinAdjoinStable, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RayPrimeSpan, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RealCharacter, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RealDiff, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RegularUnitPoints, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ReprMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Reps, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RepsProd, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ResAlgClosed, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ResidueHomNorm, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RestrictedProductMeasureSet, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RieszRepresentationSesquilinear, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RightCosetSpaceCompact, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RingSec, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RootEqOne, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RootOrbit, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Saturation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SaturationByPowers, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchurIrreducible, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchurScalar, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchurTwistHolds, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.BlockTriangularLevi, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.CongruenceSubgroupHecke, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.DoubleSumReduceSecond, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.EigenvectorsSumZeroEqZero, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.EnnrealRpowTwoEqSq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.ExistsEquivInnerOfNondegenerate, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.Imports, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.IntegerSmulEqAlgebraMapSmul, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.InvNormSmulMemSphere, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.LargePrimeDivisors, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.OneAddPowMulExpLe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.PowMulExpLeHalfExp, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.PowTwoPowSubOneGrowth, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzBilinear.QuotientOutRightInvariant, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SchwartzFunctionGeneration, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SectionLift, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SelectionLemmas, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SemilinearLatticeMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SeparableOfNewtonPolygon, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SeqEx, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SesquilinearFlipConj, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SetIntegralDifferentiability, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ShiftMap, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SignActionTheta, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SignatureBlockDiagonal]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

