import Lean
import Formalism.HermitianCurvature.HermitianCurvatureProofs.SmoothDecayOfWeighted
import Formalism.HermitianCurvature.HermitianCurvatureProofs.StationaryPhaseModel
import Formalism.HermitianCurvature.HermitianCurvatureProofs.TopDegreePolynomials
import Formalism.HermitianCurvature.HermitianCurvatureProofs.TripleForm
import Formalism.HermitianCurvature.HermitianCurvatureProofs.WeakApproximationGL
import Formalism.HermitianCurvature.HermitianCurvatureProofs.WhittakerVanishingImpliesZero
import Formalism.HermitianCurvature.HermitianCurvatureProofs.WordMonicExtraction
import Formalism.HermitianCurvature.LowerBlockNormalisedBoundFromComponents
import Formalism.HermitianCurvature.MemParahoricTimesPrincipalCongruenceIff
import Formalism.HermitianCurvature.StatementTA
import Formalism.HermitianCurvature.StatementTB
import Formalism.HermitianCurvature.StatementW
import Formalism.HermitianCurvature.ThetaExistenceInductiveFromPieces
import Formalism.HermitianLattices.StatementLat
import Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.TheoremBEntryFormula
import Formalism.IncomingBounds.FlowDegreeBounds.AltChooseSumEqZero
import Formalism.IncomingBounds.FlowDegreeBounds.BaseTermLeTopTerm
import Formalism.IncomingBounds.FlowDegreeBounds.Cayley
import Formalism.IncomingBounds.FlowDegreeBounds.LemmaF
import Formalism.IncomingBounds.FlowDegreeBounds.PadicValFactorialRatioProd
import Formalism.IncomingBounds.FlowDegreeBounds.Series
import Formalism.IncomingBounds.LemmaMNumerics
import Formalism.IncomingBounds.ValuationWindowImpliesOriginal
import Formalism.JumpKernelCokernel.Statement
import Formalism.LagrangeIdealLifts.CocyclePolynomialDivision.LagrangeIdealCyc
import Formalism.LagrangeIdealLifts.CocyclePolynomialDivision.UChase
import Formalism.LagrangeIdealLifts.CocyclePolynomialDivision.UClaim
import Formalism.LatticeRigidity.HeightMinimum.OneLeProdOfInt
import Formalism.LatticeRigidity.HeightMinimum.PowFinrankEqZeroOfTracePow
import Formalism.LatticeSlopes.LatticeSlopesProofs.CovolEqCovolume
import Formalism.LatticeSlopes.LatticeSlopesProofs.CovolPos
import Formalism.LatticeSlopes.LatticeSlopesProofs.DegQuot
import Formalism.LatticeSlopes.LatticeSlopesProofs.MuMaxAttained
import Formalism.LatticeSlopes.LatticeSlopesProofs.ShortVector
import Formalism.LatticeSlopes.LatticeSlopesProofs.SlopeInequality
import Formalism.LatticeSlopes.LatticeSlopesProofs.SlopeLeMuMaxOf
import Formalism.LatticeSlopes.LatticeSlopesProofs.SlopesBdd
import Formalism.LatticeTheta.LatticeThetaProofs.Assembly
import Formalism.LatticeTheta.LatticeThetaProofs.FundamentalDomainEqPreimage
import Formalism.LatticeTheta.LatticeThetaProofs.GaussSchwartz
import Formalism.LatticeTheta.LatticeThetaProofs.InnerDualVecBasis
import Formalism.LatticeTheta.LatticeThetaProofs.LatticeSummableDecay
import Formalism.LatticeTheta.LatticeThetaProofs.Periodization
import Formalism.LatticeTheta.LatticeThetaProofs.UnfoldCoeff
import Formalism.LocalRingCardinality.SpanPowerMembership.ExistsOmegaLeb
import Formalism.LocalToGlobal.CMDeterminantIdeals.DetIdeal
import Formalism.LocalToGlobal.CharacterGerms.NatCastMulTmul
import Formalism.LocalToGlobal.CharacterGerms.RowTiePHaLeaves
import Formalism.LocalToGlobal.GlobalTheory.BlockActions.LatSOfMem
import Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.MemClosureOfMemSS
import Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.DifferentIdeal.LineR
import Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EpsteinZeta.Homothety
import Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EpsteinZeta.IdealBasis
import Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EpsteinZeta.Jacobi
import Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EpsteinZeta.UnitsEqOneOrNegOne
import Formalism.LocalToGlobal.GroupLattices.LevelCharts.SignBlockDeterminant
import Formalism.LocalToGlobal.GroupLattices.PendingLemmas.WittFractionToCpAlgebraMap
import Formalism.LocalToGlobal.IndefiniteReal.DatumF
import Formalism.LocalToGlobal.IndefiniteReal.DoubleCosetOperators.HkCore
import Formalism.LocalToGlobal.IndefiniteReal.FinitePlaces.FourModel
import Formalism.LocalToGlobal.IndefiniteReal.HaarTransfer.MinfUnique
import Formalism.LocalToGlobal.IndefiniteReal.LevelTypeEquivalence.NormIterFderivApplyLe
import Formalism.LocalToGlobal.IndefiniteReal.LocalNormSurjectivity.MemMaxVAIff
import Formalism.LocalToGlobal.PairingIndexBounds.ModelLatticeMoves.GoodLat

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.HermitianCurvature.HermitianCurvatureProofs.SmoothDecayOfWeighted, `Formalism.HermitianCurvature.HermitianCurvatureProofs.StationaryPhaseModel, `Formalism.HermitianCurvature.HermitianCurvatureProofs.TopDegreePolynomials, `Formalism.HermitianCurvature.HermitianCurvatureProofs.TripleForm, `Formalism.HermitianCurvature.HermitianCurvatureProofs.WeakApproximationGL, `Formalism.HermitianCurvature.HermitianCurvatureProofs.WhittakerVanishingImpliesZero, `Formalism.HermitianCurvature.HermitianCurvatureProofs.WordMonicExtraction, `Formalism.HermitianCurvature.LowerBlockNormalisedBoundFromComponents, `Formalism.HermitianCurvature.MemParahoricTimesPrincipalCongruenceIff, `Formalism.HermitianCurvature.StatementTA, `Formalism.HermitianCurvature.StatementTB, `Formalism.HermitianCurvature.StatementW, `Formalism.HermitianCurvature.ThetaExistenceInductiveFromPieces, `Formalism.HermitianLattices.StatementLat, `Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.TheoremBEntryFormula, `Formalism.IncomingBounds.FlowDegreeBounds.AltChooseSumEqZero, `Formalism.IncomingBounds.FlowDegreeBounds.BaseTermLeTopTerm, `Formalism.IncomingBounds.FlowDegreeBounds.Cayley, `Formalism.IncomingBounds.FlowDegreeBounds.LemmaF, `Formalism.IncomingBounds.FlowDegreeBounds.PadicValFactorialRatioProd, `Formalism.IncomingBounds.FlowDegreeBounds.Series, `Formalism.IncomingBounds.LemmaMNumerics, `Formalism.IncomingBounds.ValuationWindowImpliesOriginal, `Formalism.JumpKernelCokernel.Statement, `Formalism.LagrangeIdealLifts.CocyclePolynomialDivision.LagrangeIdealCyc, `Formalism.LagrangeIdealLifts.CocyclePolynomialDivision.UChase, `Formalism.LagrangeIdealLifts.CocyclePolynomialDivision.UClaim, `Formalism.LatticeRigidity.HeightMinimum.OneLeProdOfInt, `Formalism.LatticeRigidity.HeightMinimum.PowFinrankEqZeroOfTracePow, `Formalism.LatticeSlopes.LatticeSlopesProofs.CovolEqCovolume, `Formalism.LatticeSlopes.LatticeSlopesProofs.CovolPos, `Formalism.LatticeSlopes.LatticeSlopesProofs.DegQuot, `Formalism.LatticeSlopes.LatticeSlopesProofs.MuMaxAttained, `Formalism.LatticeSlopes.LatticeSlopesProofs.ShortVector, `Formalism.LatticeSlopes.LatticeSlopesProofs.SlopeInequality, `Formalism.LatticeSlopes.LatticeSlopesProofs.SlopeLeMuMaxOf, `Formalism.LatticeSlopes.LatticeSlopesProofs.SlopesBdd, `Formalism.LatticeTheta.LatticeThetaProofs.Assembly, `Formalism.LatticeTheta.LatticeThetaProofs.FundamentalDomainEqPreimage, `Formalism.LatticeTheta.LatticeThetaProofs.GaussSchwartz, `Formalism.LatticeTheta.LatticeThetaProofs.InnerDualVecBasis, `Formalism.LatticeTheta.LatticeThetaProofs.LatticeSummableDecay, `Formalism.LatticeTheta.LatticeThetaProofs.Periodization, `Formalism.LatticeTheta.LatticeThetaProofs.UnfoldCoeff, `Formalism.LocalRingCardinality.SpanPowerMembership.ExistsOmegaLeb, `Formalism.LocalToGlobal.CMDeterminantIdeals.DetIdeal, `Formalism.LocalToGlobal.CharacterGerms.NatCastMulTmul, `Formalism.LocalToGlobal.CharacterGerms.RowTiePHaLeaves, `Formalism.LocalToGlobal.GlobalTheory.BlockActions.LatSOfMem, `Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.MemClosureOfMemSS, `Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.DifferentIdeal.LineR, `Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EpsteinZeta.Homothety, `Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EpsteinZeta.IdealBasis, `Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EpsteinZeta.Jacobi, `Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EpsteinZeta.UnitsEqOneOrNegOne, `Formalism.LocalToGlobal.GroupLattices.LevelCharts.SignBlockDeterminant, `Formalism.LocalToGlobal.GroupLattices.PendingLemmas.WittFractionToCpAlgebraMap, `Formalism.LocalToGlobal.IndefiniteReal.DatumF, `Formalism.LocalToGlobal.IndefiniteReal.DoubleCosetOperators.HkCore, `Formalism.LocalToGlobal.IndefiniteReal.FinitePlaces.FourModel, `Formalism.LocalToGlobal.IndefiniteReal.HaarTransfer.MinfUnique, `Formalism.LocalToGlobal.IndefiniteReal.LevelTypeEquivalence.NormIterFderivApplyLe, `Formalism.LocalToGlobal.IndefiniteReal.LocalNormSurjectivity.MemMaxVAIff, `Formalism.LocalToGlobal.PairingIndexBounds.ModelLatticeMoves.GoodLat]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

