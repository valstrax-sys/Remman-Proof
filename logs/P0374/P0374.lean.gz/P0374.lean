import Lean
import Formalism.CharacterColumnKernels.IdempotentNormalForms.SumIteLe
import Formalism.CharacterColumnKernels.StatementGC
import Formalism.CharacterColumnKernels.StatementRho
import Formalism.CoboundaryTransfers.WachBridges
import Formalism.CyclotomicNorms.NonsquarefreeBounds.IrreducibilityOfRestriction
import Formalism.DirichletDensity.Statement
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.DescentEstimateDownUp
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.Graded
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.LemmaCFull
import Formalism.DistinguishedUnitIdeals.FrobeniusCoboundedArc
import Formalism.DistinguishedUnitIdeals.PhiFreeOfBasis
import Formalism.DropLevelBounds.ConstantCoeffVanishing.UbintConstantCoeffEqZero
import Formalism.EllipticTorsion.EllipticTorsionProofs.CoefficientWeightsLemmaTwo
import Formalism.EllipticTorsion.EllipticTorsionProofs.ExistsSumPowPrimePow
import Formalism.EllipticTorsion.EllipticTorsionProofs.FormalGroupPointsHomDef
import Formalism.EllipticTorsion.EllipticTorsionProofs.FormalGroupPointsParamDef
import Formalism.FilteredPoleLength.LocalDescentLevels.LeadingTermLength
import Formalism.FilteredPoleLength.LocalDescentLevels.LevelsLengthSum
import Formalism.FilteredPoleLength.LocalDescentLevels.LocalStepExtOf
import Formalism.FlagUnipotentLattices.InterlaceBlocksW
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.BlockMinorSumCounterexample
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.GaussSumCharacterAverageBound
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.IntegrableOnIoiTruncatedPowerMoment
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.InterlacingOfBlocksSecondCase
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.NormalisationIdentity
import Formalism.FlagUnipotentLattices.StabiliserComplementDecomposition
import Formalism.FlagUnipotentLattices.ValuationProductBound
import Formalism.FormalDegreeBessel.FinalDS
import Formalism.FormalGroupWitt.FormalGroupWittProofs.CoeffExpandEqZero
import Formalism.FormalGroupWitt.FormalGroupWittProofs.CoeffV
import Formalism.FormalGroupWitt.FormalGroupWittProofs.EqSingleOfDegreeEqOne
import Formalism.FormalGroupWitt.FormalGroupWittProofs.FrobSqV
import Formalism.FormalGroupWitt.FormalGroupWittProofs.IntegralSubstVector
import Formalism.FormalGroupWitt.FormalGroupWittProofs.InvIntV
import Formalism.FormalGroupWitt.FormalGroupWittProofs.SolveV
import Formalism.FrobeniusBaseCase.FrobeniusBaseCaseProofs.BaseCaseFalseGeneralHolds
import Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.ConjReal
import Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.CoprimeTwoPow
import Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.FrobMulInertia
import Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.Galois
import Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.ThickExists
import Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.ThickFrames
import Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.ThickOrbit
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.PNTExplRectA
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsNormRepresentation
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsOrthUnitFrame
import Formalism.GL3MeanSquares.HookFormulaTorsion.DoubleCosetDecompositionAll
import Formalism.GL3MeanSquares.HookFormulaTorsion.InvariantKernelTraceVanishes
import Formalism.GL3MeanSquares.HookFormulaTorsion.LemmaCTwistRamified
import Formalism.GL3MeanSquares.InvariantSeriesBidegreeOneOne
import Formalism.GL3MeanSquares.LegendreCoefficient
import Formalism.GL3MeanSquares.OrbitPointsDistinct
import Formalism.GaloisCohomology.Statement
import Formalism.GaussJetBounds.GaussJetProofs.AsmOne
import Formalism.GaussJetBounds.GaussJetProofs.FrameCoeffMulLin
import Formalism.GaussJetBounds.GaussJetProofs.WeightsAddOverOrbits
import Formalism.GaussJetBounds.OneLetterGaussJets.OneLetterGaussProofs.CompanionTheory
import Formalism.GaussJetBounds.StatementI
import Formalism.GaussValuationBounds.NokLemmaCVal
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.BideterminantMem
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.CompDeg
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylDominanceOf
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylIntRat
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.EvalDeg

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.CharacterColumnKernels.IdempotentNormalForms.SumIteLe, `Formalism.CharacterColumnKernels.StatementGC, `Formalism.CharacterColumnKernels.StatementRho, `Formalism.CoboundaryTransfers.WachBridges, `Formalism.CyclotomicNorms.NonsquarefreeBounds.IrreducibilityOfRestriction, `Formalism.DirichletDensity.Statement, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.DescentEstimateDownUp, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.Graded, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.LemmaCFull, `Formalism.DistinguishedUnitIdeals.FrobeniusCoboundedArc, `Formalism.DistinguishedUnitIdeals.PhiFreeOfBasis, `Formalism.DropLevelBounds.ConstantCoeffVanishing.UbintConstantCoeffEqZero, `Formalism.EllipticTorsion.EllipticTorsionProofs.CoefficientWeightsLemmaTwo, `Formalism.EllipticTorsion.EllipticTorsionProofs.ExistsSumPowPrimePow, `Formalism.EllipticTorsion.EllipticTorsionProofs.FormalGroupPointsHomDef, `Formalism.EllipticTorsion.EllipticTorsionProofs.FormalGroupPointsParamDef, `Formalism.FilteredPoleLength.LocalDescentLevels.LeadingTermLength, `Formalism.FilteredPoleLength.LocalDescentLevels.LevelsLengthSum, `Formalism.FilteredPoleLength.LocalDescentLevels.LocalStepExtOf, `Formalism.FlagUnipotentLattices.InterlaceBlocksW, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.BlockMinorSumCounterexample, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.GaussSumCharacterAverageBound, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.IntegrableOnIoiTruncatedPowerMoment, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.InterlacingOfBlocksSecondCase, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.NormalisationIdentity, `Formalism.FlagUnipotentLattices.StabiliserComplementDecomposition, `Formalism.FlagUnipotentLattices.ValuationProductBound, `Formalism.FormalDegreeBessel.FinalDS, `Formalism.FormalGroupWitt.FormalGroupWittProofs.CoeffExpandEqZero, `Formalism.FormalGroupWitt.FormalGroupWittProofs.CoeffV, `Formalism.FormalGroupWitt.FormalGroupWittProofs.EqSingleOfDegreeEqOne, `Formalism.FormalGroupWitt.FormalGroupWittProofs.FrobSqV, `Formalism.FormalGroupWitt.FormalGroupWittProofs.IntegralSubstVector, `Formalism.FormalGroupWitt.FormalGroupWittProofs.InvIntV, `Formalism.FormalGroupWitt.FormalGroupWittProofs.SolveV, `Formalism.FrobeniusBaseCase.FrobeniusBaseCaseProofs.BaseCaseFalseGeneralHolds, `Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.ConjReal, `Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.CoprimeTwoPow, `Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.FrobMulInertia, `Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.Galois, `Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.ThickExists, `Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.ThickFrames, `Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.ThickOrbit, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.PNTExplRectA, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsNormRepresentation, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsOrthUnitFrame, `Formalism.GL3MeanSquares.HookFormulaTorsion.DoubleCosetDecompositionAll, `Formalism.GL3MeanSquares.HookFormulaTorsion.InvariantKernelTraceVanishes, `Formalism.GL3MeanSquares.HookFormulaTorsion.LemmaCTwistRamified, `Formalism.GL3MeanSquares.InvariantSeriesBidegreeOneOne, `Formalism.GL3MeanSquares.LegendreCoefficient, `Formalism.GL3MeanSquares.OrbitPointsDistinct, `Formalism.GaloisCohomology.Statement, `Formalism.GaussJetBounds.GaussJetProofs.AsmOne, `Formalism.GaussJetBounds.GaussJetProofs.FrameCoeffMulLin, `Formalism.GaussJetBounds.GaussJetProofs.WeightsAddOverOrbits, `Formalism.GaussJetBounds.OneLetterGaussJets.OneLetterGaussProofs.CompanionTheory, `Formalism.GaussJetBounds.StatementI, `Formalism.GaussValuationBounds.NokLemmaCVal, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.BideterminantMem, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.CompDeg, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylDominanceOf, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylIntRat, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.EvalDeg]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

