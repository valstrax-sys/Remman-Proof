import Lean
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockQBilin
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockQPos
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockRowAdj
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.HWInClosed
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.PeelDecomp
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.PeelDegBound
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.PeelHomog
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.PeelLead
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.RowDivClosedGraded
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.SSYTExists
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.SSYTPeel
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.SumIcoTsubTelescope
import Formalism.GrowthSums.LemmaATwoFactList
import Formalism.HalfLinks.Statement
import Formalism.HarderNarasimhan.StatementPl
import Formalism.HermitianCurvature.HermitianCurvatureProofs.AdmissibleRecOfAdmissibleWord
import Formalism.HermitianCurvature.HermitianCurvatureProofs.AxiomsFromFamilies
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ChebyshevToThreshold
import Formalism.HermitianCurvature.HermitianCurvatureProofs.DiagScalarCommuteOfEntries
import Formalism.HermitianCurvature.HermitianCurvatureProofs.DualCovolumeChangeOfVariables
import Formalism.HermitianCurvature.HermitianCurvatureProofs.EtaleIntegralityFacts
import Formalism.HermitianCurvature.HermitianCurvatureProofs.FreeOf2RmatrixTranspose
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ImCircleIntegral
import Formalism.HermitianCurvature.HermitianCurvatureProofs.JointInstanceTheoremA
import Formalism.HermitianCurvature.HermitianCurvatureProofs.KernelQuotientFinite
import Formalism.HermitianCurvature.HermitianCurvatureProofs.LastBlockDecay
import Formalism.HermitianCurvature.HermitianCurvatureProofs.LatticeSummability
import Formalism.HermitianCurvature.HermitianCurvatureProofs.LevelSizesJointMean
import Formalism.HermitianCurvature.HermitianCurvatureProofs.LocalConditionsAndQuotientSplitting
import Formalism.HermitianCurvature.HermitianCurvatureProofs.MinusLetterFrameOfData
import Formalism.HermitianCurvature.HermitianCurvatureProofs.NormOfMemRootSetOne
import Formalism.HermitianCurvature.HermitianCurvatureProofs.OutsideSystemsBound
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PlusLetterFrameOfData
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PoissonJointFirstReduction
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PsdFormConjRewrite
import Formalism.HermitianCurvature.HermitianCurvatureProofs.QEFirstMulSecondEqSwap
import Formalism.HermitianCurvature.HermitianCurvatureProofs.RecursionGivesUniformBoundsForm
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ResidueForm
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ScalarCommuteTransposedRMatrixEntry
import Formalism.HermitianCurvature.HermitianCurvatureProofs.SixteenMulLeTwoPow
import Formalism.HermitianCurvature.HermitianCurvatureProofs.StepClaimFromStepsFull
import Formalism.HermitianCurvature.HermitianCurvatureProofs.SupremumAIsMajorant
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ThresholdBelowOne
import Formalism.HermitianCurvature.HermitianCurvatureProofs.WeightedL2BoundedMul
import Formalism.HermitianCurvature.StatementM
import Formalism.HermitianCurvature.StatementTC
import Formalism.HermitianLattices.HermitianLatticesProofs.AutFinite
import Formalism.HermitianLattices.HermitianLatticesProofs.ClassSetAssembly
import Formalism.HermitianLattices.HermitianLatticesProofs.GenusScale
import Formalism.HermitianLattices.HermitianLatticesProofs.MajLattice
import Formalism.HermitianLattices.HermitianLatticesProofs.NeighbourConstruct
import Formalism.HermitianLattices.HermitianLatticesProofs.OpBound
import Formalism.HermitianLattices.HermitianLatticesProofs.TraceReal
import Formalism.HermitianLattices.StatementMass
import Formalism.HermitianLattices.ThetaLEuclid
import Formalism.HyperbolicPlaceProducts.SecondLevelArithmeticNorm
import Formalism.JumpKernelCokernel.JumpShiftProofs.RowDJoint
import Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.ExistsLocalZeroExpansionOfBound
import Formalism.LatticeSlopes.ExistsSaturatedSlopeEqMuMax
import Formalism.LatticeTheta.ThetaShiftInversion
import Formalism.LocalRingCardinality.Params
import Formalism.LocalRingCardinality.SpanPowerMembership.NDLocB
import Formalism.LocalRingCardinality.SpanPowerMembership.SignSplitEquivInl
import Formalism.LocalToGlobal.CMDeterminantIdeals.CMIdealValuations.AbsNormSpanGalois

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockQBilin, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockQPos, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockRowAdj, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.HWInClosed, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.PeelDecomp, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.PeelDegBound, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.PeelHomog, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.PeelLead, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.RowDivClosedGraded, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.SSYTExists, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.SSYTPeel, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.SumIcoTsubTelescope, `Formalism.GrowthSums.LemmaATwoFactList, `Formalism.HalfLinks.Statement, `Formalism.HarderNarasimhan.StatementPl, `Formalism.HermitianCurvature.HermitianCurvatureProofs.AdmissibleRecOfAdmissibleWord, `Formalism.HermitianCurvature.HermitianCurvatureProofs.AxiomsFromFamilies, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ChebyshevToThreshold, `Formalism.HermitianCurvature.HermitianCurvatureProofs.DiagScalarCommuteOfEntries, `Formalism.HermitianCurvature.HermitianCurvatureProofs.DualCovolumeChangeOfVariables, `Formalism.HermitianCurvature.HermitianCurvatureProofs.EtaleIntegralityFacts, `Formalism.HermitianCurvature.HermitianCurvatureProofs.FreeOf2RmatrixTranspose, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ImCircleIntegral, `Formalism.HermitianCurvature.HermitianCurvatureProofs.JointInstanceTheoremA, `Formalism.HermitianCurvature.HermitianCurvatureProofs.KernelQuotientFinite, `Formalism.HermitianCurvature.HermitianCurvatureProofs.LastBlockDecay, `Formalism.HermitianCurvature.HermitianCurvatureProofs.LatticeSummability, `Formalism.HermitianCurvature.HermitianCurvatureProofs.LevelSizesJointMean, `Formalism.HermitianCurvature.HermitianCurvatureProofs.LocalConditionsAndQuotientSplitting, `Formalism.HermitianCurvature.HermitianCurvatureProofs.MinusLetterFrameOfData, `Formalism.HermitianCurvature.HermitianCurvatureProofs.NormOfMemRootSetOne, `Formalism.HermitianCurvature.HermitianCurvatureProofs.OutsideSystemsBound, `Formalism.HermitianCurvature.HermitianCurvatureProofs.PlusLetterFrameOfData, `Formalism.HermitianCurvature.HermitianCurvatureProofs.PoissonJointFirstReduction, `Formalism.HermitianCurvature.HermitianCurvatureProofs.PsdFormConjRewrite, `Formalism.HermitianCurvature.HermitianCurvatureProofs.QEFirstMulSecondEqSwap, `Formalism.HermitianCurvature.HermitianCurvatureProofs.RecursionGivesUniformBoundsForm, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ResidueForm, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ScalarCommuteTransposedRMatrixEntry, `Formalism.HermitianCurvature.HermitianCurvatureProofs.SixteenMulLeTwoPow, `Formalism.HermitianCurvature.HermitianCurvatureProofs.StepClaimFromStepsFull, `Formalism.HermitianCurvature.HermitianCurvatureProofs.SupremumAIsMajorant, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ThresholdBelowOne, `Formalism.HermitianCurvature.HermitianCurvatureProofs.WeightedL2BoundedMul, `Formalism.HermitianCurvature.StatementM, `Formalism.HermitianCurvature.StatementTC, `Formalism.HermitianLattices.HermitianLatticesProofs.AutFinite, `Formalism.HermitianLattices.HermitianLatticesProofs.ClassSetAssembly, `Formalism.HermitianLattices.HermitianLatticesProofs.GenusScale, `Formalism.HermitianLattices.HermitianLatticesProofs.MajLattice, `Formalism.HermitianLattices.HermitianLatticesProofs.NeighbourConstruct, `Formalism.HermitianLattices.HermitianLatticesProofs.OpBound, `Formalism.HermitianLattices.HermitianLatticesProofs.TraceReal, `Formalism.HermitianLattices.StatementMass, `Formalism.HermitianLattices.ThetaLEuclid, `Formalism.HyperbolicPlaceProducts.SecondLevelArithmeticNorm, `Formalism.JumpKernelCokernel.JumpShiftProofs.RowDJoint, `Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.ExistsLocalZeroExpansionOfBound, `Formalism.LatticeSlopes.ExistsSaturatedSlopeEqMuMax, `Formalism.LatticeTheta.ThetaShiftInversion, `Formalism.LocalRingCardinality.Params, `Formalism.LocalRingCardinality.SpanPowerMembership.NDLocB, `Formalism.LocalRingCardinality.SpanPowerMembership.SignSplitEquivInl, `Formalism.LocalToGlobal.CMDeterminantIdeals.CMIdealValuations.AbsNormSpanGalois]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

