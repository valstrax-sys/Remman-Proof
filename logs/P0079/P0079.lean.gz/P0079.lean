import Lean
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.ExistsGLLatBasisOfIsSplitEquiv
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.ExistsSumPadicValIntWindowEq
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.Imports
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.InvSubOneSqLeInv
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.LeValOneAddPowSub
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.SmulEqZeroOfAevalProd
import Formalism.SharpRestriction.LevelLetterCocycles.StageStep
import Formalism.SharpRestriction.LevelLetterCocycles.SumSubEqSumIocOfSub
import Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.InertiaGaloisSymmetry.KcPair
import Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.InertiaGaloisSymmetry.RdArith
import Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.InertiaGaloisSymmetry.RdDiff
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.CardOfIsFiniteLength
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.EulerVanishingBelowDimension
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LiftInvariantsFinrankEq
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.ScaledValuations.ScaleEps
import Formalism.SizeWindowBrackets.ClaimGaFree
import Formalism.SizeWindowBrackets.CutFailsForRSubmodule
import Formalism.SizeWindowBrackets.RealSlopeBoundsSplit
import Formalism.SizeWindowBrackets.TraceSquareAndDiagBounds
import Formalism.SmithDeterminants.StatementDVR
import Formalism.SmithDeterminants.StatementGram
import Formalism.SobolevGaussianKernels.StatementCS
import Formalism.SobolevGaussianKernels.StatementEI
import Formalism.SobolevGaussianKernels.StatementLF
import Formalism.SobolevGaussianKernels.StatementMV
import Formalism.SobolevGaussianKernels.StatementNC
import Formalism.SobolevGaussianKernels.StatementSB
import Formalism.Statement
import Formalism.SubspaceCounting.Statement
import Formalism.SubspaceCounting.StatementB
import Formalism.SubspaceCounting.StatementW
import Formalism.SuccessiveMinima.StatementMink
import Formalism.SuccessiveMinima.StatementNP
import Formalism.TameInertiaTowers.StatementGroup
import Formalism.ThetaLogCoordinates.BihomogeneousPairs.LetterChainEmbeddings.ScalSum
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.DefsObj
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.DualWeylProofs.QkDetExpand
import Formalism.ThetaLogCoordinates.JacobiPathWeights.DefsCol
import Formalism.ThetaLogCoordinates.JacobiPathWeights.DetLetters
import Formalism.ThetaLogCoordinates.ProductIdealMonotone.ParamDefs
import Formalism.ThetaLogCoordinates.ResidueClassEstimates.Letters
import Formalism.ThetaLogCoordinates.ResidueClassEstimates.StatementL
import Formalism.ThetaLogCoordinates.ResidueClassEstimates.StatementN
import Formalism.ThetaLogCoordinates.TraceIsometryWeights.DivStable
import Formalism.TowerValuationBounds.HermitianSumValuationBound
import Formalism.TowerValuationBounds.TowerValuationBoundIndexed
import Formalism.TranslateCocycles.Statement
import Formalism.TranslateCocycles.StatementCEStep
import Formalism.TranslateCocycles.StatementHC
import Formalism.TranslateCocycles.StatementNet
import Formalism.TruncatedSeriesCounting.LengthQuotientLeOfPowSMul
import Formalism.UnipotentAdelicQuotients.BruhatFunctionExistsVariant
import Formalism.UnipotentAdelicQuotients.CharRealisedOverRootsOfUnity
import Formalism.UnipotentAdelicQuotients.ClassNumberFinite
import Formalism.UnipotentAdelicQuotients.ClassNumberQuad
import Formalism.UnipotentAdelicQuotients.CuspEllipticValues
import Formalism.UnipotentAdelicQuotients.CuspidalCharExists
import Formalism.UnipotentAdelicQuotients.CyclicNormPrinciple
import Formalism.UnipotentAdelicQuotients.EllReg
import Formalism.UnipotentAdelicQuotients.FinOrdValGen
import Formalism.UnipotentAdelicQuotients.GlobalNormIndexTwo
import Formalism.UnipotentAdelicQuotients.GordanCones
import Formalism.UnipotentAdelicQuotients.HaarProductClosedCompact
import Formalism.UnipotentAdelicQuotients.JetMomFound

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.ExistsGLLatBasisOfIsSplitEquiv, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.ExistsSumPadicValIntWindowEq, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.Imports, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.InvSubOneSqLeInv, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.LeValOneAddPowSub, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.SmulEqZeroOfAevalProd, `Formalism.SharpRestriction.LevelLetterCocycles.StageStep, `Formalism.SharpRestriction.LevelLetterCocycles.SumSubEqSumIocOfSub, `Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.InertiaGaloisSymmetry.KcPair, `Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.InertiaGaloisSymmetry.RdArith, `Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.InertiaGaloisSymmetry.RdDiff, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.CardOfIsFiniteLength, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.EulerVanishingBelowDimension, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LiftInvariantsFinrankEq, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.ScaledValuations.ScaleEps, `Formalism.SizeWindowBrackets.ClaimGaFree, `Formalism.SizeWindowBrackets.CutFailsForRSubmodule, `Formalism.SizeWindowBrackets.RealSlopeBoundsSplit, `Formalism.SizeWindowBrackets.TraceSquareAndDiagBounds, `Formalism.SmithDeterminants.StatementDVR, `Formalism.SmithDeterminants.StatementGram, `Formalism.SobolevGaussianKernels.StatementCS, `Formalism.SobolevGaussianKernels.StatementEI, `Formalism.SobolevGaussianKernels.StatementLF, `Formalism.SobolevGaussianKernels.StatementMV, `Formalism.SobolevGaussianKernels.StatementNC, `Formalism.SobolevGaussianKernels.StatementSB, `Formalism.Statement, `Formalism.SubspaceCounting.Statement, `Formalism.SubspaceCounting.StatementB, `Formalism.SubspaceCounting.StatementW, `Formalism.SuccessiveMinima.StatementMink, `Formalism.SuccessiveMinima.StatementNP, `Formalism.TameInertiaTowers.StatementGroup, `Formalism.ThetaLogCoordinates.BihomogeneousPairs.LetterChainEmbeddings.ScalSum, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.DefsObj, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.DualWeylProofs.QkDetExpand, `Formalism.ThetaLogCoordinates.JacobiPathWeights.DefsCol, `Formalism.ThetaLogCoordinates.JacobiPathWeights.DetLetters, `Formalism.ThetaLogCoordinates.ProductIdealMonotone.ParamDefs, `Formalism.ThetaLogCoordinates.ResidueClassEstimates.Letters, `Formalism.ThetaLogCoordinates.ResidueClassEstimates.StatementL, `Formalism.ThetaLogCoordinates.ResidueClassEstimates.StatementN, `Formalism.ThetaLogCoordinates.TraceIsometryWeights.DivStable, `Formalism.TowerValuationBounds.HermitianSumValuationBound, `Formalism.TowerValuationBounds.TowerValuationBoundIndexed, `Formalism.TranslateCocycles.Statement, `Formalism.TranslateCocycles.StatementCEStep, `Formalism.TranslateCocycles.StatementHC, `Formalism.TranslateCocycles.StatementNet, `Formalism.TruncatedSeriesCounting.LengthQuotientLeOfPowSMul, `Formalism.UnipotentAdelicQuotients.BruhatFunctionExistsVariant, `Formalism.UnipotentAdelicQuotients.CharRealisedOverRootsOfUnity, `Formalism.UnipotentAdelicQuotients.ClassNumberFinite, `Formalism.UnipotentAdelicQuotients.ClassNumberQuad, `Formalism.UnipotentAdelicQuotients.CuspEllipticValues, `Formalism.UnipotentAdelicQuotients.CuspidalCharExists, `Formalism.UnipotentAdelicQuotients.CyclicNormPrinciple, `Formalism.UnipotentAdelicQuotients.EllReg, `Formalism.UnipotentAdelicQuotients.FinOrdValGen, `Formalism.UnipotentAdelicQuotients.GlobalNormIndexTwo, `Formalism.UnipotentAdelicQuotients.GordanCones, `Formalism.UnipotentAdelicQuotients.HaarProductClosedCompact, `Formalism.UnipotentAdelicQuotients.JetMomFound]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

