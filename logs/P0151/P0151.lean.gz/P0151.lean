import Lean
import Formalism.NormUnitaryBounds.DetPolynomialWeights.NatDegreeAevalLe
import Formalism.NormUnitaryBounds.DetPolynomialWeights.NormMul
import Formalism.NormUnitaryBounds.DetPolynomialWeights.NormUnitary
import Formalism.NormUnitaryBounds.DetPolynomialWeights.ShearCoefficients
import Formalism.NormUnitaryBounds.DetPolynomialWeights.ShearHypothesisTwo
import Formalism.PadicSubsetSums.CentralIdempotents.ArchimedeanComponents
import Formalism.PadicSubsetSums.CentralIdempotents.FactorOverLocalSubalgebraMonic
import Formalism.PadicSubsetSums.CentralIdempotents.GaloisConjCentralIdempotent
import Formalism.PadicSubsetSums.CentralIdempotents.GaloisIrreducibility
import Formalism.PadicSubsetSums.StableGradedCounts.CharpolyFactorAnnihilator
import Formalism.PadicSubsetSums.StableGradedCounts.ContinuousCoeffCharpolyRev
import Formalism.PadicSubsetSums.StableGradedCounts.FactorOverLocalSubalgebra
import Formalism.PadicSubsetSums.StableGradedCounts.LiftingTheExponent
import Formalism.PadicSubsetSums.StableGradedCounts.PadicDigits
import Formalism.PadicSubsetSums.StableGradedCounts.PadicValCardGL
import Formalism.PadicSubsetSums.StableGradedCounts.TOPSgLe
import Formalism.PadicSubsetSums.StableGradedCounts.TOPSgRange
import Formalism.PadicSubsetSums.StableGradedCounts.ZBrauerNesbittAlg
import Formalism.PadicSubsetSums.StableGradedCounts.ZCircleCharExtends
import Formalism.PadicSubsetSums.StableGradedCounts.ZGoodCuspidal
import Formalism.PeriodIntegrals.AreaLat
import Formalism.PeriodIntegrals.BallQuotLen
import Formalism.PeriodIntegrals.DSExist
import Formalism.PeriodIntegrals.DiscrNe
import Formalism.PeriodIntegrals.EagonNorthcottSpec
import Formalism.PeriodIntegrals.EagonNorthcottZ
import Formalism.PeriodIntegrals.EfRankSum
import Formalism.PeriodIntegrals.FinOrdAd
import Formalism.PeriodIntegrals.HCFdeg
import Formalism.PeriodIntegrals.HCMult
import Formalism.PeriodIntegrals.HeisMul
import Formalism.PeriodIntegrals.HeisNorm
import Formalism.PeriodIntegrals.HeisPull
import Formalism.PeriodIntegrals.IdealLattice
import Formalism.PeriodIntegrals.InvSerSub
import Formalism.PeriodIntegrals.IsLowUnitH
import Formalism.PeriodIntegrals.JointBlockShapes.JointShape
import Formalism.PeriodIntegrals.KFinSmooth
import Formalism.PeriodIntegrals.MinkowskiQ
import Formalism.PeriodIntegrals.NablaSpans.MinorProdSpanHasCompl
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PhNormLimit
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PhProdConv
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SumAntidiagonalTuple
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.WedgeDetNz
import Formalism.PeriodIntegrals.PhEven
import Formalism.PeriodIntegrals.QuotSetU
import Formalism.PeriodIntegrals.SelfDualOfDiff
import Formalism.PeriodIntegrals.SigmaStarEx
import Formalism.PeriodIntegrals.SigmaStarUniq
import Formalism.PeriodIntegrals.SqfDivDeg
import Formalism.PeriodIntegrals.SqfPrimeFactor
import Formalism.PeriodIntegrals.SqfRootShift
import Formalism.PeriodIntegrals.SqfRootsInj
import Formalism.PeriodIntegrals.SwSand
import Formalism.PeriodIntegrals.SymDist
import Formalism.PeriodIntegrals.ThGDefs
import Formalism.PeriodIntegrals.ThetaNormCM
import Formalism.PeriodIntegrals.TransInvLat
import Formalism.PeriodIntegrals.UnitaryApproxFin
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdditiveIntegralGroups.GuLine
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicClassFiniteness.ExistsBoundedMultiplier
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicIndexEquality.InertGen
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdicCompactDensity.ExistsNatLocal
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdicIntegersCompact.IsCompactAdicCompletionIntegers

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.NormUnitaryBounds.DetPolynomialWeights.NatDegreeAevalLe, `Formalism.NormUnitaryBounds.DetPolynomialWeights.NormMul, `Formalism.NormUnitaryBounds.DetPolynomialWeights.NormUnitary, `Formalism.NormUnitaryBounds.DetPolynomialWeights.ShearCoefficients, `Formalism.NormUnitaryBounds.DetPolynomialWeights.ShearHypothesisTwo, `Formalism.PadicSubsetSums.CentralIdempotents.ArchimedeanComponents, `Formalism.PadicSubsetSums.CentralIdempotents.FactorOverLocalSubalgebraMonic, `Formalism.PadicSubsetSums.CentralIdempotents.GaloisConjCentralIdempotent, `Formalism.PadicSubsetSums.CentralIdempotents.GaloisIrreducibility, `Formalism.PadicSubsetSums.StableGradedCounts.CharpolyFactorAnnihilator, `Formalism.PadicSubsetSums.StableGradedCounts.ContinuousCoeffCharpolyRev, `Formalism.PadicSubsetSums.StableGradedCounts.FactorOverLocalSubalgebra, `Formalism.PadicSubsetSums.StableGradedCounts.LiftingTheExponent, `Formalism.PadicSubsetSums.StableGradedCounts.PadicDigits, `Formalism.PadicSubsetSums.StableGradedCounts.PadicValCardGL, `Formalism.PadicSubsetSums.StableGradedCounts.TOPSgLe, `Formalism.PadicSubsetSums.StableGradedCounts.TOPSgRange, `Formalism.PadicSubsetSums.StableGradedCounts.ZBrauerNesbittAlg, `Formalism.PadicSubsetSums.StableGradedCounts.ZCircleCharExtends, `Formalism.PadicSubsetSums.StableGradedCounts.ZGoodCuspidal, `Formalism.PeriodIntegrals.AreaLat, `Formalism.PeriodIntegrals.BallQuotLen, `Formalism.PeriodIntegrals.DSExist, `Formalism.PeriodIntegrals.DiscrNe, `Formalism.PeriodIntegrals.EagonNorthcottSpec, `Formalism.PeriodIntegrals.EagonNorthcottZ, `Formalism.PeriodIntegrals.EfRankSum, `Formalism.PeriodIntegrals.FinOrdAd, `Formalism.PeriodIntegrals.HCFdeg, `Formalism.PeriodIntegrals.HCMult, `Formalism.PeriodIntegrals.HeisMul, `Formalism.PeriodIntegrals.HeisNorm, `Formalism.PeriodIntegrals.HeisPull, `Formalism.PeriodIntegrals.IdealLattice, `Formalism.PeriodIntegrals.InvSerSub, `Formalism.PeriodIntegrals.IsLowUnitH, `Formalism.PeriodIntegrals.JointBlockShapes.JointShape, `Formalism.PeriodIntegrals.KFinSmooth, `Formalism.PeriodIntegrals.MinkowskiQ, `Formalism.PeriodIntegrals.NablaSpans.MinorProdSpanHasCompl, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PhNormLimit, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PhProdConv, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SumAntidiagonalTuple, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.WedgeDetNz, `Formalism.PeriodIntegrals.PhEven, `Formalism.PeriodIntegrals.QuotSetU, `Formalism.PeriodIntegrals.SelfDualOfDiff, `Formalism.PeriodIntegrals.SigmaStarEx, `Formalism.PeriodIntegrals.SigmaStarUniq, `Formalism.PeriodIntegrals.SqfDivDeg, `Formalism.PeriodIntegrals.SqfPrimeFactor, `Formalism.PeriodIntegrals.SqfRootShift, `Formalism.PeriodIntegrals.SqfRootsInj, `Formalism.PeriodIntegrals.SwSand, `Formalism.PeriodIntegrals.SymDist, `Formalism.PeriodIntegrals.ThGDefs, `Formalism.PeriodIntegrals.ThetaNormCM, `Formalism.PeriodIntegrals.TransInvLat, `Formalism.PeriodIntegrals.UnitaryApproxFin, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdditiveIntegralGroups.GuLine, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicClassFiniteness.ExistsBoundedMultiplier, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicIndexEquality.InertGen, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdicCompactDensity.ExistsNatLocal, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdicIntegersCompact.IsCompactAdicCompletionIntegers]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

