import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreimageEqOfFiniteAppLE
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreirreducibleSpaceFibreHypersurfaceSpectrumIff
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreirreducibleSpaceTensorOfPullback
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreirreducibleTensorLocalizationAway
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrescribedValuationDifferenceElements
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrimaryTorsionDivisibleAndTorsionEqIdealTorsion
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrimitiveElementCoordinatePolynomials
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrimitiveElementDenominatorClearing
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrimitiveElementFiniteAlgebraic
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrimitiveVectorQuadraticLevelMeasure
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdArgRealUnitEqOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdClassGroupMk0EqOfLinearEquivPi
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdFourMapsEqOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdHomeoSymmApplySnd
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdIoiSubEqAntisymmMonomial
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdOfFnEqSingle
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdRpowDecayIsBigOCocompact
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdZpowAdd
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdZpowMul
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProjectiveBaseChangeOfPresentationMatrixSplit
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProjectiveCharZeroTensorRingOfIntegers
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProperMapBumpFunctionExists
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PsumSmul
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PullbackResidueFieldsGenerate
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PushoutResidueLinearIndependent
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QActMSubAlgebraMap
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuotientFlatOfCompletionFlat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuotientHaarMeasureNormal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuotientIntegralEquivariantComplex
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuotientRetractPiQuotientOfSummand
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RTensorInjectiveOfPowSmulEqBot
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RadicalEltMovingDualToMajorant
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RamificationIdxDvdOfGaloisDegreeDvdUnitDvr
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RamificationLeCardOfSpan
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RangeComapIncludeRightField
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RankLeOfGrowthInRadius
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RationalFunctionalTraceRepresentation
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RationalMatrixIdentityTransferToComplexMap
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReDetRelation
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReGt
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RealAlgSep
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RealCompactPartitionUnity
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RealEqOfExpNegTwoPiIDivEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReducedArtinianInvolutionIdempotentSplit
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReducedFibresAlmostAllOfSeparableDedekindCurve
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReducedFiniteFreePointsSeparate
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexConjEqOfPowEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexCoprimeOfTorsion
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexISupMapEqPow
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexInfConjEqFinprodRestrictedProduct
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexMapNsmulComapEqAbsNormDet
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexUnfoldSemidirectProduct
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelSpecMapIsIsoOverBasicOpen
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RenameSwapOfEqualPartials
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RepTraceEqMulTrace
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ResidueDegreeEqInertiaDegAffineChart
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ResidueFieldAtPrimeIsSepClosedOfFiniteType
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ResidueFieldBaseChangePullback
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ResidueFieldMapSurjectiveOfMono
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ResidueNormalOfProfiniteInvariants
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RiemannSumOfOneSidedIncrements
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RightInvariantGLOfUpperTriangularRightInvariant
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RightInverseCoordinateNormalForm
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingHomDualNumberSndEqZero

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreimageEqOfFiniteAppLE, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreirreducibleSpaceFibreHypersurfaceSpectrumIff, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreirreducibleSpaceTensorOfPullback, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreirreducibleTensorLocalizationAway, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrescribedValuationDifferenceElements, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrimaryTorsionDivisibleAndTorsionEqIdealTorsion, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrimitiveElementCoordinatePolynomials, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrimitiveElementDenominatorClearing, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrimitiveElementFiniteAlgebraic, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrimitiveVectorQuadraticLevelMeasure, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdArgRealUnitEqOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdClassGroupMk0EqOfLinearEquivPi, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdFourMapsEqOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdHomeoSymmApplySnd, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdIoiSubEqAntisymmMonomial, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdOfFnEqSingle, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdRpowDecayIsBigOCocompact, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdZpowAdd, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdZpowMul, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProjectiveBaseChangeOfPresentationMatrixSplit, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProjectiveCharZeroTensorRingOfIntegers, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProperMapBumpFunctionExists, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PsumSmul, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PullbackResidueFieldsGenerate, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PushoutResidueLinearIndependent, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QActMSubAlgebraMap, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuotientFlatOfCompletionFlat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuotientHaarMeasureNormal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuotientIntegralEquivariantComplex, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuotientRetractPiQuotientOfSummand, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RTensorInjectiveOfPowSmulEqBot, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RadicalEltMovingDualToMajorant, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RamificationIdxDvdOfGaloisDegreeDvdUnitDvr, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RamificationLeCardOfSpan, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RangeComapIncludeRightField, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RankLeOfGrowthInRadius, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RationalFunctionalTraceRepresentation, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RationalMatrixIdentityTransferToComplexMap, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReDetRelation, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReGt, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RealAlgSep, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RealCompactPartitionUnity, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RealEqOfExpNegTwoPiIDivEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReducedArtinianInvolutionIdempotentSplit, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReducedFibresAlmostAllOfSeparableDedekindCurve, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReducedFiniteFreePointsSeparate, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexConjEqOfPowEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexCoprimeOfTorsion, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexISupMapEqPow, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexInfConjEqFinprodRestrictedProduct, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexMapNsmulComapEqAbsNormDet, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexUnfoldSemidirectProduct, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelSpecMapIsIsoOverBasicOpen, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RenameSwapOfEqualPartials, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RepTraceEqMulTrace, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ResidueDegreeEqInertiaDegAffineChart, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ResidueFieldAtPrimeIsSepClosedOfFiniteType, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ResidueFieldBaseChangePullback, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ResidueFieldMapSurjectiveOfMono, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ResidueNormalOfProfiniteInvariants, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RiemannSumOfOneSidedIncrements, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RightInvariantGLOfUpperTriangularRightInvariant, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RightInverseCoordinateNormalForm, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingHomDualNumberSndEqZero]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

