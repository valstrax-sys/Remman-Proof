import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LineChernProductSumStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LineGramCurvatureAllFormulaStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LineGramCurvatureFormulaStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalDensityBoundNearPoint
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalMaximumPrincipleWeightFiniteMvPolynomialStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationIntegralClosureEquiv
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationNormalizationRootAdjoinIsDVRStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocallyQuasiFiniteOfUniqueGeomPointsStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogDerOneHolds
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogNormSqHolomorphicDdcZeroStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogisticFactorMem
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapEisensteinDivPeriod
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapEqZeroOfFiberIntegral
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapFrobeniusCharP
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapLinearEquivAddHaarLocalField
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MassFormulaConjugationActionStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeasurableAbsLogNormSectionStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeasurePreservingPiProdSplit
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MellinDerivativeLinearComb
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemGUIffAdjJ
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemRangeOfMonic
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemSpanValuationSubringIff
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemVarLat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MetricDeterminedByCurvatureZeroSection
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MetricRatioPeriodicConstantStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MetricTranslationPullbackFlat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MobiusInversionAffineFinrankSubspacesStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModDepthGETwoQuotientPowFreeOverRegularLocalRingStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModularFormPolynomialE4E6
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModuleFreeOfRegularOfFreeQuotientLocalStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MongeAmpereDensityBoundStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MongeAmpereExhaustionLimitStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MongeAmpereLocalIntegral
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MonicPolynomialsHaveRootsIffIntegrallyClosedAlgCStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NonemptyLinearEquivOfPiFinPowFiniteStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormCharacterUnitEqOneHeisenberg
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormCoeffIdealFamilyMapBasicOpen
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormHeckeTermDecayFourierIntegralLeStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormMulNormalisedAbsPowHalfEqOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NumberFieldToModPSquared
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OmAOneApply
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OrdL
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OriginIdealUniquePrimeOver
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicApproxAlgebraicPointStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicRingHomUniqueAdicCompleteStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PairingHarishChandraInductionCharpolyFunctionStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PartialOperatorFderivFormula
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodCharacterBoundedAwayOneStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodCharacterUniformlyAwayFromOneStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodChartUniformConstantsHalfPolydiscStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodQuadraticFormsSmoothStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PhiPullBaseComm
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluriharmonicIsRealPartHolomorphic
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluriharmonicLogGrowthExtensionStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PoincareMetricPuncturedPolydiscBoundsStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialSystemEventuallySolvableColimit
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PotentialBoundarySmoothStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreservesFilteredColimitsAddCommGrpIffElementsStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrincipalSeriesCoordinateLocallyConstantStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrincipalSeriesCoordinateNearInfinityStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrincipalSeriesZeroOfCoordinateZeroStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdRootPowerSumMapGaloisEqStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PshExtensionOffClosedSet
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PshPullbackHolomorphicStatement

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.LineChernProductSumStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LineGramCurvatureAllFormulaStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LineGramCurvatureFormulaStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalDensityBoundNearPoint, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalMaximumPrincipleWeightFiniteMvPolynomialStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationIntegralClosureEquiv, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationNormalizationRootAdjoinIsDVRStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocallyQuasiFiniteOfUniqueGeomPointsStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogDerOneHolds, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogNormSqHolomorphicDdcZeroStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogisticFactorMem, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapEisensteinDivPeriod, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapEqZeroOfFiberIntegral, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapFrobeniusCharP, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapLinearEquivAddHaarLocalField, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MassFormulaConjugationActionStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeasurableAbsLogNormSectionStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeasurePreservingPiProdSplit, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MellinDerivativeLinearComb, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemGUIffAdjJ, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemRangeOfMonic, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemSpanValuationSubringIff, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemVarLat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MetricDeterminedByCurvatureZeroSection, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MetricRatioPeriodicConstantStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MetricTranslationPullbackFlat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MobiusInversionAffineFinrankSubspacesStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModDepthGETwoQuotientPowFreeOverRegularLocalRingStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModularFormPolynomialE4E6, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModuleFreeOfRegularOfFreeQuotientLocalStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MongeAmpereDensityBoundStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MongeAmpereExhaustionLimitStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MongeAmpereLocalIntegral, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MonicPolynomialsHaveRootsIffIntegrallyClosedAlgCStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NonemptyLinearEquivOfPiFinPowFiniteStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormCharacterUnitEqOneHeisenberg, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormCoeffIdealFamilyMapBasicOpen, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormHeckeTermDecayFourierIntegralLeStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormMulNormalisedAbsPowHalfEqOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NumberFieldToModPSquared, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OmAOneApply, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OrdL, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OriginIdealUniquePrimeOver, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicApproxAlgebraicPointStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicRingHomUniqueAdicCompleteStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PairingHarishChandraInductionCharpolyFunctionStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PartialOperatorFderivFormula, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodCharacterBoundedAwayOneStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodCharacterUniformlyAwayFromOneStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodChartUniformConstantsHalfPolydiscStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodQuadraticFormsSmoothStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PhiPullBaseComm, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluriharmonicIsRealPartHolomorphic, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluriharmonicLogGrowthExtensionStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PoincareMetricPuncturedPolydiscBoundsStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialSystemEventuallySolvableColimit, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PotentialBoundarySmoothStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreservesFilteredColimitsAddCommGrpIffElementsStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrincipalSeriesCoordinateLocallyConstantStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrincipalSeriesCoordinateNearInfinityStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrincipalSeriesZeroOfCoordinateZeroStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdRootPowerSumMapGaloisEqStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PshExtensionOffClosedSet, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PshPullbackHolomorphicStatement]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

