import Lean
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GapN
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericLuDecompositionUnique
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.HBBound
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ImplicitRootAnalytic
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IntegralOverLocalizationScaled
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IotaMultiChangeOfBasisDet
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IotaMultiNeZeroOfLinIndep
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsUnitOfBasicOpenNonemptyOfUniversallyClosed
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.KaehlerBasisTower
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.KaehlerDifferentialsSpanLocal
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.KaehlerFinrankFractionField
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LinIndepDescent
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalHomCharZeroUnits
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalSubringIntegralClosureMax
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalizationKaehlerPrimeIdeal
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalizationSheafGlueModules
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalizedModuleBaseChange
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LuFactorsGenerateSameField
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.MatrixEqOfLinearIndependent
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.MaximalIdealMembershipOfLocal
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.MemSpanOfIotaMultiProportional
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.MultiplicativeDerivationRank
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.NilpotentDerivationRank
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.NonarchValuationOfPrime
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.NumberFieldMapsLocalRingUnique
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrimeIdealExtensionLocalDomain
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrimeMemIffNotUnitLocalization
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrimitiveElementPowersIndep
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ProjectiveModulesGlueCover
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SectionExtendsFromStalkPullback
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SmoothMapLocalizationCompat
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SncChartPoint
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SubspaceContainsUnit
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SurjectiveOfDualHomomorphismKernelKilled
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.AdaptedFrameOrthogonalSubspace
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.DigammaTendstoLogSubHarmonic
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.DirichletLogDerivReflectionFormula
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.FiniteDimensionalOfCompactCoercive
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.IntegralLeftVerticalLineBound
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.LocPrincipalSpan
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.NearIdentityMatrixPositiveSolution
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.RamifiedPrimeContainsDiscriminant
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.TraceIdempotentNotDivisible
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.UniqueReducedOrbitRepresentative
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.DenseHasCompactSupport
import Development.AutomorphicSpectrum.Proofs.MetricProofs.AnalyticDoublingMapLocalInverse
import Development.AutomorphicSpectrum.Proofs.MetricProofs.AnalyticGroupLawBoundedCommutator
import Development.AutomorphicSpectrum.Proofs.MetricProofs.DominatedConvergenceExhaustion
import Development.AutomorphicSpectrum.Proofs.MetricProofs.EqNegSumIicDifferences
import Development.AutomorphicSpectrum.Proofs.MetricProofs.EvalW
import Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsIsFundamentalDomainOfRelIndexNeZero
import Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsReversedTriangularFrameChange
import Development.AutomorphicSpectrum.Proofs.MetricProofs.ImLowerOnKernel
import Development.AutomorphicSpectrum.Proofs.MetricProofs.IntegralAngMeas
import Development.AutomorphicSpectrum.Proofs.MetricProofs.IsCompactSphere
import Development.AutomorphicSpectrum.Proofs.MetricProofs.IterDifferentiableOn
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LocalNormOutsideFiniteSet
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LojasiewiczInequalityAnalytic
import Development.AutomorphicSpectrum.Proofs.MetricProofs.MulVecEqZeroOfPair
import Development.AutomorphicSpectrum.Proofs.MetricProofs.ProdIicBlockDiagDetFactors
import Development.AutomorphicSpectrum.Proofs.MetricProofs.RatioSuccessiveNonzeroRegular
import Development.AutomorphicSpectrum.Proofs.MetricProofs.SiegelOfRiemann
import Development.AutomorphicSpectrum.Proofs.MetricProofs.TendstoLimUnderOfCauchyRate
import Development.AutomorphicSpectrum.Proofs.TwistedProofs.EqZeroOfForallNhds

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.GeometryProofs.GapN, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericLuDecompositionUnique, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.HBBound, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ImplicitRootAnalytic, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IntegralOverLocalizationScaled, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IotaMultiChangeOfBasisDet, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IotaMultiNeZeroOfLinIndep, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsUnitOfBasicOpenNonemptyOfUniversallyClosed, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.KaehlerBasisTower, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.KaehlerDifferentialsSpanLocal, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.KaehlerFinrankFractionField, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LinIndepDescent, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalHomCharZeroUnits, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalSubringIntegralClosureMax, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalizationKaehlerPrimeIdeal, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalizationSheafGlueModules, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalizedModuleBaseChange, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LuFactorsGenerateSameField, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.MatrixEqOfLinearIndependent, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.MaximalIdealMembershipOfLocal, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.MemSpanOfIotaMultiProportional, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.MultiplicativeDerivationRank, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.NilpotentDerivationRank, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.NonarchValuationOfPrime, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.NumberFieldMapsLocalRingUnique, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrimeIdealExtensionLocalDomain, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrimeMemIffNotUnitLocalization, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrimitiveElementPowersIndep, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ProjectiveModulesGlueCover, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.SectionExtendsFromStalkPullback, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.SmoothMapLocalizationCompat, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.SncChartPoint, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.SubspaceContainsUnit, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.SurjectiveOfDualHomomorphismKernelKilled, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.AdaptedFrameOrthogonalSubspace, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.DigammaTendstoLogSubHarmonic, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.DirichletLogDerivReflectionFormula, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.FiniteDimensionalOfCompactCoercive, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.IntegralLeftVerticalLineBound, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.LocPrincipalSpan, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.NearIdentityMatrixPositiveSolution, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.RamifiedPrimeContainsDiscriminant, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.TraceIdempotentNotDivisible, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.UniqueReducedOrbitRepresentative, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.DenseHasCompactSupport, `Development.AutomorphicSpectrum.Proofs.MetricProofs.AnalyticDoublingMapLocalInverse, `Development.AutomorphicSpectrum.Proofs.MetricProofs.AnalyticGroupLawBoundedCommutator, `Development.AutomorphicSpectrum.Proofs.MetricProofs.DominatedConvergenceExhaustion, `Development.AutomorphicSpectrum.Proofs.MetricProofs.EqNegSumIicDifferences, `Development.AutomorphicSpectrum.Proofs.MetricProofs.EvalW, `Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsIsFundamentalDomainOfRelIndexNeZero, `Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsReversedTriangularFrameChange, `Development.AutomorphicSpectrum.Proofs.MetricProofs.ImLowerOnKernel, `Development.AutomorphicSpectrum.Proofs.MetricProofs.IntegralAngMeas, `Development.AutomorphicSpectrum.Proofs.MetricProofs.IsCompactSphere, `Development.AutomorphicSpectrum.Proofs.MetricProofs.IterDifferentiableOn, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LocalNormOutsideFiniteSet, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LojasiewiczInequalityAnalytic, `Development.AutomorphicSpectrum.Proofs.MetricProofs.MulVecEqZeroOfPair, `Development.AutomorphicSpectrum.Proofs.MetricProofs.ProdIicBlockDiagDetFactors, `Development.AutomorphicSpectrum.Proofs.MetricProofs.RatioSuccessiveNonzeroRegular, `Development.AutomorphicSpectrum.Proofs.MetricProofs.SiegelOfRiemann, `Development.AutomorphicSpectrum.Proofs.MetricProofs.TendstoLimUnderOfCauchyRate, `Development.AutomorphicSpectrum.Proofs.TwistedProofs.EqZeroOfForallNhds]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

