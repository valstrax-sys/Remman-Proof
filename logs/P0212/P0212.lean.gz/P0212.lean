import Lean
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.Turan2Main
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.UbTerms
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.CardLiftUnimod
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsSubMemOfInert
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsUnitaryNear
import Formalism.GL3MeanSquares.HookFormulaTorsion.BlockOperatorNormBound
import Formalism.GL3MeanSquares.HookFormulaTorsion.ExpNegLeDivPowFour
import Formalism.GL3MeanSquares.HookFormulaTorsion.HookRowProductEqFactorial
import Formalism.GL3MeanSquares.HookFormulaTorsion.MinkowskiDivisorBound
import Formalism.GL3MeanSquares.HookFormulaTorsion.OrthogonalMinorBound
import Formalism.GL3MeanSquares.HookFormulaTorsion.PrimesInProgressionCountLowerBound
import Formalism.GL3MeanSquares.HookFormulaTorsion.SeparatedSetPackingBound
import Formalism.GL3MeanSquares.HookFormulaTorsion.SmallPrimeFactorSumBound
import Formalism.GL3MeanSquares.HookFormulaTorsion.SmoothedRemainderRealHasDerivBound
import Formalism.GL3MeanSquares.HookFormulaTorsion.SmoothedRemainderRealIntegralFormula
import Formalism.GL3MeanSquares.HookFormulaTorsion.SquareMomentFromBound
import Formalism.GL3MeanSquares.HookFormulaTorsion.SumLogFactorialRowsBounds
import Formalism.GL3MeanSquares.InverseNormLeOfIntegerInner
import Formalism.GL3MeanSquares.PrimeCountAsymptoticInProgressions
import Formalism.GaloisCohomology.StatementAlg
import Formalism.GaloisCohomology.StatementLoc
import Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.BlockBoundOfOrbits
import Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.IrredOf
import Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.LemmaAOf
import Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.NoSolvableOf
import Formalism.GaussJetBounds.GenLogInverse
import Formalism.GaussJetBounds.OneLetterGaussJets.OddLevelGainSum
import Formalism.GaussJetBounds.StatementA
import Formalism.GaussJetBounds.StatementB
import Formalism.GaussJetBounds.StatementC
import Formalism.GaussJetBounds.StatementD
import Formalism.GaussValuationBounds.GaussUnit
import Formalism.GaussValuationBounds.GaussValueContraction.ExponentSumIdentity
import Formalism.GaussValuationBounds.GaussValueContraction.SigBound
import Formalism.GaussValuationBounds.GaussValueContraction.TruncationExponentBounds
import Formalism.GaussValuationBounds.GaussValueContraction.WStepContract
import Formalism.GaussValuationBounds.KapBound3
import Formalism.GelfandTransference.HadamardGelfand.Highest
import Formalism.GradedWeylDivisibility.StatementA
import Formalism.GrowthSums.FactorialBaseGrowth.Coarse
import Formalism.GrowthSums.FactorialBaseGrowth.Harmonic
import Formalism.GrowthSums.FactorialBaseGrowth.QuadraticExponentIdentity
import Formalism.GrowthSums.StatementC
import Formalism.GrowthSums.StatementG
import Formalism.HarderNarasimhan.DegSupermodZ
import Formalism.HarderNarasimhan.StatementCor
import Formalism.HermitianCurvature.HermitianCurvatureProofs.AddedBlockKernelSupport
import Formalism.HermitianCurvature.HermitianCurvatureProofs.AntidiagMulDiagonal
import Formalism.HermitianCurvature.HermitianCurvatureProofs.BoxOne
import Formalism.HermitianCurvature.HermitianCurvatureProofs.CharacterOrthogonalityDual
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ChebyshevExtremalPolynomials
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ColumnOperationTripleForm
import Formalism.HermitianCurvature.HermitianCurvatureProofs.CorollaryAOfPropositionA
import Formalism.HermitianCurvature.HermitianCurvatureProofs.FacSuccOfNotMem
import Formalism.HermitianCurvature.HermitianCurvatureProofs.FderivDecomp
import Formalism.HermitianCurvature.HermitianCurvatureProofs.FirstKernelPropertiesOfHypotheses
import Formalism.HermitianCurvature.HermitianCurvatureProofs.FourierUniquenessMirabolic
import Formalism.HermitianCurvature.HermitianCurvatureProofs.HerglotzLowerSemicontinuous
import Formalism.HermitianCurvature.HermitianCurvatureProofs.KernelNonzeroModulusDeterminantEq
import Formalism.HermitianCurvature.HermitianCurvatureProofs.LevelGrowthBounds
import Formalism.HermitianCurvature.HermitianCurvatureProofs.OrbitalIntegralConvergesAbs
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ProductFactorBounds
import Formalism.HermitianCurvature.HermitianCurvatureProofs.RowNormSquareBounds
import Formalism.HermitianCurvature.HermitianCurvatureProofs.SecondKernelPropertyKernel

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.Turan2Main, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.UbTerms, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.CardLiftUnimod, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsSubMemOfInert, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsUnitaryNear, `Formalism.GL3MeanSquares.HookFormulaTorsion.BlockOperatorNormBound, `Formalism.GL3MeanSquares.HookFormulaTorsion.ExpNegLeDivPowFour, `Formalism.GL3MeanSquares.HookFormulaTorsion.HookRowProductEqFactorial, `Formalism.GL3MeanSquares.HookFormulaTorsion.MinkowskiDivisorBound, `Formalism.GL3MeanSquares.HookFormulaTorsion.OrthogonalMinorBound, `Formalism.GL3MeanSquares.HookFormulaTorsion.PrimesInProgressionCountLowerBound, `Formalism.GL3MeanSquares.HookFormulaTorsion.SeparatedSetPackingBound, `Formalism.GL3MeanSquares.HookFormulaTorsion.SmallPrimeFactorSumBound, `Formalism.GL3MeanSquares.HookFormulaTorsion.SmoothedRemainderRealHasDerivBound, `Formalism.GL3MeanSquares.HookFormulaTorsion.SmoothedRemainderRealIntegralFormula, `Formalism.GL3MeanSquares.HookFormulaTorsion.SquareMomentFromBound, `Formalism.GL3MeanSquares.HookFormulaTorsion.SumLogFactorialRowsBounds, `Formalism.GL3MeanSquares.InverseNormLeOfIntegerInner, `Formalism.GL3MeanSquares.PrimeCountAsymptoticInProgressions, `Formalism.GaloisCohomology.StatementAlg, `Formalism.GaloisCohomology.StatementLoc, `Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.BlockBoundOfOrbits, `Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.IrredOf, `Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.LemmaAOf, `Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.NoSolvableOf, `Formalism.GaussJetBounds.GenLogInverse, `Formalism.GaussJetBounds.OneLetterGaussJets.OddLevelGainSum, `Formalism.GaussJetBounds.StatementA, `Formalism.GaussJetBounds.StatementB, `Formalism.GaussJetBounds.StatementC, `Formalism.GaussJetBounds.StatementD, `Formalism.GaussValuationBounds.GaussUnit, `Formalism.GaussValuationBounds.GaussValueContraction.ExponentSumIdentity, `Formalism.GaussValuationBounds.GaussValueContraction.SigBound, `Formalism.GaussValuationBounds.GaussValueContraction.TruncationExponentBounds, `Formalism.GaussValuationBounds.GaussValueContraction.WStepContract, `Formalism.GaussValuationBounds.KapBound3, `Formalism.GelfandTransference.HadamardGelfand.Highest, `Formalism.GradedWeylDivisibility.StatementA, `Formalism.GrowthSums.FactorialBaseGrowth.Coarse, `Formalism.GrowthSums.FactorialBaseGrowth.Harmonic, `Formalism.GrowthSums.FactorialBaseGrowth.QuadraticExponentIdentity, `Formalism.GrowthSums.StatementC, `Formalism.GrowthSums.StatementG, `Formalism.HarderNarasimhan.DegSupermodZ, `Formalism.HarderNarasimhan.StatementCor, `Formalism.HermitianCurvature.HermitianCurvatureProofs.AddedBlockKernelSupport, `Formalism.HermitianCurvature.HermitianCurvatureProofs.AntidiagMulDiagonal, `Formalism.HermitianCurvature.HermitianCurvatureProofs.BoxOne, `Formalism.HermitianCurvature.HermitianCurvatureProofs.CharacterOrthogonalityDual, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ChebyshevExtremalPolynomials, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ColumnOperationTripleForm, `Formalism.HermitianCurvature.HermitianCurvatureProofs.CorollaryAOfPropositionA, `Formalism.HermitianCurvature.HermitianCurvatureProofs.FacSuccOfNotMem, `Formalism.HermitianCurvature.HermitianCurvatureProofs.FderivDecomp, `Formalism.HermitianCurvature.HermitianCurvatureProofs.FirstKernelPropertiesOfHypotheses, `Formalism.HermitianCurvature.HermitianCurvatureProofs.FourierUniquenessMirabolic, `Formalism.HermitianCurvature.HermitianCurvatureProofs.HerglotzLowerSemicontinuous, `Formalism.HermitianCurvature.HermitianCurvatureProofs.KernelNonzeroModulusDeterminantEq, `Formalism.HermitianCurvature.HermitianCurvatureProofs.LevelGrowthBounds, `Formalism.HermitianCurvature.HermitianCurvatureProofs.OrbitalIntegralConvergesAbs, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ProductFactorBounds, `Formalism.HermitianCurvature.HermitianCurvatureProofs.RowNormSquareBounds, `Formalism.HermitianCurvature.HermitianCurvatureProofs.SecondKernelPropertyKernel]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

