import Lean
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.TaylorDiscriminants.WickVanishing.GaugeTrans
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.TaylorDiscriminants.WickVanishing.HStable
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.TaylorDiscriminants.WickVanishing.HarmSecond
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.TaylorDiscriminants.WickVanishing.KillAddQ
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ValuationLifting.ValApprox
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.WeightedSumBounds.GeomSumRoot
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.WeightedSumBounds.LgCurvePcurve
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.WeightedSumBounds.NsmulCoprimeBijectiveCurves
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.WeightedSumBounds.PtRescaleGood
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.AnalyticVectors.Growth
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.AnalyticVectors.IteratedDerivOrbit
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.AnalyticVectors.LayerSpan
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.AnalyticVectors.Unitary
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.BochnerInequality.BigCasA
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.BochnerInequality.IsKUnitaryOfIsInfUnitary
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.BochnerInequality.Numerics
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.BochnerInequality.PositionPrependMemNoncompactPositionSubmodule
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.CasimirCoefficients.PsiExistsStatement
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.CasimirCoefficients.SignedIdentityColumns
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.DiscreteSeriesExistence.AnyAdj
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.DiscreteSeriesExistence.CFPrimeA
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.LaplaceOperators.CapelliIdentity.ColAnti
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.LaplaceOperators.InterlacingWalks.InterlacesULt
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.LaplaceOperators.InterlacingWalks.RsParLamMinus
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.LaplaceOperators.SpectralGap.VogDrop
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.RigidityTheorems.InKRealSmul
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.RigidityTheorems.IrredA
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.RigidityTheorems.MultOneA
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.CriticalExponentSucc
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.DeZeroBounds
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.LintegralInsertFiberLe
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.CARSqB
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.Resolvent
import ReciprocityTheory.ReductiveGroups.SymplecticTraces.WeylCharacters.BlockP
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.CoeffRescaleExpandOfNotDvd
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ExistsPowerMulUnitNorm
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModChebOm
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModDeltaInt
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModFacSlash
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModGBasic
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModHnf
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModJTau
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModQuadInt
import ReciprocityTheory.SemistableReduction.ApproxBasis
import ReciprocityTheory.SemistableReduction.ApproxGraphC
import ReciprocityTheory.SemistableReduction.DegAddHolds
import ReciprocityTheory.SemistableReduction.GaussExtensionAndResidueTrdegEq
import ReciprocityTheory.SemistableReduction.IntCores
import ReciprocityTheory.SemistableReduction.LogNormCoeffSubLeBlockSphereLogMean
import ReciprocityTheory.SemistableReduction.SJCoreD
import ReciprocityTheory.SemistableReduction.SemiContract
import ReciprocityTheory.SemistableReduction.SemiDegAA
import ReciprocityTheory.SemistableReduction.SemiDegBA
import ReciprocityTheory.SemistableReduction.SemiDegCD
import ReciprocityTheory.SemistableReduction.SemiDegDA
import ReciprocityTheory.SemistableReduction.SemiDegDB
import ReciprocityTheory.SemistableReduction.SemiDegE
import ReciprocityTheory.SemistableReduction.SphereTorus
import ReciprocityTheory.SemistableReduction.TorusLex
import ReciprocityTheory.SemistableReduction.TorusMeanD
import ReciprocityTheory.SemistableReduction.Unipotent
import ReciprocityTheory.ThetaQuasiPeriods.Change

open Lean Elab Command

def auditTargets : Array Name := #[`ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.TaylorDiscriminants.WickVanishing.GaugeTrans, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.TaylorDiscriminants.WickVanishing.HStable, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.TaylorDiscriminants.WickVanishing.HarmSecond, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.TaylorDiscriminants.WickVanishing.KillAddQ, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ValuationLifting.ValApprox, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.WeightedSumBounds.GeomSumRoot, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.WeightedSumBounds.LgCurvePcurve, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.WeightedSumBounds.NsmulCoprimeBijectiveCurves, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.WeightedSumBounds.PtRescaleGood, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.AnalyticVectors.Growth, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.AnalyticVectors.IteratedDerivOrbit, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.AnalyticVectors.LayerSpan, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.AnalyticVectors.Unitary, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.BochnerInequality.BigCasA, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.BochnerInequality.IsKUnitaryOfIsInfUnitary, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.BochnerInequality.Numerics, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.BochnerInequality.PositionPrependMemNoncompactPositionSubmodule, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.CasimirCoefficients.PsiExistsStatement, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.CasimirCoefficients.SignedIdentityColumns, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.DiscreteSeriesExistence.AnyAdj, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.DiscreteSeriesExistence.CFPrimeA, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.LaplaceOperators.CapelliIdentity.ColAnti, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.LaplaceOperators.InterlacingWalks.InterlacesULt, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.LaplaceOperators.InterlacingWalks.RsParLamMinus, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.LaplaceOperators.SpectralGap.VogDrop, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.RigidityTheorems.InKRealSmul, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.RigidityTheorems.IrredA, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.RigidityTheorems.MultOneA, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.CriticalExponentSucc, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.DeZeroBounds, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.LintegralInsertFiberLe, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.CARSqB, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.Resolvent, `ReciprocityTheory.ReductiveGroups.SymplecticTraces.WeylCharacters.BlockP, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.CoeffRescaleExpandOfNotDvd, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ExistsPowerMulUnitNorm, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModChebOm, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModDeltaInt, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModFacSlash, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModGBasic, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModHnf, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModJTau, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModQuadInt, `ReciprocityTheory.SemistableReduction.ApproxBasis, `ReciprocityTheory.SemistableReduction.ApproxGraphC, `ReciprocityTheory.SemistableReduction.DegAddHolds, `ReciprocityTheory.SemistableReduction.GaussExtensionAndResidueTrdegEq, `ReciprocityTheory.SemistableReduction.IntCores, `ReciprocityTheory.SemistableReduction.LogNormCoeffSubLeBlockSphereLogMean, `ReciprocityTheory.SemistableReduction.SJCoreD, `ReciprocityTheory.SemistableReduction.SemiContract, `ReciprocityTheory.SemistableReduction.SemiDegAA, `ReciprocityTheory.SemistableReduction.SemiDegBA, `ReciprocityTheory.SemistableReduction.SemiDegCD, `ReciprocityTheory.SemistableReduction.SemiDegDA, `ReciprocityTheory.SemistableReduction.SemiDegDB, `ReciprocityTheory.SemistableReduction.SemiDegE, `ReciprocityTheory.SemistableReduction.SphereTorus, `ReciprocityTheory.SemistableReduction.TorusLex, `ReciprocityTheory.SemistableReduction.TorusMeanD, `ReciprocityTheory.SemistableReduction.Unipotent, `ReciprocityTheory.ThetaQuasiPeriods.Change]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

