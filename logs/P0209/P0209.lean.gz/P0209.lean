import Lean
import Development.AutomorphicSpectrum.Proofs.MetricProofs.SubframeDetLogGrowth
import Development.AutomorphicSpectrum.Proofs.MetricProofs.WeightMapAntisymmetricDeltaIdentity
import Development.AutomorphicSpectrum.Proofs.MetricProofs.WeightedPolynomialHomogeneousCoeffBound
import Development.AutomorphicSpectrum.Proofs.TwistedProofs.NormDetLeFactorialMulProd
import Development.AutomorphicSpectrum.Statements.GeometryStatements.NonemptyEquivOfCardHom
import Development.DiscreteGroups.GlobalIrreducibility.DzDigShift
import Development.DiscreteGroups.GlobalIrreducibility.DzStickValOne
import Development.DiscreteGroups.PiInvariants.CompactSupportTwists.TsumEnormEq
import Development.EtaleCohomology.CohomologicalPurity.LeafRootHensPf
import Development.EtaleCohomology.CohomologicalPurity.LeafRootStdPf
import Development.EtaleCohomology.DivisorCycles.OpenCoset
import Development.EtaleCohomology.EtaleSheaves.LeafFinInfPf
import Development.EtaleCohomology.EtaleSheaves.LeafFinValPf
import Development.ResolutionOfSingularities.EmbeddedResolution.AlgebraicPreliminaries.DisjointUnionOfOpensPullback
import Development.ResolutionOfSingularities.EmbeddedResolution.AlgebraicPreliminaries.KernelFlatBaseChange
import Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.DerivativeIdealFieldExtension
import Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.DerivativeIdealSheaf
import Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.DerivativesInBlowupCharts
import Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.LeadingForm
import Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.LogDerivativeIdealLocalization
import Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.LogDerivativeIdealQuotient
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.AdaptedParameters
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.IdealGeneratorsFromBase
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.StrictNormalCrossings
import Development.ResolutionOfSingularities.EmbeddedResolution.IteratedBlowups.BlowupSequenceBasic
import Development.ResolutionOfSingularities.EmbeddedResolution.IteratedBlowups.BlowupSequenceRelations
import Development.ResolutionOfSingularities.EmbeddedResolution.IteratedBlowups.CartierDivisorComponents
import Development.ResolutionOfSingularities.EmbeddedResolution.MaximalContactHypersurfaces.TunedIdealPowers
import Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.FieldExtensionEtaleCover
import Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.GraphAlgebraSpecSmooth
import Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.IdealSheafFlatComapInjective
import Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.SubordinateAffineCover
import Development.ResolutionOfSingularities.EmbeddedResolution.StrongResolution.StrongResolution
import Development.ResolutionOfSingularities.Foundations.Blowup.AffineBlowupProper
import Development.ResolutionOfSingularities.Foundations.Blowup.AffineBlowupUniversalLift
import Development.ResolutionOfSingularities.Foundations.Blowup.BlowupBasic
import Development.WeilBound.CoreStatements.AbelianHeightsDuality.ZarhinTrick.QiCharP
import Development.WeilBound.CoreStatements.AbelianHeightsDuality.ZarhinTrick.QiIdem
import Development.WeilBound.CoreStatements.ArcCellEmbeddings.Imports
import Development.WeilBound.CoreStatements.AutomorphicKernels.BernsteinUnitaryProducts.BernsteinTheoremA.FrobeniusReciprocity.SupportedInIffOfFrob
import Development.WeilBound.CoreStatements.AutomorphicKernels.EisensteinSeriesG2.G2HaarMeasure.PhiEqZeroIff
import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.FockSpaces.EvXTemperate
import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.LocalOperatorBlocks.GaussSec
import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.LocalOperatorBlocks.GaussianMomentRealCoords
import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.PolynomialGaussianIntegrals.PolyGaussOfLines
import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.ThetaSchwartzSums.SchwartzPolyGauss
import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.ThetaSplitting.ActUDiagMonomial
import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.VacuumIwasawa.FrameLin
import Development.WeilBound.CoreStatements.CommonZeroEvaluation.AlgebraicApproximationValued
import Development.WeilBound.CoreStatements.CompactAveragingSplitting.EigenvectorLifting.SiegelTransportAlg
import Development.WeilBound.CoreStatements.CompactAveragingSplitting.EigenvectorLifting.SiegelTransportAn
import Development.WeilBound.CoreStatements.EqualVolumeCompactOpens.Master
import Development.WeilBound.CoreStatements.GaussianSeminormBounds.RealSeminormFiltration.FockAct1FockAct2Commute
import Development.WeilBound.CoreStatements.HodgeTatePoints.BtOrderOfPoints
import Development.WeilBound.CoreStatements.HodgeTatePoints.HtatHopfDesc
import Development.WeilBound.CoreStatements.HodgeTatePoints.KftwoExt
import Development.WeilBound.CoreStatements.HodgeTatePoints.PfibRing
import Development.WeilBound.CoreStatements.HodgeTatePoints.TwhopfInd
import Development.WeilBound.CoreStatements.HodgeTatePoints.ValAtRestrict
import Development.WeilBound.CoreStatements.HomogeneousNonvanishing.CPluri
import Development.WeilBound.CoreStatements.HomogeneousNonvanishing.TwGSemi
import Development.WeilBound.CoreStatements.HomogeneousNonvanishing.TwGXi
import Development.WeilBound.CoreStatements.LocalThetaKernels.LocrepSB
import Development.WeilBound.CoreStatements.MinimalPrimeDimensions.ContinuousAeval

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.MetricProofs.SubframeDetLogGrowth, `Development.AutomorphicSpectrum.Proofs.MetricProofs.WeightMapAntisymmetricDeltaIdentity, `Development.AutomorphicSpectrum.Proofs.MetricProofs.WeightedPolynomialHomogeneousCoeffBound, `Development.AutomorphicSpectrum.Proofs.TwistedProofs.NormDetLeFactorialMulProd, `Development.AutomorphicSpectrum.Statements.GeometryStatements.NonemptyEquivOfCardHom, `Development.DiscreteGroups.GlobalIrreducibility.DzDigShift, `Development.DiscreteGroups.GlobalIrreducibility.DzStickValOne, `Development.DiscreteGroups.PiInvariants.CompactSupportTwists.TsumEnormEq, `Development.EtaleCohomology.CohomologicalPurity.LeafRootHensPf, `Development.EtaleCohomology.CohomologicalPurity.LeafRootStdPf, `Development.EtaleCohomology.DivisorCycles.OpenCoset, `Development.EtaleCohomology.EtaleSheaves.LeafFinInfPf, `Development.EtaleCohomology.EtaleSheaves.LeafFinValPf, `Development.ResolutionOfSingularities.EmbeddedResolution.AlgebraicPreliminaries.DisjointUnionOfOpensPullback, `Development.ResolutionOfSingularities.EmbeddedResolution.AlgebraicPreliminaries.KernelFlatBaseChange, `Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.DerivativeIdealFieldExtension, `Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.DerivativeIdealSheaf, `Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.DerivativesInBlowupCharts, `Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.LeadingForm, `Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.LogDerivativeIdealLocalization, `Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.LogDerivativeIdealQuotient, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.AdaptedParameters, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.IdealGeneratorsFromBase, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.StrictNormalCrossings, `Development.ResolutionOfSingularities.EmbeddedResolution.IteratedBlowups.BlowupSequenceBasic, `Development.ResolutionOfSingularities.EmbeddedResolution.IteratedBlowups.BlowupSequenceRelations, `Development.ResolutionOfSingularities.EmbeddedResolution.IteratedBlowups.CartierDivisorComponents, `Development.ResolutionOfSingularities.EmbeddedResolution.MaximalContactHypersurfaces.TunedIdealPowers, `Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.FieldExtensionEtaleCover, `Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.GraphAlgebraSpecSmooth, `Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.IdealSheafFlatComapInjective, `Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.SubordinateAffineCover, `Development.ResolutionOfSingularities.EmbeddedResolution.StrongResolution.StrongResolution, `Development.ResolutionOfSingularities.Foundations.Blowup.AffineBlowupProper, `Development.ResolutionOfSingularities.Foundations.Blowup.AffineBlowupUniversalLift, `Development.ResolutionOfSingularities.Foundations.Blowup.BlowupBasic, `Development.WeilBound.CoreStatements.AbelianHeightsDuality.ZarhinTrick.QiCharP, `Development.WeilBound.CoreStatements.AbelianHeightsDuality.ZarhinTrick.QiIdem, `Development.WeilBound.CoreStatements.ArcCellEmbeddings.Imports, `Development.WeilBound.CoreStatements.AutomorphicKernels.BernsteinUnitaryProducts.BernsteinTheoremA.FrobeniusReciprocity.SupportedInIffOfFrob, `Development.WeilBound.CoreStatements.AutomorphicKernels.EisensteinSeriesG2.G2HaarMeasure.PhiEqZeroIff, `Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.FockSpaces.EvXTemperate, `Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.LocalOperatorBlocks.GaussSec, `Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.LocalOperatorBlocks.GaussianMomentRealCoords, `Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.PolynomialGaussianIntegrals.PolyGaussOfLines, `Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.ThetaSchwartzSums.SchwartzPolyGauss, `Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.ThetaSplitting.ActUDiagMonomial, `Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.VacuumIwasawa.FrameLin, `Development.WeilBound.CoreStatements.CommonZeroEvaluation.AlgebraicApproximationValued, `Development.WeilBound.CoreStatements.CompactAveragingSplitting.EigenvectorLifting.SiegelTransportAlg, `Development.WeilBound.CoreStatements.CompactAveragingSplitting.EigenvectorLifting.SiegelTransportAn, `Development.WeilBound.CoreStatements.EqualVolumeCompactOpens.Master, `Development.WeilBound.CoreStatements.GaussianSeminormBounds.RealSeminormFiltration.FockAct1FockAct2Commute, `Development.WeilBound.CoreStatements.HodgeTatePoints.BtOrderOfPoints, `Development.WeilBound.CoreStatements.HodgeTatePoints.HtatHopfDesc, `Development.WeilBound.CoreStatements.HodgeTatePoints.KftwoExt, `Development.WeilBound.CoreStatements.HodgeTatePoints.PfibRing, `Development.WeilBound.CoreStatements.HodgeTatePoints.TwhopfInd, `Development.WeilBound.CoreStatements.HodgeTatePoints.ValAtRestrict, `Development.WeilBound.CoreStatements.HomogeneousNonvanishing.CPluri, `Development.WeilBound.CoreStatements.HomogeneousNonvanishing.TwGSemi, `Development.WeilBound.CoreStatements.HomogeneousNonvanishing.TwGXi, `Development.WeilBound.CoreStatements.LocalThetaKernels.LocrepSB, `Development.WeilBound.CoreStatements.MinimalPrimeDimensions.ContinuousAeval]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

