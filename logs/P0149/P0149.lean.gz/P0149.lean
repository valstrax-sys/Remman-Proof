import Lean
import Formalism.LatticeSlopes.LatticeSlopesProofs.GramDetLe
import Formalism.LatticeTheta.LatticeSummableDecay
import Formalism.LatticeTheta.LatticeThetaProofs.CovolumeDual
import Formalism.LatticeTheta.LatticeThetaProofs.DualLattice
import Formalism.LocalRingCardinality.DataCD
import Formalism.LocalRingCardinality.SpanPowerMembership.ExistsDensity
import Formalism.LocalRingCardinality.SpanPowerMembership.Primes
import Formalism.LocalRingCardinality.SpanPowerMembership.UrPkgNonempty
import Formalism.LocalToGlobal.CharacterGerms.CompleteOfBasis
import Formalism.LocalToGlobal.CharacterGerms.DetNeZeroOfChars
import Formalism.LocalToGlobal.CharacterGerms.RowTiePHaDefs
import Formalism.LocalToGlobal.CharacterGerms.RowTiePKeyJoint
import Formalism.LocalToGlobal.CharacterGerms.RowTiePSplitLA
import Formalism.LocalToGlobal.CharacterGerms.ScaledSecondIntegral
import Formalism.LocalToGlobal.CharacterGerms.WipDworkInvG
import Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.CoordMulTmul
import Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.ExistsDenOfIsCompactAdele
import Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.Imports
import Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EisensteinSeries.RemLipTermB
import Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EpsteinZeta.DedekindFactorK
import Formalism.LocalToGlobal.GlobalTheory.GL3.PUnitBasis
import Formalism.LocalToGlobal.GroupLattices.ComparisonMaps.ClsFib
import Formalism.LocalToGlobal.GroupLattices.PerfectRings.AlgebraMapFinite
import Formalism.LocalToGlobal.GroupLattices.PerfectRings.IsLocalRingOfComplete
import Formalism.LocalToGlobal.IndefiniteForms.IndefiniteTree.RealCubicMeans.LogMeanShares.LogMeanStatements.ShareLow
import Formalism.LocalToGlobal.IndefiniteReal.DoubleCosetOperators.GoodPartLeTypeSubspace
import Formalism.LocalToGlobal.IndefiniteReal.FinitePlaces.SmulSubMulLe
import Formalism.LocalToGlobal.IndefiniteReal.HaarTransfer.UnimodP
import Formalism.LocalToGlobal.IndefiniteReal.LevelTypeEquivalence.FdomExistsAll
import Formalism.LocalToGlobal.IndefiniteReal.LevelTypeEquivalence.SobSym
import Formalism.LocalToGlobal.IndefiniteReal.LocalNormSurjectivity.WittFN
import Formalism.LocalToGlobal.IndefiniteReal.LocalNormSurjectivity.WittHS
import Formalism.LocalToGlobal.IndefiniteReal.NormalDecomposition.Decomp
import Formalism.LocalToGlobal.KernelLattices.DeterminantCokernelCount.CokernelIndexFactors.ThirdMomentLaw
import Formalism.LocalToGlobal.NormalizedHeckeFactors.CoverAlg
import Formalism.LocalToGlobal.PairingIndexBounds.ModelLatticeMoves.ModelMoves
import Formalism.LocalToGlobal.PairingIndexBounds.SplitPairEquations.SplitPairGen
import Formalism.LocalToGlobal.ProjectiveLattices.ArchimedeanQuadraticData.FinitePlaceArcs.BeSumPf
import Formalism.LocalToGlobal.ProjectiveLattices.ArchimedeanQuadraticData.HQsmulRight
import Formalism.LocalToGlobal.ProjectiveLattices.ChartWD
import Formalism.LocalToGlobal.ProjectiveLattices.ComplSt
import Formalism.LocalToGlobal.ProjectiveLattices.CrudeMin
import Formalism.LocalToGlobal.ProjectiveLattices.DatTheta
import Formalism.LocalToGlobal.ProjectiveLattices.GenSectB
import Formalism.LocalToGlobal.ProjectiveLattices.IntegrableOnIntegrand
import Formalism.LocalToGlobal.ProjectiveLattices.KapTrdegPfB
import Formalism.LocalToGlobal.ProjectiveLattices.LocalIntegralPolynomials.LocStructSt
import Formalism.LocalToGlobal.ProjectiveLattices.LocalUnitReduction.IsUnitMkOfForallPrime
import Formalism.LocalToGlobal.ProjectiveLattices.ReadAlg
import Formalism.LocalToGlobal.ProjectiveLattices.RhoWApply
import Formalism.LocalToGlobal.ProjectiveLattices.UnifDom
import Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.LieAveraging.AvgCore
import Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.PiMapMulRight
import Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.QuotIndepPf
import Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.RCocompactPfConj
import Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.RCocompactPfKer
import Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.RelativeIndexFlags.FiltRelIndex
import Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.SatGramLoc
import Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.StabilizerIndexVolumes.PtMatIsUnit
import Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.BoxFund
import Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.MapConjOfBounded
import Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.PhiMapAdd
import Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.SwapMp
import Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.TwoLeAbsNormPrime

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.LatticeSlopes.LatticeSlopesProofs.GramDetLe, `Formalism.LatticeTheta.LatticeSummableDecay, `Formalism.LatticeTheta.LatticeThetaProofs.CovolumeDual, `Formalism.LatticeTheta.LatticeThetaProofs.DualLattice, `Formalism.LocalRingCardinality.DataCD, `Formalism.LocalRingCardinality.SpanPowerMembership.ExistsDensity, `Formalism.LocalRingCardinality.SpanPowerMembership.Primes, `Formalism.LocalRingCardinality.SpanPowerMembership.UrPkgNonempty, `Formalism.LocalToGlobal.CharacterGerms.CompleteOfBasis, `Formalism.LocalToGlobal.CharacterGerms.DetNeZeroOfChars, `Formalism.LocalToGlobal.CharacterGerms.RowTiePHaDefs, `Formalism.LocalToGlobal.CharacterGerms.RowTiePKeyJoint, `Formalism.LocalToGlobal.CharacterGerms.RowTiePSplitLA, `Formalism.LocalToGlobal.CharacterGerms.ScaledSecondIntegral, `Formalism.LocalToGlobal.CharacterGerms.WipDworkInvG, `Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.CoordMulTmul, `Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.ExistsDenOfIsCompactAdele, `Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.Imports, `Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EisensteinSeries.RemLipTermB, `Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EpsteinZeta.DedekindFactorK, `Formalism.LocalToGlobal.GlobalTheory.GL3.PUnitBasis, `Formalism.LocalToGlobal.GroupLattices.ComparisonMaps.ClsFib, `Formalism.LocalToGlobal.GroupLattices.PerfectRings.AlgebraMapFinite, `Formalism.LocalToGlobal.GroupLattices.PerfectRings.IsLocalRingOfComplete, `Formalism.LocalToGlobal.IndefiniteForms.IndefiniteTree.RealCubicMeans.LogMeanShares.LogMeanStatements.ShareLow, `Formalism.LocalToGlobal.IndefiniteReal.DoubleCosetOperators.GoodPartLeTypeSubspace, `Formalism.LocalToGlobal.IndefiniteReal.FinitePlaces.SmulSubMulLe, `Formalism.LocalToGlobal.IndefiniteReal.HaarTransfer.UnimodP, `Formalism.LocalToGlobal.IndefiniteReal.LevelTypeEquivalence.FdomExistsAll, `Formalism.LocalToGlobal.IndefiniteReal.LevelTypeEquivalence.SobSym, `Formalism.LocalToGlobal.IndefiniteReal.LocalNormSurjectivity.WittFN, `Formalism.LocalToGlobal.IndefiniteReal.LocalNormSurjectivity.WittHS, `Formalism.LocalToGlobal.IndefiniteReal.NormalDecomposition.Decomp, `Formalism.LocalToGlobal.KernelLattices.DeterminantCokernelCount.CokernelIndexFactors.ThirdMomentLaw, `Formalism.LocalToGlobal.NormalizedHeckeFactors.CoverAlg, `Formalism.LocalToGlobal.PairingIndexBounds.ModelLatticeMoves.ModelMoves, `Formalism.LocalToGlobal.PairingIndexBounds.SplitPairEquations.SplitPairGen, `Formalism.LocalToGlobal.ProjectiveLattices.ArchimedeanQuadraticData.FinitePlaceArcs.BeSumPf, `Formalism.LocalToGlobal.ProjectiveLattices.ArchimedeanQuadraticData.HQsmulRight, `Formalism.LocalToGlobal.ProjectiveLattices.ChartWD, `Formalism.LocalToGlobal.ProjectiveLattices.ComplSt, `Formalism.LocalToGlobal.ProjectiveLattices.CrudeMin, `Formalism.LocalToGlobal.ProjectiveLattices.DatTheta, `Formalism.LocalToGlobal.ProjectiveLattices.GenSectB, `Formalism.LocalToGlobal.ProjectiveLattices.IntegrableOnIntegrand, `Formalism.LocalToGlobal.ProjectiveLattices.KapTrdegPfB, `Formalism.LocalToGlobal.ProjectiveLattices.LocalIntegralPolynomials.LocStructSt, `Formalism.LocalToGlobal.ProjectiveLattices.LocalUnitReduction.IsUnitMkOfForallPrime, `Formalism.LocalToGlobal.ProjectiveLattices.ReadAlg, `Formalism.LocalToGlobal.ProjectiveLattices.RhoWApply, `Formalism.LocalToGlobal.ProjectiveLattices.UnifDom, `Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.LieAveraging.AvgCore, `Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.PiMapMulRight, `Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.QuotIndepPf, `Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.RCocompactPfConj, `Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.RCocompactPfKer, `Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.RelativeIndexFlags.FiltRelIndex, `Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.SatGramLoc, `Formalism.LocalToGlobal.SiegelLatticeTheory.ClosedLocalOrbits.GaugeLatticeShifts.StabilizerIndexVolumes.PtMatIsUnit, `Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.BoxFund, `Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.MapConjOfBounded, `Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.PhiMapAdd, `Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.SwapMp, `Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.TwoLeAbsNormPrime]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

