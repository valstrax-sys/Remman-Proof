import Lean
import GroundTheory.AutomorphicForms.TensorProductTheorem.CoeToRepresentationApply
import GroundTheory.AutomorphicForms.TensorProductTheorem.CompactRep
import GroundTheory.AutomorphicForms.TensorProductTheorem.Irreducible
import GroundTheory.AutomorphicForms.TraceFormulaSpectral
import GroundTheory.AutomorphicForms.WhittakerCells
import GroundTheory.AutomorphicForms.WhittakerCriterion
import GroundTheory.AutomorphicForms.WhittakerGroups
import GroundTheory.Brauer.CrossedProductTensor
import GroundTheory.FunctionField.Divisor
import GroundTheory.FunctionField.PlaceBridge
import GroundTheory.GlobalFields.Adele.BaseChange.FiniteMap
import GroundTheory.GlobalFields.Artin.MackeyFrobeniusEmbed
import GroundTheory.GlobalFields.CompletionAtPlace.Degree
import GroundTheory.GlobalFields.ComplexMultiplication.ReductionGauss
import GroundTheory.GlobalFields.ComplexMultiplication.Uniformization
import GroundTheory.GlobalFields.CyclotomicCharacters.Degree
import GroundTheory.GlobalFields.HerbrandQuotients.SUnitsPerm
import GroundTheory.GlobalFields.IdeleGroups.UnitBound
import GroundTheory.GlobalFields.KummerTheory.Splitting
import GroundTheory.GlobalFields.NormResidueSymbol.Abstract
import GroundTheory.GlobalFields.NormResidueSymbol.RationalCyclotomic
import GroundTheory.GlobalFields.TateThesis.AdeleMeasure
import GroundTheory.GlobalFields.TateThesis.AdelicCharDual
import GroundTheory.GlobalFields.TateThesis.HeckeChar
import GroundTheory.GlobalFields.TateThesis.TraceLatticeEuclidean
import GroundTheory.HeightsAndTheta.Heights.Antisymmetric.AddBlockPullbackOfChartBundlePullback
import GroundTheory.HeightsAndTheta.Heights.Antisymmetric.PNefOnFibresRelabel
import GroundTheory.HeightsAndTheta.Heights.ArithDegree
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.MahlerMul
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PAdmissibleAE
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PAdmissibleAENrm
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PAreaFormulaInj
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PBallAverageLinear
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PBallVolume
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PBaseChangeLogBound
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PCharacterised
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowCycleSwap
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowDegreePos
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowFormAssoc
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowFormBaseChange
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowFormCycleAdd
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowFormCycleSmul
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowFormReduced
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowFormReducedRadical
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeAverage
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeBallFinite
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeFubini
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeIntegralLine
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeMapAreaOne
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PCycleAverage
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PCycleIntegralSection
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PCycleSectionChow
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PCycleSectionData
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PDefectAverage
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PDefectConstStep
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PDefectConstZero
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PDefectPoint
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PDefectSymm
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PDivCyclePrime
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PEvalSpecFirst
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PFsLogAverage
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PFsLogMeasurable
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PFsLogPointOf
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PFsLogSmul

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.AutomorphicForms.TensorProductTheorem.CoeToRepresentationApply, `GroundTheory.AutomorphicForms.TensorProductTheorem.CompactRep, `GroundTheory.AutomorphicForms.TensorProductTheorem.Irreducible, `GroundTheory.AutomorphicForms.TraceFormulaSpectral, `GroundTheory.AutomorphicForms.WhittakerCells, `GroundTheory.AutomorphicForms.WhittakerCriterion, `GroundTheory.AutomorphicForms.WhittakerGroups, `GroundTheory.Brauer.CrossedProductTensor, `GroundTheory.FunctionField.Divisor, `GroundTheory.FunctionField.PlaceBridge, `GroundTheory.GlobalFields.Adele.BaseChange.FiniteMap, `GroundTheory.GlobalFields.Artin.MackeyFrobeniusEmbed, `GroundTheory.GlobalFields.CompletionAtPlace.Degree, `GroundTheory.GlobalFields.ComplexMultiplication.ReductionGauss, `GroundTheory.GlobalFields.ComplexMultiplication.Uniformization, `GroundTheory.GlobalFields.CyclotomicCharacters.Degree, `GroundTheory.GlobalFields.HerbrandQuotients.SUnitsPerm, `GroundTheory.GlobalFields.IdeleGroups.UnitBound, `GroundTheory.GlobalFields.KummerTheory.Splitting, `GroundTheory.GlobalFields.NormResidueSymbol.Abstract, `GroundTheory.GlobalFields.NormResidueSymbol.RationalCyclotomic, `GroundTheory.GlobalFields.TateThesis.AdeleMeasure, `GroundTheory.GlobalFields.TateThesis.AdelicCharDual, `GroundTheory.GlobalFields.TateThesis.HeckeChar, `GroundTheory.GlobalFields.TateThesis.TraceLatticeEuclidean, `GroundTheory.HeightsAndTheta.Heights.Antisymmetric.AddBlockPullbackOfChartBundlePullback, `GroundTheory.HeightsAndTheta.Heights.Antisymmetric.PNefOnFibresRelabel, `GroundTheory.HeightsAndTheta.Heights.ArithDegree, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.MahlerMul, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PAdmissibleAE, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PAdmissibleAENrm, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PAreaFormulaInj, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PBallAverageLinear, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PBallVolume, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PBaseChangeLogBound, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PCharacterised, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowCycleSwap, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowDegreePos, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowFormAssoc, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowFormBaseChange, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowFormCycleAdd, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowFormCycleSmul, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowFormReduced, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowFormReducedRadical, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeAverage, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeBallFinite, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeFubini, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeIntegralLine, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeMapAreaOne, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PCycleAverage, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PCycleIntegralSection, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PCycleSectionChow, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PCycleSectionData, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PDefectAverage, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PDefectConstStep, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PDefectConstZero, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PDefectPoint, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PDefectSymm, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PDivCyclePrime, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PEvalSpecFirst, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PFsLogAverage, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PFsLogMeasurable, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PFsLogPointOf, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PFsLogSmul]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

