import Lean
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StMaximalCountUnbranched
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalBoundedQuotient
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalComplementConnected
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalGermIntegrallyClosed
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalGermIrreducible
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalLocallyIrreducible
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalMaximumPrinciple
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalModelExists
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalModelProper
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalRiemannExtension
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalRiemannExtensionLocal
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalZerosNowhereDense
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StOpenProjectionDominantComponents
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimitiveDiscriminant
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimitiveElementFibres
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRegularLocusIdentity
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSerreConditions
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StWeaklyHolomorphicIntegral
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StZariskiAnalyticNormality
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StatementsArea
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StatementsConeAvoid
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PAvoidMatrixLemma
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PCuspWeightBound
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PInteriorDichotomy
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PLimitInEpsilon
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PMeanCountBound
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PMeanCuspWeight
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PMeanLogPlus
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PMinkowskiCovolumeBound
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PPackingCount
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PReductionSmallFirst
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PReductionSmallLast
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PShortVectorsOrthogonal
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PTailBound
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PTelescopeMetric
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.Cartier
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PAdjoinTrdegAdd
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PDimensionInequality
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PDimensionInequalityOneGenerator
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PMaximalIdealHeightFG
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PPolynomialDimensionInequality
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PPolynomialPrimeOverZeroHeight
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PPrincipalReductionOfBoundedGens
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PQuotientHeightAddOne
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PReesAlgebraDim
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.Statements
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsCN
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsDvrConeDimTrdeg
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsGenericDimGe
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsMultAtOfSaturated
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PDivision
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PJetOfMonomialSum
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PLocUnifAnalytic
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PShareCore
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PShellPolar
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.StatementsShareBound
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PAntisymDivisible
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PAntisymPerturbation
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PAntisymStability
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PFlatDegreeBoundX
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PLaplacianHoloComp
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PNormLemmaX
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.ContractRelevant
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.NoetherCharP

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StMaximalCountUnbranched, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalBoundedQuotient, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalComplementConnected, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalGermIntegrallyClosed, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalGermIrreducible, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalLocallyIrreducible, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalMaximumPrinciple, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalModelExists, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalModelProper, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalRiemannExtension, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalRiemannExtensionLocal, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalZerosNowhereDense, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StOpenProjectionDominantComponents, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimitiveDiscriminant, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimitiveElementFibres, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRegularLocusIdentity, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSerreConditions, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StWeaklyHolomorphicIntegral, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StZariskiAnalyticNormality, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StatementsArea, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StatementsConeAvoid, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PAvoidMatrixLemma, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PCuspWeightBound, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PInteriorDichotomy, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PLimitInEpsilon, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PMeanCountBound, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PMeanCuspWeight, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PMeanLogPlus, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PMinkowskiCovolumeBound, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PPackingCount, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PReductionSmallFirst, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PReductionSmallLast, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PShortVectorsOrthogonal, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PTailBound, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.PTelescopeMetric, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.Cartier, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PAdjoinTrdegAdd, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PDimensionInequality, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PDimensionInequalityOneGenerator, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PMaximalIdealHeightFG, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PPolynomialDimensionInequality, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PPolynomialPrimeOverZeroHeight, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PPrincipalReductionOfBoundedGens, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PQuotientHeightAddOne, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PReesAlgebraDim, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.Statements, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsCN, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsDvrConeDimTrdeg, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsGenericDimGe, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsMultAtOfSaturated, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PDivision, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PJetOfMonomialSum, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PLocUnifAnalytic, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PShareCore, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PShellPolar, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.StatementsShareBound, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PAntisymDivisible, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PAntisymPerturbation, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PAntisymStability, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PFlatDegreeBoundX, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PLaplacianHoloComp, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PNormLemmaX, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.ContractRelevant, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.NoetherCharP]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

