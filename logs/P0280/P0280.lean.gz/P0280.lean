import Lean
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.GeneratorCommutatorQuantumDet
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.QuantumDetHighestWeightHolds
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.ShiftedGeneratorEqIteSmulAdd
import Formalism.RealPlaceAnalysis.StatementU
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Adelstab
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.AfsplitB
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.FIwasawaA
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.FSatakeB
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Heckecomm
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.LocalAlgebraInertPrime
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Satake
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Spherical
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.TjcosetsLoc
import Formalism.SatakeDualWeyl.StatementB
import Formalism.SatakeDualWeyl.StatementW
import Formalism.SharpRestriction.CuspSpanNormBounds.IsTermOver
import Formalism.SharpRestriction.GlobalSchurBounds.GlobalRankLatticeProofs.UnitTraceSumBounds.FrameTransportCM
import Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.QuadraticBasis.FinalO
import Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.AddMemSupportOfMemSupportCoefOut
import Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.CgeZeroIffIntegral
import Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.CollapseExponent
import Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.ExistsMonomialOrder
import Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.FockMonomialRight
import Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.SlopeOfBinomCombGen
import Formalism.SharpRestriction.GrowthBounds.RootWeights.MatrixSubstTransvectionMonomialOfFixed
import Formalism.SharpRestriction.GrowthBounds.TwistedSubstitution.TwistedMonomialFiltration.SumCCMulSumOfMulEqOne
import Formalism.SharpRestriction.LevelLetterCocycles.DataNLoc
import Formalism.SharpRestriction.LevelLetterCocycles.LevelKernelDetection.DetectPt
import Formalism.SharpRestriction.LevelLetterCocycles.LocCoh
import Formalism.SharpRestriction.LevelLetterCocycles.PrimesOverLiterature.RayPrimeCountAllToSquarefree
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.DivAddLogbLeEightMulErrorScale
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.MemPairOfMemSingle
import Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.ZsmulGeneratorEqZeroOfProjection
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RulePos
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.SumPowersetFinSucc
import Formalism.SizeWindowBrackets.ChainSlopeWindows.AdmissibleSchurLemma
import Formalism.SizeWindowBrackets.ChainSlopeWindows.LevelOfCongruence
import Formalism.SmithDeterminants.TruncationChainBoundNonnegExponents
import Formalism.SobolevGaussianKernels.KernelBoundRel
import Formalism.SubspaceCounting.SubspaceCountingProofs.ChoiceOfTopsRefined
import Formalism.SubspaceCounting.SubspaceCountingProofs.ManyOrbitsRefined
import Formalism.SubspaceCounting.SubspaceCountingProofs.MarkedRun
import Formalism.SuccessiveMinima.MinkowskiIIUpper
import Formalism.TameInertiaTowers.CentralOrderTwo.OddEqOneOfSubOneMem
import Formalism.TameInertiaTowers.FinalGroup
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.DualWeylProofs.QcEvGLDetUZpow
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.DualWeylProofs.QhDetZpowMem
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.FiltrationTheoremOfClauses
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.StripDataTensorColumnFamilies
import Formalism.ThetaLogCoordinates.JacobiPathWeights.GenSpaceFacts
import Formalism.ThetaLogCoordinates.JacobiPathWeights.JacobiMinorProofs.ActFormContract
import Formalism.ThetaLogCoordinates.JacobiPathWeights.JacobiMinorProofs.LeIffLtColHeight
import Formalism.ThetaLogCoordinates.JacobiPathWeights.JacobiMinorProofs.LinearIndependentOfLead
import Formalism.ThetaLogCoordinates.JacobiPathWeights.ValuationProductsComponents
import Formalism.ThetaLogCoordinates.ProductIdealMonotone.ElementarySymmetricExpBound
import Formalism.ThetaLogCoordinates.SandwichModelDomains.StatementW
import Formalism.ThetaLogCoordinates.UniformThetaSubstitution.CyclicPowerClassOfExpEquiv
import Formalism.ThetaLogCoordinates.UniformThetaSubstitution.FrobeniusLiftNorms.TheoremCIiiMulti
import Formalism.ThetaSupremumBounds.GaussianShiftBounds.GaussCoord
import Formalism.TorsionNormIteration.InverseIntegralClasses.InvInt
import Formalism.TorsionNormIteration.InverseIntegralClasses.MemSpanOfNormLe
import Formalism.TorsionNormIteration.InverseIntegralClasses.NormSigmaLeOne
import Formalism.TorsionNormIteration.InverseIntegralClasses.SigmaNormLeOne
import Formalism.TorsionNormIteration.InverseIntegralClasses.SolveExistsProof

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.RealPlaceAnalysis.RealPlaceTaylor.GeneratorCommutatorQuantumDet, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.QuantumDetHighestWeightHolds, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.ShiftedGeneratorEqIteSmulAdd, `Formalism.RealPlaceAnalysis.StatementU, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Adelstab, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.AfsplitB, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.FIwasawaA, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.FSatakeB, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Heckecomm, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.LocalAlgebraInertPrime, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Satake, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Spherical, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.TjcosetsLoc, `Formalism.SatakeDualWeyl.StatementB, `Formalism.SatakeDualWeyl.StatementW, `Formalism.SharpRestriction.CuspSpanNormBounds.IsTermOver, `Formalism.SharpRestriction.GlobalSchurBounds.GlobalRankLatticeProofs.UnitTraceSumBounds.FrameTransportCM, `Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.QuadraticBasis.FinalO, `Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.AddMemSupportOfMemSupportCoefOut, `Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.CgeZeroIffIntegral, `Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.CollapseExponent, `Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.ExistsMonomialOrder, `Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.FockMonomialRight, `Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.SlopeOfBinomCombGen, `Formalism.SharpRestriction.GrowthBounds.RootWeights.MatrixSubstTransvectionMonomialOfFixed, `Formalism.SharpRestriction.GrowthBounds.TwistedSubstitution.TwistedMonomialFiltration.SumCCMulSumOfMulEqOne, `Formalism.SharpRestriction.LevelLetterCocycles.DataNLoc, `Formalism.SharpRestriction.LevelLetterCocycles.LevelKernelDetection.DetectPt, `Formalism.SharpRestriction.LevelLetterCocycles.LocCoh, `Formalism.SharpRestriction.LevelLetterCocycles.PrimesOverLiterature.RayPrimeCountAllToSquarefree, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.DivAddLogbLeEightMulErrorScale, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.MemPairOfMemSingle, `Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.ZsmulGeneratorEqZeroOfProjection, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RulePos, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.SumPowersetFinSucc, `Formalism.SizeWindowBrackets.ChainSlopeWindows.AdmissibleSchurLemma, `Formalism.SizeWindowBrackets.ChainSlopeWindows.LevelOfCongruence, `Formalism.SmithDeterminants.TruncationChainBoundNonnegExponents, `Formalism.SobolevGaussianKernels.KernelBoundRel, `Formalism.SubspaceCounting.SubspaceCountingProofs.ChoiceOfTopsRefined, `Formalism.SubspaceCounting.SubspaceCountingProofs.ManyOrbitsRefined, `Formalism.SubspaceCounting.SubspaceCountingProofs.MarkedRun, `Formalism.SuccessiveMinima.MinkowskiIIUpper, `Formalism.TameInertiaTowers.CentralOrderTwo.OddEqOneOfSubOneMem, `Formalism.TameInertiaTowers.FinalGroup, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.DualWeylProofs.QcEvGLDetUZpow, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.DualWeylProofs.QhDetZpowMem, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.FiltrationTheoremOfClauses, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.StripDataTensorColumnFamilies, `Formalism.ThetaLogCoordinates.JacobiPathWeights.GenSpaceFacts, `Formalism.ThetaLogCoordinates.JacobiPathWeights.JacobiMinorProofs.ActFormContract, `Formalism.ThetaLogCoordinates.JacobiPathWeights.JacobiMinorProofs.LeIffLtColHeight, `Formalism.ThetaLogCoordinates.JacobiPathWeights.JacobiMinorProofs.LinearIndependentOfLead, `Formalism.ThetaLogCoordinates.JacobiPathWeights.ValuationProductsComponents, `Formalism.ThetaLogCoordinates.ProductIdealMonotone.ElementarySymmetricExpBound, `Formalism.ThetaLogCoordinates.SandwichModelDomains.StatementW, `Formalism.ThetaLogCoordinates.UniformThetaSubstitution.CyclicPowerClassOfExpEquiv, `Formalism.ThetaLogCoordinates.UniformThetaSubstitution.FrobeniusLiftNorms.TheoremCIiiMulti, `Formalism.ThetaSupremumBounds.GaussianShiftBounds.GaussCoord, `Formalism.TorsionNormIteration.InverseIntegralClasses.InvInt, `Formalism.TorsionNormIteration.InverseIntegralClasses.MemSpanOfNormLe, `Formalism.TorsionNormIteration.InverseIntegralClasses.NormSigmaLeOne, `Formalism.TorsionNormIteration.InverseIntegralClasses.SigmaNormLeOne, `Formalism.TorsionNormIteration.InverseIntegralClasses.SolveExistsProof]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

