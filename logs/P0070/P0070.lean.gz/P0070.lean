import Lean
import Formalism.LocalRingCardinality.SpanPowerMembership.NZColB
import Formalism.LocalRingCardinality.SpanPowerMembership.NZTypeD
import Formalism.LocalRingCardinality.SpanPowerMembership.RelDetCore
import Formalism.LocalRingCardinality.SpanPowerMembership.UnitsPowSurjective
import Formalism.LocalRingCardinality.SpanPowerMembership.UrRing
import Formalism.LocalToGlobal.AdelicCompactOpens.GLintCompactOpen
import Formalism.LocalToGlobal.AdelicCompactOpens.HermDefONFamily
import Formalism.LocalToGlobal.AdelicCompactOpens.IntAdelesCompactOpen
import Formalism.LocalToGlobal.CharacterGerms.AltInv
import Formalism.LocalToGlobal.CharacterGerms.ExistsStrictMonoMinor
import Formalism.LocalToGlobal.CharacterGerms.GeNatCast
import Formalism.LocalToGlobal.CharacterGerms.PoincEx
import Formalism.LocalToGlobal.CharacterGerms.RowTiePKeyJointDef
import Formalism.LocalToGlobal.CharacterGerms.RowTiePSplitDef
import Formalism.LocalToGlobal.CharacterGerms.RowTieUpFBrPl
import Formalism.LocalToGlobal.Columns.MemWmPerp
import Formalism.LocalToGlobal.Columns.RowFormsNZp
import Formalism.LocalToGlobal.GaloisLevelStructure.DefsGal
import Formalism.LocalToGlobal.GlobalTheory.BlockActions.ExtendOneMulVecSingleLast
import Formalism.LocalToGlobal.GlobalTheory.CoordinateLengths.PairingContinuityBound
import Formalism.LocalToGlobal.GlobalTheory.ElemZeroZeroMulApply
import Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.AdeleIntA
import Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.CompactFixesLattice
import Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.DedekindFactorization.OmegaPoly
import Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EisensteinSeries.DslopePhiCDifferentiableAt
import Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EisensteinSeries.RemLipTermA
import Formalism.LocalToGlobal.GlobalTheory.GL3.PFourSq
import Formalism.LocalToGlobal.GlobalTheory.GL4.PLemTAmgm
import Formalism.LocalToGlobal.GlobalTheory.GL6.CoordMapInjective
import Formalism.LocalToGlobal.GlobalTheory.GL6.LinearIndependentProdRenameOfCard
import Formalism.LocalToGlobal.GlobalTheory.UnramifiedTrace.CardFilterSubtype
import Formalism.LocalToGlobal.GlobalTheory.UnramifiedTrace.SumFib
import Formalism.LocalToGlobal.GroupLattices.ComparisonMaps.IsComplRatCompl
import Formalism.LocalToGlobal.GroupLattices.PerfectRings.ExistsSqEqIntCast
import Formalism.LocalToGlobal.GroupLattices.TiedFamilies.TieDim
import Formalism.LocalToGlobal.IndefiniteForms.IndefiniteTree.RealCubicMeans.LogMeanShares.LogMeanStatements.HSClaim
import Formalism.LocalToGlobal.IndefiniteForms.IndefiniteTree.RealCubicMeans.LogMeanShares.LogMeanStatements.LineDegreeClosedFormula
import Formalism.LocalToGlobal.IndefiniteForms.IndefiniteTree.RealCubicMeans.LogMeanShares.LogMeanStatements.MeanLogS
import Formalism.LocalToGlobal.IndefiniteReal.DeterminantProjection
import Formalism.LocalToGlobal.IndefiniteReal.EigenDecomposition
import Formalism.LocalToGlobal.IndefiniteReal.GramCEqTranspose
import Formalism.LocalToGlobal.IndefiniteReal.HaarTransfer.SchurClosable
import Formalism.LocalToGlobal.IndefiniteReal.HaarTransfer.SobLeafP
import Formalism.LocalToGlobal.IndefiniteReal.HaarTransfer.Unimod
import Formalism.LocalToGlobal.IndefiniteReal.HeckeNonvanishing.Imports
import Formalism.LocalToGlobal.IndefiniteReal.IndefiniteWeightData
import Formalism.LocalToGlobal.IndefiniteReal.LevelTypeEquivalence.IterSymmR
import Formalism.LocalToGlobal.IndefiniteReal.LocalNormSurjectivity.FinNormSurj
import Formalism.LocalToGlobal.IndefiniteReal.LocalNormSurjectivity.WittDiag
import Formalism.LocalToGlobal.IndefiniteReal.NormalDecomposition.DecompOfNormalStatement
import Formalism.LocalToGlobal.IndefiniteReal.RationalAdjoints.CoordRat
import Formalism.LocalToGlobal.IndefiniteReal.SobolevIteration.DifferentiableUpdate
import Formalism.LocalToGlobal.IndefiniteReal.SobolevIteration.HasFDerivAtIntegralPIter
import Formalism.LocalToGlobal.KernelLattices.DeterminantCokernelCount.CokernelIndexFactors.IdxSmith
import Formalism.LocalToGlobal.KernelLattices.DeterminantCokernelCount.CokernelIndexFactors.StatementB
import Formalism.LocalToGlobal.LatticeGeometry.OperatorNormFibers.FormData
import Formalism.LocalToGlobal.LatticeGeometry.RealizationNorms.ExistsStarMulSelf
import Formalism.LocalToGlobal.NormalizedHeckeFactors.CoverLen
import Formalism.LocalToGlobal.NormalizedHeckeFactors.CoverPoly
import Formalism.LocalToGlobal.NormalizedHeckeFactors.CoverVal
import Formalism.LocalToGlobal.NormalizedHeckeFactors.ExtNRowsGen
import Formalism.LocalToGlobal.NumberFieldFamilies.OwnStruct
import Formalism.LocalToGlobal.PairingIndexBounds.ModelLatticeMoves.IsBichar
import Formalism.LocalToGlobal.PairingIndexBounds.RowActionCoefficients.AdmissibleInterpolation.GeXZero

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.LocalRingCardinality.SpanPowerMembership.NZColB, `Formalism.LocalRingCardinality.SpanPowerMembership.NZTypeD, `Formalism.LocalRingCardinality.SpanPowerMembership.RelDetCore, `Formalism.LocalRingCardinality.SpanPowerMembership.UnitsPowSurjective, `Formalism.LocalRingCardinality.SpanPowerMembership.UrRing, `Formalism.LocalToGlobal.AdelicCompactOpens.GLintCompactOpen, `Formalism.LocalToGlobal.AdelicCompactOpens.HermDefONFamily, `Formalism.LocalToGlobal.AdelicCompactOpens.IntAdelesCompactOpen, `Formalism.LocalToGlobal.CharacterGerms.AltInv, `Formalism.LocalToGlobal.CharacterGerms.ExistsStrictMonoMinor, `Formalism.LocalToGlobal.CharacterGerms.GeNatCast, `Formalism.LocalToGlobal.CharacterGerms.PoincEx, `Formalism.LocalToGlobal.CharacterGerms.RowTiePKeyJointDef, `Formalism.LocalToGlobal.CharacterGerms.RowTiePSplitDef, `Formalism.LocalToGlobal.CharacterGerms.RowTieUpFBrPl, `Formalism.LocalToGlobal.Columns.MemWmPerp, `Formalism.LocalToGlobal.Columns.RowFormsNZp, `Formalism.LocalToGlobal.GaloisLevelStructure.DefsGal, `Formalism.LocalToGlobal.GlobalTheory.BlockActions.ExtendOneMulVecSingleLast, `Formalism.LocalToGlobal.GlobalTheory.CoordinateLengths.PairingContinuityBound, `Formalism.LocalToGlobal.GlobalTheory.ElemZeroZeroMulApply, `Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.AdeleIntA, `Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.CompactFixesLattice, `Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.DedekindFactorization.OmegaPoly, `Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EisensteinSeries.DslopePhiCDifferentiableAt, `Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.EisensteinSeries.RemLipTermA, `Formalism.LocalToGlobal.GlobalTheory.GL3.PFourSq, `Formalism.LocalToGlobal.GlobalTheory.GL4.PLemTAmgm, `Formalism.LocalToGlobal.GlobalTheory.GL6.CoordMapInjective, `Formalism.LocalToGlobal.GlobalTheory.GL6.LinearIndependentProdRenameOfCard, `Formalism.LocalToGlobal.GlobalTheory.UnramifiedTrace.CardFilterSubtype, `Formalism.LocalToGlobal.GlobalTheory.UnramifiedTrace.SumFib, `Formalism.LocalToGlobal.GroupLattices.ComparisonMaps.IsComplRatCompl, `Formalism.LocalToGlobal.GroupLattices.PerfectRings.ExistsSqEqIntCast, `Formalism.LocalToGlobal.GroupLattices.TiedFamilies.TieDim, `Formalism.LocalToGlobal.IndefiniteForms.IndefiniteTree.RealCubicMeans.LogMeanShares.LogMeanStatements.HSClaim, `Formalism.LocalToGlobal.IndefiniteForms.IndefiniteTree.RealCubicMeans.LogMeanShares.LogMeanStatements.LineDegreeClosedFormula, `Formalism.LocalToGlobal.IndefiniteForms.IndefiniteTree.RealCubicMeans.LogMeanShares.LogMeanStatements.MeanLogS, `Formalism.LocalToGlobal.IndefiniteReal.DeterminantProjection, `Formalism.LocalToGlobal.IndefiniteReal.EigenDecomposition, `Formalism.LocalToGlobal.IndefiniteReal.GramCEqTranspose, `Formalism.LocalToGlobal.IndefiniteReal.HaarTransfer.SchurClosable, `Formalism.LocalToGlobal.IndefiniteReal.HaarTransfer.SobLeafP, `Formalism.LocalToGlobal.IndefiniteReal.HaarTransfer.Unimod, `Formalism.LocalToGlobal.IndefiniteReal.HeckeNonvanishing.Imports, `Formalism.LocalToGlobal.IndefiniteReal.IndefiniteWeightData, `Formalism.LocalToGlobal.IndefiniteReal.LevelTypeEquivalence.IterSymmR, `Formalism.LocalToGlobal.IndefiniteReal.LocalNormSurjectivity.FinNormSurj, `Formalism.LocalToGlobal.IndefiniteReal.LocalNormSurjectivity.WittDiag, `Formalism.LocalToGlobal.IndefiniteReal.NormalDecomposition.DecompOfNormalStatement, `Formalism.LocalToGlobal.IndefiniteReal.RationalAdjoints.CoordRat, `Formalism.LocalToGlobal.IndefiniteReal.SobolevIteration.DifferentiableUpdate, `Formalism.LocalToGlobal.IndefiniteReal.SobolevIteration.HasFDerivAtIntegralPIter, `Formalism.LocalToGlobal.KernelLattices.DeterminantCokernelCount.CokernelIndexFactors.IdxSmith, `Formalism.LocalToGlobal.KernelLattices.DeterminantCokernelCount.CokernelIndexFactors.StatementB, `Formalism.LocalToGlobal.LatticeGeometry.OperatorNormFibers.FormData, `Formalism.LocalToGlobal.LatticeGeometry.RealizationNorms.ExistsStarMulSelf, `Formalism.LocalToGlobal.NormalizedHeckeFactors.CoverLen, `Formalism.LocalToGlobal.NormalizedHeckeFactors.CoverPoly, `Formalism.LocalToGlobal.NormalizedHeckeFactors.CoverVal, `Formalism.LocalToGlobal.NormalizedHeckeFactors.ExtNRowsGen, `Formalism.LocalToGlobal.NumberFieldFamilies.OwnStruct, `Formalism.LocalToGlobal.PairingIndexBounds.ModelLatticeMoves.IsBichar, `Formalism.LocalToGlobal.PairingIndexBounds.RowActionCoefficients.AdmissibleInterpolation.GeXZero]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

