import Lean
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SingleMemOfDiagonal
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SingleMemSubmodule
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SmoothOf
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SmoothOnAdditive
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SmoothOnGroupSum
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SmoothQuot
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SmoothTensorFactor
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SmulMemOfSpanEqTop
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SmulNn
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpanImageDenominators
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpanLinearIndependentBase
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpanMapRingHomEqTop
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpanOfVariable
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpanSInduction
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpanTopFamily
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpecialLinearMap
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpecialMapFinite
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpectrumNonemptyOfCountableRank
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SplittingFieldConstruction
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SqShift
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SquareNormBound
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SquareOfApproximation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Stabilizer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StabilizerIsOpen
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StabilizerOf
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StabilizerSubgroup
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StandardAdditiveCharacter
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StandardLattice
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StarEqOfSq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StrictlyUpperRank
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StronglyIrreducible
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SubalgebraEqTop
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SubgroupFixed
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SumChar
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SumCompSurj
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SumEmbeddingsEqRealAddComplex
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SumOverPlacesFibre
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SumRMulNe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SumRightInverse
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SumSupportEq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SummableAbsNormRpowInv
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SummableProdCoord
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SummandLocalization
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SxLimPt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SymmetricShiftIsUnit
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TendstoCut
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TensorHomExt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TensorSubRight
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ThetaInvolution
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TmASmSum
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TmulSurjectiveRankOne
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TorsSatMult
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TorsStep
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TotalDegreeLinear
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TraceEqSumReCmType
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TraceMixedEmbedding
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TracePowEqZeroOfLeDim
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TraceZero
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TransferOfCompSubtype
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TransposeInverseTheta
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TriDiag
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TripleNe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Tube
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TwistedKernelFixed

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SingleMemOfDiagonal, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SingleMemSubmodule, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SmoothOf, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SmoothOnAdditive, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SmoothOnGroupSum, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SmoothQuot, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SmoothTensorFactor, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SmulMemOfSpanEqTop, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SmulNn, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpanImageDenominators, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpanLinearIndependentBase, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpanMapRingHomEqTop, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpanOfVariable, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpanSInduction, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpanTopFamily, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpecialLinearMap, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpecialMapFinite, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpectrumNonemptyOfCountableRank, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SplittingFieldConstruction, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SqShift, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SquareNormBound, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SquareOfApproximation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Stabilizer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StabilizerIsOpen, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StabilizerOf, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StabilizerSubgroup, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StandardAdditiveCharacter, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StandardLattice, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StarEqOfSq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StrictlyUpperRank, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StronglyIrreducible, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SubalgebraEqTop, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SubgroupFixed, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SumChar, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SumCompSurj, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SumEmbeddingsEqRealAddComplex, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SumOverPlacesFibre, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SumRMulNe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SumRightInverse, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SumSupportEq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SummableAbsNormRpowInv, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SummableProdCoord, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SummandLocalization, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SxLimPt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SymmetricShiftIsUnit, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TendstoCut, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TensorHomExt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TensorSubRight, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ThetaInvolution, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TmASmSum, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TmulSurjectiveRankOne, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TorsSatMult, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TorsStep, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TotalDegreeLinear, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TraceEqSumReCmType, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TraceMixedEmbedding, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TracePowEqZeroOfLeDim, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TraceZero, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TransferOfCompSubtype, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TransposeInverseTheta, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TriDiag, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TripleNe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Tube, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.TwistedKernelFixed]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

