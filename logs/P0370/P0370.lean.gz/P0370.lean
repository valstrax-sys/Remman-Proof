import Lean
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FunctionFieldRatioGenerators
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenPtSpecializesOfSpecializes
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericFlagFieldChange
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericFlagOverGenericField
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericFlagTrdegFormulaStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericFlagTriangularChangeStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GermStalkClosedPointToBaseChange
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GlobalIndexFrameLogNorm
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GluedLatticeFiniteIndexStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GluedLatticeLocalizationStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GoodProjExistsStatementHolds
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.HeightOnePrimeDvrStalk
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.HodgeTateFunctionalEndomorphism
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.HodgeTateFunctionalMul
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.HodgeTateFunctionalUnique
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IntegralClosureChartSpan
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsFinOpenSubOfFinite
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeEigenVectorBundleStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeSpanProjectionBound
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeTensorPowerDegreeStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeTensorPowerLineBundleStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeVectorBundlePullbackStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieLatticeVectorBundleOfSmooth
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieModelExistsUniqueSemilinear
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieModelPullbackEquivalenceStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalIndexAtSinglePlaceStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalSubringChartPoint
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.MemOfAevalEqZero
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.MemRegAtOfCodimOne
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.MinorRatioRegularOfInvertible
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.NormalIsoOfIntegrallyClosed
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrincipalExtensionProjectiveModuleStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ProdUpdateDiv
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ProjectiveModelNonempty
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ProperDominatingSurjective
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegAtFractionNoetherianClosedStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularAtBaseChange
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularLocalRingFractionField
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ReversedDualTriangularStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SepCountNonneg
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SmoothGroupTangentLiftStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.StalkClosedPointToGermTop
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.StalkSurjectiveOpenImmersion
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.TangentVectorOfDualHomStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.TranslateIntoSmallerOpenStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.UnitSectionDivisorEq
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ValuationCoordsComplexPoint
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ValueAlongStalkSurjection
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.WedgeLatticeGenerator
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.BlockParabolicModulusIntegral
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.CartanDecompositionGeneralLinearStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.DifferentDvdRamifiedPrimePowerStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.DirichletLogDerivBoundLeftHalfPlane
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.FiniteContinuousCrossedHomomorphisms
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.FinitelyManyOpenSubgroupsBoundedIndex
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.GaloisUnramifiedOutsideCohomology
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.GeneralLinearUnimodularHaar
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.LocalFieldTopologyNormBallsStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.NormalSubgroupLeUnramifiedFixing
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.OneLeNormOneSub
import Development.AutomorphicSpectrum.Proofs.HermitianForms.ExistsSdWSdHerm
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.DblCoordUnique
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.ExistsStd
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.SwapCApply

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.GeometryProofs.FunctionFieldRatioGenerators, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenPtSpecializesOfSpecializes, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericFlagFieldChange, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericFlagOverGenericField, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericFlagTrdegFormulaStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericFlagTriangularChangeStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GermStalkClosedPointToBaseChange, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GlobalIndexFrameLogNorm, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GluedLatticeFiniteIndexStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GluedLatticeLocalizationStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GoodProjExistsStatementHolds, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.HeightOnePrimeDvrStalk, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.HodgeTateFunctionalEndomorphism, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.HodgeTateFunctionalMul, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.HodgeTateFunctionalUnique, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IntegralClosureChartSpan, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsFinOpenSubOfFinite, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeEigenVectorBundleStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeSpanProjectionBound, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeTensorPowerDegreeStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeTensorPowerLineBundleStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeVectorBundlePullbackStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieLatticeVectorBundleOfSmooth, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieModelExistsUniqueSemilinear, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieModelPullbackEquivalenceStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalIndexAtSinglePlaceStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocalSubringChartPoint, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.MemOfAevalEqZero, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.MemRegAtOfCodimOne, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.MinorRatioRegularOfInvertible, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.NormalIsoOfIntegrallyClosed, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrincipalExtensionProjectiveModuleStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ProdUpdateDiv, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ProjectiveModelNonempty, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ProperDominatingSurjective, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegAtFractionNoetherianClosedStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularAtBaseChange, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularLocalRingFractionField, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ReversedDualTriangularStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.SepCountNonneg, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.SmoothGroupTangentLiftStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.StalkClosedPointToGermTop, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.StalkSurjectiveOpenImmersion, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.TangentVectorOfDualHomStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.TranslateIntoSmallerOpenStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.UnitSectionDivisorEq, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ValuationCoordsComplexPoint, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ValueAlongStalkSurjection, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.WedgeLatticeGenerator, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.BlockParabolicModulusIntegral, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.CartanDecompositionGeneralLinearStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.DifferentDvdRamifiedPrimePowerStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.DirichletLogDerivBoundLeftHalfPlane, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.FiniteContinuousCrossedHomomorphisms, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.FinitelyManyOpenSubgroupsBoundedIndex, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.GaloisUnramifiedOutsideCohomology, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.GeneralLinearUnimodularHaar, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.LocalFieldTopologyNormBallsStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.NormalSubgroupLeUnramifiedFixing, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.OneLeNormOneSub, `Development.AutomorphicSpectrum.Proofs.HermitianForms.ExistsSdWSdHerm, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.DblCoordUnique, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.ExistsStd, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.SwapCApply]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

