import Lean
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.PDominatingDVR
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.PFiniteIntegralClosure
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.PHeightOneIntersection
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.PLatticesAgree
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.PMertensUpper
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.PPrimeOpensCover
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.PSectionNef
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.PSumCp
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.PullbackBasis
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.RatLocalAffine
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.SpreadIsoModelIff
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsFreeSheafBasis
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsGenericGerm
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsGenericSections
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsGlue
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsHeightOneSections
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsInvOpenInside
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsInvOpenInsideRat
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsKrullAkizuki
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsLocSectionsInj
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsPullbackFaithful
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsRatDenominators
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsSpreadHom
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsSpreadLocal
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsSpreadNbhd
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsZLocDenominators
import GroundTheory.HeightsAndTheta.Heights.Intersections.PTorusInvLevi
import GroundTheory.HeightsAndTheta.Heights.Intersections.StChartScalingIndep
import GroundTheory.HeightsAndTheta.Heights.Intersections.StFnDegAdjoin
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.BaseChangeObj
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CechPartitionSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CutDimLowerSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CutMultPosSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CycleSplitFiltStepSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.GenericPointSectionHypotheses
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.GlobalFunctionsIntegralSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.ImportsBisAltAlt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.ImportsBisAltBis
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.ImportsBisFurther
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.ImportsLastLast
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.ImportsRestLast
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.LeadingCoeffPosSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.NefExtendIsoSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.NotTwistFiniteAtZero
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCechCone
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCechExact
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCechTransport
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCohomRetract
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PDegLocExact
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PGradedPres
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PGradedULift
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PKHPrimeFilt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PPrimeFiltrationRestrict
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerreFinite
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerrePoly
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerrePolyLaurent
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerrePolyLaurentCohom
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerreVanish
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PointDegreePosSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PointSecsLenSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsCycleSplitCurve
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsCycleSplitFilt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsCycleSplitSmall
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsIdealTwist

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.IntegralModels.PDominatingDVR, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.PFiniteIntegralClosure, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.PHeightOneIntersection, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.PLatticesAgree, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.PMertensUpper, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.PPrimeOpensCover, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.PSectionNef, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.PSumCp, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.PullbackBasis, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.RatLocalAffine, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.SpreadIsoModelIff, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsFreeSheafBasis, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsGenericGerm, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsGenericSections, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsGlue, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsHeightOneSections, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsInvOpenInside, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsInvOpenInsideRat, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsKrullAkizuki, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsLocSectionsInj, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsPullbackFaithful, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsRatDenominators, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsSpreadHom, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsSpreadLocal, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsSpreadNbhd, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.StatementsZLocDenominators, `GroundTheory.HeightsAndTheta.Heights.Intersections.PTorusInvLevi, `GroundTheory.HeightsAndTheta.Heights.Intersections.StChartScalingIndep, `GroundTheory.HeightsAndTheta.Heights.Intersections.StFnDegAdjoin, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.BaseChangeObj, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CechPartitionSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CutDimLowerSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CutMultPosSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CycleSplitFiltStepSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.GenericPointSectionHypotheses, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.GlobalFunctionsIntegralSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.ImportsBisAltAlt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.ImportsBisAltBis, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.ImportsBisFurther, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.ImportsLastLast, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.ImportsRestLast, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.LeadingCoeffPosSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.NefExtendIsoSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.NotTwistFiniteAtZero, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCechCone, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCechExact, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCechTransport, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCohomRetract, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PDegLocExact, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PGradedPres, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PGradedULift, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PKHPrimeFilt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PPrimeFiltrationRestrict, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerreFinite, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerrePoly, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerrePolyLaurent, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerrePolyLaurentCohom, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PSerreVanish, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PointDegreePosSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PointSecsLenSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsCycleSplitCurve, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsCycleSplitFilt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsCycleSplitSmall, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsIdealTwist]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

