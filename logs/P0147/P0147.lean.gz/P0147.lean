import Lean
import Formalism.FlagUnipotentLattices.DetIndexProductHyperbolicInequality
import Formalism.FlagUnipotentLattices.MemOfOrthogonalAnisotropic
import Formalism.FlagUnipotentLattices.PairingOrthogonalComplement
import Formalism.FockGram.FockGramProofs.CovolGram
import Formalism.FockGram.FockGramProofs.SubIndexNorm
import Formalism.FockGram.StatementFock
import Formalism.FockGram.StatementHerm
import Formalism.FockGram.StatementTensor
import Formalism.FormalDegreeBessel.FormalDegreeRatio.AdjointFunctionalHolds
import Formalism.FormalDegreeBessel.FormalDegreeRatio.WRPres
import Formalism.FormalDegreeBessel.FormalDegreeRatio.WRWeyl
import Formalism.FormalDegreeBessel.StatementG
import Formalism.FormalGroupLog.Statement
import Formalism.FrobeniusBaseCase.CoeffOfFirstMultiplier
import Formalism.FrobeniusBaseCase.FrobeniusBaseCaseProofs.BaseCaseKOneHolds
import Formalism.FrobeniusBaseCase.FrobeniusBaseCaseProofs.HasUniqueFixedPoint
import Formalism.FrobeniusBaseCase.FrobeniusBaseCaseProofs.IdentityTwentyB
import Formalism.FrobeniusBaseCase.StatementFix
import Formalism.FrobeniusContraction.EulerC
import Formalism.FrobeniusContraction.FrobeniusContractionProofs.CocycleComponentRelation
import Formalism.FrobeniusContraction.FrobeniusContractionProofs.ContractBij
import Formalism.FrobeniusContraction.FrobeniusContractionProofs.FiniteCocyclesLeCocycles
import Formalism.FrobeniusContraction.FrobeniusContractionProofs.FrobIterQModPrimeHolds
import Formalism.FrobeniusContraction.FrobeniusContractionProofs.LemmaS
import Formalism.FrobeniusContraction.FrobeniusContractionProofs.LenBound
import Formalism.FrobeniusContraction.FrobeniusContractionProofs.LowestComponent
import Formalism.FrobeniusContraction.HighestWeightResidueAvoids
import Formalism.GL3MeanSquares.ConcavityEquidistribution
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.CountA
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.ExceptionalCharacterBounds.EffSmooth
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.HDSucc
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.MSqPage
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.PNTDHFinishB
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.TwentyFiveMulSmallConstant
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.CardLiftMatrix
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsInvOneAdd
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.MemRangeLinPart
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.NotIsPrimeMapOfSplit
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.PolNatDegreeLe
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.StepIdentity
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.TendstoWeightedTprod
import Formalism.GL3MeanSquares.SmoothedRemainderRealIntegralFormula
import Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.AltNotSolvable
import Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.FewLargeParts
import Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.JordanPrime
import Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.OneNonUnit
import Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.OrbitSubSum
import Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.PermSubSumInv
import Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.PowerPCycle
import Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.PrimitiveOfPCycle
import Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.ResiduesLe
import Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.RestrictRoots
import Formalism.GaloisIrreducibility.NoSolvableOf
import Formalism.GaussIdealIdentity.GaussIdealPrimality.GaussLocalizationLengthHolds
import Formalism.GaussJetBounds.Statement
import Formalism.GaussValuationBounds.Statement
import Formalism.GelfandTransference.HadamardGelfand.Gelfand
import Formalism.GelfandTransference.Statement
import Formalism.GrowthSums.StatementA
import Formalism.HarderNarasimhan.Statement
import Formalism.HermitianCurvature.BlockKernelPropertiesOfSteps
import Formalism.HermitianCurvature.HermitianCurvatureProofs.AdditiveCharacterPsi
import Formalism.HermitianCurvature.HermitianCurvatureProofs.AffineChangeOfVariables
import Formalism.HermitianCurvature.HermitianCurvatureProofs.BetaFactorisation

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.FlagUnipotentLattices.DetIndexProductHyperbolicInequality, `Formalism.FlagUnipotentLattices.MemOfOrthogonalAnisotropic, `Formalism.FlagUnipotentLattices.PairingOrthogonalComplement, `Formalism.FockGram.FockGramProofs.CovolGram, `Formalism.FockGram.FockGramProofs.SubIndexNorm, `Formalism.FockGram.StatementFock, `Formalism.FockGram.StatementHerm, `Formalism.FockGram.StatementTensor, `Formalism.FormalDegreeBessel.FormalDegreeRatio.AdjointFunctionalHolds, `Formalism.FormalDegreeBessel.FormalDegreeRatio.WRPres, `Formalism.FormalDegreeBessel.FormalDegreeRatio.WRWeyl, `Formalism.FormalDegreeBessel.StatementG, `Formalism.FormalGroupLog.Statement, `Formalism.FrobeniusBaseCase.CoeffOfFirstMultiplier, `Formalism.FrobeniusBaseCase.FrobeniusBaseCaseProofs.BaseCaseKOneHolds, `Formalism.FrobeniusBaseCase.FrobeniusBaseCaseProofs.HasUniqueFixedPoint, `Formalism.FrobeniusBaseCase.FrobeniusBaseCaseProofs.IdentityTwentyB, `Formalism.FrobeniusBaseCase.StatementFix, `Formalism.FrobeniusContraction.EulerC, `Formalism.FrobeniusContraction.FrobeniusContractionProofs.CocycleComponentRelation, `Formalism.FrobeniusContraction.FrobeniusContractionProofs.ContractBij, `Formalism.FrobeniusContraction.FrobeniusContractionProofs.FiniteCocyclesLeCocycles, `Formalism.FrobeniusContraction.FrobeniusContractionProofs.FrobIterQModPrimeHolds, `Formalism.FrobeniusContraction.FrobeniusContractionProofs.LemmaS, `Formalism.FrobeniusContraction.FrobeniusContractionProofs.LenBound, `Formalism.FrobeniusContraction.FrobeniusContractionProofs.LowestComponent, `Formalism.FrobeniusContraction.HighestWeightResidueAvoids, `Formalism.GL3MeanSquares.ConcavityEquidistribution, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.CountA, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.ExceptionalCharacterBounds.EffSmooth, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.HDSucc, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.MSqPage, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.PNTDHFinishB, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.TwentyFiveMulSmallConstant, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.CardLiftMatrix, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsInvOneAdd, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.MemRangeLinPart, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.NotIsPrimeMapOfSplit, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.PolNatDegreeLe, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.StepIdentity, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.TendstoWeightedTprod, `Formalism.GL3MeanSquares.SmoothedRemainderRealIntegralFormula, `Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.AltNotSolvable, `Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.FewLargeParts, `Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.JordanPrime, `Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.OneNonUnit, `Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.OrbitSubSum, `Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.PermSubSumInv, `Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.PowerPCycle, `Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.PrimitiveOfPCycle, `Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.ResiduesLe, `Formalism.GaloisIrreducibility.GaloisIrreducibilityProofs.RestrictRoots, `Formalism.GaloisIrreducibility.NoSolvableOf, `Formalism.GaussIdealIdentity.GaussIdealPrimality.GaussLocalizationLengthHolds, `Formalism.GaussJetBounds.Statement, `Formalism.GaussValuationBounds.Statement, `Formalism.GelfandTransference.HadamardGelfand.Gelfand, `Formalism.GelfandTransference.Statement, `Formalism.GrowthSums.StatementA, `Formalism.HarderNarasimhan.Statement, `Formalism.HermitianCurvature.BlockKernelPropertiesOfSteps, `Formalism.HermitianCurvature.HermitianCurvatureProofs.AdditiveCharacterPsi, `Formalism.HermitianCurvature.HermitianCurvatureProofs.AffineChangeOfVariables, `Formalism.HermitianCurvature.HermitianCurvatureProofs.BetaFactorisation]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

