import Lean
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsJoin
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsSnapper
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsTildeVanish
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsTwistSplit
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.SubFamilyTwistSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.TildeFiniteESt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.TildeShiftSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.TwistAlg
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.TwistFiniteness.Graded
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.TwistTildeSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.VeryAmpleDegreeSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.VeryAmpleDimSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.VeryAmpleHilbertSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.VeryAmplePowSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.VeryAmpleProductPosSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.VeryAmpleSecsSt
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.VeryAmpleSnapperSt
import GroundTheory.HeightsAndTheta.Heights.LocalDensities.LeviFormGbPotOne
import GroundTheory.HeightsAndTheta.Heights.LocalDensities.Statements
import GroundTheory.HeightsAndTheta.Heights.MatrixCharts.Bounds
import GroundTheory.HeightsAndTheta.Heights.MatrixCharts.PshMatrix
import GroundTheory.HeightsAndTheta.Heights.MatrixCharts.PshMean
import GroundTheory.HeightsAndTheta.Heights.MatrixCharts.StatementsCusp
import GroundTheory.HeightsAndTheta.Heights.MatrixCharts.TransposeEqOfPosSemidef
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.ExistsDominantSubSmul
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.ImportsAlt
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PCBounds
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PCFlPos
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PKaPBound
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PKaPInert
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PKaPSplit
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PNormUbar
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PRestPBound
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PRestSummable
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PShTotIndependent
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PShTotInvertiblePair
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PTermA
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PTermB
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PTermC
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PTermD
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.SingleDecompIsHomDecomp
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.StatementsHomDecomp
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.StatementsShTotSmall
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.TauSumRearrangement
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.TendstoSumPrimesInRestP
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.TotSumLineF
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.GraphIdeal
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PInvertibleIndexCharP
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PInvertibleProductRep
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PLocalGenFamily
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PLocallyPrincipalCoprimeField
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StLocalMultComap
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsBaseChangeRelabel
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsBlockTrdeg
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsDegreeFibre
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsExistsUniqueRelabel
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsSymmRelabel
import GroundTheory.HeightsAndTheta.Heights.Regularisation.IsOpenKappaOpenNeighbourhood
import GroundTheory.HeightsAndTheta.Heights.Regularisation.Statements
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.DegPolynomialIsHomogeneous
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.FlagIntegralRealEqMulDdConst
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.ImportsAlt
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.InhabitantsComb
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCharacterAtIdentity

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsJoin, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsSnapper, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsTildeVanish, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsTwistSplit, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.SubFamilyTwistSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.TildeFiniteESt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.TildeShiftSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.TwistAlg, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.TwistFiniteness.Graded, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.TwistTildeSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.VeryAmpleDegreeSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.VeryAmpleDimSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.VeryAmpleHilbertSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.VeryAmplePowSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.VeryAmpleProductPosSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.VeryAmpleSecsSt, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.VeryAmpleSnapperSt, `GroundTheory.HeightsAndTheta.Heights.LocalDensities.LeviFormGbPotOne, `GroundTheory.HeightsAndTheta.Heights.LocalDensities.Statements, `GroundTheory.HeightsAndTheta.Heights.MatrixCharts.Bounds, `GroundTheory.HeightsAndTheta.Heights.MatrixCharts.PshMatrix, `GroundTheory.HeightsAndTheta.Heights.MatrixCharts.PshMean, `GroundTheory.HeightsAndTheta.Heights.MatrixCharts.StatementsCusp, `GroundTheory.HeightsAndTheta.Heights.MatrixCharts.TransposeEqOfPosSemidef, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.ExistsDominantSubSmul, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.ImportsAlt, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PCBounds, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PCFlPos, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PKaPBound, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PKaPInert, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PKaPSplit, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PNormUbar, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PRestPBound, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PRestSummable, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PShTotIndependent, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PShTotInvertiblePair, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PTermA, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PTermB, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PTermC, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.PTermD, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.SingleDecompIsHomDecomp, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.StatementsHomDecomp, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.StatementsShTotSmall, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.TauSumRearrangement, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.TendstoSumPrimesInRestP, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.TotSumLineF, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.GraphIdeal, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PInvertibleIndexCharP, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PInvertibleProductRep, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PLocalGenFamily, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PLocallyPrincipalCoprimeField, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StLocalMultComap, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsBaseChangeRelabel, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsBlockTrdeg, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsDegreeFibre, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsExistsUniqueRelabel, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsSymmRelabel, `GroundTheory.HeightsAndTheta.Heights.Regularisation.IsOpenKappaOpenNeighbourhood, `GroundTheory.HeightsAndTheta.Heights.Regularisation.Statements, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.DegPolynomialIsHomogeneous, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.FlagIntegralRealEqMulDdConst, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.ImportsAlt, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.InhabitantsComb, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCharacterAtIdentity]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

