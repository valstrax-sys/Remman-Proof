import Lean
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularFunctionIffSectionStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ReversedDualTriangular
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SectionEqZeroOfValuesStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SmoothGroupTangentLift
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SpecStalkSpecializesComp
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.TangentVectorOfDualHom
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.TranslateIntoSmallerOpen
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.CartanDecompositionGeneralLinear
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.DiagonalConjugateCongruenceBox
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.DifferentDvdRamifiedPrimePower
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.DigammaLogBoundLeftRegionStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.HasDerivAtLpOfDominated
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.KaehlerBasisOnLocalizationAwayStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.KaehlerBasisSpreadsToNeighbourhoodStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.LocalFieldTopologyNormBalls
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.MemBoxLatticeIffCongruence
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.MemIntegralGLIffIntegralUnitDetStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.RegularSequenceGermsRegularLocalStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.SmoothLocalRingFreeDifferentialsStatement
import Development.AutomorphicSpectrum.Proofs.HermitianForms.AdelicCharacterLocalNontrivial
import Development.AutomorphicSpectrum.Proofs.HermitianForms.HasCoordOfFiniteDimensional
import Development.AutomorphicSpectrum.Proofs.HermitianForms.IndicatorInSchrodingerSpanStatement
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.BigCellLocal
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.CharacterAugmentationSubspaceQuotientActionTop
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.DualNumberGraphFiltrationIsotropicOfSkew
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.ExistsBasisCols
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.IntegrablePair
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.IsLatticeOfCompactOpen
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.LagrangianStabilizerCharacterTrivial
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.LocallyCompactOfGoodChar
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.SchrodingerModelSelfDualLatticeStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.AnalyticAtMobiusDetJacobianEq
import Development.AutomorphicSpectrum.Proofs.MetricProofs.GramLogUnitaryTriangularInvarianceStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.HolomorphicGroupLawGermStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.HorizontalDivSuppTwist
import Development.AutomorphicSpectrum.Proofs.MetricProofs.IntegralNormSqMobDMulCompMob
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LeviFlatSeparatelyHarmonicStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LeviZeroInCompatibleChartStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LocalUnitaryNormalFrame2x2
import Development.AutomorphicSpectrum.Proofs.MetricProofs.MobiusChangeOfVariablesPair
import Development.AutomorphicSpectrum.Proofs.MetricProofs.MobiusPairAnalyticDetJacobianEq
import Development.AutomorphicSpectrum.Proofs.MetricProofs.MongeAmpereIntegralCongrPotentials
import Development.AutomorphicSpectrum.Proofs.MetricProofs.PolydiscPoissonReproducesHarmonic
import Development.AutomorphicSpectrum.Proofs.MetricProofs.PshExtensionAcrossClosedDenseStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.RiemannFormPeriodDeterminantStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.RingKrullDimTwistSucc
import Development.AutomorphicSpectrum.Proofs.MetricProofs.SmoothExtensionAcrossClosedDenseStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.SmoothInCompatibleChart
import Development.AutomorphicSpectrum.Proofs.MetricProofs.SmoothOnOfChartCompositionStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.SncBoundaryCoordinateChartStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.TwLineSmoothConjInvariantGlue
import Development.AutomorphicSpectrum.Proofs.MetricProofs.TwistIsMultiHomogIdeal
import Development.AutomorphicSpectrum.Proofs.MetricProofs.TwistIsPrime
import Development.AutomorphicSpectrum.Proofs.MetricProofs.WeakConvergenceOffZeroSetStatement
import Development.AutomorphicSpectrum.Statements.AlgebraStatements.PolarisedAFStatement
import Development.AutomorphicSpectrum.Statements.AlgebraStatements.PolarisedFlagStatement
import Development.DiscreteGroups.GlobalIrreducibility.DzGenDefs
import Development.DiscreteGroups.GlobalIrreducibility.DzGenMat
import Development.DiscreteGroups.GlobalIrreducibility.DzStickValMain
import Development.EtaleCohomology.DivisorCycles.AlgStruct2
import Development.EtaleCohomology.DivisorCycles.BigCorner2
import Development.EtaleCohomology.DivisorCycles.ChainPf
import Development.EtaleCohomology.DivisorCycles.CoeMulInv
import Development.EtaleCohomology.DivisorCycles.ConjugateIdempotents

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularFunctionIffSectionStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ReversedDualTriangular, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.SectionEqZeroOfValuesStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.SmoothGroupTangentLift, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.SpecStalkSpecializesComp, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.TangentVectorOfDualHom, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.TranslateIntoSmallerOpen, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.CartanDecompositionGeneralLinear, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.DiagonalConjugateCongruenceBox, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.DifferentDvdRamifiedPrimePower, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.DigammaLogBoundLeftRegionStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.HasDerivAtLpOfDominated, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.KaehlerBasisOnLocalizationAwayStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.KaehlerBasisSpreadsToNeighbourhoodStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.LocalFieldTopologyNormBalls, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.MemBoxLatticeIffCongruence, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.MemIntegralGLIffIntegralUnitDetStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.RegularSequenceGermsRegularLocalStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.SmoothLocalRingFreeDifferentialsStatement, `Development.AutomorphicSpectrum.Proofs.HermitianForms.AdelicCharacterLocalNontrivial, `Development.AutomorphicSpectrum.Proofs.HermitianForms.HasCoordOfFiniteDimensional, `Development.AutomorphicSpectrum.Proofs.HermitianForms.IndicatorInSchrodingerSpanStatement, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.BigCellLocal, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.CharacterAugmentationSubspaceQuotientActionTop, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.DualNumberGraphFiltrationIsotropicOfSkew, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.ExistsBasisCols, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.IntegrablePair, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.IsLatticeOfCompactOpen, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.LagrangianStabilizerCharacterTrivial, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.LocallyCompactOfGoodChar, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.SchrodingerModelSelfDualLatticeStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.AnalyticAtMobiusDetJacobianEq, `Development.AutomorphicSpectrum.Proofs.MetricProofs.GramLogUnitaryTriangularInvarianceStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.HolomorphicGroupLawGermStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.HorizontalDivSuppTwist, `Development.AutomorphicSpectrum.Proofs.MetricProofs.IntegralNormSqMobDMulCompMob, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LeviFlatSeparatelyHarmonicStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LeviZeroInCompatibleChartStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LocalUnitaryNormalFrame2x2, `Development.AutomorphicSpectrum.Proofs.MetricProofs.MobiusChangeOfVariablesPair, `Development.AutomorphicSpectrum.Proofs.MetricProofs.MobiusPairAnalyticDetJacobianEq, `Development.AutomorphicSpectrum.Proofs.MetricProofs.MongeAmpereIntegralCongrPotentials, `Development.AutomorphicSpectrum.Proofs.MetricProofs.PolydiscPoissonReproducesHarmonic, `Development.AutomorphicSpectrum.Proofs.MetricProofs.PshExtensionAcrossClosedDenseStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.RiemannFormPeriodDeterminantStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.RingKrullDimTwistSucc, `Development.AutomorphicSpectrum.Proofs.MetricProofs.SmoothExtensionAcrossClosedDenseStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.SmoothInCompatibleChart, `Development.AutomorphicSpectrum.Proofs.MetricProofs.SmoothOnOfChartCompositionStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.SncBoundaryCoordinateChartStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.TwLineSmoothConjInvariantGlue, `Development.AutomorphicSpectrum.Proofs.MetricProofs.TwistIsMultiHomogIdeal, `Development.AutomorphicSpectrum.Proofs.MetricProofs.TwistIsPrime, `Development.AutomorphicSpectrum.Proofs.MetricProofs.WeakConvergenceOffZeroSetStatement, `Development.AutomorphicSpectrum.Statements.AlgebraStatements.PolarisedAFStatement, `Development.AutomorphicSpectrum.Statements.AlgebraStatements.PolarisedFlagStatement, `Development.DiscreteGroups.GlobalIrreducibility.DzGenDefs, `Development.DiscreteGroups.GlobalIrreducibility.DzGenMat, `Development.DiscreteGroups.GlobalIrreducibility.DzStickValMain, `Development.EtaleCohomology.DivisorCycles.AlgStruct2, `Development.EtaleCohomology.DivisorCycles.BigCorner2, `Development.EtaleCohomology.DivisorCycles.ChainPf, `Development.EtaleCohomology.DivisorCycles.CoeMulInv, `Development.EtaleCohomology.DivisorCycles.ConjugateIdempotents]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

