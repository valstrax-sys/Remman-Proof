import Lean
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.HeckeCharacterChoice.OddRad
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.HeckeCharacterChoice.SplitDef
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.HeckeCharacterChoice.TendstoUnderCofinite
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.IdealCounting.ClassA
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.IdealCounting.ClassB
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.IdealValuations.ResidueUnit
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.EmbDefY
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.FieldDefs
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.LocDiffY
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.LogRootDiscChar
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.IrreducibleSpans.CostCond
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.SelmerDuality.H1cEqH1
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.SumArith
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.UnimodularGram.StarRingOfInvolution
import Development.AutomorphicArithmetic.CyclotomicBounds.DeRhamLattices.AdmissibleLatticesCommensurable
import Development.AutomorphicArithmetic.CyclotomicBounds.DeRhamLattices.CoeffEqZeroOfSumTmulLinearIndependentEqZero
import Development.AutomorphicArithmetic.CyclotomicBounds.DeRhamLattices.ExistsLinearEquivQuotientOfLatticeSum
import Development.AutomorphicArithmetic.CyclotomicBounds.DeRhamLattices.ExistsLinearMapSpanBaseChangeOfSemilinear
import Development.AutomorphicArithmetic.CyclotomicBounds.DeRhamLattices.FiltrationEqSpanOfEisensteinPowBasisChange
import Development.AutomorphicArithmetic.CyclotomicBounds.DeRhamLattices.MemRangeSemilinearOfValuesMemRange
import Development.AutomorphicArithmetic.CyclotomicBounds.RamifiedDiscriminants.Sector
import Development.AutomorphicArithmetic.CyclotomicBounds.RootsOfUnity.TorsionReduceInjective
import Development.AutomorphicArithmetic.CyclotomicBounds.SmallSum
import Development.AutomorphicArithmetic.CyclotomicBounds.TraceDuality.DualFamily
import Development.AutomorphicArithmetic.CyclotomicBounds.TraceDuality.EmbSum
import Development.AutomorphicArithmetic.CyclotomicBounds.TraceDuality.LocalGen
import Development.AutomorphicArithmetic.CyclotomicBounds.TraceDuality.TraceForm
import Development.AutomorphicArithmetic.CyclotomicBounds.WildJets.LogSum
import Development.AutomorphicArithmetic.DedekindLFunctions.CharFamily
import Development.AutomorphicArithmetic.DivisorFrames.AdeleUnitsPolarCircles
import Development.AutomorphicArithmetic.DivisorFrames.ClosedSubgroupEqTopOfDense
import Development.AutomorphicArithmetic.DivisorFrames.EqTopOfCircleSup
import Development.AutomorphicArithmetic.DivisorFrames.ExistsInjectiveLatticeHomRingOfIntegersOfFinrank
import Development.AutomorphicArithmetic.DivisorFrames.ExistsLinearlyDisjointSpan
import Development.AutomorphicArithmetic.DivisorFrames.ExistsNsmulMemSumImageLatticeOfSurjectiveMod
import Development.AutomorphicArithmetic.DivisorFrames.GaussianFourierConjPower
import Development.AutomorphicArithmetic.EtaleIdempotents.GaloisEquivariantTensorDescentOfPrimePowerUnits
import Development.AutomorphicArithmetic.Foundations.Convolution.ConvolutionKernels.AutOrder
import Development.AutomorphicArithmetic.Foundations.Convolution.ConvolutionKernels.CommProj
import Development.AutomorphicArithmetic.Foundations.Convolution.ConvolutionKernels.IntEst
import Development.AutomorphicArithmetic.Foundations.Convolution.ConvolutionKernels.PresOfOrder
import Development.AutomorphicArithmetic.Foundations.Convolution.HermitianDescent.IsHerm
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.ChebClosed
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.Degree
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.GenFund
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.GenTrunc
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.MatrixEntryAbsSumUnitaryLieCoordinatesSplit
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.OpBound
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.PermOf
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.Points
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.PowSym
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.TwoNode
import Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.AdmissibleResidues.SumThree
import Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.AnnihilatorModels.GenericMulOfProd
import Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.SeparatingAlgebras.GroupDetAlt
import Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.ThetaParseval.BlockDeterminants.ExponentialEntries.TprodNe
import Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.TypeConditions.SpanMulMem
import Development.AutomorphicArithmetic.Foundations.LocalLanglands.LocalCentralUnits.PinNum
import Development.AutomorphicArithmetic.Foundations.UnitarySphericalFixing.SatakeParameters.SwOn
import Development.AutomorphicArithmetic.FrobeniusLocalisation.LocStab
import Development.AutomorphicArithmetic.FrobeniusTwistedNorms.ExistsTwistedTraceEqOneOfResidueFrobenius
import Development.AutomorphicArithmetic.IntegralCasts.AlgebraicInfinityType.InfinityType
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AOpRightInvariant

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.HeckeCharacterChoice.OddRad, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.HeckeCharacterChoice.SplitDef, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.HeckeCharacterChoice.TendstoUnderCofinite, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.IdealCounting.ClassA, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.IdealCounting.ClassB, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.IdealValuations.ResidueUnit, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.EmbDefY, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.FieldDefs, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.LocDiffY, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.LogRootDiscChar, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.IrreducibleSpans.CostCond, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.SelmerDuality.H1cEqH1, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.SumArith, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.UnimodularGram.StarRingOfInvolution, `Development.AutomorphicArithmetic.CyclotomicBounds.DeRhamLattices.AdmissibleLatticesCommensurable, `Development.AutomorphicArithmetic.CyclotomicBounds.DeRhamLattices.CoeffEqZeroOfSumTmulLinearIndependentEqZero, `Development.AutomorphicArithmetic.CyclotomicBounds.DeRhamLattices.ExistsLinearEquivQuotientOfLatticeSum, `Development.AutomorphicArithmetic.CyclotomicBounds.DeRhamLattices.ExistsLinearMapSpanBaseChangeOfSemilinear, `Development.AutomorphicArithmetic.CyclotomicBounds.DeRhamLattices.FiltrationEqSpanOfEisensteinPowBasisChange, `Development.AutomorphicArithmetic.CyclotomicBounds.DeRhamLattices.MemRangeSemilinearOfValuesMemRange, `Development.AutomorphicArithmetic.CyclotomicBounds.RamifiedDiscriminants.Sector, `Development.AutomorphicArithmetic.CyclotomicBounds.RootsOfUnity.TorsionReduceInjective, `Development.AutomorphicArithmetic.CyclotomicBounds.SmallSum, `Development.AutomorphicArithmetic.CyclotomicBounds.TraceDuality.DualFamily, `Development.AutomorphicArithmetic.CyclotomicBounds.TraceDuality.EmbSum, `Development.AutomorphicArithmetic.CyclotomicBounds.TraceDuality.LocalGen, `Development.AutomorphicArithmetic.CyclotomicBounds.TraceDuality.TraceForm, `Development.AutomorphicArithmetic.CyclotomicBounds.WildJets.LogSum, `Development.AutomorphicArithmetic.DedekindLFunctions.CharFamily, `Development.AutomorphicArithmetic.DivisorFrames.AdeleUnitsPolarCircles, `Development.AutomorphicArithmetic.DivisorFrames.ClosedSubgroupEqTopOfDense, `Development.AutomorphicArithmetic.DivisorFrames.EqTopOfCircleSup, `Development.AutomorphicArithmetic.DivisorFrames.ExistsInjectiveLatticeHomRingOfIntegersOfFinrank, `Development.AutomorphicArithmetic.DivisorFrames.ExistsLinearlyDisjointSpan, `Development.AutomorphicArithmetic.DivisorFrames.ExistsNsmulMemSumImageLatticeOfSurjectiveMod, `Development.AutomorphicArithmetic.DivisorFrames.GaussianFourierConjPower, `Development.AutomorphicArithmetic.EtaleIdempotents.GaloisEquivariantTensorDescentOfPrimePowerUnits, `Development.AutomorphicArithmetic.Foundations.Convolution.ConvolutionKernels.AutOrder, `Development.AutomorphicArithmetic.Foundations.Convolution.ConvolutionKernels.CommProj, `Development.AutomorphicArithmetic.Foundations.Convolution.ConvolutionKernels.IntEst, `Development.AutomorphicArithmetic.Foundations.Convolution.ConvolutionKernels.PresOfOrder, `Development.AutomorphicArithmetic.Foundations.Convolution.HermitianDescent.IsHerm, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.ChebClosed, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.Degree, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.GenFund, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.GenTrunc, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.MatrixEntryAbsSumUnitaryLieCoordinatesSplit, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.OpBound, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.PermOf, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.Points, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.PowSym, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.TwoNode, `Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.AdmissibleResidues.SumThree, `Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.AnnihilatorModels.GenericMulOfProd, `Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.SeparatingAlgebras.GroupDetAlt, `Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.ThetaParseval.BlockDeterminants.ExponentialEntries.TprodNe, `Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.TypeConditions.SpanMulMem, `Development.AutomorphicArithmetic.Foundations.LocalLanglands.LocalCentralUnits.PinNum, `Development.AutomorphicArithmetic.Foundations.UnitarySphericalFixing.SatakeParameters.SwOn, `Development.AutomorphicArithmetic.FrobeniusLocalisation.LocStab, `Development.AutomorphicArithmetic.FrobeniusTwistedNorms.ExistsTwistedTraceEqOneOfResidueFrobenius, `Development.AutomorphicArithmetic.IntegralCasts.AlgebraicInfinityType.InfinityType, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AOpRightInvariant]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

