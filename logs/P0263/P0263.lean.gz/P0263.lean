import Lean
import Development.AutomorphicArithmetic.CommutativeAlgebra.ExistsInvertibleModuleOfLocallyTrivialCocycle
import Development.AutomorphicArithmetic.CommutativeAlgebra.ExistsMonicFactorLiftOfPowMulSubOnePow
import Development.AutomorphicArithmetic.CommutativeAlgebra.ExistsZeroOfLinearFormJacobianHenselian
import Development.AutomorphicArithmetic.CommutativeAlgebra.TorsorRelSelfIffExistsCoboundary
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.HeckeCharacterChoice.NCInhab
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.IdealValuations.ExistsUnitOfIsDecomp
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.IdealValuations.LocDefY
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.Bounds
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.CondDvd
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.CycDifferent
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.CycInertia
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.Decomp
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.Filtration
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.RootNorm
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.SelmerDuality.Frobenius
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.SelmerDuality.LengthFrac
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.EqOneOfMemPrincOne
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.GalAut
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.NuBasic
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.PrincTop
import Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.GchiConj
import Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.LandauCoeff
import Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.LandauDichotomy
import Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.LandauNearest
import Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.LandauPoleAsym
import Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.landauTails
import Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.landauWindowIneq
import Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.mellinGchiModOne
import Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.mellinGchiOfNeOne
import Development.AutomorphicArithmetic.DivisorFrames.EmbeddingCountExtensions
import Development.AutomorphicArithmetic.Foundations.Convolution.HermitianDescent.ExistsNotMem
import Development.AutomorphicArithmetic.Foundations.Convolution.HermitianDescent.GalExt
import Development.AutomorphicArithmetic.Foundations.Convolution.HermitianDescent.NmCent
import Development.AutomorphicArithmetic.Foundations.Convolution.HermitianDescent.NormProd
import Development.AutomorphicArithmetic.Foundations.Convolution.HermitianDescent.RepNmSucc
import Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.NormEx
import Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.QuotEq
import Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.QuotFub
import Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.QuotLin
import Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.QuotMap
import Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.QuotOpen
import Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.QuotPi
import Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.QuotProd
import Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.SplitEquiv
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.AevalSingleZero
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.HasSumSingle
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.IntMvPolynomialCoeffAbsSumAddLe
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.KillLiftSingle
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.LiftSingle
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.SubEqZeroIff
import Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.AnnihilatorModels.GenericMulOfProdHolds
import Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.SchurDeterminants.FibreSum
import Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.SchurDeterminants.PairSplit
import Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.SchurDeterminants.WeylTieOf
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.EqIdOfFixed
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CayleyHamiltonSymmetric
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FgZ1T
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LevelOfCongruence
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Parity
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RelativeK1Module
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SimpLemmas
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StationaryPhaseModel
import Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.DeRham
import Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.Embedding

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.CommutativeAlgebra.ExistsInvertibleModuleOfLocallyTrivialCocycle, `Development.AutomorphicArithmetic.CommutativeAlgebra.ExistsMonicFactorLiftOfPowMulSubOnePow, `Development.AutomorphicArithmetic.CommutativeAlgebra.ExistsZeroOfLinearFormJacobianHenselian, `Development.AutomorphicArithmetic.CommutativeAlgebra.TorsorRelSelfIffExistsCoboundary, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.HeckeCharacterChoice.NCInhab, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.IdealValuations.ExistsUnitOfIsDecomp, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.IdealValuations.LocDefY, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.Bounds, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.CondDvd, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.CycDifferent, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.CycInertia, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.Decomp, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.Filtration, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.RootNorm, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.SelmerDuality.Frobenius, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.SelmerDuality.LengthFrac, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.EqOneOfMemPrincOne, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.GalAut, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.NuBasic, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.PrincTop, `Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.GchiConj, `Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.LandauCoeff, `Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.LandauDichotomy, `Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.LandauNearest, `Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.LandauPoleAsym, `Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.landauTails, `Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.landauWindowIneq, `Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.mellinGchiModOne, `Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.mellinGchiOfNeOne, `Development.AutomorphicArithmetic.DivisorFrames.EmbeddingCountExtensions, `Development.AutomorphicArithmetic.Foundations.Convolution.HermitianDescent.ExistsNotMem, `Development.AutomorphicArithmetic.Foundations.Convolution.HermitianDescent.GalExt, `Development.AutomorphicArithmetic.Foundations.Convolution.HermitianDescent.NmCent, `Development.AutomorphicArithmetic.Foundations.Convolution.HermitianDescent.NormProd, `Development.AutomorphicArithmetic.Foundations.Convolution.HermitianDescent.RepNmSucc, `Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.NormEx, `Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.QuotEq, `Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.QuotFub, `Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.QuotLin, `Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.QuotMap, `Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.QuotOpen, `Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.QuotPi, `Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.QuotProd, `Development.AutomorphicArithmetic.Foundations.Convolution.LocalGroupAnalysis.SplitEquiv, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.AevalSingleZero, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.HasSumSingle, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.IntMvPolynomialCoeffAbsSumAddLe, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.KillLiftSingle, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.LiftSingle, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.SubEqZeroIff, `Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.AnnihilatorModels.GenericMulOfProdHolds, `Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.SchurDeterminants.FibreSum, `Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.SchurDeterminants.PairSplit, `Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.SchurDeterminants.WeylTieOf, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.EqIdOfFixed, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CayleyHamiltonSymmetric, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FgZ1T, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LevelOfCongruence, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Parity, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RelativeK1Module, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SimpLemmas, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.StationaryPhaseModel, `Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.DeRham, `Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.Embedding]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

