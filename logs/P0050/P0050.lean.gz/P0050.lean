import Lean
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsCommonMultiple
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsCyclic
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsDiagonalization
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsEquivOfFinrank
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsEvaluation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsExpansion
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsFactor
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsFinsetSeparating
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsFixedLift
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsGoodWithoutBad
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsIndepOfSat
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsInjectiveCharacter
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsInvariantSubspace
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsKill
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsLimitOfApprox
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsLocalGenerator
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsNatMulMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsNsmulMemClosure
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsOfLi
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsOrthonormalBasisSesquilinear
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsPermOfMapEq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsPlace
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsPowMemOfMulMemPow
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsPowSmulMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsPowSmulMemAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsPrimeMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsPsi
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsRetr
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsRingHomExtendOfIsIntegral
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsRootCongruence
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsRootOfAdicComplete
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsRowsLinearIndependent
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsSemi
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsSmoothExtensionNear
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsSmulMemTer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsSpanModSq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsSum
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsSumTmul
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsSupported
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsUniqueFixedPoint
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsUniqueNormed
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsValuationSubLeOne
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExpSq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExtIntegral
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExtendPt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FGe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FInt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FactorConjugationCancel
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FactorialTendstoZero
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FactorizationBis
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiltrationExponentBound
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FinOfHom
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FinQuotAnn
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiniteAndNcardBound
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiniteModuleMaximalIdealAnnihilation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiniteOfFiniteOverNormal
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiniteOfIsFiniteLength
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FinitePlaceSumLe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiniteSpanAddSmul
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiniteSubfieldSpecial
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FinitelyGeneratedModPow
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FinrankOfPlace
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FirstStatementA
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FirstStatementB

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsCommonMultiple, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsCyclic, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsDiagonalization, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsEquivOfFinrank, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsEvaluation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsExpansion, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsFactor, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsFinsetSeparating, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsFixedLift, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsGoodWithoutBad, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsIndepOfSat, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsInjectiveCharacter, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsInvariantSubspace, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsKill, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsLimitOfApprox, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsLocalGenerator, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsNatMulMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsNsmulMemClosure, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsOfLi, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsOrthonormalBasisSesquilinear, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsPermOfMapEq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsPlace, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsPowMemOfMulMemPow, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsPowSmulMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsPowSmulMemAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsPrimeMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsPsi, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsRetr, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsRingHomExtendOfIsIntegral, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsRootCongruence, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsRootOfAdicComplete, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsRowsLinearIndependent, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsSemi, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsSmoothExtensionNear, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsSmulMemTer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsSpanModSq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsSum, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsSumTmul, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsSupported, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsUniqueFixedPoint, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsUniqueNormed, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsValuationSubLeOne, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExpSq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExtIntegral, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExtendPt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FGe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FInt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FactorConjugationCancel, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FactorialTendstoZero, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FactorizationBis, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiltrationExponentBound, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FinOfHom, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FinQuotAnn, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiniteAndNcardBound, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiniteModuleMaximalIdealAnnihilation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiniteOfFiniteOverNormal, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiniteOfIsFiniteLength, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FinitePlaceSumLe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiniteSpanAddSmul, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiniteSubfieldSpecial, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FinitelyGeneratedModPow, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FinrankOfPlace, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FirstStatementA, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FirstStatementB]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

