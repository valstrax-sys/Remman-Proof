import Lean
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PFiniteAlgebraLengthSum
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PLocalizedQuotientLength
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PfContractedHypothesesExample
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.Statements
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsHilbEmptyZero
import GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.IsClosedUnitaryOfComplex
import GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.PDoubleCosetCovolume
import GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.PIntegralFormCovolume
import GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.PTorusIntegralHomogeneous
import GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.PUnipotentModulusHaar
import GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.PUnitsInvHaar
import GroundTheory.HeightsAndTheta.Heights.HeightComparison.HeightPlacesRingQuot
import GroundTheory.HeightsAndTheta.Heights.HeightComparison.PSubringPrimeMaximal
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.AltFrob
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.AltPush
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.AltRow
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.ChartMassAffine
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.CoordFirst
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.CoordSiegel
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.CoordWeak
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PCauchyBinet
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PHadamardPSD
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PHermFormCompare
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PLogCardLength
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PPlueckerKernel
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PPlueckerNormSq
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PPlueckerUnitBound
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRootsOfUnityDense
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.RestCutBasic
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.ShortVectors
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.Statements
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartMass
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsGauss
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsInvertibleIdealIndex
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsSympl
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsTheta
import GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.Slopes
import GroundTheory.HeightsAndTheta.Heights.HermitianSum
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IntNumOffBlocks
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.PClopenPieceSheetCount
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.PEntirePolynomialGrowth
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.PMonicRootGrowth
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StPieceCoefficientsHolomorphic
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StPrimeCoverPieceSheets
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StatementsUnbranched
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PComplexMinimalPrimesContract
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PConstantsDescend
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PDoubleComplexVanish
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PFiniteSeparatingModel
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PIndependentModBaseChange
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PIrreducibleConnected
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PMixedTopAlgebra
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PNoetherProjection
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PPolyNonnegAtZero
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PPolyNonvanishDense
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PPolySandwich
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PPrimeComplexRadical
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PRatPrimeDense
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PRootGridLower
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PRootsBounded
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PRootsLiftToZeros
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PRootsNear
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PSerreGraded
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PUnitApprox

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PFiniteAlgebraLengthSum, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PLocalizedQuotientLength, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PfContractedHypothesesExample, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.Statements, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsHilbEmptyZero, `GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.IsClosedUnitaryOfComplex, `GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.PDoubleCosetCovolume, `GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.PIntegralFormCovolume, `GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.PTorusIntegralHomogeneous, `GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.PUnipotentModulusHaar, `GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.PUnitsInvHaar, `GroundTheory.HeightsAndTheta.Heights.HeightComparison.HeightPlacesRingQuot, `GroundTheory.HeightsAndTheta.Heights.HeightComparison.PSubringPrimeMaximal, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.AltFrob, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.AltPush, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.AltRow, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.ChartMassAffine, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.CoordFirst, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.CoordSiegel, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.CoordWeak, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PCauchyBinet, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PHadamardPSD, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PHermFormCompare, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PLogCardLength, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PPlueckerKernel, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PPlueckerNormSq, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PPlueckerUnitBound, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRootsOfUnityDense, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.RestCutBasic, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.ShortVectors, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.Statements, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartMass, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsGauss, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsInvertibleIdealIndex, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsSympl, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsTheta, `GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.Slopes, `GroundTheory.HeightsAndTheta.Heights.HermitianSum, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IntNumOffBlocks, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.PClopenPieceSheetCount, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.PEntirePolynomialGrowth, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.PMonicRootGrowth, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StPieceCoefficientsHolomorphic, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StPrimeCoverPieceSheets, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StatementsUnbranched, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PComplexMinimalPrimesContract, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PConstantsDescend, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PDoubleComplexVanish, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PFiniteSeparatingModel, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PIndependentModBaseChange, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PIrreducibleConnected, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PMixedTopAlgebra, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PNoetherProjection, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PPolyNonnegAtZero, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PPolyNonvanishDense, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PPolySandwich, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PPrimeComplexRadical, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PRatPrimeDense, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PRootGridLower, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PRootsBounded, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PRootsLiftToZeros, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PRootsNear, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PSerreGraded, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PUnitApprox]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

