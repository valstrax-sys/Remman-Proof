import Lean
import Development.AutomorphicArithmetic.Foundations.LocalLanglands.LocalCentralUnits.PinChar
import Development.AutomorphicArithmetic.FrobeniusTwistedNorms.IsAdicCompleteAdjoinRootOfMonic
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AbsoluteValueAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AbsoluteValueAltAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BoundedSums
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaF
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaG
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CasimirCommutation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CommonEigenvalueSecond
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CommonEigenvectorExistence
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DensePiDecomposition
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DerAeval
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DiagHermitian
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsCommonEigenvectorSecond
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsFun
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsNsmulIntegral
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiniteOfApprox
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FlatnessPrecompleteProducts
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GLRealOpen
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMoreBis
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerFurther
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsPFSum
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LinearIndependentEigenvectors
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocalSituation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemFixedPiIff
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MonicNormLtOne
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MulFunctionAe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MulLinearAe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NonemptyNormalModelOfPresentation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProofSimp
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RangeExtension
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RestrictAutomorphism
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RootEquality
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SimultaneousEigenvectors
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpecialLinearTensor
import Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.Envelope
import Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.TruncLogEqOfPowEqZero
import Development.AutomorphicArithmetic.IntegralCasts.IsOpenStabOfMemNhds
import Development.AutomorphicArithmetic.IntegralCasts.RegAlgFam
import Development.AutomorphicArithmetic.IwahoriCommensurability.CharpolySmulSeparable
import Development.AutomorphicArithmetic.LocalEmbeddings.CoinvFin
import Development.AutomorphicArithmetic.OrbitLabellings.FnumEqRhoMulSumOfDemandRatioLe
import Development.AutomorphicArithmetic.QuadraticCharacters.PreHostA
import Development.AutomorphicArithmetic.ThetaCorrespondence.HoweDuality.Nak
import Development.AutomorphicArithmetic.ThetaCorrespondence.HoweDuality.PartStable
import Development.AutomorphicArithmetic.ThetaCorrespondence.HoweDuality.RadFin
import Development.AutomorphicArithmetic.ThetaCorrespondence.HoweDuality.SlotBasic
import Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.BandCc
import Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.ConvAssoc
import Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.ConvEig
import Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.EigBand
import Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.EqZeroOfTest
import Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.ExistsCompactTail
import Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.Fourier
import Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.Transl
import Development.AutomorphicArithmetic.TwistedTraces.ExistsScalarOfTwistedIntertwinerCommutingAlgebra
import Development.AutomorphicArithmetic.UnitaryInvolutions.ExistsMulInvolutionEqFixedUnitOfComplete
import Development.AutomorphicArithmetic.WeightCongruences.DvdNormSubOneOfIdempotentInterpolationRelNormOne
import Development.AutomorphicArithmetic.WeightCongruences.ExistsShiftWeightCongruenceLtTorsionOrder
import Development.AutomorphicArithmetic.WeightCongruences.IffNum
import Development.AutomorphicArithmetic.WeightCongruences.NormRootOfUnityQuadraticSubfield
import Development.AutomorphicArithmetic.WeightCongruences.ProdResidueCharNormOneUnitEqOne
import Development.AutomorphicArithmetic.WhittakerHecke.FiniteTranslatesMatrixCoefficient
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.DualOrder

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.Foundations.LocalLanglands.LocalCentralUnits.PinChar, `Development.AutomorphicArithmetic.FrobeniusTwistedNorms.IsAdicCompleteAdjoinRootOfMonic, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AbsoluteValueAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.AbsoluteValueAltAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.BoundedSums, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaF, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CapelliComplements.FirstLemmaG, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CasimirCommutation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CommonEigenvalueSecond, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CommonEigenvectorExistence, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DensePiDecomposition, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DerAeval, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DiagHermitian, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsCommonEigenvectorSecond, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsFun, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsNsmulIntegral, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FiniteOfApprox, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FlatnessPrecompleteProducts, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GLRealOpen, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMoreBis, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerFurther, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsPFSum, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LinearIndependentEigenvectors, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocalSituation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemFixedPiIff, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MonicNormLtOne, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MulFunctionAe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MulLinearAe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NonemptyNormalModelOfPresentation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ProofSimp, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RangeExtension, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RestrictAutomorphism, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.RootEquality, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SimultaneousEigenvectors, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.SpecialLinearTensor, `Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.Envelope, `Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.TruncLogEqOfPowEqZero, `Development.AutomorphicArithmetic.IntegralCasts.IsOpenStabOfMemNhds, `Development.AutomorphicArithmetic.IntegralCasts.RegAlgFam, `Development.AutomorphicArithmetic.IwahoriCommensurability.CharpolySmulSeparable, `Development.AutomorphicArithmetic.LocalEmbeddings.CoinvFin, `Development.AutomorphicArithmetic.OrbitLabellings.FnumEqRhoMulSumOfDemandRatioLe, `Development.AutomorphicArithmetic.QuadraticCharacters.PreHostA, `Development.AutomorphicArithmetic.ThetaCorrespondence.HoweDuality.Nak, `Development.AutomorphicArithmetic.ThetaCorrespondence.HoweDuality.PartStable, `Development.AutomorphicArithmetic.ThetaCorrespondence.HoweDuality.RadFin, `Development.AutomorphicArithmetic.ThetaCorrespondence.HoweDuality.SlotBasic, `Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.BandCc, `Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.ConvAssoc, `Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.ConvEig, `Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.EigBand, `Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.EqZeroOfTest, `Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.ExistsCompactTail, `Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.Fourier, `Development.AutomorphicArithmetic.ThetaCorrespondence.RealBands.Transl, `Development.AutomorphicArithmetic.TwistedTraces.ExistsScalarOfTwistedIntertwinerCommutingAlgebra, `Development.AutomorphicArithmetic.UnitaryInvolutions.ExistsMulInvolutionEqFixedUnitOfComplete, `Development.AutomorphicArithmetic.WeightCongruences.DvdNormSubOneOfIdempotentInterpolationRelNormOne, `Development.AutomorphicArithmetic.WeightCongruences.ExistsShiftWeightCongruenceLtTorsionOrder, `Development.AutomorphicArithmetic.WeightCongruences.IffNum, `Development.AutomorphicArithmetic.WeightCongruences.NormRootOfUnityQuadraticSubfield, `Development.AutomorphicArithmetic.WeightCongruences.ProdResidueCharNormOneUnitEqOne, `Development.AutomorphicArithmetic.WhittakerHecke.FiniteTranslatesMatrixCoefficient, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.DualOrder]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

