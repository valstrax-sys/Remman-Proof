import Lean
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.IwahoriStatementStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.LatticeCongruenceSubgroupsOpenCompactStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.MatrixNearIdentityInCongruenceSubgroup
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.ModularityStatementStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.MovingStatementStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.NearIdentityUpperLowerFactorization
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.PairingStatementStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.ProjectionStatementStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.SimpleOfCommutativeStatementStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.StatementCommutativeStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.StatementStarStatement
import CompanionTheory.ThickeningEstimates.LieGroupReduction.HasDerivAtSchwartzToL2
import Development.AbelianVarietyTheory.BlockTheory.CMModuli.CoefficientFieldBaseChange
import Development.AbelianVarietyTheory.BlockTheory.CMModuli.ExponentialDifferential
import Development.AbelianVarietyTheory.BlockTheory.ExistenceTori.GeneratorValues
import Development.AbelianVarietyTheory.BlockTheory.ExistenceTori.JetChartLaws
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.ConjugatePlaceEigen
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.EigenLatticeRankLie
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.FormalDegreeHaarQuotient
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.LieMatrixVectors
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.SmoothDecompositionForms
import Development.AbelianVarietyTheory.BlockTheory.SiegelEisenstein.FlatOmegaSeries
import Development.AbelianVarietyTheory.BlockTheory.SiegelEisenstein.SymmetricPatternGroup
import Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.TrivialOfDensityOne
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.FramePositiveSum
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.NormalRepresentationLattice
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.OmegaColumnSlices
import Development.AbelianVarietyTheory.BlockTheory.UniformisationCharts.OLinearMaps
import Development.AbelianVarietyTheory.BlockTheory.UniformisationCharts.SeparatedSymmetricModel
import Development.AbelianVarietyTheory.Counterexamples.LevelGroupExamples.PEqQOfNeg
import Development.AbelianVarietyTheory.Counterexamples.ModuliSurvey.CubeMapTripleProductUnique
import Development.AbelianVarietyTheory.Counterexamples.ModuliSurvey.W0EqOfRtEq
import Development.AbelianVarietyTheory.Counterexamples.NonGaloisSurvey.CrystallineCyclotomic
import Development.AbelianVarietyTheory.Counterexamples.NonGaloisSurvey.UnitsOfFieldDD
import Development.AbelianVarietyTheory.Definitions.ArchimedeanThetaValues.OneAddZeta21PowSevenAddPowFourteenEqZero
import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.MonodromyZeroOfWeilDeligneRepClassIff
import Development.AbelianVarietyTheory.Definitions.Divisors.DivisorSupportCondition
import Development.AbelianVarietyTheory.Definitions.Divisors.ExistsRetractionMulP
import Development.AbelianVarietyTheory.Definitions.Divisors.IdTower
import Development.AbelianVarietyTheory.Definitions.Divisors.IsAdmissibleIntegralBasisChangeOne
import Development.AbelianVarietyTheory.Definitions.Divisors.JmMulJm
import Development.AbelianVarietyTheory.Definitions.Divisors.MiddleNotMem
import Development.AbelianVarietyTheory.Definitions.Divisors.OneFormMapEqKaehlerDifferentialMap
import Development.AbelianVarietyTheory.Definitions.Divisors.PadicActionConstInjective
import Development.AbelianVarietyTheory.Definitions.Foundations.PowLtFirstRadius
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsSSFun
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.PullHXApply
import Development.AbelianVarietyTheory.Definitions.GlobalTwisting.CcKPrimitive
import Development.AbelianVarietyTheory.Definitions.HermitianLattices.TraceFormBilinSeparatingLeftIff
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.NotRedOfMem
import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.ConvZero
import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.DieuUnifDiagNotSurjective
import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.ExistsEqAlgebraMapAddPowMul
import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.SandZero
import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.UnramifiedSubfieldLeCyclotomicExt
import Development.AbelianVarietyTheory.Definitions.ShimuraVarieties.ExistsIsAffineOpenOfFiniteOpensProj
import Development.AbelianVarietyTheory.Definitions.ShimuraVarieties.IrrelevantLeMapLinearGradedMap
import Development.AbelianVarietyTheory.Definitions.SpanningFamilies.FirstCoordinateAdmissible
import Development.AbelianVarietyTheory.Definitions.TwistedInnerProducts.TypeChainPrincipalEntryNeZero
import Development.AbelianVarietyTheory.Proofs.AbelianSchemeLawProofs.AbelianSchemeTorusCompare
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.ExistsConjHarmOfSpan
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.ExistsIsQGroupWeilRestriction
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.ExistsLocalNonnormOfNonsquareAdicCompletion
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.ExistsMultiplierDescendBlockDiagPartOfRatIdempotStatement

open Lean Elab Command

def auditTargets : Array Name := #[`CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.IwahoriStatementStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.LatticeCongruenceSubgroupsOpenCompactStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.MatrixNearIdentityInCongruenceSubgroup, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.ModularityStatementStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.MovingStatementStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.NearIdentityUpperLowerFactorization, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.PairingStatementStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.ProjectionStatementStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.SimpleOfCommutativeStatementStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.StatementCommutativeStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.StatementStarStatement, `CompanionTheory.ThickeningEstimates.LieGroupReduction.HasDerivAtSchwartzToL2, `Development.AbelianVarietyTheory.BlockTheory.CMModuli.CoefficientFieldBaseChange, `Development.AbelianVarietyTheory.BlockTheory.CMModuli.ExponentialDifferential, `Development.AbelianVarietyTheory.BlockTheory.ExistenceTori.GeneratorValues, `Development.AbelianVarietyTheory.BlockTheory.ExistenceTori.JetChartLaws, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.ConjugatePlaceEigen, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.EigenLatticeRankLie, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.FormalDegreeHaarQuotient, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.LieMatrixVectors, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.SmoothDecompositionForms, `Development.AbelianVarietyTheory.BlockTheory.SiegelEisenstein.FlatOmegaSeries, `Development.AbelianVarietyTheory.BlockTheory.SiegelEisenstein.SymmetricPatternGroup, `Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.TrivialOfDensityOne, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.FramePositiveSum, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.NormalRepresentationLattice, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.OmegaColumnSlices, `Development.AbelianVarietyTheory.BlockTheory.UniformisationCharts.OLinearMaps, `Development.AbelianVarietyTheory.BlockTheory.UniformisationCharts.SeparatedSymmetricModel, `Development.AbelianVarietyTheory.Counterexamples.LevelGroupExamples.PEqQOfNeg, `Development.AbelianVarietyTheory.Counterexamples.ModuliSurvey.CubeMapTripleProductUnique, `Development.AbelianVarietyTheory.Counterexamples.ModuliSurvey.W0EqOfRtEq, `Development.AbelianVarietyTheory.Counterexamples.NonGaloisSurvey.CrystallineCyclotomic, `Development.AbelianVarietyTheory.Counterexamples.NonGaloisSurvey.UnitsOfFieldDD, `Development.AbelianVarietyTheory.Definitions.ArchimedeanThetaValues.OneAddZeta21PowSevenAddPowFourteenEqZero, `Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.MonodromyZeroOfWeilDeligneRepClassIff, `Development.AbelianVarietyTheory.Definitions.Divisors.DivisorSupportCondition, `Development.AbelianVarietyTheory.Definitions.Divisors.ExistsRetractionMulP, `Development.AbelianVarietyTheory.Definitions.Divisors.IdTower, `Development.AbelianVarietyTheory.Definitions.Divisors.IsAdmissibleIntegralBasisChangeOne, `Development.AbelianVarietyTheory.Definitions.Divisors.JmMulJm, `Development.AbelianVarietyTheory.Definitions.Divisors.MiddleNotMem, `Development.AbelianVarietyTheory.Definitions.Divisors.OneFormMapEqKaehlerDifferentialMap, `Development.AbelianVarietyTheory.Definitions.Divisors.PadicActionConstInjective, `Development.AbelianVarietyTheory.Definitions.Foundations.PowLtFirstRadius, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsSSFun, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.PullHXApply, `Development.AbelianVarietyTheory.Definitions.GlobalTwisting.CcKPrimitive, `Development.AbelianVarietyTheory.Definitions.HermitianLattices.TraceFormBilinSeparatingLeftIff, `Development.AbelianVarietyTheory.Definitions.LatticeFrames.NotRedOfMem, `Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.ConvZero, `Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.DieuUnifDiagNotSurjective, `Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.ExistsEqAlgebraMapAddPowMul, `Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.SandZero, `Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.UnramifiedSubfieldLeCyclotomicExt, `Development.AbelianVarietyTheory.Definitions.ShimuraVarieties.ExistsIsAffineOpenOfFiniteOpensProj, `Development.AbelianVarietyTheory.Definitions.ShimuraVarieties.IrrelevantLeMapLinearGradedMap, `Development.AbelianVarietyTheory.Definitions.SpanningFamilies.FirstCoordinateAdmissible, `Development.AbelianVarietyTheory.Definitions.TwistedInnerProducts.TypeChainPrincipalEntryNeZero, `Development.AbelianVarietyTheory.Proofs.AbelianSchemeLawProofs.AbelianSchemeTorusCompare, `Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.ExistsConjHarmOfSpan, `Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.ExistsIsQGroupWeilRestriction, `Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.ExistsLocalNonnormOfNonsquareAdicCompletion, `Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.ExistsMultiplierDescendBlockDiagPartOfRatIdempotStatement]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

