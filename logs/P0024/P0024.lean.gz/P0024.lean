import Lean
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.AbsSubLeExpNegSixteenthMul
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.AeEqOfDenseOfLocalSqBound
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.AestronglyMeasurableCompRep
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.CardQuotPow
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.CauchySchwarz
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.CoeFnSumSmulAeEq
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.CoeSmulMem
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.DecayOfMemSpan
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.DeepRegionExponents
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.DetUpdateRowLastSingle
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.DifferentSmulMemOfTraceIntegral
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.DiscreteSubgroupCountableAndExistsStrictFundamen
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsConsecutiveRatioLeRpow
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsHaarMapProdEq
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsIntSmulEqInteger
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsIntSmulIsIntegral
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsIntSmulLe
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsIntSmulMemLattice
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsIntSubMemPow
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsIsometricIntertwinerOfMatrixCoeffEq
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsMapMulRightEqSmul
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsMeasurableCosetSection
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsMeasurableFundamentalDomain
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsMeasurableLintegralCosetEqOneClosedSubgrou
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsMemFractionalIdealGeneratorAtPrimesOver
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsPowSmulMem
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsRealSubmoduleBlockFinrankLe
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsSubmoduleSkewBlockFinrankLe
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsUnimodularLiftOfUnimodularMod
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsUnitaryMulVecEqOfFormEq
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExpQuadraticLowerAndLogLinearLower
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExponentDivisorSumLe
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExtendAeLinearOfLocalSqBoundDense
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.FiniteAndNcardLeProdOfLevels
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.FinprodEqProdMulFinprodIte
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.FormallyUnramifiedRingOfIntegersIffDifferentIdea
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.GapThresholdPaysFarTerms
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.HasFDerivAtOfContinuousPartials
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.Imports
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsBis
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsBisBis
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsBisExtra
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsBisMore
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsBisSide
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsBisTer
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsExtra
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsFurther
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsLast
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsMore
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsRest
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsSide
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsTail
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsTer
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.InnerAddInnerEqZeroSpan
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.IntegrableExpNegMulAbs
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.IntegrableExpNegMulOfSublevelGrowth
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.IntegralNonnegOfSums
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.IntegratedOperatorIsStarProjectionAndSandwich
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.IsLatticeComapSubtype
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.IsRadicalSpanPrimeOfNcardPrimesOverEqFinrank
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.IwasawaSliceIndicatorLintegralLe
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.LintegralBoundByDyadicSummation
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.LocalGen
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.MainTheorem

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.FlagMeasures.AbsSubLeExpNegSixteenthMul, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.AeEqOfDenseOfLocalSqBound, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.AestronglyMeasurableCompRep, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.CardQuotPow, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.CauchySchwarz, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.CoeFnSumSmulAeEq, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.CoeSmulMem, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.DecayOfMemSpan, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.DeepRegionExponents, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.DetUpdateRowLastSingle, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.DifferentSmulMemOfTraceIntegral, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.DiscreteSubgroupCountableAndExistsStrictFundamen, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsConsecutiveRatioLeRpow, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsHaarMapProdEq, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsIntSmulEqInteger, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsIntSmulIsIntegral, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsIntSmulLe, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsIntSmulMemLattice, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsIntSubMemPow, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsIsometricIntertwinerOfMatrixCoeffEq, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsMapMulRightEqSmul, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsMeasurableCosetSection, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsMeasurableFundamentalDomain, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsMeasurableLintegralCosetEqOneClosedSubgrou, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsMemFractionalIdealGeneratorAtPrimesOver, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsPowSmulMem, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsRealSubmoduleBlockFinrankLe, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsSubmoduleSkewBlockFinrankLe, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsUnimodularLiftOfUnimodularMod, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsUnitaryMulVecEqOfFormEq, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExpQuadraticLowerAndLogLinearLower, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExponentDivisorSumLe, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExtendAeLinearOfLocalSqBoundDense, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.FiniteAndNcardLeProdOfLevels, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.FinprodEqProdMulFinprodIte, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.FormallyUnramifiedRingOfIntegersIffDifferentIdea, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.GapThresholdPaysFarTerms, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.HasFDerivAtOfContinuousPartials, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.Imports, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsBis, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsBisBis, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsBisExtra, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsBisMore, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsBisSide, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsBisTer, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsExtra, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsFurther, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsLast, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsMore, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsRest, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsSide, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsTail, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.ImportsTer, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.InnerAddInnerEqZeroSpan, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.IntegrableExpNegMulAbs, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.IntegrableExpNegMulOfSublevelGrowth, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.IntegralNonnegOfSums, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.IntegratedOperatorIsStarProjectionAndSandwich, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.IsLatticeComapSubtype, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.IsRadicalSpanPrimeOfNcardPrimesOverEqFinrank, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.IwasawaSliceIndicatorLintegralLe, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.LintegralBoundByDyadicSummation, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.LocalGen, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.MainTheorem]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

