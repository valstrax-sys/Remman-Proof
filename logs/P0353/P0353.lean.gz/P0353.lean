import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PurityFreeOfCompleteRegularLocalStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuadraticFormFderivComplexStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuasiperiodicDifferenceHolomorphicStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneReOpenNearOfIsUnitStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneTraceOpenFiniteAdeleRingStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneTraceOpenPiStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneTraceOpenProdStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RadialElementDifferenceExistsStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RangeGenericPointStalkSubsetOfDenseOpenStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RepTraceEqMulAlgebraTraceStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingHomsDvrCardEqFinrankStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SandwichDatumTraceEqStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchrodingerRepSchwartzPolynomialBoundStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchroedingerOperatorHeisenbergInnerPreservingStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchroedingerOperatorHeisenbergPreservesSchwartzBStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzBruhatLintegralSqNeTop
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzBruhatPartitionOfUnity
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzBruhatReindexRows
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzOperatorParametricExtension
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SectionPullbackHolomorphicStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ShearGLTransposeMul
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SiegelLemmaSmallVectorStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SiegelParabolicOperatorsHeisenbergCompat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmoothGenericFibreClosurePartition
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SncAtlasRankDropPotential
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SncComponentHolomorphicAtlas
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SplitUnitarySiegelParabolicBlockRelations
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SquaringOpenAtOneOfCompleteTwoNeZeroStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.StrPullOperatorEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubInvMulOutMemIff
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumCoeffWindowCrossingFiberPointStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumLambdaPullRhoIdentity
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SummableHilbertEisensteinLatticeClassWeightTwo
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SuperconnFinsetLinear
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SuperconnectionDifferentiable
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaFactorNormInvarianceStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaProjectionEigenImage
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaQuasiPeriodicNormalForm
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaSectionTwistDecomposition
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaVanishOnFiberTangentStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaZeroOneLowerVanishStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaZeroOneSkewConjStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ToSpanSingletonConstGenSurjective
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TopMulDescendedSubmoduleOfUnitCocycleEqTopStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionPointRowsSumEqDivisorSeries
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsorBaseChangeZmodStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslateDifferenceMemSpanStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationDilationStableRadialElementStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UniformTaylorBoundLeviPluriharmonicSplitStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryAndSeparates
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryCharacterAbsScalarBasicProperties
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryFlagFrameExistsStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitarySignsHaarIsMulRightInvariant
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.VacuumMatrixCoefficientSq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.VanishingOnWallsDivisibleStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeightNormSqSmoothPosStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeightedLintegralSobolevPointwiseStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeilInvariantFunctionalInductionStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ZmodTorsorBaseChangeTransportPoint
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ZmodTorsorExistsPointFiniteSeparable
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ZmodTorsorFieldEqProdGaloisStatement
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.AlgMem
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.CardCokernelUnramifiedOrderMatrixOfDetBaseStatement
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.CardPrimitiveTupleExtensionsLe

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.PurityFreeOfCompleteRegularLocalStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuadraticFormFderivComplexStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuasiperiodicDifferenceHolomorphicStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneReOpenNearOfIsUnitStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneTraceOpenFiniteAdeleRingStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneTraceOpenPiStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneTraceOpenProdStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RadialElementDifferenceExistsStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RangeGenericPointStalkSubsetOfDenseOpenStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RepTraceEqMulAlgebraTraceStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingHomsDvrCardEqFinrankStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SandwichDatumTraceEqStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchrodingerRepSchwartzPolynomialBoundStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchroedingerOperatorHeisenbergInnerPreservingStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchroedingerOperatorHeisenbergPreservesSchwartzBStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzBruhatLintegralSqNeTop, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzBruhatPartitionOfUnity, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzBruhatReindexRows, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzOperatorParametricExtension, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SectionPullbackHolomorphicStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ShearGLTransposeMul, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SiegelLemmaSmallVectorStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SiegelParabolicOperatorsHeisenbergCompat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmoothGenericFibreClosurePartition, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SncAtlasRankDropPotential, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SncComponentHolomorphicAtlas, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SplitUnitarySiegelParabolicBlockRelations, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SquaringOpenAtOneOfCompleteTwoNeZeroStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.StrPullOperatorEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubInvMulOutMemIff, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumCoeffWindowCrossingFiberPointStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumLambdaPullRhoIdentity, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SummableHilbertEisensteinLatticeClassWeightTwo, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SuperconnFinsetLinear, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SuperconnectionDifferentiable, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaFactorNormInvarianceStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaProjectionEigenImage, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaQuasiPeriodicNormalForm, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaSectionTwistDecomposition, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaVanishOnFiberTangentStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaZeroOneLowerVanishStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaZeroOneSkewConjStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ToSpanSingletonConstGenSurjective, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TopMulDescendedSubmoduleOfUnitCocycleEqTopStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionPointRowsSumEqDivisorSeries, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsorBaseChangeZmodStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslateDifferenceMemSpanStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationDilationStableRadialElementStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UniformTaylorBoundLeviPluriharmonicSplitStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryAndSeparates, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryCharacterAbsScalarBasicProperties, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryFlagFrameExistsStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitarySignsHaarIsMulRightInvariant, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.VacuumMatrixCoefficientSq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.VanishingOnWallsDivisibleStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeightNormSqSmoothPosStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeightedLintegralSobolevPointwiseStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeilInvariantFunctionalInductionStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ZmodTorsorBaseChangeTransportPoint, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ZmodTorsorExistsPointFiniteSeparable, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ZmodTorsorFieldEqProdGaloisStatement, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.AlgMem, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.CardCokernelUnramifiedOrderMatrixOfDetBaseStatement, `Development.AbelianVarietyTheory.Proofs.FlagMeasures.CardPrimitiveTupleExtensionsLe]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

