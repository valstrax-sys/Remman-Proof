import Lean
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.FirstSigmaValuationBound
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.KapWin
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.LemmaDetPoly
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.LemmaGIdeal
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.LemmaGVal
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.PropEta
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.KernDer
import Formalism.WachLatticeTwists.HerrComplexInjectivity.Statement
import Formalism.WachLatticeTwists.HodgeTateChains.H2KilledByTateDuality
import Formalism.WachLatticeTwists.HodgeTateChains.HodgeTateFiltrations.InverseOperatorFromInjectivity
import Formalism.WachLatticeTwists.LagrangeExtensionCocycles.ExtensionCocycleProofs.MemSpanOfFrobeniusMemSpan
import Formalism.WachLatticeTwists.RamifiedBlockRings.Statement
import Formalism.WachLatticeTwists.WachProductBases.WachProductProofs.AffineLineLocalAcyclicityOfStrictHenselianPoints
import Formalism.WachLatticeTwists.WachProductBases.WachProductProofs.ToWachModuleHolds
import Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.DPotCrisStableAndExistsPotentiallyCrystallineDat
import Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.NegJumps
import Formalism.YangianSpanCharacter.YangianRTTProofs.TransposeJTransposeReal
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.AbsZetaPrimeSumErrorLeOfOneLe
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.IntegralEqIntervalIntegralAddCompl
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.LandauLocalOf
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.LaurentAtOne
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.LogDerivBound
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.NormIntegralComplLe
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.NormLogDerivLeLamF
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.Perron
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.RectShiftOf
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.RiemannZetaNeZeroOfMemRectangle
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.SmallHeight
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.SmallHeightLogDeriv
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.ThreeFourOne
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.ZeroFactor
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.ZetaGrowth
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.ZetaInvBound
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.ZfoGrowthBall
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.ZfoTermReNonneg
import Formalism.ZetaNonvanishing.RiemannZetaOneNeZeroOfRealMemIoo
import Formalism.ZetaNonvanishingChebyshevWeights
import GroundTheory.ArithmeticGeometry.AbelianVarieties.Divisors
import GroundTheory.ArithmeticGeometry.AbelianVarieties.FormalGroup
import GroundTheory.ArithmeticGeometry.AbelianVarieties.Isogeny
import GroundTheory.ArithmeticGeometry.AbelianVarieties.TorsionGalois
import GroundTheory.ArithmeticGeometry.SchemeCohomology.AffineVanishing
import GroundTheory.ArithmeticGeometry.SchemeCohomology.CechLeray
import GroundTheory.ArithmeticGeometry.SchemeCohomology.WeilDivisorTensor
import GroundTheory.ArithmeticGeometry.ToricVarieties.Normal
import GroundTheory.AutomorphicForms.AdelicGLn
import GroundTheory.AutomorphicForms.AdelicUnitaryGroups.Topology
import GroundTheory.AutomorphicForms.DixmierMalliavinHaarDensity
import GroundTheory.AutomorphicForms.GKModules.ZKFinite
import GroundTheory.AutomorphicForms.HarishChandraCentre.Projection
import GroundTheory.AutomorphicForms.HarishChandraRegularity.ContDiffCompCoordEquiv
import GroundTheory.AutomorphicForms.HeckeAlgebraLevel
import GroundTheory.AutomorphicForms.HermitianDisc
import GroundTheory.AutomorphicForms.HermitianSplit
import GroundTheory.AutomorphicForms.HermitianWittExtension
import GroundTheory.AutomorphicForms.InductionParabolicGroups
import GroundTheory.AutomorphicForms.KernelTrace
import GroundTheory.AutomorphicForms.MeasuresGL
import GroundTheory.AutomorphicForms.MultiplicityOne.OpenSubgroupRep
import GroundTheory.AutomorphicForms.PartialDifferential.SobolevInterpolation
import GroundTheory.AutomorphicForms.QuotientKernel
import GroundTheory.AutomorphicForms.RealGroups
import GroundTheory.AutomorphicForms.SchurOrthogonality
import GroundTheory.AutomorphicForms.StableConjInvariant

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.FirstSigmaValuationBound, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.KapWin, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.LemmaDetPoly, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.LemmaGIdeal, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.LemmaGVal, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.PropEta, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.KernDer, `Formalism.WachLatticeTwists.HerrComplexInjectivity.Statement, `Formalism.WachLatticeTwists.HodgeTateChains.H2KilledByTateDuality, `Formalism.WachLatticeTwists.HodgeTateChains.HodgeTateFiltrations.InverseOperatorFromInjectivity, `Formalism.WachLatticeTwists.LagrangeExtensionCocycles.ExtensionCocycleProofs.MemSpanOfFrobeniusMemSpan, `Formalism.WachLatticeTwists.RamifiedBlockRings.Statement, `Formalism.WachLatticeTwists.WachProductBases.WachProductProofs.AffineLineLocalAcyclicityOfStrictHenselianPoints, `Formalism.WachLatticeTwists.WachProductBases.WachProductProofs.ToWachModuleHolds, `Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.DPotCrisStableAndExistsPotentiallyCrystallineDat, `Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.NegJumps, `Formalism.YangianSpanCharacter.YangianRTTProofs.TransposeJTransposeReal, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.AbsZetaPrimeSumErrorLeOfOneLe, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.IntegralEqIntervalIntegralAddCompl, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.LandauLocalOf, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.LaurentAtOne, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.LogDerivBound, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.NormIntegralComplLe, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.NormLogDerivLeLamF, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.Perron, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.RectShiftOf, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.RiemannZetaNeZeroOfMemRectangle, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.SmallHeight, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.SmallHeightLogDeriv, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.ThreeFourOne, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.ZeroFactor, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.ZetaGrowth, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.ZetaInvBound, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.ZfoGrowthBall, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.ZfoTermReNonneg, `Formalism.ZetaNonvanishing.RiemannZetaOneNeZeroOfRealMemIoo, `Formalism.ZetaNonvanishingChebyshevWeights, `GroundTheory.ArithmeticGeometry.AbelianVarieties.Divisors, `GroundTheory.ArithmeticGeometry.AbelianVarieties.FormalGroup, `GroundTheory.ArithmeticGeometry.AbelianVarieties.Isogeny, `GroundTheory.ArithmeticGeometry.AbelianVarieties.TorsionGalois, `GroundTheory.ArithmeticGeometry.SchemeCohomology.AffineVanishing, `GroundTheory.ArithmeticGeometry.SchemeCohomology.CechLeray, `GroundTheory.ArithmeticGeometry.SchemeCohomology.WeilDivisorTensor, `GroundTheory.ArithmeticGeometry.ToricVarieties.Normal, `GroundTheory.AutomorphicForms.AdelicGLn, `GroundTheory.AutomorphicForms.AdelicUnitaryGroups.Topology, `GroundTheory.AutomorphicForms.DixmierMalliavinHaarDensity, `GroundTheory.AutomorphicForms.GKModules.ZKFinite, `GroundTheory.AutomorphicForms.HarishChandraCentre.Projection, `GroundTheory.AutomorphicForms.HarishChandraRegularity.ContDiffCompCoordEquiv, `GroundTheory.AutomorphicForms.HeckeAlgebraLevel, `GroundTheory.AutomorphicForms.HermitianDisc, `GroundTheory.AutomorphicForms.HermitianSplit, `GroundTheory.AutomorphicForms.HermitianWittExtension, `GroundTheory.AutomorphicForms.InductionParabolicGroups, `GroundTheory.AutomorphicForms.KernelTrace, `GroundTheory.AutomorphicForms.MeasuresGL, `GroundTheory.AutomorphicForms.MultiplicityOne.OpenSubgroupRep, `GroundTheory.AutomorphicForms.PartialDifferential.SobolevInterpolation, `GroundTheory.AutomorphicForms.QuotientKernel, `GroundTheory.AutomorphicForms.RealGroups, `GroundTheory.AutomorphicForms.SchurOrthogonality, `GroundTheory.AutomorphicForms.StableConjInvariant]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

