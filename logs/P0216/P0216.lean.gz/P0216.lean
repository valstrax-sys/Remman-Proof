import Lean
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.GramUnit
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.Hensel
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.HermDefON
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.IndexUBound
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.InertPrime
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.IntAdCpctOpen
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.IsoDualPair
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.IsoFunV
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.IsoScaleA
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KerDetOrd
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KerExtC
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KerPerPair
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KernelLatticeT0Exists
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.LatLocGlob
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.LatMin
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.LpLower
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.MirabIndex
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.NormGramAtOrigin
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PhSchurConv
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PrimeLogOverPSqTail
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.QuotNuSigma
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.RowWtSpan
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ScGapBig
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ScalDeg
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SchurClosable
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SwBigCellG
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SwPhiDeriv
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SwPhiForm
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.TayInvPow
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.TiltDivisibility
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.UnipVal
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.VacEntire
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.WeylProd
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.WwEval
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.WwInjective
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.WwMinorExpand
import Formalism.PeriodIntegrals.SelfDualBridge
import Formalism.PeriodIntegrals.SqPair
import Formalism.PeriodIntegrals.StdCharTR
import Formalism.PeriodIntegrals.ThGExist
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdditiveIntegralGroups.CoeffPowMemS
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdditiveIntegralGroups.DvCoeffMulEqZeroOfLtOrder
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdditiveIntegralGroups.GlueHoldsVar
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdicFiniteOrder.Assembly
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.DetMulRCReal
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.FourierSD
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.GrpChartC
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.T2SpaceTensorProductFiniteExtension
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.Upq
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CauchyBinet.WwCauchyBinetMain
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CharacterIdempotents.Central
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CharacterIdempotents.Scalar
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ChebyshevPrimeBounds.ChebyshevPrimeBoundsLogFact
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ChebyshevPrimeBounds.CountSuccLe
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ChebyshevPrimeBounds.LogFactorialEqSumOfLe
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ChebyshevPrimeBounds.LogFactorialLe
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ChebyshevPrimeBounds.PsiUpperBoundOfLtThirtyMulSixPow
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CircleGaugeAction.OfRealCoordsSmulCenterCoord
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CommutingMultiplicity.CommMultOf
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CommutingMultiplicity.InjStep
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CommutingMultiplicity.IntegrableEntry
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CommutingMultiplicity.SchurStepAlt
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CompactGelfandAverage.GelfCptOfSteps
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CompactGelfandAverage.IntegrableOfContinuousCpt

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.PeriodIntegrals.OrbitalBoundsConclusion.GramUnit, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.Hensel, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.HermDefON, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.IndexUBound, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.InertPrime, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.IntAdCpctOpen, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.IsoDualPair, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.IsoFunV, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.IsoScaleA, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KerDetOrd, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KerExtC, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KerPerPair, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KernelLatticeT0Exists, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.LatLocGlob, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.LatMin, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.LpLower, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.MirabIndex, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.NormGramAtOrigin, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PhSchurConv, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PrimeLogOverPSqTail, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.QuotNuSigma, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.RowWtSpan, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ScGapBig, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ScalDeg, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SchurClosable, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SwBigCellG, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SwPhiDeriv, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SwPhiForm, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.TayInvPow, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.TiltDivisibility, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.UnipVal, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.VacEntire, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.WeylProd, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.WwEval, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.WwInjective, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.WwMinorExpand, `Formalism.PeriodIntegrals.SelfDualBridge, `Formalism.PeriodIntegrals.SqPair, `Formalism.PeriodIntegrals.StdCharTR, `Formalism.PeriodIntegrals.ThGExist, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdditiveIntegralGroups.CoeffPowMemS, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdditiveIntegralGroups.DvCoeffMulEqZeroOfLtOrder, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdditiveIntegralGroups.GlueHoldsVar, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdicFiniteOrder.Assembly, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.DetMulRCReal, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.FourierSD, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.GrpChartC, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.T2SpaceTensorProductFiniteExtension, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.Upq, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CauchyBinet.WwCauchyBinetMain, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CharacterIdempotents.Central, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CharacterIdempotents.Scalar, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ChebyshevPrimeBounds.ChebyshevPrimeBoundsLogFact, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ChebyshevPrimeBounds.CountSuccLe, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ChebyshevPrimeBounds.LogFactorialEqSumOfLe, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ChebyshevPrimeBounds.LogFactorialLe, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ChebyshevPrimeBounds.PsiUpperBoundOfLtThirtyMulSixPow, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CircleGaugeAction.OfRealCoordsSmulCenterCoord, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CommutingMultiplicity.CommMultOf, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CommutingMultiplicity.InjStep, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CommutingMultiplicity.IntegrableEntry, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CommutingMultiplicity.SchurStepAlt, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CompactGelfandAverage.GelfCptOfSteps, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CompactGelfandAverage.IntegrableOfContinuousCpt]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

