import Lean
import GroundTheory.IdeleRoots.TorusPowers.SatakeBoundGauss
import GroundTheory.LocalFields.AbstractLocalReciprocity.ProfiniteInteger
import GroundTheory.LocalFields.BrauerInductionCharacters
import GroundTheory.LocalFields.BrauerInductionElementary
import GroundTheory.LocalFields.Examples
import GroundTheory.LocalFields.ExamplesTeichmuller
import GroundTheory.LocalFields.FilteredSurj
import GroundTheory.LocalFields.Interface
import GroundTheory.LocalFields.LubinTateReciprocity.RootEval
import GroundTheory.LocalFields.MaximalAbelianExtension
import GroundTheory.LocalFields.OpenCompletion
import GroundTheory.LocalFields.UnitsBasic
import GroundTheory.PAdicHodge.Admissible
import GroundTheory.PAdicHodge.BCrisTensorKAlg
import GroundTheory.PAdicHodge.BdRSeries
import GroundTheory.PAdicHodge.CompletedAlgClosure
import GroundTheory.PAdicHodge.ExtRobbaRootPoly
import GroundTheory.PAdicHodge.ExtRobbaTeich
import GroundTheory.PAdicHodge.FWGlue
import GroundTheory.PAdicHodge.FiniteFlat
import GroundTheory.PAdicHodge.GaloisOnCp
import GroundTheory.PAdicHodge.LogPowSeries
import GroundTheory.PAdicHodge.OrthoBasis
import GroundTheory.PAdicHodge.PerfectoidField
import GroundTheory.PAdicHodge.RobbaSeries
import GroundTheory.PAdicHodge.SemilinearResidue
import GroundTheory.PAdicHodge.SenTateCharQp
import GroundTheory.PAdicHodge.SenTateCharUnits
import GroundTheory.PAdicHodge.SlopeBezout
import GroundTheory.PAdicHodge.SlopePhiModule
import GroundTheory.PAdicHodge.WAFracAlg
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.CommonDenominator
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.DescentPowerSubgroups
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.ExistsMaxMinorNeZeroOfLinearIndependentAlt
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.ExistsSmulMemFamilyOfSpanEqTop
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.FontainePhiPowerSubgroups
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.NormZpow
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.PowInvariant
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.PrecompleteOfSurjective
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.RelIndexSup
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.SingleMemInitialCoordSubspace
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.SlopeVcCountableNeighbourhoods
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.SpanEqTopSmul
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.UnitMulPowAdic
import GroundTheory.PowerSubgroups.CountableNeighbourhoods.UnramifiedClosureCountableNeighbourhoods
import GroundTheory.ProfiniteCohomology.AdditiveHilbert
import GroundTheory.ProfiniteCohomology.BridgeNested
import GroundTheory.ProfiniteCohomology.DiscreteModules
import GroundTheory.ProfiniteCohomology.FilteredHomology
import GroundTheory.ProfiniteCohomology.GaloisModules.CoeGalRootsOfUnityHomApply
import GroundTheory.ProfiniteCohomology.GlobalClassFormation.ExtensionEmbeddingOfIsRealAlgebraMap
import GroundTheory.ProfiniteCohomology.GlobalClassFormation.IdeleCohomology.Ramified
import GroundTheory.ProfiniteCohomology.GlobalEulerCharacteristic.ArtinCount
import GroundTheory.ProfiniteCohomology.GlobalEulerCharacteristic.PermLatticeCharacter
import GroundTheory.ProfiniteCohomology.GlobalEulerCharacteristic.ShapiroDefs
import GroundTheory.ProfiniteCohomology.KummerBasic
import GroundTheory.ProfiniteCohomology.LocalClassFormation.FiniteVanishing.IntScalars
import GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.AdditiveDefs
import GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.CoprimeRegular
import GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.GroupStructureDefs
import GroundTheory.ProfiniteCohomology.OpenNormal
import GroundTheory.ProfiniteCohomology.ProcyclicDefs
import GroundTheory.ProfiniteCohomology.RestrictedRamification.MaxUnramifiedOutside
import GroundTheory.ProfiniteCohomology.RestrictedRamification.Ramification

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.IdeleRoots.TorusPowers.SatakeBoundGauss, `GroundTheory.LocalFields.AbstractLocalReciprocity.ProfiniteInteger, `GroundTheory.LocalFields.BrauerInductionCharacters, `GroundTheory.LocalFields.BrauerInductionElementary, `GroundTheory.LocalFields.Examples, `GroundTheory.LocalFields.ExamplesTeichmuller, `GroundTheory.LocalFields.FilteredSurj, `GroundTheory.LocalFields.Interface, `GroundTheory.LocalFields.LubinTateReciprocity.RootEval, `GroundTheory.LocalFields.MaximalAbelianExtension, `GroundTheory.LocalFields.OpenCompletion, `GroundTheory.LocalFields.UnitsBasic, `GroundTheory.PAdicHodge.Admissible, `GroundTheory.PAdicHodge.BCrisTensorKAlg, `GroundTheory.PAdicHodge.BdRSeries, `GroundTheory.PAdicHodge.CompletedAlgClosure, `GroundTheory.PAdicHodge.ExtRobbaRootPoly, `GroundTheory.PAdicHodge.ExtRobbaTeich, `GroundTheory.PAdicHodge.FWGlue, `GroundTheory.PAdicHodge.FiniteFlat, `GroundTheory.PAdicHodge.GaloisOnCp, `GroundTheory.PAdicHodge.LogPowSeries, `GroundTheory.PAdicHodge.OrthoBasis, `GroundTheory.PAdicHodge.PerfectoidField, `GroundTheory.PAdicHodge.RobbaSeries, `GroundTheory.PAdicHodge.SemilinearResidue, `GroundTheory.PAdicHodge.SenTateCharQp, `GroundTheory.PAdicHodge.SenTateCharUnits, `GroundTheory.PAdicHodge.SlopeBezout, `GroundTheory.PAdicHodge.SlopePhiModule, `GroundTheory.PAdicHodge.WAFracAlg, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.CommonDenominator, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.DescentPowerSubgroups, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.ExistsMaxMinorNeZeroOfLinearIndependentAlt, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.ExistsSmulMemFamilyOfSpanEqTop, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.FontainePhiPowerSubgroups, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.NormZpow, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.PowInvariant, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.PrecompleteOfSurjective, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.RelIndexSup, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.SingleMemInitialCoordSubspace, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.SlopeVcCountableNeighbourhoods, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.SpanEqTopSmul, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.UnitMulPowAdic, `GroundTheory.PowerSubgroups.CountableNeighbourhoods.UnramifiedClosureCountableNeighbourhoods, `GroundTheory.ProfiniteCohomology.AdditiveHilbert, `GroundTheory.ProfiniteCohomology.BridgeNested, `GroundTheory.ProfiniteCohomology.DiscreteModules, `GroundTheory.ProfiniteCohomology.FilteredHomology, `GroundTheory.ProfiniteCohomology.GaloisModules.CoeGalRootsOfUnityHomApply, `GroundTheory.ProfiniteCohomology.GlobalClassFormation.ExtensionEmbeddingOfIsRealAlgebraMap, `GroundTheory.ProfiniteCohomology.GlobalClassFormation.IdeleCohomology.Ramified, `GroundTheory.ProfiniteCohomology.GlobalEulerCharacteristic.ArtinCount, `GroundTheory.ProfiniteCohomology.GlobalEulerCharacteristic.PermLatticeCharacter, `GroundTheory.ProfiniteCohomology.GlobalEulerCharacteristic.ShapiroDefs, `GroundTheory.ProfiniteCohomology.KummerBasic, `GroundTheory.ProfiniteCohomology.LocalClassFormation.FiniteVanishing.IntScalars, `GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.AdditiveDefs, `GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.CoprimeRegular, `GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.GroupStructureDefs, `GroundTheory.ProfiniteCohomology.OpenNormal, `GroundTheory.ProfiniteCohomology.ProcyclicDefs, `GroundTheory.ProfiniteCohomology.RestrictedRamification.MaxUnramifiedOutside, `GroundTheory.ProfiniteCohomology.RestrictedRamification.Ramification]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

