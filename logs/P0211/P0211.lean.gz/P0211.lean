import Lean
import Formalism.CharacterColumnKernels.IdempotentNormalForms.LenCokerOfDetNeZero
import Formalism.CharacterColumnKernels.StatementMF
import Formalism.CharacterColumnKernels.StatementN
import Formalism.CoboundaryTransfers.GammaStableTransfers.DiffOneSmulOfTower
import Formalism.CoboundaryTransfers.GammaStableTransfers.MemCoboundariesOfIsOneCoboundary
import Formalism.CoboundaryTransfers.GammaStableTransfers.TorsionKilledCriterionHolds
import Formalism.CoboundaryTransfers.StatementBridge
import Formalism.CoboundaryTransfers.StatementEx
import Formalism.ConjugateSelfDual.Imports
import Formalism.CyclotomicNorms.NonsquarefreeBounds.AdaptiveSubstitutionBound
import Formalism.CyclotomicNorms.NonsquarefreeBounds.RestrictionOfBlocksAndJordan
import Formalism.DefsOC
import Formalism.DegreeFormula.PointDegree.PowSum
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.AevalApplySubEvalOneMem
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.CutPlace
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.Descent
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.GroundTheory
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.LevelsModConstIffOfNoDown
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.Rounding
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.UnivPart
import Formalism.DistinguishedUnitIdeals.StatementE
import Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.IsClosedLowUni
import Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.LemmaU
import Formalism.DoubleCosetMeasures.StatementV
import Formalism.EisensteinCokernelLengths.CokernelLengthBoundOfLifts
import Formalism.EisensteinCokernelLengths.FactorialValuationBounds.DistinguishedPowMemSpanOfTrichotomy
import Formalism.EllipticTorsion.CoeffRing
import Formalism.EllipticTorsion.EllipticTorsionProofs.ExistsUnitFactor
import Formalism.EllipticTorsion.EllipticTorsionProofs.WChord
import Formalism.EllipticTorsion.EllipticTorsionProofs.WPoint
import Formalism.EllipticTorsion.EllipticTorsionProofs.WSeries
import Formalism.EllipticTorsion.EllipticTorsionProofs.WSubst
import Formalism.EllipticTorsion.Statement
import Formalism.FilteredPoleLength.LocalDescentLevels.BCount
import Formalism.FilteredPoleLength.LocalDescentLevels.FilIntegerStep
import Formalism.FilteredPoleLength.LocalDescentLevels.LinearIndependentOfIsBaseChange
import Formalism.FilteredPoleLength.LocalDescentLevels.MemSpanBasisFun
import Formalism.FilteredPoleLength.ReducedBasisBounds.LengthBaseChangeLocal
import Formalism.FlagUnipotentLattices.DetIndexProductPlacesInequalitySq
import Formalism.FlagUnipotentLattices.GramSubmersionSplit
import Formalism.FlagUnipotentLattices.LiftUnitaryFixesBase
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.ExistsHasLeadingCoeffOfMemSpanBelow
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.LatticeSumBounds
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.MeasurePreservingPiCompProd
import Formalism.FlagUnipotentLattices.SubmoduleGeneratorsBound
import Formalism.FockGram.FockGramProofs.DetSymPow
import Formalism.FockGram.FockGramProofs.FockHerm
import Formalism.FockGram.FockGramProofs.FockPerm
import Formalism.FockGram.FockGramProofs.FockSesq
import Formalism.FockGram.FockGramProofs.HermDualOf
import Formalism.FockGram.FockGramProofs.HermitianTensorMulHermitian
import Formalism.FockGram.StatementSymPos
import Formalism.FormalDegreeBessel.FinalWR
import Formalism.FormalDegreeBessel.FormalDegreeRatio.GBasic
import Formalism.FormalDegreeBessel.FormalDegreeRatio.GNonneg
import Formalism.FormalDegreeBessel.FormalDegreeRatio.GroupFactorizationHolds
import Formalism.FormalDegreeBessel.FormalDegreeRatio.UnitaryWeylNormalHolds
import Formalism.FormalDegreeBessel.StatementBF
import Formalism.FormalGroupLog.FormalGroupLogProofs.ConstantCoeffSubstOfZero
import Formalism.FormalGroupLog.FormalGroupLogProofs.HomPsSubstMvSubst
import Formalism.FrobeniusBaseCase.FrobeniusBaseCaseProofs.CoeffFrobOfNotDvd
import Formalism.FrobeniusContraction.FrobeniusContractionProofs.EulerCharacteristicHolds
import Formalism.FrobeniusOrbits.Statement
import Formalism.GL3MeanSquares.FourierTransformKernelSurjective

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.CharacterColumnKernels.IdempotentNormalForms.LenCokerOfDetNeZero, `Formalism.CharacterColumnKernels.StatementMF, `Formalism.CharacterColumnKernels.StatementN, `Formalism.CoboundaryTransfers.GammaStableTransfers.DiffOneSmulOfTower, `Formalism.CoboundaryTransfers.GammaStableTransfers.MemCoboundariesOfIsOneCoboundary, `Formalism.CoboundaryTransfers.GammaStableTransfers.TorsionKilledCriterionHolds, `Formalism.CoboundaryTransfers.StatementBridge, `Formalism.CoboundaryTransfers.StatementEx, `Formalism.ConjugateSelfDual.Imports, `Formalism.CyclotomicNorms.NonsquarefreeBounds.AdaptiveSubstitutionBound, `Formalism.CyclotomicNorms.NonsquarefreeBounds.RestrictionOfBlocksAndJordan, `Formalism.DefsOC, `Formalism.DegreeFormula.PointDegree.PowSum, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.AevalApplySubEvalOneMem, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.CutPlace, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.Descent, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.GroundTheory, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.LevelsModConstIffOfNoDown, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.Rounding, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.UnivPart, `Formalism.DistinguishedUnitIdeals.StatementE, `Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.IsClosedLowUni, `Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.LemmaU, `Formalism.DoubleCosetMeasures.StatementV, `Formalism.EisensteinCokernelLengths.CokernelLengthBoundOfLifts, `Formalism.EisensteinCokernelLengths.FactorialValuationBounds.DistinguishedPowMemSpanOfTrichotomy, `Formalism.EllipticTorsion.CoeffRing, `Formalism.EllipticTorsion.EllipticTorsionProofs.ExistsUnitFactor, `Formalism.EllipticTorsion.EllipticTorsionProofs.WChord, `Formalism.EllipticTorsion.EllipticTorsionProofs.WPoint, `Formalism.EllipticTorsion.EllipticTorsionProofs.WSeries, `Formalism.EllipticTorsion.EllipticTorsionProofs.WSubst, `Formalism.EllipticTorsion.Statement, `Formalism.FilteredPoleLength.LocalDescentLevels.BCount, `Formalism.FilteredPoleLength.LocalDescentLevels.FilIntegerStep, `Formalism.FilteredPoleLength.LocalDescentLevels.LinearIndependentOfIsBaseChange, `Formalism.FilteredPoleLength.LocalDescentLevels.MemSpanBasisFun, `Formalism.FilteredPoleLength.ReducedBasisBounds.LengthBaseChangeLocal, `Formalism.FlagUnipotentLattices.DetIndexProductPlacesInequalitySq, `Formalism.FlagUnipotentLattices.GramSubmersionSplit, `Formalism.FlagUnipotentLattices.LiftUnitaryFixesBase, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.ExistsHasLeadingCoeffOfMemSpanBelow, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.LatticeSumBounds, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.MeasurePreservingPiCompProd, `Formalism.FlagUnipotentLattices.SubmoduleGeneratorsBound, `Formalism.FockGram.FockGramProofs.DetSymPow, `Formalism.FockGram.FockGramProofs.FockHerm, `Formalism.FockGram.FockGramProofs.FockPerm, `Formalism.FockGram.FockGramProofs.FockSesq, `Formalism.FockGram.FockGramProofs.HermDualOf, `Formalism.FockGram.FockGramProofs.HermitianTensorMulHermitian, `Formalism.FockGram.StatementSymPos, `Formalism.FormalDegreeBessel.FinalWR, `Formalism.FormalDegreeBessel.FormalDegreeRatio.GBasic, `Formalism.FormalDegreeBessel.FormalDegreeRatio.GNonneg, `Formalism.FormalDegreeBessel.FormalDegreeRatio.GroupFactorizationHolds, `Formalism.FormalDegreeBessel.FormalDegreeRatio.UnitaryWeylNormalHolds, `Formalism.FormalDegreeBessel.StatementBF, `Formalism.FormalGroupLog.FormalGroupLogProofs.ConstantCoeffSubstOfZero, `Formalism.FormalGroupLog.FormalGroupLogProofs.HomPsSubstMvSubst, `Formalism.FrobeniusBaseCase.FrobeniusBaseCaseProofs.CoeffFrobOfNotDvd, `Formalism.FrobeniusContraction.FrobeniusContractionProofs.EulerCharacteristicHolds, `Formalism.FrobeniusOrbits.Statement, `Formalism.GL3MeanSquares.FourierTransformKernelSurjective]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

