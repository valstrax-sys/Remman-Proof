import Lean
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Actions
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.AssocFin
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.AutomorphicFormsDecompositionHolds
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.FiniteCosetsInDoset
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.GlintPrincRelIndexNeZero
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.HeckeActMem
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Heckebasic
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.InclusionInjective
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Ipindep
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.LinSubstIsHomogeneous
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Nabladual
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.RationalPointsLeHolds
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.SignatureConjugationInvariant
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.SignatureExists
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.SplitUnitaryGroupIso
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Stabfin
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Stabstd
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Transport
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Upqcpt
import Formalism.SatakeDualWeyl.StatementC
import Formalism.SatakeDualWeyl.StatementE
import Formalism.SatakeDualWeyl.StatementF
import Formalism.SharpRestriction.CuspSpanNormBounds.CayleyDegreeNondegeneracy.RowsOneN
import Formalism.SharpRestriction.CuspSpanNormBounds.FractionFieldToGenericStalkAlgebraMapEq
import Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrRightOfFinite
import Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrkAesmTsum
import Formalism.SharpRestriction.Divisibility.GeneratorPowers.AevalDiagMonomial
import Formalism.SharpRestriction.Divisibility.GeneratorPowers.GaugeExpPow
import Formalism.SharpRestriction.Divisibility.GeneratorPowers.LegendreSumSt
import Formalism.SharpRestriction.Divisibility.GeneratorPowers.PhiCMinC
import Formalism.SharpRestriction.Divisibility.GeneratorPowers.PhiCMinE
import Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.IsIntegralOfAll
import Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.RecNZFullLen
import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes
import Formalism.SharpRestriction.GlobalSchurBounds.GlobalRankLatticeProofs.UnitTraceSumBounds.CBCardNC
import Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.QuadraticBasis.PresIso
import Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.QuadraticBasis.QuadBasis
import Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.QuadraticBasis.QuadRoots
import Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.LiftBoundOfHypotheses
import Formalism.SharpRestriction.GrowthBounds.MultisetValuation.JpSubstExpand
import Formalism.SharpRestriction.GrowthBounds.RootWeights.TwistSubEqMatrixSubst
import Formalism.SharpRestriction.GrowthBounds.SegRing
import Formalism.SharpRestriction.GrowthBounds.TwistedSubstitution.TwistedMonomialFiltration.TMemLaurentFiltration
import Formalism.SharpRestriction.GrowthBounds.TwistedSubstitution.TypeBound
import Formalism.SharpRestriction.LevelLetterCocycles.CohomologyScalarsVanish.CohScalarsVanish
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.AlgHomPowerSeriesCoeEqAeval
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.ConstantCoeffAeval
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.CycloDist
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.CycloSimple
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.EqZeroOfBlockSumEqZero
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.ExpRescaleCoeff
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.PiSeries
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.PolynomialCoePowerSeriesEqAevalX
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.PsCoprimeDvdSub
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.RhoUnit
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.DecompCoord
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.EigenUniformiser
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.FrameAbs
import Formalism.SharpRestriction.LevelLetterCocycles.PrimesOverLiterature.RayPrimeCount
import Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.IndepOfSpan
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.CoeffEqZeroOfSumEqZero
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.ThetaAtRootAlt
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.TsumThree
import Formalism.SharpRestriction.LevelLetterCocycles.WildPro

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Actions, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.AssocFin, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.AutomorphicFormsDecompositionHolds, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.FiniteCosetsInDoset, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.GlintPrincRelIndexNeZero, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.HeckeActMem, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Heckebasic, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.InclusionInjective, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Ipindep, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.LinSubstIsHomogeneous, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Nabladual, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.RationalPointsLeHolds, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.SignatureConjugationInvariant, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.SignatureExists, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.SplitUnitaryGroupIso, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Stabfin, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Stabstd, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Transport, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Upqcpt, `Formalism.SatakeDualWeyl.StatementC, `Formalism.SatakeDualWeyl.StatementE, `Formalism.SatakeDualWeyl.StatementF, `Formalism.SharpRestriction.CuspSpanNormBounds.CayleyDegreeNondegeneracy.RowsOneN, `Formalism.SharpRestriction.CuspSpanNormBounds.FractionFieldToGenericStalkAlgebraMapEq, `Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrRightOfFinite, `Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrkAesmTsum, `Formalism.SharpRestriction.Divisibility.GeneratorPowers.AevalDiagMonomial, `Formalism.SharpRestriction.Divisibility.GeneratorPowers.GaugeExpPow, `Formalism.SharpRestriction.Divisibility.GeneratorPowers.LegendreSumSt, `Formalism.SharpRestriction.Divisibility.GeneratorPowers.PhiCMinC, `Formalism.SharpRestriction.Divisibility.GeneratorPowers.PhiCMinE, `Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.IsIntegralOfAll, `Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.RecNZFullLen, `Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes, `Formalism.SharpRestriction.GlobalSchurBounds.GlobalRankLatticeProofs.UnitTraceSumBounds.CBCardNC, `Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.QuadraticBasis.PresIso, `Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.QuadraticBasis.QuadBasis, `Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.QuadraticBasis.QuadRoots, `Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.LiftBoundOfHypotheses, `Formalism.SharpRestriction.GrowthBounds.MultisetValuation.JpSubstExpand, `Formalism.SharpRestriction.GrowthBounds.RootWeights.TwistSubEqMatrixSubst, `Formalism.SharpRestriction.GrowthBounds.SegRing, `Formalism.SharpRestriction.GrowthBounds.TwistedSubstitution.TwistedMonomialFiltration.TMemLaurentFiltration, `Formalism.SharpRestriction.GrowthBounds.TwistedSubstitution.TypeBound, `Formalism.SharpRestriction.LevelLetterCocycles.CohomologyScalarsVanish.CohScalarsVanish, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.AlgHomPowerSeriesCoeEqAeval, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.ConstantCoeffAeval, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.CycloDist, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.CycloSimple, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.EqZeroOfBlockSumEqZero, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.ExpRescaleCoeff, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.PiSeries, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.PolynomialCoePowerSeriesEqAevalX, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.PsCoprimeDvdSub, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.RhoUnit, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.DecompCoord, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.EigenUniformiser, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.FrameAbs, `Formalism.SharpRestriction.LevelLetterCocycles.PrimesOverLiterature.RayPrimeCount, `Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.IndepOfSpan, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.CoeffEqZeroOfSumEqZero, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.ThetaAtRootAlt, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.TsumThree, `Formalism.SharpRestriction.LevelLetterCocycles.WildPro]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

