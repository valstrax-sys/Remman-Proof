import Lean
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImportsTer
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.InfinitePlaceEqOfEmbeddingCompAlgebraMapEq
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.IsAlgClosedResidueField
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.IsCMFieldOfForallIsConj
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.IsComplOrthogonalOfNoCommonIrreducibleTypes
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.IsNilpotentOfTracePow
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.IsReducedQuotientOfArtinianOfMaximalLe
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.JointEigenDecomposition
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.LengthLeOfForallFgSubmoduleLengthLe
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.LengthQuotientScalarMul
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.LengthQuotientSmulSupLeIntermediate
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.LengthQuotientSpanPowLeMulLength
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.LinearIndependentJointEigenvectors
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.NatCardMatricesMulEqZero
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.NormAevalSubLe
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.NormLeOfRecurrenceGrowth
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.NormSumLt
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.NormTensorProductMapLeft
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.NumberFieldEmbMemAlgebraicClosure
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ProdFinEqProdCastLE
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.QuadraticRingOfIntegersMulMemSpanOneGen
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ReduceToAffineSource
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ResidueDegreeOneOfLinearMem
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.SegmentEigenvalueSumFormula
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.SpanExtendScalarsInfEqBotOfInfEqBot
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.TraceMulEq
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.TraceQuotientEqOfProjective
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.TraceRMulPowEqZero
import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ExistsBoundedMultipleNearInteger
import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ExistsCommonSmulMem
import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ExistsEqSumIndicatorOfRightInvariant
import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.LintegralMulRight
import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.SummableProdPi
import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.TailSumLtOne
import Development.AbelianVarietyTheory.Proofs.ThetaFamilyOrigin.ExistsMulMemAdjoinOfMemPowRange
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.AlternatingSumChooseMulSubPow
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.CardHomVanishingOfDiagBasis
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.CoeffEqZeroOfMemSpanPow
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.DetKroneckerPower
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.DifferentiableOnCoordOfLinearIndependent
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.DiscrMulDetEqNormOfAnnihilator
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.EntireEqZeroOrEqZeroOfMulEqZero
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.ExistsAlgHomNeZeroOfCountable
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.ExistsAlgHomOfIsTranscendenceBasis
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.ExistsCountableLocalPidSubring
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.ExistsIsSymmMulVecAddDiagModTwo
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.ExistsNatMulQuadraticLt
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.ExistsPrimeDimensionLEOneAvoiding
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.ExistsRepresentativesModSimilitudeTranspose
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.FinitePreimageOfIsPullbackOfFiniteBase
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.MkTensorLe
import Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.MulTransposeEqOfTransposeMulEq
import Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.CommonEigenvectorsFlatBaseChange
import Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.EqZeroOfForallEmbeddingSumEqZero
import Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.ExistsBasisOverEmbedding
import Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.ExistsConstRatioOfNormEq
import Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.ExistsEqNsmulOfForallAddChar
import Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.ExistsLineBasis
import Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.IrreducibleDetOfIsRelPrime
import Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.IsExtensionOfIsPushout
import Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.MemSpanSingleInlIff
import Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.SummableExpNegSumAbs
import Development.AbelianVarietyTheory.Proofs.ToricGeometry.AppellHumbertNormalFormOfLinearExponent
import Development.AbelianVarietyTheory.Proofs.ToricGeometry.AutomorphyFactorExpLinearOfCube

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImportsTer, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.InfinitePlaceEqOfEmbeddingCompAlgebraMapEq, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.IsAlgClosedResidueField, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.IsCMFieldOfForallIsConj, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.IsComplOrthogonalOfNoCommonIrreducibleTypes, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.IsNilpotentOfTracePow, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.IsReducedQuotientOfArtinianOfMaximalLe, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.JointEigenDecomposition, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.LengthLeOfForallFgSubmoduleLengthLe, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.LengthQuotientScalarMul, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.LengthQuotientSmulSupLeIntermediate, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.LengthQuotientSpanPowLeMulLength, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.LinearIndependentJointEigenvectors, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.NatCardMatricesMulEqZero, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.NormAevalSubLe, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.NormLeOfRecurrenceGrowth, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.NormSumLt, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.NormTensorProductMapLeft, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.NumberFieldEmbMemAlgebraicClosure, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ProdFinEqProdCastLE, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.QuadraticRingOfIntegersMulMemSpanOneGen, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ReduceToAffineSource, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ResidueDegreeOneOfLinearMem, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.SegmentEigenvalueSumFormula, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.SpanExtendScalarsInfEqBotOfInfEqBot, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.TraceMulEq, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.TraceQuotientEqOfProjective, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.TraceRMulPowEqZero, `Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ExistsBoundedMultipleNearInteger, `Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ExistsCommonSmulMem, `Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ExistsEqSumIndicatorOfRightInvariant, `Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.LintegralMulRight, `Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.SummableProdPi, `Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.TailSumLtOne, `Development.AbelianVarietyTheory.Proofs.ThetaFamilyOrigin.ExistsMulMemAdjoinOfMemPowRange, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.AlternatingSumChooseMulSubPow, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.CardHomVanishingOfDiagBasis, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.CoeffEqZeroOfMemSpanPow, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.DetKroneckerPower, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.DifferentiableOnCoordOfLinearIndependent, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.DiscrMulDetEqNormOfAnnihilator, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.EntireEqZeroOrEqZeroOfMulEqZero, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.ExistsAlgHomNeZeroOfCountable, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.ExistsAlgHomOfIsTranscendenceBasis, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.ExistsCountableLocalPidSubring, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.ExistsIsSymmMulVecAddDiagModTwo, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.ExistsNatMulQuadraticLt, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.ExistsPrimeDimensionLEOneAvoiding, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.ExistsRepresentativesModSimilitudeTranspose, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.FinitePreimageOfIsPullbackOfFiniteBase, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.MkTensorLe, `Development.AbelianVarietyTheory.Proofs.ThetaLawProofs.MulTransposeEqOfTransposeMulEq, `Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.CommonEigenvectorsFlatBaseChange, `Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.EqZeroOfForallEmbeddingSumEqZero, `Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.ExistsBasisOverEmbedding, `Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.ExistsConstRatioOfNormEq, `Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.ExistsEqNsmulOfForallAddChar, `Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.ExistsLineBasis, `Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.IrreducibleDetOfIsRelPrime, `Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.IsExtensionOfIsPushout, `Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.MemSpanSingleInlIff, `Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.SummableExpNegSumAbs, `Development.AbelianVarietyTheory.Proofs.ToricGeometry.AppellHumbertNormalFormOfLinearExponent, `Development.AbelianVarietyTheory.Proofs.ToricGeometry.AutomorphyFactorExpLinearOfCube]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

