import Lean
import GroundTheory.PAdicHodge.RobbaNewton
import GroundTheory.PAdicHodge.TiltAlgClosed
import GroundTheory.PAdicHodge.TiltMap
import GroundTheory.ProfiniteCohomology.Bridge
import GroundTheory.ProfiniteCohomology.CohomologicalDimension.PrimaryComponentCohomologyEqBotOfScdpLt
import GroundTheory.ProfiniteCohomology.CohomologyFunctoriality
import GroundTheory.ProfiniteCohomology.ContinuousCochains.Functoriality
import GroundTheory.ProfiniteCohomology.EulerCharDefs
import GroundTheory.ProfiniteCohomology.GaloisCohomology.UnitsInflationCochainsFHomApply
import GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.UnitsLattice
import GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.VanishingUnits
import GroundTheory.ProfiniteCohomology.NotDvdSuperIndexIffMap
import GroundTheory.ProfiniteCohomology.RestrictedRamification.IsUnramifiedOutsideIffLeMaxUnramifiedOutside
import GroundTheory.TateCohomology.Annihilation
import GroundTheory.TateCohomology.Characters
import GroundTheory.TateCohomology.CochainReverse
import GroundTheory.TateCohomology.CohTrivialBasic
import GroundTheory.TateCohomology.Herbrand
import GroundTheory.TateCohomology.TateConnecting
import GroundTheory.TateCohomology.TateShapiro
import Lemmata.DetMonotoneStarMulSelf.OneLeReDetOneAdd
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.DualNumberUnitMulDecomposition
import ReciprocityTheory.AnalyticForms.LeviForms.HomDensA
import ReciprocityTheory.AnalyticForms.LeviForms.TailCutA
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.LeviOneEqLaplacianThm
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.LintegralImageEqLintegralNormSqDetMul
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PartsAlg
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshBasic
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshExt
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshRegMax
import ReciprocityTheory.AnalyticForms.PotentialTheory.AnalyticSubsetChartLocal
import ReciprocityTheory.AnalyticForms.PotentialTheory.ContDiffAtOfIsPotential
import ReciprocityTheory.AnalyticForms.PotentialTheory.ContDiffFubiniStudyRatioCompChart0
import ReciprocityTheory.AnalyticForms.PotentialTheory.DegreeInhab
import ReciprocityTheory.AnalyticForms.PotentialTheory.HessCEqZeroOfEventuallyEqZero
import ReciprocityTheory.AnalyticForms.PotentialTheory.HessCIsHermitian
import ReciprocityTheory.AnalyticForms.PotentialTheory.Partition
import ReciprocityTheory.AnalyticForms.PotentialTheory.PshShiftB
import ReciprocityTheory.AnalyticForms.PotentialTheory.SNCAtlas
import ReciprocityTheory.AnalyticForms.RegularLocalRings.PreMemIrreducibleComponents
import ReciprocityTheory.Chebotarev.EulerLim
import ReciprocityTheory.Chebotarev.IdealLat
import ReciprocityTheory.Chebotarev.MeanZero
import ReciprocityTheory.Chebotarev.SplitEA
import ReciprocityTheory.Chebotarev.Support
import ReciprocityTheory.ClassFieldTheory.LocalClassField.KbarRepContAction
import ReciprocityTheory.ClassFieldTheory.LocalClassField.NormSubEqOneOfPowEqOne
import ReciprocityTheory.ClassFieldTheory.LocalClassField.QZDefs
import ReciprocityTheory.ClassFieldTheory.LocalClassField.UnitsHerbrandD
import ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.Unmixed
import ReciprocityTheory.DualLattices.BlockOneMulMulBlockOne
import ReciprocityTheory.DualLattices.ColengthCotangentBoundStatementOfClaim
import ReciprocityTheory.DualLattices.ColengthSqBlockVandermonde
import ReciprocityTheory.DualLattices.ExistsMatOfEquiv
import ReciprocityTheory.DualLattices.Imports
import ReciprocityTheory.DualLattices.IsFibreSq
import ReciprocityTheory.DualLattices.IsPairingValueAddRight
import ReciprocityTheory.DualLattices.LenIdStatement
import ReciprocityTheory.DualLattices.LinPairStatement
import ReciprocityTheory.DualLattices.MemDualLatMapFourier
import ReciprocityTheory.DualLattices.MemMapAugmentationIdealComapPullbackQuotient
import ReciprocityTheory.DualLattices.NilSurjOfSqZero
import ReciprocityTheory.DualLattices.PrimeHopfOrderOfAddEquiv
import ReciprocityTheory.DualLattices.ProdDvdOfIso

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.PAdicHodge.RobbaNewton, `GroundTheory.PAdicHodge.TiltAlgClosed, `GroundTheory.PAdicHodge.TiltMap, `GroundTheory.ProfiniteCohomology.Bridge, `GroundTheory.ProfiniteCohomology.CohomologicalDimension.PrimaryComponentCohomologyEqBotOfScdpLt, `GroundTheory.ProfiniteCohomology.CohomologyFunctoriality, `GroundTheory.ProfiniteCohomology.ContinuousCochains.Functoriality, `GroundTheory.ProfiniteCohomology.EulerCharDefs, `GroundTheory.ProfiniteCohomology.GaloisCohomology.UnitsInflationCochainsFHomApply, `GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.UnitsLattice, `GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.VanishingUnits, `GroundTheory.ProfiniteCohomology.NotDvdSuperIndexIffMap, `GroundTheory.ProfiniteCohomology.RestrictedRamification.IsUnramifiedOutsideIffLeMaxUnramifiedOutside, `GroundTheory.TateCohomology.Annihilation, `GroundTheory.TateCohomology.Characters, `GroundTheory.TateCohomology.CochainReverse, `GroundTheory.TateCohomology.CohTrivialBasic, `GroundTheory.TateCohomology.Herbrand, `GroundTheory.TateCohomology.TateConnecting, `GroundTheory.TateCohomology.TateShapiro, `Lemmata.DetMonotoneStarMulSelf.OneLeReDetOneAdd, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.DualNumberUnitMulDecomposition, `ReciprocityTheory.AnalyticForms.LeviForms.HomDensA, `ReciprocityTheory.AnalyticForms.LeviForms.TailCutA, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.LeviOneEqLaplacianThm, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.LintegralImageEqLintegralNormSqDetMul, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PartsAlg, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshBasic, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshExt, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshRegMax, `ReciprocityTheory.AnalyticForms.PotentialTheory.AnalyticSubsetChartLocal, `ReciprocityTheory.AnalyticForms.PotentialTheory.ContDiffAtOfIsPotential, `ReciprocityTheory.AnalyticForms.PotentialTheory.ContDiffFubiniStudyRatioCompChart0, `ReciprocityTheory.AnalyticForms.PotentialTheory.DegreeInhab, `ReciprocityTheory.AnalyticForms.PotentialTheory.HessCEqZeroOfEventuallyEqZero, `ReciprocityTheory.AnalyticForms.PotentialTheory.HessCIsHermitian, `ReciprocityTheory.AnalyticForms.PotentialTheory.Partition, `ReciprocityTheory.AnalyticForms.PotentialTheory.PshShiftB, `ReciprocityTheory.AnalyticForms.PotentialTheory.SNCAtlas, `ReciprocityTheory.AnalyticForms.RegularLocalRings.PreMemIrreducibleComponents, `ReciprocityTheory.Chebotarev.EulerLim, `ReciprocityTheory.Chebotarev.IdealLat, `ReciprocityTheory.Chebotarev.MeanZero, `ReciprocityTheory.Chebotarev.SplitEA, `ReciprocityTheory.Chebotarev.Support, `ReciprocityTheory.ClassFieldTheory.LocalClassField.KbarRepContAction, `ReciprocityTheory.ClassFieldTheory.LocalClassField.NormSubEqOneOfPowEqOne, `ReciprocityTheory.ClassFieldTheory.LocalClassField.QZDefs, `ReciprocityTheory.ClassFieldTheory.LocalClassField.UnitsHerbrandD, `ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.Unmixed, `ReciprocityTheory.DualLattices.BlockOneMulMulBlockOne, `ReciprocityTheory.DualLattices.ColengthCotangentBoundStatementOfClaim, `ReciprocityTheory.DualLattices.ColengthSqBlockVandermonde, `ReciprocityTheory.DualLattices.ExistsMatOfEquiv, `ReciprocityTheory.DualLattices.Imports, `ReciprocityTheory.DualLattices.IsFibreSq, `ReciprocityTheory.DualLattices.IsPairingValueAddRight, `ReciprocityTheory.DualLattices.LenIdStatement, `ReciprocityTheory.DualLattices.LinPairStatement, `ReciprocityTheory.DualLattices.MemDualLatMapFourier, `ReciprocityTheory.DualLattices.MemMapAugmentationIdealComapPullbackQuotient, `ReciprocityTheory.DualLattices.NilSurjOfSqZero, `ReciprocityTheory.DualLattices.PrimeHopfOrderOfAddEquiv, `ReciprocityTheory.DualLattices.ProdDvdOfIso]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

