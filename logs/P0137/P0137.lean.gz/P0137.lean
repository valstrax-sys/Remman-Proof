import Lean
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.IntStable
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.IsGroupHomog
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.LieLatticeData
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.Models
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.OnbMat
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.PluckerCoord
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.CoordsAt
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.DefiniteFormStabilizerFiniteAwayFromP
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.HasValues
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.InjectiveOfIsCptGen
import Development.AutomorphicSpectrum.Definitions.MembershipCriteria.HasElemDiv
import Development.AutomorphicSpectrum.Definitions.MetricPeriods.ExistsIntSmulIsAdicIntegralInTensorBasis
import Development.AutomorphicSpectrum.Definitions.MetricPeriods.GramSignatureTwoOneEntryZeroZero
import Development.AutomorphicSpectrum.Definitions.MetricPeriods.ZeroMemLieBall
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.SchurTranslationsCharacters
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.UnitLogOrthogonalWeightConstantStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.AlgClosedTensorIsDomain
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.BundleDegreeEqSumValuations
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.CharacteristicPolynomialFreeGenerators
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DegreeInvariantLinearEquiv
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.EigenProjectorsSplitAction
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsSectionLevel
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsSymplecticBasisLagrangianBetween
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsUniformDenominator
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExtensionOrderEqSpan
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FinitePresentationOfFaithfullyFlat
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FixedByAutomorphismsMemField
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FrobeniusChainCarry
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderContainsCharacters
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderTranslationInvariant
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.IsSplitInjectiveAndExists
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LatticeBasisAdaptedToSubspace
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LatticeKernelRankBoundNorm
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeFiniteProjectiveBaseChange
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeOfFiniteProjective
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.MemRangeOfIntegralAtHeightOneOver
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.MemSpanOverOfMem
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.PadicEmbeddingsConjugateOfUnits
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ProductInequalitiesForceEquality
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.QuadraticCharacterPrescribedPlaces
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.RepresentationBasisLinearIndependent
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.RootMulComplexConjEqOne
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SaturatedLatticeQuotientCount
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SeparatedOfFiniteSurjectiveQuotientStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SmulMemSpanOver
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.StatementUnavailableOne
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SumMemLoc
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SymplecticPeriodMatrixIntegrality
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.TeichmullerCharacterOrderGeneratesStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.TelescopingCoordinateDifferenceStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AbsolutelyClosedPolynomialSplits
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AbsolutelyIntegrallyClosedOfNewton
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AdicCompleteTensorFinite
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AePolynomialNonvanishingStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AicValOfIsColim
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AlternatingMapEqZeroOfSpan
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AnnihilatorCompactWithinNhdsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AntitoneDiagonalConjugateStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AntitoneWeightedSumZeroStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ApproximateIdentityProductBumpsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ArchimedeanOrbitalIntegralContinuous
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AutomorphicFunctionalHolomorphicDerivative
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.BijectiveAlgebraMapZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardCosetRepsEqRelIndexStatement

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.IntStable, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.IsGroupHomog, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.LieLatticeData, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.Models, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.OnbMat, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.PluckerCoord, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.CoordsAt, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.DefiniteFormStabilizerFiniteAwayFromP, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.HasValues, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.InjectiveOfIsCptGen, `Development.AutomorphicSpectrum.Definitions.MembershipCriteria.HasElemDiv, `Development.AutomorphicSpectrum.Definitions.MetricPeriods.ExistsIntSmulIsAdicIntegralInTensorBasis, `Development.AutomorphicSpectrum.Definitions.MetricPeriods.GramSignatureTwoOneEntryZeroZero, `Development.AutomorphicSpectrum.Definitions.MetricPeriods.ZeroMemLieBall, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.SchurTranslationsCharacters, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.UnitLogOrthogonalWeightConstantStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.AlgClosedTensorIsDomain, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.BundleDegreeEqSumValuations, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.CharacteristicPolynomialFreeGenerators, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DegreeInvariantLinearEquiv, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.EigenProjectorsSplitAction, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsSectionLevel, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsSymplecticBasisLagrangianBetween, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsUniformDenominator, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExtensionOrderEqSpan, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FinitePresentationOfFaithfullyFlat, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FixedByAutomorphismsMemField, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FrobeniusChainCarry, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderContainsCharacters, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderTranslationInvariant, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.IsSplitInjectiveAndExists, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LatticeBasisAdaptedToSubspace, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LatticeKernelRankBoundNorm, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeFiniteProjectiveBaseChange, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeOfFiniteProjective, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.MemRangeOfIntegralAtHeightOneOver, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.MemSpanOverOfMem, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.PadicEmbeddingsConjugateOfUnits, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ProductInequalitiesForceEquality, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.QuadraticCharacterPrescribedPlaces, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.RepresentationBasisLinearIndependent, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.RootMulComplexConjEqOne, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SaturatedLatticeQuotientCount, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SeparatedOfFiniteSurjectiveQuotientStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SmulMemSpanOver, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.StatementUnavailableOne, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SumMemLoc, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SymplecticPeriodMatrixIntegrality, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.TeichmullerCharacterOrderGeneratesStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.TelescopingCoordinateDifferenceStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AbsolutelyClosedPolynomialSplits, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AbsolutelyIntegrallyClosedOfNewton, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AdicCompleteTensorFinite, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AePolynomialNonvanishingStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AicValOfIsColim, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AlternatingMapEqZeroOfSpan, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AnnihilatorCompactWithinNhdsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AntitoneDiagonalConjugateStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AntitoneWeightedSumZeroStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ApproximateIdentityProductBumpsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ArchimedeanOrbitalIntegralContinuous, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AutomorphicFunctionalHolomorphicDerivative, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.BijectiveAlgebraMapZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardCosetRepsEqRelIndexStatement]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

