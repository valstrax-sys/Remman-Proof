import Lean
import Development.WeilBound.CoreStatements.FiniteTypeHarishChandra.SupportExistsAll
import Development.WeilBound.CoreStatements.FlagImmersions.IsPotentialSumPot
import Development.WeilBound.CoreStatements.FlagImmersions.ShiftPowerSumMul
import Development.WeilBound.CoreStatements.GaussianSeminormBounds.RealSeminormFiltration.Tensor
import Development.WeilBound.CoreStatements.HodgeTatePoints.CompMemAddFun
import Development.WeilBound.CoreStatements.HodgeTatePoints.FormMemLin
import Development.WeilBound.CoreStatements.HodgeTatePoints.HtatBcPull
import Development.WeilBound.CoreStatements.HodgeTatePoints.HtatHt
import Development.WeilBound.CoreStatements.HodgeTatePoints.PowCongr
import Development.WeilBound.CoreStatements.HodgeTatePoints.RaChar
import Development.WeilBound.CoreStatements.HodgeTatePoints.RbProj
import Development.WeilBound.CoreStatements.HodgeTatePoints.RbTriang
import Development.WeilBound.CoreStatements.HodgeTatePoints.RdBase
import Development.WeilBound.CoreStatements.HodgeTatePoints.RhPull
import Development.WeilBound.CoreStatements.HomogeneousNonvanishing.LGenflagLU
import Development.WeilBound.CoreStatements.HomogeneousNonvanishing.TwGPadic
import Development.WeilBound.CoreStatements.MinimalPrimeDimensions.MemMinimalPrimesIff
import Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.CechPairings.CechAugRow
import Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.PerfectoidPullbacks.LocalSystemQuotients.QuoDMk
import Development.WeilBound.CoreStatements.PluriharmonicCharts.XFibHess
import Development.WeilBound.CoreStatements.PluriharmonicCharts.XFibMdisc
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.BasisFormSumOfGain
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.BasisSumOfOrthogonality
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.CasimirPowerCommute
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.CasimirRealOfCentral
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.CasimirRealScalar
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.ColumnMomentsOfSymmetric
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.CommutatorAdjointHolds
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.CompactGroupFacts
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.EigenWeightedSumBound
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.EigenbasisOfBasic
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.EigenspacesOrthogonalOfCalculus
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.EnvelopingAlgebraGrowthBound
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.FunctionalCalculusOfBasic
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.GelfandCentralHolds
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.GroupFactsHolds
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.GrowthOfBasic
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.GrowthPolynomialOperator
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.IdentityFiltrationBound
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.InversePowerBoundHolds
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.KFiniteInclusion
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.MatrixActionSingle
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.MaximumPrincipleOfFacts
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.NilpotentOfPowerTraces
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.OrthonormalEigenbasisOfBasic
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.PMaxPr
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.SecondDerivativeHolds
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.SymmetricPowerHolds
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.U0Commute
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.WordFiltrationCommute
import Development.WeilBound.CoreStatements.PublishedTheorems.NadelVanishingPairs.NadelVanishingLemmas.CechVanishingAlongFiltration
import Development.WeilBound.CoreStatements.PublishedTheorems.NadelVanishingPairs.NadelVanishingLemmas.ExistsFrobeniusSplittingDatumStatement
import Development.WeilBound.CoreStatements.PublishedTheorems.NadelVanishingPairs.NadelVanishingLemmas.FrobLiftPsiNatCastMul
import Development.WeilBound.CoreStatements.PublishedTheorems.NadelVanishingPairs.NadelVanishingLemmas.FrobeniusSplittingClosedStatement
import Development.WeilBound.CoreStatements.SesquilinearFractions.ExistsIntegralPosDefPerturbation
import Development.WeilBound.CoreStatements.SesquilinearFractions.NPlaces
import Development.WeilBound.CoreStatements.ThetaDilations.ParAlg
import Development.WeilBound.CoreStatements.TorusUniformisation.ChowMahlerFamilies.FirstLatticeBaseChange
import Development.WeilBound.RepresentationTheoryGL.ArchimedeanBaseChange.ArchimedeanBaseChangeProof.SatakeExponents.UniformizerValuations.FixedSpaceRankOne.FinrankFixedEqOne
import Development.WeilBound.RepresentationTheoryGL.ArchimedeanBaseChange.ArchimedeanBaseChangeProof.SatakeExponents.UniformizerValuations.SubOfEig
import Development.WeilBound.RepresentationTheoryGL.CasimirAlgebra.KugaCoordinates.CasimirBounds.CountSame
import Development.WeilBound.RepresentationTheoryGL.CasimirAlgebra.KugaCoordinates.CasimirBounds.ReSwapSumLe
import Development.WeilBound.RepresentationTheoryGL.CasimirAlgebra.KugaCoordinates.CoefficientGluing.SumFinVal
import Development.WeilBound.RepresentationTheoryGL.CasimirAlgebra.TensorRelationsGL.StepFormula

open Lean Elab Command

def auditTargets : Array Name := #[`Development.WeilBound.CoreStatements.FiniteTypeHarishChandra.SupportExistsAll, `Development.WeilBound.CoreStatements.FlagImmersions.IsPotentialSumPot, `Development.WeilBound.CoreStatements.FlagImmersions.ShiftPowerSumMul, `Development.WeilBound.CoreStatements.GaussianSeminormBounds.RealSeminormFiltration.Tensor, `Development.WeilBound.CoreStatements.HodgeTatePoints.CompMemAddFun, `Development.WeilBound.CoreStatements.HodgeTatePoints.FormMemLin, `Development.WeilBound.CoreStatements.HodgeTatePoints.HtatBcPull, `Development.WeilBound.CoreStatements.HodgeTatePoints.HtatHt, `Development.WeilBound.CoreStatements.HodgeTatePoints.PowCongr, `Development.WeilBound.CoreStatements.HodgeTatePoints.RaChar, `Development.WeilBound.CoreStatements.HodgeTatePoints.RbProj, `Development.WeilBound.CoreStatements.HodgeTatePoints.RbTriang, `Development.WeilBound.CoreStatements.HodgeTatePoints.RdBase, `Development.WeilBound.CoreStatements.HodgeTatePoints.RhPull, `Development.WeilBound.CoreStatements.HomogeneousNonvanishing.LGenflagLU, `Development.WeilBound.CoreStatements.HomogeneousNonvanishing.TwGPadic, `Development.WeilBound.CoreStatements.MinimalPrimeDimensions.MemMinimalPrimesIff, `Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.CechPairings.CechAugRow, `Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.PerfectoidPullbacks.LocalSystemQuotients.QuoDMk, `Development.WeilBound.CoreStatements.PluriharmonicCharts.XFibHess, `Development.WeilBound.CoreStatements.PluriharmonicCharts.XFibMdisc, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.BasisFormSumOfGain, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.BasisSumOfOrthogonality, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.CasimirPowerCommute, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.CasimirRealOfCentral, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.CasimirRealScalar, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.ColumnMomentsOfSymmetric, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.CommutatorAdjointHolds, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.CompactGroupFacts, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.EigenWeightedSumBound, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.EigenbasisOfBasic, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.EigenspacesOrthogonalOfCalculus, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.EnvelopingAlgebraGrowthBound, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.FunctionalCalculusOfBasic, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.GelfandCentralHolds, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.GroupFactsHolds, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.GrowthOfBasic, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.GrowthPolynomialOperator, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.IdentityFiltrationBound, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.InversePowerBoundHolds, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.KFiniteInclusion, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.MatrixActionSingle, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.MaximumPrincipleOfFacts, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.NilpotentOfPowerTraces, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.OrthonormalEigenbasisOfBasic, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.PMaxPr, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.SecondDerivativeHolds, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.SymmetricPowerHolds, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.U0Commute, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.WordFiltrationCommute, `Development.WeilBound.CoreStatements.PublishedTheorems.NadelVanishingPairs.NadelVanishingLemmas.CechVanishingAlongFiltration, `Development.WeilBound.CoreStatements.PublishedTheorems.NadelVanishingPairs.NadelVanishingLemmas.ExistsFrobeniusSplittingDatumStatement, `Development.WeilBound.CoreStatements.PublishedTheorems.NadelVanishingPairs.NadelVanishingLemmas.FrobLiftPsiNatCastMul, `Development.WeilBound.CoreStatements.PublishedTheorems.NadelVanishingPairs.NadelVanishingLemmas.FrobeniusSplittingClosedStatement, `Development.WeilBound.CoreStatements.SesquilinearFractions.ExistsIntegralPosDefPerturbation, `Development.WeilBound.CoreStatements.SesquilinearFractions.NPlaces, `Development.WeilBound.CoreStatements.ThetaDilations.ParAlg, `Development.WeilBound.CoreStatements.TorusUniformisation.ChowMahlerFamilies.FirstLatticeBaseChange, `Development.WeilBound.RepresentationTheoryGL.ArchimedeanBaseChange.ArchimedeanBaseChangeProof.SatakeExponents.UniformizerValuations.FixedSpaceRankOne.FinrankFixedEqOne, `Development.WeilBound.RepresentationTheoryGL.ArchimedeanBaseChange.ArchimedeanBaseChangeProof.SatakeExponents.UniformizerValuations.SubOfEig, `Development.WeilBound.RepresentationTheoryGL.CasimirAlgebra.KugaCoordinates.CasimirBounds.CountSame, `Development.WeilBound.RepresentationTheoryGL.CasimirAlgebra.KugaCoordinates.CasimirBounds.ReSwapSumLe, `Development.WeilBound.RepresentationTheoryGL.CasimirAlgebra.KugaCoordinates.CoefficientGluing.SumFinVal, `Development.WeilBound.RepresentationTheoryGL.CasimirAlgebra.TensorRelationsGL.StepFormula]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

