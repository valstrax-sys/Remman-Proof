import Lean
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PMahlerAverageSplit
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PMahlerIntegrand
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PMahlerSection
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PMahlerSectionOfConst
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PMahlerZeroSpec
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PPointChowForm
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PPointLine
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PPolyLocalGenerators
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PProjDegreeChow
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PProjSecDomain
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PProperSymm
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PProperSymmCycle
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PRecursion
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PSpecFirstHomog
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PSpecFirstRename
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PSpecFirstSwapMahler
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PSphereMeanFubini
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PSphereMeanLinearBall
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PSupportCycleSection
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.SpecFirstDetFormNeZero
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.SphereMean
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChartChoiceAlgClosed
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChartLengthAlgClosed
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChartNormAlgClosed
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChartNormSep
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChartResidueDegreeAlgClosed
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsIncidenceZeroLocus
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSectionComponents
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSectionOrderAlgClosed
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PChartFirstGroupPrime
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PChartIncDomain
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PChartKernel
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PChartLocDomain
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PChartResidueDegree
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PChowFormMultiHomog
import GroundTheory.HeightsAndTheta.Heights.ChowForms.StatementsChartFirstGroupDvd
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.FrameProjEq
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.ImportsBis
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.IsAddHaarMeasureHausdorffMeasureEuclideanSpaceCo
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAffineCompletionNormal
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAuslanderBuchsbaumProjDimUpper
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PBranchInverseHolomorphic
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PBranchInverseOffHypersurface
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PCompletionNormalDescent
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjectionOffZerosDense
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjectionSheetedClosureEquations
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjectionSheetsDense
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGermCompletionEquiv
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PHolGermPointIdealSpan
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PHolGermsIntegrallyClosed
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PHolGermsNoetherian
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PImplicitCurve
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PInjectiveHolomorphicInverse
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PIsolatedFibreLocalUnbranched
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PLocalGraphProjectionMass
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PMaximalCountUnbranched
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNonIsolatedFibreCurve
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNormalGermIntegrallyClosed
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNormalZerosNowhereDense
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PPolyGermPointPow
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PPrimeGermNullstellensatz
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PProperHolomorphicSurjective
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PProperOpenProjectionLocalCover
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PRegularOffHypersurface

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PMahlerAverageSplit, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PMahlerIntegrand, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PMahlerSection, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PMahlerSectionOfConst, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PMahlerZeroSpec, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PPointChowForm, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PPointLine, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PPolyLocalGenerators, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PProjDegreeChow, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PProjSecDomain, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PProperSymm, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PProperSymmCycle, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PRecursion, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PSpecFirstHomog, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PSpecFirstRename, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PSpecFirstSwapMahler, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PSphereMeanFubini, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PSphereMeanLinearBall, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PSupportCycleSection, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.SpecFirstDetFormNeZero, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.SphereMean, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChartChoiceAlgClosed, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChartLengthAlgClosed, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChartNormAlgClosed, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChartNormSep, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChartResidueDegreeAlgClosed, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsIncidenceZeroLocus, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSectionComponents, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSectionOrderAlgClosed, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PChartFirstGroupPrime, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PChartIncDomain, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PChartKernel, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PChartLocDomain, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PChartResidueDegree, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PChowFormMultiHomog, `GroundTheory.HeightsAndTheta.Heights.ChowForms.StatementsChartFirstGroupDvd, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.FrameProjEq, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.ImportsBis, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.IsAddHaarMeasureHausdorffMeasureEuclideanSpaceCo, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAffineCompletionNormal, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAuslanderBuchsbaumProjDimUpper, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PBranchInverseHolomorphic, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PBranchInverseOffHypersurface, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PCompletionNormalDescent, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjectionOffZerosDense, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjectionSheetedClosureEquations, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjectionSheetsDense, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGermCompletionEquiv, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PHolGermPointIdealSpan, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PHolGermsIntegrallyClosed, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PHolGermsNoetherian, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PImplicitCurve, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PInjectiveHolomorphicInverse, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PIsolatedFibreLocalUnbranched, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PLocalGraphProjectionMass, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PMaximalCountUnbranched, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNonIsolatedFibreCurve, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNormalGermIntegrallyClosed, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNormalZerosNowhereDense, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PPolyGermPointPow, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PPrimeGermNullstellensatz, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PProperHolomorphicSurjective, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PProperOpenProjectionLocalCover, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PRegularOffHypersurface]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

