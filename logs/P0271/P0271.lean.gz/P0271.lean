import Lean
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.BaseGamC
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.DUConst
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.LevelsModConstIffOfDownDown
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.LinExtEqZeroOfMemExt
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.RhoMapFunctorial
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.SplittingOfPositiveLevel
import Formalism.DistinguishedUnitIdeals.FrobeniusDiffBijective
import Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.MeasureUniformizerMatrixSetMulCard
import Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.RelIndexMulMeasure
import Formalism.DropLevelBounds.Statement
import Formalism.EisensteinCokernelLengths.FactorialValuationBounds.ToolsB
import Formalism.EisensteinCokernelLengths.RationalTailBound
import Formalism.EllipticTorsion.ChangeIntegral
import Formalism.EllipticTorsion.CompExpWeight
import Formalism.EllipticTorsion.EllipticTorsionProofs.ConstantCoeffLogOnePlus
import Formalism.EllipticTorsion.EllipticTorsionProofs.CubeThree
import Formalism.EllipticTorsion.EllipticTorsionProofs.IntVal
import Formalism.EllipticTorsion.EllipticTorsionProofs.IntegralPSBserSubOne
import Formalism.EllipticTorsion.EllipticTorsionProofs.LegendreInvariant
import Formalism.EllipticTorsion.EllipticTorsionProofs.ModelUnitOf
import Formalism.EllipticTorsion.EllipticTorsionProofs.NDeriv
import Formalism.EllipticTorsion.EllipticTorsionProofs.PadicMult
import Formalism.EllipticTorsion.FormalGroupPointsTorsionFree
import Formalism.EllipticTorsion.JetsCube
import Formalism.EllipticTorsion.UnitCancel
import Formalism.EllipticTorsion.VeluIntegralModel
import Formalism.FilteredPoleLength.LocalDescentLevels.ExistsSmulMemOfMemSpan
import Formalism.FilteredPoleLength.LocalDescentLevels.LatticeDescent
import Formalism.FilteredPoleLength.LocalDescentLevels.LatticeIndexBis
import Formalism.FilteredPoleLength.LocalDescentLevels.LengthBaseChange
import Formalism.FilteredPoleLength.LocalDescentLevels.ReductionQuotient
import Formalism.FilteredPoleLength.ReducedBasisBounds.LocalStepLevelsExt
import Formalism.FlagUnipotentLattices.ConductorCharacterLeakBound
import Formalism.FlagUnipotentLattices.IdealCountLeW
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.DetMulEqSumProdMulDetSubmatrix
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.ExponentInequalityNondegenerateMid
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.SchurAverage
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.SumComplexEmbeddingsEqSumInfinitePlace
import Formalism.FlagUnipotentLattices.UnitSumBound
import Formalism.FockGram.SymGramPosSemidef
import Formalism.FormalDegreeBessel.FormalDegreeRatio.BFCell
import Formalism.FormalDegreeBessel.FormalDegreeRatio.BesselUnipotentEquivHolds
import Formalism.FormalDegreeBessel.FormalDegreeRatio.BesselUnitaryEquivHolds
import Formalism.FormalDegreeBessel.FormalDegreeRatio.ReverseCauchySchwarzHolds
import Formalism.FormalDegreeBessel.StatementDS
import Formalism.FormalGroupLog.LogDeterminesLaw
import Formalism.FormalGroupWitt.Statement
import Formalism.FrobeniusBaseCase.FrobeniusBaseCaseProofs.ChainI
import Formalism.FrobeniusOrbits.DiscrMaximalRealCyclotomic
import Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.RealCyclotomicSubfield
import Formalism.FrobeniusOrbits.HostDiffSupport
import Formalism.FrobeniusOrbits.HostOrbitsPlaces
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.NormUSum
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsIsomFix
import Formalism.GL3MeanSquares.HookFormulaTorsion.ConditionIffDualEqFunctional
import Formalism.GL3MeanSquares.HookFormulaTorsion.FourierCommutesHeckeScalar
import Formalism.GL3MeanSquares.HookFormulaTorsion.HadamardUnitDiagonalDetLeOne
import Formalism.GL3MeanSquares.HookFormulaTorsion.HasDerivAtLogSquareAntiderivative
import Formalism.GL3MeanSquares.HookFormulaTorsion.ShortIntervalImpliesProgressionsStatement
import Formalism.GL3MeanSquares.HookFormulaTorsion.SizeEstimates
import Formalism.GL3MeanSquares.HookFormulaTorsion.SquareMomentArithmeticBound
import Formalism.GL3MeanSquares.IntegralMultipleNormLowerBound
import Formalism.GL3MeanSquares.RationalMatrixPrimeOrderBound
import Formalism.GaloisCohomology.GaloisCohomologyProofs.DevTorsion

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.BaseGamC, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.DUConst, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.LevelsModConstIffOfDownDown, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.LinExtEqZeroOfMemExt, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.RhoMapFunctorial, `Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.SplittingOfPositiveLevel, `Formalism.DistinguishedUnitIdeals.FrobeniusDiffBijective, `Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.MeasureUniformizerMatrixSetMulCard, `Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.RelIndexMulMeasure, `Formalism.DropLevelBounds.Statement, `Formalism.EisensteinCokernelLengths.FactorialValuationBounds.ToolsB, `Formalism.EisensteinCokernelLengths.RationalTailBound, `Formalism.EllipticTorsion.ChangeIntegral, `Formalism.EllipticTorsion.CompExpWeight, `Formalism.EllipticTorsion.EllipticTorsionProofs.ConstantCoeffLogOnePlus, `Formalism.EllipticTorsion.EllipticTorsionProofs.CubeThree, `Formalism.EllipticTorsion.EllipticTorsionProofs.IntVal, `Formalism.EllipticTorsion.EllipticTorsionProofs.IntegralPSBserSubOne, `Formalism.EllipticTorsion.EllipticTorsionProofs.LegendreInvariant, `Formalism.EllipticTorsion.EllipticTorsionProofs.ModelUnitOf, `Formalism.EllipticTorsion.EllipticTorsionProofs.NDeriv, `Formalism.EllipticTorsion.EllipticTorsionProofs.PadicMult, `Formalism.EllipticTorsion.FormalGroupPointsTorsionFree, `Formalism.EllipticTorsion.JetsCube, `Formalism.EllipticTorsion.UnitCancel, `Formalism.EllipticTorsion.VeluIntegralModel, `Formalism.FilteredPoleLength.LocalDescentLevels.ExistsSmulMemOfMemSpan, `Formalism.FilteredPoleLength.LocalDescentLevels.LatticeDescent, `Formalism.FilteredPoleLength.LocalDescentLevels.LatticeIndexBis, `Formalism.FilteredPoleLength.LocalDescentLevels.LengthBaseChange, `Formalism.FilteredPoleLength.LocalDescentLevels.ReductionQuotient, `Formalism.FilteredPoleLength.ReducedBasisBounds.LocalStepLevelsExt, `Formalism.FlagUnipotentLattices.ConductorCharacterLeakBound, `Formalism.FlagUnipotentLattices.IdealCountLeW, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.DetMulEqSumProdMulDetSubmatrix, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.ExponentInequalityNondegenerateMid, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.SchurAverage, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.SumComplexEmbeddingsEqSumInfinitePlace, `Formalism.FlagUnipotentLattices.UnitSumBound, `Formalism.FockGram.SymGramPosSemidef, `Formalism.FormalDegreeBessel.FormalDegreeRatio.BFCell, `Formalism.FormalDegreeBessel.FormalDegreeRatio.BesselUnipotentEquivHolds, `Formalism.FormalDegreeBessel.FormalDegreeRatio.BesselUnitaryEquivHolds, `Formalism.FormalDegreeBessel.FormalDegreeRatio.ReverseCauchySchwarzHolds, `Formalism.FormalDegreeBessel.StatementDS, `Formalism.FormalGroupLog.LogDeterminesLaw, `Formalism.FormalGroupWitt.Statement, `Formalism.FrobeniusBaseCase.FrobeniusBaseCaseProofs.ChainI, `Formalism.FrobeniusOrbits.DiscrMaximalRealCyclotomic, `Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.RealCyclotomicSubfield, `Formalism.FrobeniusOrbits.HostDiffSupport, `Formalism.FrobeniusOrbits.HostOrbitsPlaces, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.NormUSum, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsIsomFix, `Formalism.GL3MeanSquares.HookFormulaTorsion.ConditionIffDualEqFunctional, `Formalism.GL3MeanSquares.HookFormulaTorsion.FourierCommutesHeckeScalar, `Formalism.GL3MeanSquares.HookFormulaTorsion.HadamardUnitDiagonalDetLeOne, `Formalism.GL3MeanSquares.HookFormulaTorsion.HasDerivAtLogSquareAntiderivative, `Formalism.GL3MeanSquares.HookFormulaTorsion.ShortIntervalImpliesProgressionsStatement, `Formalism.GL3MeanSquares.HookFormulaTorsion.SizeEstimates, `Formalism.GL3MeanSquares.HookFormulaTorsion.SquareMomentArithmeticBound, `Formalism.GL3MeanSquares.IntegralMultipleNormLowerBound, `Formalism.GL3MeanSquares.RationalMatrixPrimeOrderBound, `Formalism.GaloisCohomology.GaloisCohomologyProofs.DevTorsion]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

