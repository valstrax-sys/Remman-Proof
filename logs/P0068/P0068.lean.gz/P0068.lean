import Lean
import Development.WeilBound.ThetaLifts.LatticeBasics.PairsD
import Development.WeilBound.ThetaLifts.LatticeBasics.UnfoldA
import Development.WeilBound.ThetaLifts.LeviDeterminants.GrowSobA
import Development.WeilBound.ThetaLifts.LeviDeterminants.MixedModels.PlaneGen
import Development.WeilBound.ThetaLifts.LocalTheory.ArchimedeanBumps.DictHaar
import Development.WeilBound.ThetaLifts.LocalTheory.ArchimedeanBumps.ExistsDensity
import Development.WeilBound.ThetaLifts.LocalTheory.ConeShifts.FubGen
import Development.WeilBound.ThetaLifts.LocalTheory.ConeShifts.FubTate
import Development.WeilBound.ThetaLifts.SchwartzMoments.JetApply
import Development.WeilBound.ThetaLifts.SchwartzMoments.NormIterComp
import Development.WeilBound.ThetaLifts.SmallCones.ColsOfMul
import Development.WeilBound.ThetaLifts.SmallCones.RightOfCompact
import Development.WeilBound.ThetaLifts.SmallCones.SliceArch
import Development.WeilBound.ThetaLifts.SphericalLattices.DgPerm
import Development.WeilBound.ThetaLifts.SphericalLattices.LatDefs
import Development.WeilBound.ThetaLifts.TowerModels.ExistsRefl
import Development.WeilBound.ThetaLifts.TowerModels.LeviAlg
import Formalism.AlphaUniqueness.Statement
import Formalism.ArtinHasse.Statement
import Formalism.BehrendSets.Statement
import Formalism.BranchSandwichDivisors.StatementR
import Formalism.CharacterColumnKernels.StatLowestInZ
import Formalism.CharacterColumnKernels.Statement
import Formalism.CoboundaryTransfers.Statement
import Formalism.ConjugateSelfDual.Statement
import Formalism.CorankShare.StatementFR
import Formalism.CyclotomicNorms.DiscardKernel
import Formalism.CyclotomicNorms.StatementA
import Formalism.CyclotomicNorms.StatementI
import Formalism.CyclotomicNorms.StatementTW
import Formalism.DegreeFormula.FlagDegFormula
import Formalism.DistinguishedUnitIdeals.Statement
import Formalism.DoubleCosetMeasures.Statement
import Formalism.DropLevelBounds.SumAdd
import Formalism.DropLevelBounds.ThBounds
import Formalism.EllipticTorsion.IsoExpand
import Formalism.EllipticTorsion.WSeriesUnique
import Formalism.FilteredPoleLength.ReducedBasisBounds.AlternatingBinomial
import Formalism.FilteredPoleLength.ReducedBasisBounds.FourTermSumBoundOfParameters
import Formalism.FilteredPoleLength.ReducedBasisBounds.GFiniteOrderUnipotent
import Formalism.FilteredPoleLength.ReducedBasisBounds.ParameterInequalities
import Formalism.FilteredPoleLength.ReducedBasisBounds.TransvectionIsometry
import Formalism.FockGram.StatementLat
import Formalism.FormalDegreeBessel.StatementWR
import Formalism.FormalGroupLog.FormalGroupLogProofs.ChainRule
import Formalism.FrobeniusBaseCase.Statement
import Formalism.FrobeniusContraction.Statement
import Formalism.FrobeniusContraction.StatementB
import Formalism.FrobeniusContraction.StatementTop
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.CountSt
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.ExceptionalCharacterBounds.EffBase
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.ExceptionalCharacterBounds.EffConsts
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.ExceptionalCharacterBounds.ExcTerm
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.ExistsFarFromPoints
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.ExistsPowerSumLowerBound
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.MSqMainA
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.MSqMainB
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.PNTBAsmA
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.PNTDHFinishA
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.PNTDHPrimeB
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.PNTExplMainA
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.PNTSharpA
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.RootNorm
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.TailKernel

open Lean Elab Command

def auditTargets : Array Name := #[`Development.WeilBound.ThetaLifts.LatticeBasics.PairsD, `Development.WeilBound.ThetaLifts.LatticeBasics.UnfoldA, `Development.WeilBound.ThetaLifts.LeviDeterminants.GrowSobA, `Development.WeilBound.ThetaLifts.LeviDeterminants.MixedModels.PlaneGen, `Development.WeilBound.ThetaLifts.LocalTheory.ArchimedeanBumps.DictHaar, `Development.WeilBound.ThetaLifts.LocalTheory.ArchimedeanBumps.ExistsDensity, `Development.WeilBound.ThetaLifts.LocalTheory.ConeShifts.FubGen, `Development.WeilBound.ThetaLifts.LocalTheory.ConeShifts.FubTate, `Development.WeilBound.ThetaLifts.SchwartzMoments.JetApply, `Development.WeilBound.ThetaLifts.SchwartzMoments.NormIterComp, `Development.WeilBound.ThetaLifts.SmallCones.ColsOfMul, `Development.WeilBound.ThetaLifts.SmallCones.RightOfCompact, `Development.WeilBound.ThetaLifts.SmallCones.SliceArch, `Development.WeilBound.ThetaLifts.SphericalLattices.DgPerm, `Development.WeilBound.ThetaLifts.SphericalLattices.LatDefs, `Development.WeilBound.ThetaLifts.TowerModels.ExistsRefl, `Development.WeilBound.ThetaLifts.TowerModels.LeviAlg, `Formalism.AlphaUniqueness.Statement, `Formalism.ArtinHasse.Statement, `Formalism.BehrendSets.Statement, `Formalism.BranchSandwichDivisors.StatementR, `Formalism.CharacterColumnKernels.StatLowestInZ, `Formalism.CharacterColumnKernels.Statement, `Formalism.CoboundaryTransfers.Statement, `Formalism.ConjugateSelfDual.Statement, `Formalism.CorankShare.StatementFR, `Formalism.CyclotomicNorms.DiscardKernel, `Formalism.CyclotomicNorms.StatementA, `Formalism.CyclotomicNorms.StatementI, `Formalism.CyclotomicNorms.StatementTW, `Formalism.DegreeFormula.FlagDegFormula, `Formalism.DistinguishedUnitIdeals.Statement, `Formalism.DoubleCosetMeasures.Statement, `Formalism.DropLevelBounds.SumAdd, `Formalism.DropLevelBounds.ThBounds, `Formalism.EllipticTorsion.IsoExpand, `Formalism.EllipticTorsion.WSeriesUnique, `Formalism.FilteredPoleLength.ReducedBasisBounds.AlternatingBinomial, `Formalism.FilteredPoleLength.ReducedBasisBounds.FourTermSumBoundOfParameters, `Formalism.FilteredPoleLength.ReducedBasisBounds.GFiniteOrderUnipotent, `Formalism.FilteredPoleLength.ReducedBasisBounds.ParameterInequalities, `Formalism.FilteredPoleLength.ReducedBasisBounds.TransvectionIsometry, `Formalism.FockGram.StatementLat, `Formalism.FormalDegreeBessel.StatementWR, `Formalism.FormalGroupLog.FormalGroupLogProofs.ChainRule, `Formalism.FrobeniusBaseCase.Statement, `Formalism.FrobeniusContraction.Statement, `Formalism.FrobeniusContraction.StatementB, `Formalism.FrobeniusContraction.StatementTop, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.CountSt, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.ExceptionalCharacterBounds.EffBase, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.ExceptionalCharacterBounds.EffConsts, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.ExceptionalCharacterBounds.ExcTerm, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.ExistsFarFromPoints, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.ExistsPowerSumLowerBound, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.MSqMainA, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.MSqMainB, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.PNTBAsmA, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.PNTDHFinishA, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.PNTDHPrimeB, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.PNTExplMainA, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.PNTSharpA, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.RootNorm, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.TailKernel]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

