import Lean
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MovedPointDeterminant
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MsMul
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MulIntegralStatement
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MulLeftCancelOfDetNeZero
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MulMemIntA
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MulMemLp
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MulVecFixOfSupp
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MultiDimensional
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MultilinearVanishLattice
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MultiplicationFunction
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MultiplicationNormBound
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MultiplicationPackage
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MultisetSeparation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NearOfAdjoin
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NoetherNormalizationChart
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NonSplitSequence
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NonvanishingPoint
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormDetLe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormDetLeAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormEqMulCE
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormEqOne
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormIndexQuadratic
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormIntegersLeOne
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormLeOneOfIntegral
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormLeOneOfIsIntegral
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormLeOneOfMonicRoot
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormLeSum
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormLtOne
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormNatCastPrime
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormOnValuationRing
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormPowSubPowLe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormRingALe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormSubgroupOpen
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormSumLt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormalizedMatrixSpan
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OddSpanVariable
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OmMul
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OmegaConstruction
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OneAlg
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OneLeftCongr
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OpenFix
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OrbitFinite
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OrderedFlagDiagonal
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PairCases
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PairedCharacterCondition
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ParabolicUnipotentGL
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PartialDerivMonomialLaplace
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PartialFiltrationCoeff
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PbMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Per
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PhiMulSelf
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PhiMulTranspose
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PiSpanVariable
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PinsOfClosedSubgroupPadicCharacterInv
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PlaceRankTwoOne
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PlacewiseToOutsideS
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Plc
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PointFinitePower
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PolyInMul
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PowCong
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PowEig
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PowSubMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PowSubOneMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PrecompleteOfFinite

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MovedPointDeterminant, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MsMul, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MulIntegralStatement, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MulLeftCancelOfDetNeZero, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MulMemIntA, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MulMemLp, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MulVecFixOfSupp, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MultiDimensional, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MultilinearVanishLattice, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MultiplicationFunction, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MultiplicationNormBound, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MultiplicationPackage, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MultisetSeparation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NearOfAdjoin, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NoetherNormalizationChart, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NonSplitSequence, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NonvanishingPoint, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormDetLe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormDetLeAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormEqMulCE, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormEqOne, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormIndexQuadratic, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormIntegersLeOne, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormLeOneOfIntegral, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormLeOneOfIsIntegral, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormLeOneOfMonicRoot, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormLeSum, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormLtOne, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormNatCastPrime, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormOnValuationRing, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormPowSubPowLe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormRingALe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormSubgroupOpen, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormSumLt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.NormalizedMatrixSpan, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OddSpanVariable, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OmMul, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OmegaConstruction, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OneAlg, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OneLeftCongr, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OpenFix, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OrbitFinite, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.OrderedFlagDiagonal, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PairCases, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PairedCharacterCondition, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ParabolicUnipotentGL, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PartialDerivMonomialLaplace, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PartialFiltrationCoeff, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PbMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Per, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PhiMulSelf, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PhiMulTranspose, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PiSpanVariable, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PinsOfClosedSubgroupPadicCharacterInv, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PlaceRankTwoOne, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PlacewiseToOutsideS, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Plc, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PointFinitePower, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PolyInMul, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PowCong, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PowEig, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PowSubMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PowSubOneMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.PrecompleteOfFinite]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

