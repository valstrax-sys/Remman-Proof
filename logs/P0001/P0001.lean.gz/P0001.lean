import Lean
import BuildAid.D1
import BuildAid.D2
import BuildAid.D3
import BuildAid.D4
import BuildAid.D5
import CompanionTheory.AutomorphicTheory.BesselWaveGrids.InterlacingGrids.CloudProd
import CompanionTheory.AutomorphicTheory.BesselWaveGrids.InterlacingGrids.FreeFamily
import CompanionTheory.AutomorphicTheory.BesselWaveGrids.InterlacingGrids.GridSum
import CompanionTheory.AutomorphicTheory.BesselWaveGrids.InterlacingGrids.LagSum
import CompanionTheory.AutomorphicTheory.BesselWaveGrids.InterlacingGrids.PairOKOfInterlace
import CompanionTheory.AutomorphicTheory.BesselWaveGrids.InterlacingGrids.ProgYInjective
import CompanionTheory.AutomorphicTheory.DiscreteGroupWaves.IntegralEqOfSqrtCauchy
import CompanionTheory.AutomorphicTheory.HeckeStandardModules.ExistsCen
import CompanionTheory.AutomorphicTheory.JacobiDiagonalBounds.Vander
import CompanionTheory.AutomorphicTheory.SchurLimitBounds.SchurOrthogonality.URepBasic
import CompanionTheory.AutomorphicTheory.ThetaDilations.Nuabs
import CompanionTheory.HarishChandraModules.BesselParameterIntegrals.ContDiffOnExpPartialHomeomorphSymm
import CompanionTheory.HarishChandraModules.KFiniteAnalyticVectors.AdmissibleSmoothVectors.GardingAvg
import CompanionTheory.HarishChandraModules.KFiniteAnalyticVectors.AdmissibleSmoothVectors.IwaChol
import CompanionTheory.HarishChandraModules.KFiniteAnalyticVectors.FundamentalDomainCusps.CompactIntegralBoundedByQuotientNorm
import CompanionTheory.HarishChandraModules.KFiniteAnalyticVectors.FundamentalDomainCusps.NilpAlg
import CompanionTheory.HarishChandraModules.NonemptyRepresentations.ExpEntry
import CompanionTheory.HarishChandraModules.NonemptyRepresentations.NonemptyOfAntitone
import CompanionTheory.RealGroups.FormalDegrees.ArchimedeanFormalDegrees.MomB
import CompanionTheory.RealGroups.UnitaryAdmissibility.ArchimedeanUnitaryDual.StSandwich
import CompanionTheory.SpectralGeometry.CountingDefinitions.AdelicEulerProducts.CountData
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.AdeleRingStableRangeOne
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.CompactPartClosedOrbit
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.ExistsCompactForMeasurePreservingEndos
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.FiniteCovolumeUnimodular
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.GeomSumIntLe
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.GroupActionHaarScalingContinuous
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.InfiniteProductMultipliable
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.MatrixInductionTransvectionDiagonal
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.SymmetricInvertibleExistsPosdefCongruence
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.TotallyRealContinuousEmbeddingInfiniteAdeles
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.CommuteOfMemAdjoin
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.CompactSubgroupFiniteOpenCosets
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.FinrankAdjoinLeAdd
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.FinrankRangePowConvex
import Development.AbelianVarietyTheory.BlockTheory.AdelicCMFields.UnitaryHeckeCharacterIdele
import Development.AbelianVarietyTheory.BlockTheory.CMModuli.HostConjugateIdeal
import Development.AbelianVarietyTheory.BlockTheory.CMModuli.ProjectiveSpaceOverSpec
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.AdelicScalarMultiplier
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.IdeleNormTraceForm
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.MultiplicationKernelIdentity
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.OmegaFactorization
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.QuotientEigenDifference
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.TensorProductAction
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.TraceDualDifferent
import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.InvariantRadonFibre
import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.StabiliserCardinality
import Development.AbelianVarietyTheory.BlockTheory.HeightDefect.SchurLatticeConjugates
import Development.AbelianVarietyTheory.BlockTheory.HeightDefect.SphereBlockLogMean
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.BalancedHermitianSpace
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.DecreasingNodeGaps
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.HarishChandraParameters
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.IntegralPartDecomposition
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.NodalSeriesPeriods
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.RelativeDifferentValues
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.RootValueClassBasis
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.SplitUnramifiedPlaces
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.TraceFormDualSystem
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.HeckeFlatSpecialisation

open Lean Elab Command

def auditTargets : Array Name := #[`BuildAid.D1, `BuildAid.D2, `BuildAid.D3, `BuildAid.D4, `BuildAid.D5, `CompanionTheory.AutomorphicTheory.BesselWaveGrids.InterlacingGrids.CloudProd, `CompanionTheory.AutomorphicTheory.BesselWaveGrids.InterlacingGrids.FreeFamily, `CompanionTheory.AutomorphicTheory.BesselWaveGrids.InterlacingGrids.GridSum, `CompanionTheory.AutomorphicTheory.BesselWaveGrids.InterlacingGrids.LagSum, `CompanionTheory.AutomorphicTheory.BesselWaveGrids.InterlacingGrids.PairOKOfInterlace, `CompanionTheory.AutomorphicTheory.BesselWaveGrids.InterlacingGrids.ProgYInjective, `CompanionTheory.AutomorphicTheory.DiscreteGroupWaves.IntegralEqOfSqrtCauchy, `CompanionTheory.AutomorphicTheory.HeckeStandardModules.ExistsCen, `CompanionTheory.AutomorphicTheory.JacobiDiagonalBounds.Vander, `CompanionTheory.AutomorphicTheory.SchurLimitBounds.SchurOrthogonality.URepBasic, `CompanionTheory.AutomorphicTheory.ThetaDilations.Nuabs, `CompanionTheory.HarishChandraModules.BesselParameterIntegrals.ContDiffOnExpPartialHomeomorphSymm, `CompanionTheory.HarishChandraModules.KFiniteAnalyticVectors.AdmissibleSmoothVectors.GardingAvg, `CompanionTheory.HarishChandraModules.KFiniteAnalyticVectors.AdmissibleSmoothVectors.IwaChol, `CompanionTheory.HarishChandraModules.KFiniteAnalyticVectors.FundamentalDomainCusps.CompactIntegralBoundedByQuotientNorm, `CompanionTheory.HarishChandraModules.KFiniteAnalyticVectors.FundamentalDomainCusps.NilpAlg, `CompanionTheory.HarishChandraModules.NonemptyRepresentations.ExpEntry, `CompanionTheory.HarishChandraModules.NonemptyRepresentations.NonemptyOfAntitone, `CompanionTheory.RealGroups.FormalDegrees.ArchimedeanFormalDegrees.MomB, `CompanionTheory.RealGroups.UnitaryAdmissibility.ArchimedeanUnitaryDual.StSandwich, `CompanionTheory.SpectralGeometry.CountingDefinitions.AdelicEulerProducts.CountData, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.AdeleRingStableRangeOne, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.CompactPartClosedOrbit, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.ExistsCompactForMeasurePreservingEndos, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.FiniteCovolumeUnimodular, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.GeomSumIntLe, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.GroupActionHaarScalingContinuous, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.InfiniteProductMultipliable, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.MatrixInductionTransvectionDiagonal, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.SymmetricInvertibleExistsPosdefCongruence, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.TotallyRealContinuousEmbeddingInfiniteAdeles, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.CommuteOfMemAdjoin, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.CompactSubgroupFiniteOpenCosets, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.FinrankAdjoinLeAdd, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.FinrankRangePowConvex, `Development.AbelianVarietyTheory.BlockTheory.AdelicCMFields.UnitaryHeckeCharacterIdele, `Development.AbelianVarietyTheory.BlockTheory.CMModuli.HostConjugateIdeal, `Development.AbelianVarietyTheory.BlockTheory.CMModuli.ProjectiveSpaceOverSpec, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.AdelicScalarMultiplier, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.IdeleNormTraceForm, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.MultiplicationKernelIdentity, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.OmegaFactorization, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.QuotientEigenDifference, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.TensorProductAction, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.TraceDualDifferent, `Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.InvariantRadonFibre, `Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.StabiliserCardinality, `Development.AbelianVarietyTheory.BlockTheory.HeightDefect.SchurLatticeConjugates, `Development.AbelianVarietyTheory.BlockTheory.HeightDefect.SphereBlockLogMean, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.BalancedHermitianSpace, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.DecreasingNodeGaps, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.HarishChandraParameters, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.IntegralPartDecomposition, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.NodalSeriesPeriods, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.RelativeDifferentValues, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.RootValueClassBasis, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.SplitUnramifiedPlaces, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.TraceFormDualSystem, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.HeckeFlatSpecialisation]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

