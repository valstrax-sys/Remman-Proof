import Lean
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.MultiplicityOne.HermitianMeasures.NHeisInt
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.MultiplicityOne.TransposeUnitary
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.IntegrableUnitIndicator
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.ScaleInt
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.TailInt
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.CoefAInnerEqZero
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.CoefCExpEntrySummable
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.GelfandSeries
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.MomentMatch
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.UnitarizeA
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TraceGap.TraceEqTraceRestrictOfRangeLe
import ReciprocityTheory.ReductiveGroups.ExtensionEmbeddings.ExtEmb
import ReciprocityTheory.ReductiveGroups.LatticeEmbeddings.IotaPlaceB
import ReciprocityTheory.ReductiveGroups.Lattices.LatUnrCharA
import ReciprocityTheory.ReductiveGroups.PlaceCounting.RaySplA
import ReciprocityTheory.ReductiveGroups.SymplecticTraces.WeylCharacters.AltBranchStatement
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.KapUnit
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.NormEqOfNormSubLt
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.RedPrime
import ReciprocityTheory.SemistableReduction.AlgebraicIndependentOfDerivations
import ReciprocityTheory.SemistableReduction.BWPolyA
import ReciprocityTheory.SemistableReduction.ComapInclusionIsLocalHom
import ReciprocityTheory.SemistableReduction.DetGramEqProdGramSchmidt
import ReciprocityTheory.SemistableReduction.GaussIndepOfLeTrdeg
import ReciprocityTheory.SemistableReduction.LogNormEvalZeroLeCircleAverage
import ReciprocityTheory.SemistableReduction.NormOrdLengthResidue
import ReciprocityTheory.SemistableReduction.SJCoreA
import ReciprocityTheory.SemistableReduction.SemiContractA
import ReciprocityTheory.SemistableReduction.SemiDegCA
import ReciprocityTheory.SemistableReduction.SphereLogIntegrableStatement
import ReciprocityTheory.SemistableReduction.TorsionNonvanishStatement
import ReciprocityTheory.SemistableReduction.TorusMeanA
import ReciprocityTheory.SemistableReduction.UnipotentA
import ReciprocityTheory.ThetaQuasiPeriods.PeriodLattice
import ReciprocityTheory.ThetaSummability.RealCoinvariants.GlRelZero
import ReciprocityTheory.ThetaSummability.RealCoinvariants.Numbers
import ReciprocityTheory.ThetaSummability.TailSumEstimates.ConeDefs
import ReciprocityTheory.ThetaSummability.TailSumEstimates.LatSumPi
import Statements

open Lean Elab Command

def auditTargets : Array Name := #[`ReciprocityTheory.ReductiveGroups.DiscreteSeries.MultiplicityOne.HermitianMeasures.NHeisInt, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.MultiplicityOne.TransposeUnitary, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.IntegrableUnitIndicator, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.ScaleInt, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.TailInt, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.CoefAInnerEqZero, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.CoefCExpEntrySummable, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.GelfandSeries, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.MomentMatch, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.UnitarizeA, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TraceGap.TraceEqTraceRestrictOfRangeLe, `ReciprocityTheory.ReductiveGroups.ExtensionEmbeddings.ExtEmb, `ReciprocityTheory.ReductiveGroups.LatticeEmbeddings.IotaPlaceB, `ReciprocityTheory.ReductiveGroups.Lattices.LatUnrCharA, `ReciprocityTheory.ReductiveGroups.PlaceCounting.RaySplA, `ReciprocityTheory.ReductiveGroups.SymplecticTraces.WeylCharacters.AltBranchStatement, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.KapUnit, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.NormEqOfNormSubLt, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.RedPrime, `ReciprocityTheory.SemistableReduction.AlgebraicIndependentOfDerivations, `ReciprocityTheory.SemistableReduction.BWPolyA, `ReciprocityTheory.SemistableReduction.ComapInclusionIsLocalHom, `ReciprocityTheory.SemistableReduction.DetGramEqProdGramSchmidt, `ReciprocityTheory.SemistableReduction.GaussIndepOfLeTrdeg, `ReciprocityTheory.SemistableReduction.LogNormEvalZeroLeCircleAverage, `ReciprocityTheory.SemistableReduction.NormOrdLengthResidue, `ReciprocityTheory.SemistableReduction.SJCoreA, `ReciprocityTheory.SemistableReduction.SemiContractA, `ReciprocityTheory.SemistableReduction.SemiDegCA, `ReciprocityTheory.SemistableReduction.SphereLogIntegrableStatement, `ReciprocityTheory.SemistableReduction.TorsionNonvanishStatement, `ReciprocityTheory.SemistableReduction.TorusMeanA, `ReciprocityTheory.SemistableReduction.UnipotentA, `ReciprocityTheory.ThetaQuasiPeriods.PeriodLattice, `ReciprocityTheory.ThetaSummability.RealCoinvariants.GlRelZero, `ReciprocityTheory.ThetaSummability.RealCoinvariants.Numbers, `ReciprocityTheory.ThetaSummability.TailSumEstimates.ConeDefs, `ReciprocityTheory.ThetaSummability.TailSumEstimates.LatSumPi, `Statements]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

