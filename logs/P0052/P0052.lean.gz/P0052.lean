import Lean
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraLast
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraMore
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraRest
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraSide
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraTail
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsFurther
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsFurtherBis
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsFurtherExtra
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsFurtherFurther
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsFurtherMore
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsFurtherSide
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsFurtherTer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsLast
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMore
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMoreFurther
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMoreLast
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMoreRest
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMoreSide
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMoreTail
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMoreTer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRest
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestBis
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestExtra
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestFurther
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestLast
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestMore
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestRest
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestSide
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestTail
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestTer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSide
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideBis
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideExtra
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideFurther
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideLast
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideMore
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideRest
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideSide
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideTail
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideTer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTail
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTailAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTailBis
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTailExtra
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTailFurther
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTailMore
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTailRest
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTailTer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerBis
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerLast
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerRest
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerSide
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerTail
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerTer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InPApplyEqZero
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InclR
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IndependenceCharacters
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IndependenceEigenvectors
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InfEmbUnique
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InfiniteNormOneElements

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraLast, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraMore, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraRest, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraSide, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraTail, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsFurther, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsFurtherBis, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsFurtherExtra, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsFurtherFurther, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsFurtherMore, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsFurtherSide, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsFurtherTer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsLast, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMore, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMoreFurther, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMoreLast, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMoreRest, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMoreSide, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMoreTail, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsMoreTer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRest, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestBis, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestExtra, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestFurther, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestLast, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestMore, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestRest, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestSide, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestTail, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsRestTer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSide, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideBis, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideExtra, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideFurther, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideLast, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideMore, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideRest, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideSide, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideTail, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsSideTer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTail, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTailAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTailBis, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTailExtra, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTailFurther, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTailMore, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTailRest, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTailTer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerBis, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerLast, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerRest, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerSide, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerTail, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsTerTer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InPApplyEqZero, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InclR, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IndependenceCharacters, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IndependenceEigenvectors, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InfEmbUnique, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InfiniteNormOneElements]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

