import Lean
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PadicChangeOfVariables
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PairingTriangular
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PeriodLatticeFactsSplitOfGeneral
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PhaseFunctionDerivatives
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PolynomialTheoremsAssembly
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PositionInsertionDiagonalCompat
import Formalism.HermitianCurvature.HermitianCurvatureProofs.RootPushforwardDensity
import Formalism.HermitianCurvature.HermitianCurvatureProofs.SecondEmbedMulFirstEmbedApply
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ShiftBound
import Formalism.HermitianCurvature.HermitianCurvatureProofs.SplitPrimeToDifferent
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ThetaAtBasePointZero
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ThetaLimit
import Formalism.HermitianCurvature.HermitianCurvatureProofs.TwistedIsRealOrderLattice
import Formalism.HermitianCurvature.PositionExpansionTopCoefficients
import Formalism.HermitianCurvature.StatementFr
import Formalism.HermitianCurvature.StatementJ
import Formalism.HermitianLattices.GenusCovolBound
import Formalism.HermitianLattices.HermitianLatticesProofs.DualLattice
import Formalism.HermitianLattices.HermitianLatticesProofs.DualOrthSum
import Formalism.HermitianLattices.HermitianLatticesProofs.FinIntermediate
import Formalism.HermitianLattices.HermitianLatticesProofs.GenusBasic
import Formalism.HermitianLattices.HermitianLatticesProofs.IndexBasic
import Formalism.HermitianLattices.HermitianLatticesProofs.IsomOfTrace
import Formalism.HermitianLattices.HermitianLatticesProofs.LocDual
import Formalism.HermitianLattices.HermitianLatticesProofs.NeighbourBasic
import Formalism.HermitianLattices.HermitianLatticesProofs.ShortVectors
import Formalism.HermitianLattices.HermitianLatticesProofs.ThetaBasic
import Formalism.HermitianLattices.HermitianLatticesProofs.ThetaSummable
import Formalism.HermitianLattices.StatementMaj
import Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.SesquilinearDeterminantHolds
import Formalism.IncomingBounds.FlowDegreeBounds.ThmPExp
import Formalism.IncomingBounds.FlowDegreeBounds.ThmPJet
import Formalism.IncomingBounds.WeightIdentities
import Formalism.JumpKernelCokernel.JumpShiftProofs.CokerTors
import Formalism.JumpKernelCokernel.JumpShiftProofs.ExpRowD
import Formalism.JumpKernelCokernel.JumpShiftProofs.LemmaDJoint
import Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.EulerFactorLogDerivBound
import Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.LocalZerosOf
import Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.NoZeroComplexOf
import Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.Positivity
import Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.RealLargeTOf
import Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.RealSmallTOf
import Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.TrivReal
import Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.TwoRealOf
import Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.ZFRDirichletOf
import Formalism.LatticeSlopes.LatticeSlopesProofs.FiniteSaturated
import Formalism.LatticeTheta.LatticeThetaProofs.LatticeFourierSeries
import Formalism.LocalRingCardinality.SpanPowerMembership.NDLocA
import Formalism.LocalToGlobal.CMDeterminantIdeals.CMIdealValuations.ExistsEvalNeZeroOfTotalDegreeLt
import Formalism.LocalToGlobal.CMDeterminantIdeals.CMIdealValuations.ExistsMonicIrreducibleCardGt
import Formalism.LocalToGlobal.CMDeterminantIdeals.CMIdealValuations.FiniteDetAddSmulOneEqZero
import Formalism.LocalToGlobal.CMDeterminantIdeals.CMIdealValuations.OneLeAbsNormOfLeOne
import Formalism.LocalToGlobal.CMDeterminantIdeals.CMIdealValuations.ProdMulLeDetIdeal
import Formalism.LocalToGlobal.CMDeterminantIdeals.CoeffMemOfLoc
import Formalism.LocalToGlobal.CharacterGerms.BiadditiveInSingleVariables
import Formalism.LocalToGlobal.CyclotomicLocalNorms.NormSubToZModPowVal
import Formalism.LocalToGlobal.GaloisLevelStructure.DefsAut
import Formalism.LocalToGlobal.GlobalTheory.BlockActions.InclEMemTensInt
import Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.SingleMemLam
import Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.SingleMemOrb
import Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.DifferentIdeal.FractionalIdealDualFamily
import Formalism.LocalToGlobal.GroupLattices.LevelCharts.AtGLev
import Formalism.LocalToGlobal.IndefiniteReal.FinitePlaces.SmulFinsum
import Formalism.LocalToGlobal.IndefiniteReal.HaarTransfer.MinfUniqueP

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.HermitianCurvature.HermitianCurvatureProofs.PadicChangeOfVariables, `Formalism.HermitianCurvature.HermitianCurvatureProofs.PairingTriangular, `Formalism.HermitianCurvature.HermitianCurvatureProofs.PeriodLatticeFactsSplitOfGeneral, `Formalism.HermitianCurvature.HermitianCurvatureProofs.PhaseFunctionDerivatives, `Formalism.HermitianCurvature.HermitianCurvatureProofs.PolynomialTheoremsAssembly, `Formalism.HermitianCurvature.HermitianCurvatureProofs.PositionInsertionDiagonalCompat, `Formalism.HermitianCurvature.HermitianCurvatureProofs.RootPushforwardDensity, `Formalism.HermitianCurvature.HermitianCurvatureProofs.SecondEmbedMulFirstEmbedApply, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ShiftBound, `Formalism.HermitianCurvature.HermitianCurvatureProofs.SplitPrimeToDifferent, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ThetaAtBasePointZero, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ThetaLimit, `Formalism.HermitianCurvature.HermitianCurvatureProofs.TwistedIsRealOrderLattice, `Formalism.HermitianCurvature.PositionExpansionTopCoefficients, `Formalism.HermitianCurvature.StatementFr, `Formalism.HermitianCurvature.StatementJ, `Formalism.HermitianLattices.GenusCovolBound, `Formalism.HermitianLattices.HermitianLatticesProofs.DualLattice, `Formalism.HermitianLattices.HermitianLatticesProofs.DualOrthSum, `Formalism.HermitianLattices.HermitianLatticesProofs.FinIntermediate, `Formalism.HermitianLattices.HermitianLatticesProofs.GenusBasic, `Formalism.HermitianLattices.HermitianLatticesProofs.IndexBasic, `Formalism.HermitianLattices.HermitianLatticesProofs.IsomOfTrace, `Formalism.HermitianLattices.HermitianLatticesProofs.LocDual, `Formalism.HermitianLattices.HermitianLatticesProofs.NeighbourBasic, `Formalism.HermitianLattices.HermitianLatticesProofs.ShortVectors, `Formalism.HermitianLattices.HermitianLatticesProofs.ThetaBasic, `Formalism.HermitianLattices.HermitianLatticesProofs.ThetaSummable, `Formalism.HermitianLattices.StatementMaj, `Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.SesquilinearDeterminantHolds, `Formalism.IncomingBounds.FlowDegreeBounds.ThmPExp, `Formalism.IncomingBounds.FlowDegreeBounds.ThmPJet, `Formalism.IncomingBounds.WeightIdentities, `Formalism.JumpKernelCokernel.JumpShiftProofs.CokerTors, `Formalism.JumpKernelCokernel.JumpShiftProofs.ExpRowD, `Formalism.JumpKernelCokernel.JumpShiftProofs.LemmaDJoint, `Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.EulerFactorLogDerivBound, `Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.LocalZerosOf, `Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.NoZeroComplexOf, `Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.Positivity, `Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.RealLargeTOf, `Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.RealSmallTOf, `Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.TrivReal, `Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.TwoRealOf, `Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.ZFRDirichletOf, `Formalism.LatticeSlopes.LatticeSlopesProofs.FiniteSaturated, `Formalism.LatticeTheta.LatticeThetaProofs.LatticeFourierSeries, `Formalism.LocalRingCardinality.SpanPowerMembership.NDLocA, `Formalism.LocalToGlobal.CMDeterminantIdeals.CMIdealValuations.ExistsEvalNeZeroOfTotalDegreeLt, `Formalism.LocalToGlobal.CMDeterminantIdeals.CMIdealValuations.ExistsMonicIrreducibleCardGt, `Formalism.LocalToGlobal.CMDeterminantIdeals.CMIdealValuations.FiniteDetAddSmulOneEqZero, `Formalism.LocalToGlobal.CMDeterminantIdeals.CMIdealValuations.OneLeAbsNormOfLeOne, `Formalism.LocalToGlobal.CMDeterminantIdeals.CMIdealValuations.ProdMulLeDetIdeal, `Formalism.LocalToGlobal.CMDeterminantIdeals.CoeffMemOfLoc, `Formalism.LocalToGlobal.CharacterGerms.BiadditiveInSingleVariables, `Formalism.LocalToGlobal.CyclotomicLocalNorms.NormSubToZModPowVal, `Formalism.LocalToGlobal.GaloisLevelStructure.DefsAut, `Formalism.LocalToGlobal.GlobalTheory.BlockActions.InclEMemTensInt, `Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.SingleMemLam, `Formalism.LocalToGlobal.GlobalTheory.GL1.CompactFixesLattice.SingleMemOrb, `Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.DifferentIdeal.FractionalIdealDualFamily, `Formalism.LocalToGlobal.GroupLattices.LevelCharts.AtGLev, `Formalism.LocalToGlobal.IndefiniteReal.FinitePlaces.SmulFinsum, `Formalism.LocalToGlobal.IndefiniteReal.HaarTransfer.MinfUniqueP]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

