import Lean
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DegreeAdditiveSubQuotient
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.EigSubEqDifferentSmulEigQuot
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsIntegralPosDefPerturbation
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FiniteFlatSubgroupScheme
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.GenerationAlongInvariants
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderContainsAddCharacters
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderInductionIdStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderScalarExtensionStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.Imports
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LatticeGoodBaseChange
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LinearIndependentMapVec
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeTestPointMembershipStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.MemFirstLatticeIff
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.NegDefBlockOfPosDefStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.StableHopfOrderFundamentalCharacter
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.StableHopfOrderSubgroupLength
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.TrivialPolarizedAbelianPointEqOne
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.UltrametricDetNormStableStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AnnihilatorOpenCompactStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ArchimedeanFundamentalDomainIntegers
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.BoundedCokernelLimitToLevel
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.BruhatDecompositionTwoBlocks
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.BruhatDecompositionUnique
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardHermitianMatricesModPowStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardParabolicSubgroup
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardRangeMulQuotientBoundedLevelStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CentralIdempotentAction
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ColGeR
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CompactnessStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetCongruenceRefinement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetEmptyPlacesLattice
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetUnitIdealIntegral
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CuspidalIsomorphismProperties
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CuspidalOfUnipotentSumsVanish
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CuspidalVanishing
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DeterminantMonotonicityStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DisintegrationHaarBase
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EtaleSurjectiveLocalSectionStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EulerProductConvergenceBound
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EventuallyActMemLatVIff
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCharacterSeparatingLatticeStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsIntegralMultipleBoundedPlaces
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsUnitaryInterlacingRealization
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteLengthOfLseqFirstStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteProductDifferenceBound
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteProjectionPushforwardStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FlatBaseChangeLimitSystem
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FractionFieldTranscendenceBasisExtStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FrobeniusReciprocityInnerProduct
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GalleryOfTubesAndCrossingStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussSumHermitianNormLevelOneStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussSumHermitianNormLevelShiftStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussianDetLeviIntegral
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GoodWordCount
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HaarRinvUJ
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HeckeAlgebraStructure
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianCharacterOrthogonalityStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianMatrixDiagonalizableStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianVectorValuesCardStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HuaDeterminantIntegrableOfLtStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IntertwinerInnerProduct
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InverseTransformLocallyBoundedStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InverseTransformRecoversFunctionStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IrreducibleHomFixedVectorsStatement

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DegreeAdditiveSubQuotient, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.EigSubEqDifferentSmulEigQuot, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsIntegralPosDefPerturbation, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FiniteFlatSubgroupScheme, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.GenerationAlongInvariants, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderContainsAddCharacters, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderInductionIdStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.HopfOrderScalarExtensionStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.Imports, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LatticeGoodBaseChange, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LinearIndependentMapVec, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocallyFreeTestPointMembershipStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.MemFirstLatticeIff, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.NegDefBlockOfPosDefStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.StableHopfOrderFundamentalCharacter, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.StableHopfOrderSubgroupLength, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.TrivialPolarizedAbelianPointEqOne, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.UltrametricDetNormStableStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AnnihilatorOpenCompactStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ArchimedeanFundamentalDomainIntegers, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.BoundedCokernelLimitToLevel, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.BruhatDecompositionTwoBlocks, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.BruhatDecompositionUnique, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardHermitianMatricesModPowStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardParabolicSubgroup, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardRangeMulQuotientBoundedLevelStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CentralIdempotentAction, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ColGeR, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CompactnessStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetCongruenceRefinement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetEmptyPlacesLattice, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetUnitIdealIntegral, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CuspidalIsomorphismProperties, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CuspidalOfUnipotentSumsVanish, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CuspidalVanishing, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DeterminantMonotonicityStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DisintegrationHaarBase, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EtaleSurjectiveLocalSectionStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EulerProductConvergenceBound, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EventuallyActMemLatVIff, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCharacterSeparatingLatticeStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsIntegralMultipleBoundedPlaces, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsUnitaryInterlacingRealization, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteLengthOfLseqFirstStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteProductDifferenceBound, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteProjectionPushforwardStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FlatBaseChangeLimitSystem, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FractionFieldTranscendenceBasisExtStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FrobeniusReciprocityInnerProduct, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GalleryOfTubesAndCrossingStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussSumHermitianNormLevelOneStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussSumHermitianNormLevelShiftStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussianDetLeviIntegral, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GoodWordCount, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HaarRinvUJ, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HeckeAlgebraStructure, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianCharacterOrthogonalityStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianMatrixDiagonalizableStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianVectorValuesCardStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HuaDeterminantIntegrableOfLtStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IntertwinerInnerProduct, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InverseTransformLocallyBoundedStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InverseTransformRecoversFunctionStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IrreducibleHomFixedVectorsStatement]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

