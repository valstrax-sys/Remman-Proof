import Lean
import Formalism.MahlerMeasure.MahlerMeasureProofs.GaussRad
import Formalism.MahlerMeasure.MahlerMeasureProofs.MahlerK
import Formalism.MahlerMeasure.MahlerMeasureProofs.PhiInt
import Formalism.MahlerMeasure.MahlerMeasureProofs.RemoveS
import Formalism.MahlerMeasure.QuotientUpperBoundsOfPowerBounds
import Formalism.MahlerMeasure.StatementE
import Formalism.MeanHeightDescent.AverageDegreeBounds.SumComponents
import Formalism.MoebiusJetDuality.EvDualJet
import Formalism.NormUnitaryBounds.DetPolynomialWeights.ExistsNeZeroNormLeRankDivOfDualMinimum
import Formalism.PadicSubsetSums.CentralIdempotents.StretchedExponentialDominance
import Formalism.PadicSubsetSums.StableGradedCounts.BaseChangeIwahoriFactorization
import Formalism.PadicSubsetSums.StableGradedCounts.CentralIdempotentsSumOne
import Formalism.PadicSubsetSums.StableGradedCounts.ConcreteDictionaryHolds
import Formalism.PadicSubsetSums.StableGradedCounts.DegreeOneSplit
import Formalism.PadicSubsetSums.StableGradedCounts.ExistsNeZeroAevalEqZero
import Formalism.PadicSubsetSums.StableGradedCounts.FixedByAutomorphismInField
import Formalism.PadicSubsetSums.StableGradedCounts.FourMulSumLeProduct
import Formalism.PadicSubsetSums.StableGradedCounts.IRRCentralIdemOrthogonal
import Formalism.PadicSubsetSums.StableGradedCounts.IRRCycleProbSum
import Formalism.PadicSubsetSums.StableGradedCounts.IRRPrimeToPartEqIff
import Formalism.PadicSubsetSums.StableGradedCounts.IRRSquarefreeCount
import Formalism.PadicSubsetSums.StableGradedCounts.IRRTypeCountExact
import Formalism.PadicSubsetSums.StableGradedCounts.ProdPowFactorizationLe
import Formalism.PadicSubsetSums.StableGradedCounts.TWBoundedSeriesIntegral
import Formalism.PadicSubsetSums.StableGradedCounts.TWCentralIdempotentIntegral
import Formalism.PadicSubsetSums.StableGradedCounts.TWHeckeDetFactors
import Formalism.PadicSubsetSums.StableGradedCounts.TWIndexAdditive
import Formalism.PadicSubsetSums.StableGradedCounts.TWLengthBaseChange
import Formalism.PadicSubsetSums.StableGradedCounts.TWUnitBallLattice
import Formalism.PeriodIntegrals.AlgebraMapMemO
import Formalism.PeriodIntegrals.BordDefs
import Formalism.PeriodIntegrals.DatumBlockEigen
import Formalism.PeriodIntegrals.DatumConjInv
import Formalism.PeriodIntegrals.GaugeGap
import Formalism.PeriodIntegrals.HaarDefs
import Formalism.PeriodIntegrals.HermitianGenusExtension.SemilocalHermitianLattices.ExistsIsomFix
import Formalism.PeriodIntegrals.LatIdxDet
import Formalism.PeriodIntegrals.LocDensCorank
import Formalism.PeriodIntegrals.LocDualGen
import Formalism.PeriodIntegrals.LocHaarRR
import Formalism.PeriodIntegrals.LocHerm
import Formalism.PeriodIntegrals.LocLatEq
import Formalism.PeriodIntegrals.LocLatSat
import Formalism.PeriodIntegrals.LocProdFormula
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.AreaLat
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.BeDiagZp
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.CommMult
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.CubeRelationOfParallelogram
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DvFormEq
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FglPtW
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FiltLenF
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FlagGramNonneg
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FockRaiseLow
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.GelfSpan
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KerSplit
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.LocFramePrim
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PhConvProj
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PowBddInt
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PrimeLogOverP
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.QuotInv
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.QuotMeasUniq
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.RowLetter
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SimeqPdInt
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SmithMat

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.MahlerMeasure.MahlerMeasureProofs.GaussRad, `Formalism.MahlerMeasure.MahlerMeasureProofs.MahlerK, `Formalism.MahlerMeasure.MahlerMeasureProofs.PhiInt, `Formalism.MahlerMeasure.MahlerMeasureProofs.RemoveS, `Formalism.MahlerMeasure.QuotientUpperBoundsOfPowerBounds, `Formalism.MahlerMeasure.StatementE, `Formalism.MeanHeightDescent.AverageDegreeBounds.SumComponents, `Formalism.MoebiusJetDuality.EvDualJet, `Formalism.NormUnitaryBounds.DetPolynomialWeights.ExistsNeZeroNormLeRankDivOfDualMinimum, `Formalism.PadicSubsetSums.CentralIdempotents.StretchedExponentialDominance, `Formalism.PadicSubsetSums.StableGradedCounts.BaseChangeIwahoriFactorization, `Formalism.PadicSubsetSums.StableGradedCounts.CentralIdempotentsSumOne, `Formalism.PadicSubsetSums.StableGradedCounts.ConcreteDictionaryHolds, `Formalism.PadicSubsetSums.StableGradedCounts.DegreeOneSplit, `Formalism.PadicSubsetSums.StableGradedCounts.ExistsNeZeroAevalEqZero, `Formalism.PadicSubsetSums.StableGradedCounts.FixedByAutomorphismInField, `Formalism.PadicSubsetSums.StableGradedCounts.FourMulSumLeProduct, `Formalism.PadicSubsetSums.StableGradedCounts.IRRCentralIdemOrthogonal, `Formalism.PadicSubsetSums.StableGradedCounts.IRRCycleProbSum, `Formalism.PadicSubsetSums.StableGradedCounts.IRRPrimeToPartEqIff, `Formalism.PadicSubsetSums.StableGradedCounts.IRRSquarefreeCount, `Formalism.PadicSubsetSums.StableGradedCounts.IRRTypeCountExact, `Formalism.PadicSubsetSums.StableGradedCounts.ProdPowFactorizationLe, `Formalism.PadicSubsetSums.StableGradedCounts.TWBoundedSeriesIntegral, `Formalism.PadicSubsetSums.StableGradedCounts.TWCentralIdempotentIntegral, `Formalism.PadicSubsetSums.StableGradedCounts.TWHeckeDetFactors, `Formalism.PadicSubsetSums.StableGradedCounts.TWIndexAdditive, `Formalism.PadicSubsetSums.StableGradedCounts.TWLengthBaseChange, `Formalism.PadicSubsetSums.StableGradedCounts.TWUnitBallLattice, `Formalism.PeriodIntegrals.AlgebraMapMemO, `Formalism.PeriodIntegrals.BordDefs, `Formalism.PeriodIntegrals.DatumBlockEigen, `Formalism.PeriodIntegrals.DatumConjInv, `Formalism.PeriodIntegrals.GaugeGap, `Formalism.PeriodIntegrals.HaarDefs, `Formalism.PeriodIntegrals.HermitianGenusExtension.SemilocalHermitianLattices.ExistsIsomFix, `Formalism.PeriodIntegrals.LatIdxDet, `Formalism.PeriodIntegrals.LocDensCorank, `Formalism.PeriodIntegrals.LocDualGen, `Formalism.PeriodIntegrals.LocHaarRR, `Formalism.PeriodIntegrals.LocHerm, `Formalism.PeriodIntegrals.LocLatEq, `Formalism.PeriodIntegrals.LocLatSat, `Formalism.PeriodIntegrals.LocProdFormula, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.AreaLat, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.BeDiagZp, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.CommMult, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.CubeRelationOfParallelogram, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DvFormEq, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FglPtW, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FiltLenF, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FlagGramNonneg, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FockRaiseLow, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.GelfSpan, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KerSplit, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.LocFramePrim, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PhConvProj, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PowBddInt, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PrimeLogOverP, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.QuotInv, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.QuotMeasUniq, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.RowLetter, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SimeqPdInt, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SmithMat]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

