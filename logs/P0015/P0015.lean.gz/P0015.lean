import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherFurther
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherLast
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherMore
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherRest
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherSide
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherTail
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherTer
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsLastRest
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreAlt
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreBis
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreExtra
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreFurther
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreLast
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreMore
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreRest
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreSide
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreTail
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreTer
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerAlt
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerBis
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerFurther
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerLast
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerMore
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerRest
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerTail
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerTer
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IndEtaleIncomparability
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InertiaDegBotEqFinrankFiniteDomain
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InfSupPowEqOfTorsionArtinRees
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InjectiveCotangentComplexBaseChangeOfFormsExtend
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InjectiveMulVecMapBasis
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InjectiveOfMapPderivEqAndMapOneNeZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InstPreorder
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegrableSqPowMulIteratedFDerivSchwartz
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralBasisChangeDeterminant
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralCoefficients
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralDoubleSeriesInterchange
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralFlagLiftOfResidue
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralFundamentalDomainEqSum
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralHasSumEqIntegralIndicatorHasSum
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralMemFinDimSpace
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralMulConvolutionEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralPiecewiseConstant
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralRowSpaceBasisExists
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegrallyClosedFiniteDedekindClassFinite
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntertwinerNonzeroRestriction
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvDer
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvEntryDifferentiableAt
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvFiveLogLeSumInvPrimes
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvMemConnectedComponentInFibre
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvariantMeasurableModification
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InverseMapCoordDerivativeNeZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvolutionNormClassRemoveRationalFactor
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IrreducibleDvdOfDvdCharpolyOfAevalMatrix
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IrreducibleXSqAddOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAdicCompleteOfLeOfIsNoetherianRing
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAdicCompleteSpanNatCastFiniteProjectiveAlgebra
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAffineOpenInfOfSeparatedOverAffineOpen
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAlgebraicInt
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAlgebraicOfFiniteTypeOfComapEqBot
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAlgebraicOfSubringIsAlgebraic
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsArtinianRingKummerAdjoinRootQuotientRoot
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAut
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsClopenBasicOpenSpecProdSelfFirstIdempotent

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherFurther, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherLast, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherMore, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherRest, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherSide, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherTail, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherTer, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsLastRest, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreAlt, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreBis, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreExtra, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreFurther, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreLast, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreMore, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreRest, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreSide, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreTail, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsMoreTer, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerAlt, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerBis, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerFurther, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerLast, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerMore, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerRest, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerTail, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsTerTer, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IndEtaleIncomparability, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InertiaDegBotEqFinrankFiniteDomain, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InfSupPowEqOfTorsionArtinRees, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InjectiveCotangentComplexBaseChangeOfFormsExtend, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InjectiveMulVecMapBasis, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InjectiveOfMapPderivEqAndMapOneNeZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InstPreorder, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegrableSqPowMulIteratedFDerivSchwartz, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralBasisChangeDeterminant, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralCoefficients, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralDoubleSeriesInterchange, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralFlagLiftOfResidue, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralFundamentalDomainEqSum, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralHasSumEqIntegralIndicatorHasSum, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralMemFinDimSpace, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralMulConvolutionEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralPiecewiseConstant, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralRowSpaceBasisExists, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegrallyClosedFiniteDedekindClassFinite, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntertwinerNonzeroRestriction, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvDer, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvEntryDifferentiableAt, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvFiveLogLeSumInvPrimes, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvMemConnectedComponentInFibre, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvariantMeasurableModification, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InverseMapCoordDerivativeNeZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvolutionNormClassRemoveRationalFactor, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IrreducibleDvdOfDvdCharpolyOfAevalMatrix, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IrreducibleXSqAddOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAdicCompleteOfLeOfIsNoetherianRing, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAdicCompleteSpanNatCastFiniteProjectiveAlgebra, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAffineOpenInfOfSeparatedOverAffineOpen, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAlgebraicInt, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAlgebraicOfFiniteTypeOfComapEqBot, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAlgebraicOfSubringIsAlgebraic, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsArtinianRingKummerAdjoinRootQuotientRoot, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAut, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsClopenBasicOpenSpecProdSelfFirstIdempotent]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

