import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.FundamentalDomainUnfoldSubgroup
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.FundamentalSequenceContinuityAll
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.GaloisOfFiniteGeneratingAutomorphisms
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.GammaRealFunctionalEquationConstantEvenInteger
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.GaussUnitsNormSq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.GeneratorMinpolyEigenvalueCompat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.GeometricSeriesMultiIndex
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.GlAdicCompletionEntriesBoundedOfIsCompact
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.GlueFlatOverPullbackOfSubsingleton
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.Glues
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.GramDetChangeOfBases
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.GramDetNeZeroOfKerOrth
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.GramFiberMeasuresUniqueAe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.GramPosSemidefOfIntForm
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HPolyAddTwo
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HTChartExistsHolds
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HaarLintegralMulRightLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HaarMeasureProductGroups
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasConstTermConst
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasDerivAtIntegralDominatedFamily
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasDerivAtLinearMapEvalAlgebraMap
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasDerivAtOfContinuousOfMapAdd
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasSumConjClassesRegroupWithInvariantSelection
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasTemperateGrowthElim
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasTemperateGrowthProdMkConst
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HenselianLocalRingOfIsAlgClosed
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianEndoMatrixRationalInLatticeBasis
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianFlagComplementPosDefFactorization
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianFlagUnipotentMatrixExistsSparse
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianFormEqCombinationOfSelfAdjointIdentity
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianLocalContinuousCongruenceSection
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianNormTriangleInequality
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianSimilitudeEntrySqBound
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianSpectralPartsAnticommute
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HfMulVecMulVec
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HilbertSamuelALogALe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HodgeProjectionEigenvalueCompat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HodgeProjectionFromLattice
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HolomorphicLogOnConvex
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HolomorphicParamIntegral
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HolomorphicParameterIntegral
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HomogeneousComponentsOfConeIntegralEquation
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HypersurfaceDiffIsPreirreducibleOfNoSplitting
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IInfSupPowEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ISupStableInfTypeSpace
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdealNormEquationFromLocalAssociates
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdealSheafDataComapIdealTopOfIsAffine
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdealSheafGlueOfOpenImmersions
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdempotentEqOfBasicOpenEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdempotentTriangularDecomposition
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdentityAsSumExpMinusOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsAlt
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsBisLast
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsBisRest
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsBisSide
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsBisTail
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsExtraAlt
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsExtraBis
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsExtraLast
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsExtraMore
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsExtraSide
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherAlt
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherBis
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherExtra

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.FundamentalDomainUnfoldSubgroup, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.FundamentalSequenceContinuityAll, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.GaloisOfFiniteGeneratingAutomorphisms, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.GammaRealFunctionalEquationConstantEvenInteger, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.GaussUnitsNormSq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.GeneratorMinpolyEigenvalueCompat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.GeometricSeriesMultiIndex, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.GlAdicCompletionEntriesBoundedOfIsCompact, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.GlueFlatOverPullbackOfSubsingleton, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.Glues, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.GramDetChangeOfBases, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.GramDetNeZeroOfKerOrth, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.GramFiberMeasuresUniqueAe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.GramPosSemidefOfIntForm, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HPolyAddTwo, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HTChartExistsHolds, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HaarLintegralMulRightLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HaarMeasureProductGroups, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasConstTermConst, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasDerivAtIntegralDominatedFamily, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasDerivAtLinearMapEvalAlgebraMap, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasDerivAtOfContinuousOfMapAdd, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasSumConjClassesRegroupWithInvariantSelection, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasTemperateGrowthElim, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasTemperateGrowthProdMkConst, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HenselianLocalRingOfIsAlgClosed, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianEndoMatrixRationalInLatticeBasis, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianFlagComplementPosDefFactorization, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianFlagUnipotentMatrixExistsSparse, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianFormEqCombinationOfSelfAdjointIdentity, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianLocalContinuousCongruenceSection, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianNormTriangleInequality, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianSimilitudeEntrySqBound, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianSpectralPartsAnticommute, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HfMulVecMulVec, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HilbertSamuelALogALe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HodgeProjectionEigenvalueCompat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HodgeProjectionFromLattice, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HolomorphicLogOnConvex, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HolomorphicParamIntegral, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HolomorphicParameterIntegral, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HomogeneousComponentsOfConeIntegralEquation, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HypersurfaceDiffIsPreirreducibleOfNoSplitting, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IInfSupPowEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ISupStableInfTypeSpace, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdealNormEquationFromLocalAssociates, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdealSheafDataComapIdealTopOfIsAffine, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdealSheafGlueOfOpenImmersions, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdempotentEqOfBasicOpenEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdempotentTriangularDecomposition, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdentityAsSumExpMinusOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsAlt, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsBisLast, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsBisRest, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsBisSide, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsBisTail, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsExtraAlt, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsExtraBis, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsExtraLast, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsExtraMore, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsExtraSide, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherAlt, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherBis, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsFurtherExtra]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

