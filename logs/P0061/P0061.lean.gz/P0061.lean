import Lean
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FourierInversionFiniteDim
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FourierInversionInvariantMatrix
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FourierOneParameterIntegral
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FourierParameterDerivative
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FourierTransformMatrixSpaceInvolution
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FundamentalDomainFourierUnfolding
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FundamentalDomainIntegralCountBound
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussianIntegrableFiniteDim
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HaarMeasureSplitExactSequence
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HaarMeasureSubgroupRelIndexMul
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HasDerivAtEvalCurveOfDerivation
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HasDerivAtOfContinuousHom
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HasProdMoebiusConvOfNormLe
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HasSumTaylorOfExpBounds
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianPsdIsotropicRadical
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianSemidefiniteNullRadical
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InducedGeneratedByKFinite
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IntegerCoordinatesBound
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IntegrableExpNegSumAbs
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IntegrableOfMulUnimodular
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IntegralAddRightMulChar
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InvariantFunctionalOpenStabilizer
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsAdicCompleteOfPowSmulEqZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsCompactOperatorOfScaledIsometricIntertwiner
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsCompactSupAddSubgroup
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsFieldIdemOne
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsFractionRingInteger
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsIntegrallyClosedOfReducedQuotientLocalization
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsOpenAdditiveCharacterKernel
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IteratedDerivEqOfEqOnRealSegment
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IteratedFDerivSubApply
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IwasawaUnitaryUpperTriangular
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.KaehlerPushoutSplit
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.KernelBaseChangeTowerEquiv
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.KernelFreeAtPrimesOfConstantRank
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeAnnihilatorWithinNhds
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LaurentPartialDerivationUnique
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LeOneOfPowerBounds
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LieAlgebraFunctionCalculus
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LieAlgebraStarClosedBracket
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LinearMapZeroOfInjectiveFullRank
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralUniformNearParameter
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalContinuousSectionVecMulOrbit
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalFactorisationHolomorphic
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalFreeKernelSplitting
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalSplittingKernelBaseChange
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalUniqueSquareRootNearOne
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocallyConstantSeparatingSubalgebra
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LowerLeftBlock
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LtOneOfPowerBound
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MapInjectiveOfInjective
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ModularCharacterFunEqOfMapLeftMul
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MonicFactorCoefficientsIntegral
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicativeCharacterOnCone
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultisetAntitoneEnumeration
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NonZeroDivisorOfDenseOfStrict
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormPowLeOfEigenvaluesLt
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NotMemLpOfGrowth
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PolynomialTimesGaussianBounded
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdEntrywiseLe
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdLeRevEqProdGe
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdRelIndexNeZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProductNeighbourhoodsShrinkCompactOpen
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProductSubsetSumVanishes

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FourierInversionFiniteDim, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FourierInversionInvariantMatrix, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FourierOneParameterIntegral, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FourierParameterDerivative, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FourierTransformMatrixSpaceInvolution, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FundamentalDomainFourierUnfolding, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FundamentalDomainIntegralCountBound, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussianIntegrableFiniteDim, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HaarMeasureSplitExactSequence, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HaarMeasureSubgroupRelIndexMul, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HasDerivAtEvalCurveOfDerivation, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HasDerivAtOfContinuousHom, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HasProdMoebiusConvOfNormLe, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HasSumTaylorOfExpBounds, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianPsdIsotropicRadical, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianSemidefiniteNullRadical, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InducedGeneratedByKFinite, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IntegerCoordinatesBound, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IntegrableExpNegSumAbs, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IntegrableOfMulUnimodular, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IntegralAddRightMulChar, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InvariantFunctionalOpenStabilizer, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsAdicCompleteOfPowSmulEqZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsCompactOperatorOfScaledIsometricIntertwiner, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsCompactSupAddSubgroup, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsFieldIdemOne, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsFractionRingInteger, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsIntegrallyClosedOfReducedQuotientLocalization, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsOpenAdditiveCharacterKernel, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IteratedDerivEqOfEqOnRealSegment, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IteratedFDerivSubApply, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IwasawaUnitaryUpperTriangular, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.KaehlerPushoutSplit, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.KernelBaseChangeTowerEquiv, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.KernelFreeAtPrimesOfConstantRank, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeAnnihilatorWithinNhds, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LaurentPartialDerivationUnique, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LeOneOfPowerBounds, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LieAlgebraFunctionCalculus, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LieAlgebraStarClosedBracket, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LinearMapZeroOfInjectiveFullRank, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralUniformNearParameter, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalContinuousSectionVecMulOrbit, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalFactorisationHolomorphic, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalFreeKernelSplitting, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalSplittingKernelBaseChange, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalUniqueSquareRootNearOne, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocallyConstantSeparatingSubalgebra, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LowerLeftBlock, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LtOneOfPowerBound, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MapInjectiveOfInjective, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ModularCharacterFunEqOfMapLeftMul, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MonicFactorCoefficientsIntegral, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultiplicativeCharacterOnCone, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MultisetAntitoneEnumeration, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NonZeroDivisorOfDenseOfStrict, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormPowLeOfEigenvaluesLt, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NotMemLpOfGrowth, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PolynomialTimesGaussianBounded, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdEntrywiseLe, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdLeRevEqProdGe, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProdRelIndexNeZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProductNeighbourhoodsShrinkCompactOpen, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ProductSubsetSumVanishes]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

