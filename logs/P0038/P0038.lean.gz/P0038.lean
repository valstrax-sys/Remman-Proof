import Lean
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.SurjectiveOfKerLeMapSupSq
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.TendstoIntegralInnerOfTendstoELpNormTwo
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.UnitsZpowSurjective
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.VecPolyMemSpanValues
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.AnalyticAtEntry
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.DetBicharacterPowFour
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.DetUpdateRowAlternatingMulVecMem
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.DvdMulOfIdem
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.DvdTraceOfBalancedTensor
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.EntireAntilinearLatticePeriodsConst
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.ExistsCommonAlgClosedExtension
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.ExistsEqNsmulOfForallDvdOfBijective
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.ExistsIsClopenEqualizer
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.ExistsSmoothPeriodicPartitionOfUnity
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.ExistsUniformRegularityBound
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.Imports
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.IntOfPrimeMulSq
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.MemMapKerOfOneTmulEqZeroOfFlat
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.MvPolynomialMapMaximalIdealIsPrime
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.MvPowerSeriesVariablesSyzygySocle
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.NormCardQuotientSpan
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.RelProdPow
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.SetIntegralFderivEqZeroOfLatticePeriodic
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.TendstoOfSandwich
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.TracePowerSumModEq
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.ValuationRingOfFlatOfFormallyUnramified
import Development.AbelianVarietyTheory.Proofs.RingsOfIntegers.ExistsLeastOfDiscrete
import Development.AbelianVarietyTheory.Proofs.RingsOfIntegers.ExistsRepresentativesModNsmul
import Development.AbelianVarietyTheory.Proofs.RingsOfIntegers.ExistsShiftMemPowOfMulMemPow
import Development.AbelianVarietyTheory.Proofs.RingsOfIntegers.ImportsTer
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.BcDatumNatural
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.BijectiveOfIntertwining
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.BilinFormInjectiveExistsNsmulMemRange
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.CancelProdSummandNilpotentOrBijective
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.CmFieldProdEmbeddingsRegroupMaximalReal
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ConjMemOfMemHeckeLevel
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ContinuousCharUnitsComplex
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ContinuousOfValuationEq
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.EndomorphismIndecomposableNilpotentOrBijective
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.EqOneOfNormOneValuationSubOneSmall
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsCombinationNormNeZeroOfLinearIndependentAl
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsCommonEigenvalueOfMemAdjoin
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsComplementWithoutCommonIrreducibleTypes
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsConjIntegral
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsFieldCombinationNormNeZero
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsIntertwiningFunctional
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsPowValuationDivSubOneLeOfCongr
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsRepresent
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsRepsCoprimeOutsideModulus
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsResidueClassNearRealEmbeddings
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsStableGraphOfEqualAnnihilators
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.FiniteInvolutionFixedUnitEqMulConj
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.FixedMemOfOrbitHeight
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.FunctionalFixedByIdempotentRepresented
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.GLInvMulCongrOneModUniformizer
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.GlHomNnrealTrivialOfScalarTrivial
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.GraphOfFixedGraph
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImEmbeddingNeZeroOfNotMemRangeOfTotallyRealQuadr
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImportsBis
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImportsExtra
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImportsFurther
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImportsMore
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImportsRest
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImportsSide

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.JetHarmonics.SurjectiveOfKerLeMapSupSq, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.TendstoIntegralInnerOfTendstoELpNormTwo, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.UnitsZpowSurjective, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.VecPolyMemSpanValues, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.AnalyticAtEntry, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.DetBicharacterPowFour, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.DetUpdateRowAlternatingMulVecMem, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.DvdMulOfIdem, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.DvdTraceOfBalancedTensor, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.EntireAntilinearLatticePeriodsConst, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.ExistsCommonAlgClosedExtension, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.ExistsEqNsmulOfForallDvdOfBijective, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.ExistsIsClopenEqualizer, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.ExistsSmoothPeriodicPartitionOfUnity, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.ExistsUniformRegularityBound, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.Imports, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.IntOfPrimeMulSq, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.MemMapKerOfOneTmulEqZeroOfFlat, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.MvPolynomialMapMaximalIdealIsPrime, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.MvPowerSeriesVariablesSyzygySocle, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.NormCardQuotientSpan, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.RelProdPow, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.SetIntegralFderivEqZeroOfLatticePeriodic, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.TendstoOfSandwich, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.TracePowerSumModEq, `Development.AbelianVarietyTheory.Proofs.ModuliProofs.ValuationRingOfFlatOfFormallyUnramified, `Development.AbelianVarietyTheory.Proofs.RingsOfIntegers.ExistsLeastOfDiscrete, `Development.AbelianVarietyTheory.Proofs.RingsOfIntegers.ExistsRepresentativesModNsmul, `Development.AbelianVarietyTheory.Proofs.RingsOfIntegers.ExistsShiftMemPowOfMulMemPow, `Development.AbelianVarietyTheory.Proofs.RingsOfIntegers.ImportsTer, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.BcDatumNatural, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.BijectiveOfIntertwining, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.BilinFormInjectiveExistsNsmulMemRange, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.CancelProdSummandNilpotentOrBijective, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.CmFieldProdEmbeddingsRegroupMaximalReal, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ConjMemOfMemHeckeLevel, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ContinuousCharUnitsComplex, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ContinuousOfValuationEq, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.EndomorphismIndecomposableNilpotentOrBijective, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.EqOneOfNormOneValuationSubOneSmall, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsCombinationNormNeZeroOfLinearIndependentAl, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsCommonEigenvalueOfMemAdjoin, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsComplementWithoutCommonIrreducibleTypes, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsConjIntegral, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsFieldCombinationNormNeZero, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsIntertwiningFunctional, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsPowValuationDivSubOneLeOfCongr, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsRepresent, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsRepsCoprimeOutsideModulus, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsResidueClassNearRealEmbeddings, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsStableGraphOfEqualAnnihilators, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.FiniteInvolutionFixedUnitEqMulConj, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.FixedMemOfOrbitHeight, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.FunctionalFixedByIdempotentRepresented, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.GLInvMulCongrOneModUniformizer, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.GlHomNnrealTrivialOfScalarTrivial, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.GraphOfFixedGraph, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImEmbeddingNeZeroOfNotMemRangeOfTotallyRealQuadr, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImportsBis, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImportsExtra, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImportsFurther, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImportsMore, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImportsRest, `Development.AbelianVarietyTheory.Proofs.SatakeParameters.ImportsSide]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

