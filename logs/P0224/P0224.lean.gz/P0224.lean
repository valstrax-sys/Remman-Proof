import Lean
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.SymbLower
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.WeakFourier
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.WeightDiff
import Formalism.WachLatticeTwists.HodgeTateChains.HodgeTateFiltrations.GeomFact
import Formalism.WachLatticeTwists.HodgeTateChains.HodgeTateFiltrations.InjectivityPassesToCompletion
import Formalism.WachLatticeTwists.HodgeTateChains.HodgeTateFiltrations.MinimalExponentAttained
import Formalism.WachLatticeTwists.HodgeTateChains.XiAdicFiltrationData
import Formalism.WachLatticeTwists.LagrangeExtensionCocycles.ExtensionCocycleProofs.ResidueQuotientHolds
import Formalism.WachLatticeTwists.LagrangeExtensionCocycles.ExtensionCocycleProofs.SecondDescentStatementHolds
import Formalism.WachLatticeTwists.LagrangeExtensionCocycles.ExtensionCocycleProofs.SumVal
import Formalism.WachLatticeTwists.LagrangeExtensionCocycles.StatementLetters
import Formalism.WachLatticeTwists.LagrangeExtensionCocycles.StatementTop
import Formalism.WachLatticeTwists.TorsionLengthCounts.CardFilterAddLeOfNone
import Formalism.WachLatticeTwists.TorsionLengthCounts.LengthHomCoker
import Formalism.WachLatticeTwists.TorsionLengthCounts.RowCol
import Formalism.WachLatticeTwists.TorsionLengthCounts.SubmoduleLengthBoundStatement
import Formalism.WachLatticeTwists.WachProductBases.Statement
import Formalism.WeaklyAdmissibleFiltrations.CocyclesFunctorial
import Formalism.WeaklyAdmissibleFiltrations.StatementPC
import Formalism.WeaklyAdmissibleFiltrations.StatementTor
import Formalism.WeaklyAdmissibleFiltrations.WindowCount
import Formalism.WindowSums.AnnihilatorPolynomials.LeOfPowMemIdealOfDistinctTerms
import Formalism.YangianSpanCharacter.ModHypYangian
import Formalism.YangianSpanCharacter.StatementF
import Formalism.YangianSpanCharacter.YangianRTTProofs.DiagonalEntryEqOfModularRelation
import Formalism.YangianSpanCharacter.YangianRTTProofs.SymplecticTransposeEntryZeroOne
import Formalism.YangianSpanCharacter.YangianRTTProofs.TransposeJReversed
import Formalism.ZeroFreeRegion.Statement
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.RiemannZetaOneEqOneSubOfRePos
import Formalism.ZetaNonvanishing.Assembly
import Formalism.ZetaNonvanishing.LandauLemma
import Formalism.ZetaNonvanishing.LogDerivZeroFree
import Formalism.ZetaNonvanishing.MellinDeriv
import Formalism.ZetaNonvanishing.MellinElem
import Formalism.ZetaNonvanishing.MellinSAux
import Formalism.ZetaNonvanishing.RHofHalfPlane
import Formalism.ZetaNonvanishing.ZetaRealNonvanish
import GroundTheory.ArithmeticGeometry.AbelianVarieties.KernelCard
import GroundTheory.ArithmeticGeometry.EtaleCompletion.QcohZariski
import GroundTheory.ArithmeticGeometry.ModularCurves.WeierstrassCechAlgebra
import GroundTheory.ArithmeticGeometry.ModularCurves.WeierstrassChartIso
import GroundTheory.ArithmeticGeometry.SchemeCohomology.Cartan
import GroundTheory.ArithmeticGeometry.SchemeCohomology.InvertibleDual
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProjSpace
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.ReesRing
import GroundTheory.ArithmeticGeometry.SchemeCohomology.RegularCurve
import GroundTheory.ArithmeticGeometry.SchemeCohomology.RegularUFDLocalization
import GroundTheory.ArithmeticGeometry.SchemeCohomology.WeilDivisorSheaf
import GroundTheory.ArithmeticGeometry.ToricVarieties.ToricFaces
import GroundTheory.AutomorphicForms.CompactAbelianCharacters
import GroundTheory.AutomorphicForms.DixmierMalliavinHaarCoord
import GroundTheory.AutomorphicForms.DixmierMalliavinLineBounds
import GroundTheory.AutomorphicForms.GKModules.SmoothVectors
import GroundTheory.AutomorphicForms.GLnLattice
import GroundTheory.AutomorphicForms.HaarCosets
import GroundTheory.AutomorphicForms.HarishChandraCentre.ConstantCoeffRhoOneCanonMonomial
import GroundTheory.AutomorphicForms.HermitianOrthogonal
import GroundTheory.AutomorphicForms.Induction
import GroundTheory.AutomorphicForms.InductionJacquet
import GroundTheory.AutomorphicForms.MeasuresModulus
import GroundTheory.AutomorphicForms.PartialDifferential.SobolevMollifier
import GroundTheory.AutomorphicForms.QuotientRightRegular
import GroundTheory.AutomorphicForms.RealGroupsIwasawa
import GroundTheory.AutomorphicForms.RealGroupsKAK

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.UnipotentAdelicQuotients.EllipticRegularity.SymbLower, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.WeakFourier, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.WeightDiff, `Formalism.WachLatticeTwists.HodgeTateChains.HodgeTateFiltrations.GeomFact, `Formalism.WachLatticeTwists.HodgeTateChains.HodgeTateFiltrations.InjectivityPassesToCompletion, `Formalism.WachLatticeTwists.HodgeTateChains.HodgeTateFiltrations.MinimalExponentAttained, `Formalism.WachLatticeTwists.HodgeTateChains.XiAdicFiltrationData, `Formalism.WachLatticeTwists.LagrangeExtensionCocycles.ExtensionCocycleProofs.ResidueQuotientHolds, `Formalism.WachLatticeTwists.LagrangeExtensionCocycles.ExtensionCocycleProofs.SecondDescentStatementHolds, `Formalism.WachLatticeTwists.LagrangeExtensionCocycles.ExtensionCocycleProofs.SumVal, `Formalism.WachLatticeTwists.LagrangeExtensionCocycles.StatementLetters, `Formalism.WachLatticeTwists.LagrangeExtensionCocycles.StatementTop, `Formalism.WachLatticeTwists.TorsionLengthCounts.CardFilterAddLeOfNone, `Formalism.WachLatticeTwists.TorsionLengthCounts.LengthHomCoker, `Formalism.WachLatticeTwists.TorsionLengthCounts.RowCol, `Formalism.WachLatticeTwists.TorsionLengthCounts.SubmoduleLengthBoundStatement, `Formalism.WachLatticeTwists.WachProductBases.Statement, `Formalism.WeaklyAdmissibleFiltrations.CocyclesFunctorial, `Formalism.WeaklyAdmissibleFiltrations.StatementPC, `Formalism.WeaklyAdmissibleFiltrations.StatementTor, `Formalism.WeaklyAdmissibleFiltrations.WindowCount, `Formalism.WindowSums.AnnihilatorPolynomials.LeOfPowMemIdealOfDistinctTerms, `Formalism.YangianSpanCharacter.ModHypYangian, `Formalism.YangianSpanCharacter.StatementF, `Formalism.YangianSpanCharacter.YangianRTTProofs.DiagonalEntryEqOfModularRelation, `Formalism.YangianSpanCharacter.YangianRTTProofs.SymplecticTransposeEntryZeroOne, `Formalism.YangianSpanCharacter.YangianRTTProofs.TransposeJReversed, `Formalism.ZeroFreeRegion.Statement, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.RiemannZetaOneEqOneSubOfRePos, `Formalism.ZetaNonvanishing.Assembly, `Formalism.ZetaNonvanishing.LandauLemma, `Formalism.ZetaNonvanishing.LogDerivZeroFree, `Formalism.ZetaNonvanishing.MellinDeriv, `Formalism.ZetaNonvanishing.MellinElem, `Formalism.ZetaNonvanishing.MellinSAux, `Formalism.ZetaNonvanishing.RHofHalfPlane, `Formalism.ZetaNonvanishing.ZetaRealNonvanish, `GroundTheory.ArithmeticGeometry.AbelianVarieties.KernelCard, `GroundTheory.ArithmeticGeometry.EtaleCompletion.QcohZariski, `GroundTheory.ArithmeticGeometry.ModularCurves.WeierstrassCechAlgebra, `GroundTheory.ArithmeticGeometry.ModularCurves.WeierstrassChartIso, `GroundTheory.ArithmeticGeometry.SchemeCohomology.Cartan, `GroundTheory.ArithmeticGeometry.SchemeCohomology.InvertibleDual, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProjSpace, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.ReesRing, `GroundTheory.ArithmeticGeometry.SchemeCohomology.RegularCurve, `GroundTheory.ArithmeticGeometry.SchemeCohomology.RegularUFDLocalization, `GroundTheory.ArithmeticGeometry.SchemeCohomology.WeilDivisorSheaf, `GroundTheory.ArithmeticGeometry.ToricVarieties.ToricFaces, `GroundTheory.AutomorphicForms.CompactAbelianCharacters, `GroundTheory.AutomorphicForms.DixmierMalliavinHaarCoord, `GroundTheory.AutomorphicForms.DixmierMalliavinLineBounds, `GroundTheory.AutomorphicForms.GKModules.SmoothVectors, `GroundTheory.AutomorphicForms.GLnLattice, `GroundTheory.AutomorphicForms.HaarCosets, `GroundTheory.AutomorphicForms.HarishChandraCentre.ConstantCoeffRhoOneCanonMonomial, `GroundTheory.AutomorphicForms.HermitianOrthogonal, `GroundTheory.AutomorphicForms.Induction, `GroundTheory.AutomorphicForms.InductionJacquet, `GroundTheory.AutomorphicForms.MeasuresModulus, `GroundTheory.AutomorphicForms.PartialDifferential.SobolevMollifier, `GroundTheory.AutomorphicForms.QuotientRightRegular, `GroundTheory.AutomorphicForms.RealGroupsIwasawa, `GroundTheory.AutomorphicForms.RealGroupsKAK]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

