import Lean
import GroundTheory.HeightsAndTheta.Heights.Intersections.CardLength
import GroundTheory.HeightsAndTheta.Heights.Intersections.LocQuotCard
import GroundTheory.HeightsAndTheta.Heights.Intersections.PProjBundleMultiHomogGrad
import GroundTheory.HeightsAndTheta.Heights.Intersections.RelBaseChangeSt
import GroundTheory.HeightsAndTheta.Heights.Intersections.StAdjoinIndepRelfinrank
import GroundTheory.HeightsAndTheta.Heights.Intersections.StChartPrimElt
import GroundTheory.HeightsAndTheta.Heights.Intersections.StChartSpecCount
import GroundTheory.HeightsAndTheta.Heights.Intersections.StFinrankAdjoinRange
import GroundTheory.HeightsAndTheta.Heights.Intersections.StIntClosureLocFinite
import GroundTheory.HeightsAndTheta.Heights.Intersections.StLocAwaySpec
import GroundTheory.HeightsAndTheta.Heights.Intersections.StRankAdjoinFrac
import GroundTheory.HeightsAndTheta.Heights.Intersections.StRankFracDegree
import GroundTheory.HeightsAndTheta.Heights.Intersections.StRelAlgClosureFinite
import GroundTheory.HeightsAndTheta.Heights.Intersections.StTrdegAdjoinFrac
import GroundTheory.HeightsAndTheta.Heights.Intersections.StatementsLinearQuotient
import GroundTheory.HeightsAndTheta.Heights.Intersections.StatementsReducedCut
import GroundTheory.HeightsAndTheta.Heights.IterateExamples.Statements
import GroundTheory.HeightsAndTheta.Heights.KernelsLattice
import GroundTheory.HeightsAndTheta.Heights.KernelsMatrix
import GroundTheory.HeightsAndTheta.Heights.KernelsRest
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.DegZero
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.ImportsRestBis
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.KerAltSucc
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCechDoubleStair
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PTwinEqBundleLocal
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsDedekindFibreRank
import GroundTheory.HeightsAndTheta.Heights.LatticeLemmas.BaseChangeIndex
import GroundTheory.HeightsAndTheta.Heights.LocalDensities.StatementsIntegralPoint
import GroundTheory.HeightsAndTheta.Heights.LocalDensities.StatementsKrullHeightOne
import GroundTheory.HeightsAndTheta.Heights.LocalDensities.StatementsZariskiDense
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.ExampleLimitPolynomialHypothesis
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StCriticalFibreInfinite
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsCovolumeRelIndex
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsEmbeddingSumPlaces
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsLatticeCountVolume
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsMixedBoxCount
import GroundTheory.HeightsAndTheta.Heights.ProjTopology
import GroundTheory.HeightsAndTheta.Heights.ReducedTensors.Imports
import GroundTheory.HeightsAndTheta.Heights.Regularisation.StPuncturedExpOrder
import GroundTheory.HeightsAndTheta.Heights.Regularisation.StRiemannSlices
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.CoinvReduction
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.Statements
import GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.RecordEigenInputs
import GroundTheory.HeightsAndTheta.Heights.ThetaKeyFormula.RigSymFormTauINontrivial
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSpecChartQuot
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.StatementsFibreCompDim
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.StatementsFibreCut
import GroundTheory.HeightsAndTheta.Heights.WeightedHomogeneous.IntDimTrdeg
import GroundTheory.HeightsAndTheta.Heights.WeightedHomogeneous.StatementsFibreCompDimZ
import GroundTheory.HeightsAndTheta.Heights.WeightedHomogeneous.StatementsIntDim
import GroundTheory.HeightsAndTheta.Theta.Capelli.CompleteHomogeneous
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.AdicFrames.ContinuousOnChartProjM
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.AdicFrames.Imports
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.DedekindZetaSeries.HeightGeSecondCubicBound
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.DedekindZetaSeries.ZetaSevenHalves
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.CfunOmStatements
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.UnitLevels.KrFieldExample
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.WeilPolarization.WmSysObjects
import GroundTheory.HeightsAndTheta.Theta.FiniteGL.Mirabolic
import GroundTheory.HeightsAndTheta.Theta.FundDomain
import GroundTheory.HeightsAndTheta.Theta.Inertia
import GroundTheory.HeightsAndTheta.Theta.LocallyCompactField.Countability
import GroundTheory.HeightsAndTheta.Theta.Weil.Birational
import GroundTheory.HeightsAndTheta.Theta.Weil.PartialFourierSchwartz

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.Intersections.CardLength, `GroundTheory.HeightsAndTheta.Heights.Intersections.LocQuotCard, `GroundTheory.HeightsAndTheta.Heights.Intersections.PProjBundleMultiHomogGrad, `GroundTheory.HeightsAndTheta.Heights.Intersections.RelBaseChangeSt, `GroundTheory.HeightsAndTheta.Heights.Intersections.StAdjoinIndepRelfinrank, `GroundTheory.HeightsAndTheta.Heights.Intersections.StChartPrimElt, `GroundTheory.HeightsAndTheta.Heights.Intersections.StChartSpecCount, `GroundTheory.HeightsAndTheta.Heights.Intersections.StFinrankAdjoinRange, `GroundTheory.HeightsAndTheta.Heights.Intersections.StIntClosureLocFinite, `GroundTheory.HeightsAndTheta.Heights.Intersections.StLocAwaySpec, `GroundTheory.HeightsAndTheta.Heights.Intersections.StRankAdjoinFrac, `GroundTheory.HeightsAndTheta.Heights.Intersections.StRankFracDegree, `GroundTheory.HeightsAndTheta.Heights.Intersections.StRelAlgClosureFinite, `GroundTheory.HeightsAndTheta.Heights.Intersections.StTrdegAdjoinFrac, `GroundTheory.HeightsAndTheta.Heights.Intersections.StatementsLinearQuotient, `GroundTheory.HeightsAndTheta.Heights.Intersections.StatementsReducedCut, `GroundTheory.HeightsAndTheta.Heights.IterateExamples.Statements, `GroundTheory.HeightsAndTheta.Heights.KernelsLattice, `GroundTheory.HeightsAndTheta.Heights.KernelsMatrix, `GroundTheory.HeightsAndTheta.Heights.KernelsRest, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.DegZero, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.ImportsRestBis, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.KerAltSucc, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PCechDoubleStair, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PTwinEqBundleLocal, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.StatementsDedekindFibreRank, `GroundTheory.HeightsAndTheta.Heights.LatticeLemmas.BaseChangeIndex, `GroundTheory.HeightsAndTheta.Heights.LocalDensities.StatementsIntegralPoint, `GroundTheory.HeightsAndTheta.Heights.LocalDensities.StatementsKrullHeightOne, `GroundTheory.HeightsAndTheta.Heights.LocalDensities.StatementsZariskiDense, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.ExampleLimitPolynomialHypothesis, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StCriticalFibreInfinite, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsCovolumeRelIndex, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsEmbeddingSumPlaces, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsLatticeCountVolume, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsMixedBoxCount, `GroundTheory.HeightsAndTheta.Heights.ProjTopology, `GroundTheory.HeightsAndTheta.Heights.ReducedTensors.Imports, `GroundTheory.HeightsAndTheta.Heights.Regularisation.StPuncturedExpOrder, `GroundTheory.HeightsAndTheta.Heights.Regularisation.StRiemannSlices, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.CoinvReduction, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.Statements, `GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.RecordEigenInputs, `GroundTheory.HeightsAndTheta.Heights.ThetaKeyFormula.RigSymFormTauINontrivial, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSpecChartQuot, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.StatementsFibreCompDim, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.StatementsFibreCut, `GroundTheory.HeightsAndTheta.Heights.WeightedHomogeneous.IntDimTrdeg, `GroundTheory.HeightsAndTheta.Heights.WeightedHomogeneous.StatementsFibreCompDimZ, `GroundTheory.HeightsAndTheta.Heights.WeightedHomogeneous.StatementsIntDim, `GroundTheory.HeightsAndTheta.Theta.Capelli.CompleteHomogeneous, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.AdicFrames.ContinuousOnChartProjM, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.AdicFrames.Imports, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.DedekindZetaSeries.HeightGeSecondCubicBound, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.DedekindZetaSeries.ZetaSevenHalves, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.CfunOmStatements, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.UnitLevels.KrFieldExample, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.WeilPolarization.WmSysObjects, `GroundTheory.HeightsAndTheta.Theta.FiniteGL.Mirabolic, `GroundTheory.HeightsAndTheta.Theta.FundDomain, `GroundTheory.HeightsAndTheta.Theta.Inertia, `GroundTheory.HeightsAndTheta.Theta.LocallyCompactField.Countability, `GroundTheory.HeightsAndTheta.Theta.Weil.Birational, `GroundTheory.HeightsAndTheta.Theta.Weil.PartialFourierSchwartz]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

