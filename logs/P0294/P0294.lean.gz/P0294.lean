import Lean
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.FixedVectorStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.HeckeOperatorsSpanAndFaithful
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.IsFibreFamilyLength
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.IsometricLatticeCongruenceSubgroups
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.IwahoriStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.LatticeCongruenceSubgroupsOpenCompact
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.ModularityStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.MovingStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.PairingStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.ProjectionStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.SimpleOfCommutativeStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.StatementCommutative
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.StatementStar
import CompanionTheory.ThickeningEstimates.LieGroupReduction.MetaDef
import Development.AbelianVarietyTheory.BlockTheory.AbelianSchemeLaw.CubicalPullbackLaw
import Development.AbelianVarietyTheory.BlockTheory.AbelianSchemeLaw.LevelStructureForms
import Development.AbelianVarietyTheory.BlockTheory.CMModuli.PolarizationCorrespondence
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.ScaledIntegerPeriodic
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.DegreeProportionalWords
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.HodgeTateCharacterSystems
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.TwistedPoints
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.CrystallineSubrepresentation
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.DualExactSequence
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.GammaStableInverse
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.GradedSeries
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.JumpMultiplicityDual
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.KernelDictionary
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.LettersFreeOfRank
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.LocalRingStructure
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.PointRingCommRing
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.TensorLatticeUnitPart
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.TensorMultiplication
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.UnitDualParts
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.WachCrystallineComparison
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.WachLettersFree
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.WachModuleUniqueness
import Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.SmallUnipotentElements
import Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.BlochKatoGeneratorBound
import Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.ExtendedRepresentation
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.AdjointOperatorIdentities
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.DualLatticeExchange
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.DualLiftInvariance
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.FlagVolumeFiltration
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.IndicatorFunctionIdentity
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.IwahoriDoubleCosets
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.VolumeFlatSection
import Development.AbelianVarietyTheory.BlockTheory.UniformisationCharts.CanonicalRigidImages
import Development.AbelianVarietyTheory.Counterexamples.TransversalityLocal.FramePairFixatorUnitaryAndFixesFrame
import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.IsOpenKerFinIdele
import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.IsSemisimpleOfISupEigenspace
import Development.AbelianVarietyTheory.Definitions.Divisors.BicechC
import Development.AbelianVarietyTheory.Definitions.Divisors.CrystallineConnectionFormCoboundaryZero
import Development.AbelianVarietyTheory.Definitions.Divisors.FlatTensorVacuum
import Development.AbelianVarietyTheory.Definitions.Divisors.IsBasisOfBot
import Development.AbelianVarietyTheory.Definitions.Divisors.IsCorrOpOfAvg
import Development.AbelianVarietyTheory.Definitions.Divisors.IsDualBasis
import Development.AbelianVarietyTheory.Definitions.Divisors.IsExpLieAlgebraComplexUnits
import Development.AbelianVarietyTheory.Definitions.Divisors.IsLocallyConstantSplitOm
import Development.AbelianVarietyTheory.Definitions.Divisors.LineOppositeParabolicUnitaryLeviSectionEq
import Development.AbelianVarietyTheory.Definitions.Divisors.OmAUnipFourierInv
import Development.AbelianVarietyTheory.Definitions.Divisors.OneSubOfIsIrreducible
import Development.AbelianVarietyTheory.Definitions.Divisors.SecClass
import Development.AbelianVarietyTheory.Definitions.Divisors.ToSpanSingletonConstGenInjective
import Development.AbelianVarietyTheory.Definitions.Divisors.UnipVal

open Lean Elab Command

def auditTargets : Array Name := #[`CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.FixedVectorStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.HeckeOperatorsSpanAndFaithful, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.IsFibreFamilyLength, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.IsometricLatticeCongruenceSubgroups, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.IwahoriStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.LatticeCongruenceSubgroupsOpenCompact, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.ModularityStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.MovingStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.PairingStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.ProjectionStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.SimpleOfCommutativeStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.StatementCommutative, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.StatementStar, `CompanionTheory.ThickeningEstimates.LieGroupReduction.MetaDef, `Development.AbelianVarietyTheory.BlockTheory.AbelianSchemeLaw.CubicalPullbackLaw, `Development.AbelianVarietyTheory.BlockTheory.AbelianSchemeLaw.LevelStructureForms, `Development.AbelianVarietyTheory.BlockTheory.CMModuli.PolarizationCorrespondence, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.ScaledIntegerPeriodic, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.DegreeProportionalWords, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.HodgeTateCharacterSystems, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.TwistedPoints, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.CrystallineSubrepresentation, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.DualExactSequence, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.GammaStableInverse, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.GradedSeries, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.JumpMultiplicityDual, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.KernelDictionary, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.LettersFreeOfRank, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.LocalRingStructure, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.PointRingCommRing, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.TensorLatticeUnitPart, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.TensorMultiplication, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.UnitDualParts, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.WachCrystallineComparison, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.WachLettersFree, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.WachModuleUniqueness, `Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.SmallUnipotentElements, `Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.BlochKatoGeneratorBound, `Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.ExtendedRepresentation, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.AdjointOperatorIdentities, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.DualLatticeExchange, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.DualLiftInvariance, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.FlagVolumeFiltration, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.IndicatorFunctionIdentity, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.IwahoriDoubleCosets, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.VolumeFlatSection, `Development.AbelianVarietyTheory.BlockTheory.UniformisationCharts.CanonicalRigidImages, `Development.AbelianVarietyTheory.Counterexamples.TransversalityLocal.FramePairFixatorUnitaryAndFixesFrame, `Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.IsOpenKerFinIdele, `Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.IsSemisimpleOfISupEigenspace, `Development.AbelianVarietyTheory.Definitions.Divisors.BicechC, `Development.AbelianVarietyTheory.Definitions.Divisors.CrystallineConnectionFormCoboundaryZero, `Development.AbelianVarietyTheory.Definitions.Divisors.FlatTensorVacuum, `Development.AbelianVarietyTheory.Definitions.Divisors.IsBasisOfBot, `Development.AbelianVarietyTheory.Definitions.Divisors.IsCorrOpOfAvg, `Development.AbelianVarietyTheory.Definitions.Divisors.IsDualBasis, `Development.AbelianVarietyTheory.Definitions.Divisors.IsExpLieAlgebraComplexUnits, `Development.AbelianVarietyTheory.Definitions.Divisors.IsLocallyConstantSplitOm, `Development.AbelianVarietyTheory.Definitions.Divisors.LineOppositeParabolicUnitaryLeviSectionEq, `Development.AbelianVarietyTheory.Definitions.Divisors.OmAUnipFourierInv, `Development.AbelianVarietyTheory.Definitions.Divisors.OneSubOfIsIrreducible, `Development.AbelianVarietyTheory.Definitions.Divisors.SecClass, `Development.AbelianVarietyTheory.Definitions.Divisors.ToSpanSingletonConstGenInjective, `Development.AbelianVarietyTheory.Definitions.Divisors.UnipVal]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

