import Lean
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IwasawaDecompositionStatementStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeFirstPropertyStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeFourthPropertyStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeSecondPropertyStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeThirdProperty
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LevelSquareCongruenceConjugationStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LeviDecompOfBlockDet
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LeviQuotientOfBlockDet
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralComplexPowerFiniteStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralLinearChangeVariablesComplexStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralPowerLineScalingStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralSplitColumn
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalFiniteAlgebraJacobsonRadicalStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MeasurableZeroCount
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MeetOverHypersurfaceOfGermStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NewtonApproximationLocalToGlobal
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormCentralizerIdentificationStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormCommutesSeparableHoldsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormFibreCardNonzeroStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormFibreCardZeroStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapCongruenceStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapFirstPropertyStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapIntegralPropertyStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapSecondPropertyStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapTorusSurjectiveStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.OneLeDetWStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicDoubleCosetOfEqualCorankStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicLawOfBlockDet
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionOffDiagonalIdentity
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionSquareIdentity
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialIntegralMemSchwartzBruhat
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PerfectFrobeniusRootSolutionStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PerfectTensorProductStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PiCongrRightSingle
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PositivityStatementStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ReductionCorankEqRankLowerLeftStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ReductionUniqueUpToParabolicStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ResidueAlgebraUnramifiedStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ResidueUpperUnipotentLiftStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzBruhatProdSpanTensors
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzQuadraticPhaseMultiplication
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SeparableNormCommutingStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShuffleWeightAntisymmetricEq
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SiegelInductionFromGallery
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SigmaCompactDisjointRefinement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.StandardEtaleLocalSection
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.StripEntireOfFac
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorIdealMapInjectiveStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TransferOfSectionAndWallLawsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TwistOfSectionLawStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TwistedJacquetExactSmoothStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UniformBoundednessStatementStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnimodularHaarRightInvariant
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnipotentConvergenceOfParabolic
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnipotentHeckeFourthPropertyStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitFundamentalLemmaFirstHoldsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitFundamentalLemmaSecondHoldsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedDictionaryPartB
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedDualFamilyHoldsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedExtensionIntegralBasisStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedQuotientCardStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ValuationOfLocalDichotomyStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WeaklyRegularOfCotangentIndep
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.ArithFunctionalLipschitzWeightsStatement

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IwasawaDecompositionStatementStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeFirstPropertyStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeFourthPropertyStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeSecondPropertyStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeThirdProperty, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LevelSquareCongruenceConjugationStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LeviDecompOfBlockDet, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LeviQuotientOfBlockDet, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralComplexPowerFiniteStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralLinearChangeVariablesComplexStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralPowerLineScalingStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralSplitColumn, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LocalFiniteAlgebraJacobsonRadicalStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MeasurableZeroCount, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MeetOverHypersurfaceOfGermStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NewtonApproximationLocalToGlobal, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormCentralizerIdentificationStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormCommutesSeparableHoldsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormFibreCardNonzeroStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormFibreCardZeroStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapCongruenceStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapFirstPropertyStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapIntegralPropertyStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapSecondPropertyStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.NormMapTorusSurjectiveStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.OneLeDetWStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicDoubleCosetOfEqualCorankStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ParabolicLawOfBlockDet, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionOffDiagonalIdentity, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialFractionSquareIdentity, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PartialIntegralMemSchwartzBruhat, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PerfectFrobeniusRootSolutionStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PerfectTensorProductStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PiCongrRightSingle, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.PositivityStatementStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ReductionCorankEqRankLowerLeftStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ReductionUniqueUpToParabolicStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ResidueAlgebraUnramifiedStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ResidueUpperUnipotentLiftStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzBruhatProdSpanTensors, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzQuadraticPhaseMultiplication, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SeparableNormCommutingStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ShuffleWeightAntisymmetricEq, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SiegelInductionFromGallery, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SigmaCompactDisjointRefinement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.StandardEtaleLocalSection, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.StripEntireOfFac, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorIdealMapInjectiveStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TransferOfSectionAndWallLawsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TwistOfSectionLawStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TwistedJacquetExactSmoothStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UniformBoundednessStatementStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnimodularHaarRightInvariant, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnipotentConvergenceOfParabolic, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnipotentHeckeFourthPropertyStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitFundamentalLemmaFirstHoldsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitFundamentalLemmaSecondHoldsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedDictionaryPartB, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedDualFamilyHoldsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedExtensionIntegralBasisStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedQuotientCardStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ValuationOfLocalDichotomyStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WeaklyRegularOfCotangentIndep, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.ArithFunctionalLipschitzWeightsStatement]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

