import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchrodingerProductEuclideanModelsAgreeStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchrodingerRepSchwartzPolynomialBound
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchroedingerOperatorHeisenbergInnerPreserving
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchroedingerOperatorHeisenbergPreservesSchwartzB
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzBruhatVectorIrreducibleTranslationsCharaStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzCharacterSeminormBoundStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzEqGaussianOfFderivEqMulVecStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzL2EuclideanIdentificationStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzSubmoduleSupportClosedStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzSupportVanishingIdealStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzTranslationSeminormBoundStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SectionNormLocalFormulaStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SectionPullbackHolomorphic
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SectionTensorPullbackRingHomBijectiveStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SectionsIsFractionRingStalkImageOfGenericPointStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SeminormSliceRLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SepIntPolyRootModPrimeSqStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ShiftFunctionalDecompositionStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ShiftFunctionalLinearRootPowerStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ShiftFunctionalPowerSumStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SiegelActionIsMulActionStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SiegelGaussianPairStandardGaussianStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SiegelLemmaSmallVector
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SiegelPeriodMapSimplyConnectedStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SimplyConnectedCoverStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmoothAbsOfLeAbs
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmoothOnNhdOffBoundary
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanRangeMulVecLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpecHomExtOfLocalizationAwaySpanEqTopStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SquaringOpenAtOneOfCompleteTwoNeZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubMemNsp
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumCoeffWindowCrossingFiberPoint
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SummableGaussianExtensionNormRpowStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SummableHeckeWeightTwoLatticeSumStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SummableHilbertEisensteinWeightTwoQSeriesStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SummableSeminormGaussianConvolutionSeriesTermStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SurjectiveOfTraceOfSmulMemRangeStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SymplecticHolPartDetNeZeroAndIsSymmStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TensorIsLocalRingOfUniquePrimeOverStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TensorLocalizationAtPrimeIsDomainOfIsLocalRingEtStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaFactorHolomorphicSolutionStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaFactorNormInvariance
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaMetricTranslationInvariantStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaProjectionIntertwiningStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaVanishOnFiberTangent
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaZeroOneLowerVanish
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaZeroOneSkewConj
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TopMulDescendedSubmoduleOfUnitCocycleEqTop
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionPointRowSumEqQExpansionSeriesStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsorBaseChangeZmod
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorusEmbeddingLieInjective
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorusFundamentalDomainCoversStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TotallyDisconnectedProductLocallyCompactStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslateDifferenceMemSpan
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationCharacterInvariantFormStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationDilationStableRadialElement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationPreservesFlatFormStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TruncatedGaussianIntegralUniformPosSemidefStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UniformTaylorBoundLeviPluriharmonicSplit
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitEqMulPowOnEtaleExcisionNbhdZeroLocusStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryFlagFrameExists
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryPQContinuousCharacterEqDetPowProdStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.VanishingOnWallsDivisible
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.VolumePeriodTorusEqDetImaginaryStatement

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchrodingerProductEuclideanModelsAgreeStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchrodingerRepSchwartzPolynomialBound, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchroedingerOperatorHeisenbergInnerPreserving, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchroedingerOperatorHeisenbergPreservesSchwartzB, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzBruhatVectorIrreducibleTranslationsCharaStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzCharacterSeminormBoundStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzEqGaussianOfFderivEqMulVecStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzL2EuclideanIdentificationStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzSubmoduleSupportClosedStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzSupportVanishingIdealStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchwartzTranslationSeminormBoundStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SectionNormLocalFormulaStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SectionPullbackHolomorphic, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SectionTensorPullbackRingHomBijectiveStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SectionsIsFractionRingStalkImageOfGenericPointStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SeminormSliceRLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SepIntPolyRootModPrimeSqStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ShiftFunctionalDecompositionStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ShiftFunctionalLinearRootPowerStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ShiftFunctionalPowerSumStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SiegelActionIsMulActionStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SiegelGaussianPairStandardGaussianStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SiegelLemmaSmallVector, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SiegelPeriodMapSimplyConnectedStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SimplyConnectedCoverStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmoothAbsOfLeAbs, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SmoothOnNhdOffBoundary, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanRangeMulVecLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpecHomExtOfLocalizationAwaySpanEqTopStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SquaringOpenAtOneOfCompleteTwoNeZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubMemNsp, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumCoeffWindowCrossingFiberPoint, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SummableGaussianExtensionNormRpowStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SummableHeckeWeightTwoLatticeSumStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SummableHilbertEisensteinWeightTwoQSeriesStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SummableSeminormGaussianConvolutionSeriesTermStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SurjectiveOfTraceOfSmulMemRangeStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SymplecticHolPartDetNeZeroAndIsSymmStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TensorIsLocalRingOfUniquePrimeOverStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TensorLocalizationAtPrimeIsDomainOfIsLocalRingEtStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaFactorHolomorphicSolutionStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaFactorNormInvariance, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaMetricTranslationInvariantStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaProjectionIntertwiningStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaVanishOnFiberTangent, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaZeroOneLowerVanish, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaZeroOneSkewConj, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TopMulDescendedSubmoduleOfUnitCocycleEqTop, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionPointRowSumEqQExpansionSeriesStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsorBaseChangeZmod, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorusEmbeddingLieInjective, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorusFundamentalDomainCoversStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TotallyDisconnectedProductLocallyCompactStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslateDifferenceMemSpan, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationCharacterInvariantFormStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationDilationStableRadialElement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TranslationPreservesFlatFormStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TruncatedGaussianIntegralUniformPosSemidefStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UniformTaylorBoundLeviPluriharmonicSplit, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitEqMulPowOnEtaleExcisionNbhdZeroLocusStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryFlagFrameExists, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnitaryPQContinuousCharacterEqDetPowProdStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.VanishingOnWallsDivisible, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.VolumePeriodTorusEqDetImaginaryStatement]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

