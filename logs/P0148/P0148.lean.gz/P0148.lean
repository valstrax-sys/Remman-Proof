import Lean
import Formalism.HermitianCurvature.HermitianCurvatureProofs.Cauchy
import Formalism.HermitianCurvature.HermitianCurvatureProofs.CmRingIdempotentUnitRatioIdentity
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ContinuousInvUpper
import Formalism.HermitianCurvature.HermitianCurvatureProofs.CutJmuHC
import Formalism.HermitianCurvature.HermitianCurvatureProofs.DualIdealInclusion
import Formalism.HermitianCurvature.HermitianCurvatureProofs.DualVolumePowerIdentity
import Formalism.HermitianCurvature.HermitianCurvatureProofs.GaussianHessianIntegral
import Formalism.HermitianCurvature.HermitianCurvatureProofs.HasFDerivAtPrim
import Formalism.HermitianCurvature.HermitianCurvatureProofs.Herglotz
import Formalism.HermitianCurvature.HermitianCurvatureProofs.Interlace
import Formalism.HermitianCurvature.HermitianCurvatureProofs.Markov
import Formalism.HermitianCurvature.HermitianCurvatureProofs.MassRatioFormula
import Formalism.HermitianCurvature.HermitianCurvatureProofs.MiddleThirdEstimate
import Formalism.HermitianCurvature.HermitianCurvatureProofs.MinorScalingLawGeneral
import Formalism.HermitianCurvature.HermitianCurvatureProofs.Minors
import Formalism.HermitianCurvature.HermitianCurvatureProofs.NormIteratedFDerivWithinInvOneLe
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PhaseFunctionCriticalPoints
import Formalism.HermitianCurvature.HermitianCurvatureProofs.RecText
import Formalism.HermitianCurvature.HermitianCurvatureProofs.RemainderNormLeStrictUpper
import Formalism.HermitianCurvature.HermitianCurvatureProofs.RuleGD
import Formalism.HermitianCurvature.HermitianCurvatureProofs.RuleInv
import Formalism.HermitianCurvature.HermitianCurvatureProofs.RuleSS
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ScalingExponentIdentities
import Formalism.HermitianCurvature.HermitianCurvatureProofs.SharpRecursion
import Formalism.HermitianCurvature.HermitianCurvatureProofs.StabilizerBlockPoint
import Formalism.HermitianCurvature.HermitianCurvatureProofs.StandardCharacterExists
import Formalism.HermitianCurvature.HermitianCurvatureProofs.StationaryPhaseEstimates
import Formalism.HermitianCurvature.HermitianCurvatureProofs.SumInvSqLeSub
import Formalism.HermitianCurvature.HermitianCurvatureProofs.TendstoIntegralPsiMoving
import Formalism.HermitianCurvature.HermitianCurvatureProofs.TransferProductMonic
import Formalism.HermitianCurvature.HermitianCurvatureProofs.UnitaryInvariantGaussian
import Formalism.HermitianCurvature.HermitianCurvatureProofs.VandermondeRatioHarmonic
import Formalism.HermitianCurvature.HermitianCurvatureProofs.WirtingerIntegrationByParts
import Formalism.HermitianCurvature.LevelRecursionCondNeeded
import Formalism.HermitianCurvature.StatementA
import Formalism.HermitianCurvature.StatementK
import Formalism.HermitianLattices.HermitianLatticesProofs.UnimodUnramUnique
import Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.ArithmeticLatticeHypothesis
import Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.CardEqCardRangeNsmulMulCardKer
import Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.CountO
import Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.DedekindLFunctions
import Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.DetIndexProductHyperbolicInequality
import Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.OmegaPow
import Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.ProdInfinitePlaceLeOfIntegral
import Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.SubgroupCount
import Formalism.IncomingBounds.FlowDegreeBounds.LemmaFd
import Formalism.IncomingBounds.FlowDegreeBounds.MaxFlowValueAttained
import Formalism.IncomingBounds.IndexLastStep
import Formalism.IncomingBounds.LevelTail
import Formalism.IncomingBounds.StatementThmP
import Formalism.JumpKernelCokernel.JumpShiftProofs.KerCokerEq
import Formalism.LagrangeIdealLifts.CocyclePolynomialDivision.CoeffSumXPowMulExpand
import Formalism.LagrangeIdealLifts.CocyclePolynomialDivision.CompsOfMemMap
import Formalism.LagrangeIdealLifts.CocyclePolynomialDivision.Graded
import Formalism.LagrangeIdealLifts.CocyclePolynomialDivision.LagrangeIdeal
import Formalism.LatticeLocalGlobal.LatticeLocalGlobalOfGlobal
import Formalism.LatticeRigidity.HeightMinimum.BlockEquationHolds
import Formalism.LatticeRigidity.HeightMinimum.ChebyshevLeadingCoeffHolds
import Formalism.LatticeRigidity.HeightMinimum.PackingCountGeometricMean
import Formalism.LatticeRigidity.HeightMinimum.SqrtAbsNormLeProd
import Formalism.LatticeRigidity.StatementD
import Formalism.LatticeSlopes.CovolAntiSameRank
import Formalism.LatticeSlopes.LatticeSlopesProofs.CovolEqGram
import Formalism.LatticeSlopes.LatticeSlopesProofs.DiscreteTopologyOfLe

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.HermitianCurvature.HermitianCurvatureProofs.Cauchy, `Formalism.HermitianCurvature.HermitianCurvatureProofs.CmRingIdempotentUnitRatioIdentity, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ContinuousInvUpper, `Formalism.HermitianCurvature.HermitianCurvatureProofs.CutJmuHC, `Formalism.HermitianCurvature.HermitianCurvatureProofs.DualIdealInclusion, `Formalism.HermitianCurvature.HermitianCurvatureProofs.DualVolumePowerIdentity, `Formalism.HermitianCurvature.HermitianCurvatureProofs.GaussianHessianIntegral, `Formalism.HermitianCurvature.HermitianCurvatureProofs.HasFDerivAtPrim, `Formalism.HermitianCurvature.HermitianCurvatureProofs.Herglotz, `Formalism.HermitianCurvature.HermitianCurvatureProofs.Interlace, `Formalism.HermitianCurvature.HermitianCurvatureProofs.Markov, `Formalism.HermitianCurvature.HermitianCurvatureProofs.MassRatioFormula, `Formalism.HermitianCurvature.HermitianCurvatureProofs.MiddleThirdEstimate, `Formalism.HermitianCurvature.HermitianCurvatureProofs.MinorScalingLawGeneral, `Formalism.HermitianCurvature.HermitianCurvatureProofs.Minors, `Formalism.HermitianCurvature.HermitianCurvatureProofs.NormIteratedFDerivWithinInvOneLe, `Formalism.HermitianCurvature.HermitianCurvatureProofs.PhaseFunctionCriticalPoints, `Formalism.HermitianCurvature.HermitianCurvatureProofs.RecText, `Formalism.HermitianCurvature.HermitianCurvatureProofs.RemainderNormLeStrictUpper, `Formalism.HermitianCurvature.HermitianCurvatureProofs.RuleGD, `Formalism.HermitianCurvature.HermitianCurvatureProofs.RuleInv, `Formalism.HermitianCurvature.HermitianCurvatureProofs.RuleSS, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ScalingExponentIdentities, `Formalism.HermitianCurvature.HermitianCurvatureProofs.SharpRecursion, `Formalism.HermitianCurvature.HermitianCurvatureProofs.StabilizerBlockPoint, `Formalism.HermitianCurvature.HermitianCurvatureProofs.StandardCharacterExists, `Formalism.HermitianCurvature.HermitianCurvatureProofs.StationaryPhaseEstimates, `Formalism.HermitianCurvature.HermitianCurvatureProofs.SumInvSqLeSub, `Formalism.HermitianCurvature.HermitianCurvatureProofs.TendstoIntegralPsiMoving, `Formalism.HermitianCurvature.HermitianCurvatureProofs.TransferProductMonic, `Formalism.HermitianCurvature.HermitianCurvatureProofs.UnitaryInvariantGaussian, `Formalism.HermitianCurvature.HermitianCurvatureProofs.VandermondeRatioHarmonic, `Formalism.HermitianCurvature.HermitianCurvatureProofs.WirtingerIntegrationByParts, `Formalism.HermitianCurvature.LevelRecursionCondNeeded, `Formalism.HermitianCurvature.StatementA, `Formalism.HermitianCurvature.StatementK, `Formalism.HermitianLattices.HermitianLatticesProofs.UnimodUnramUnique, `Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.ArithmeticLatticeHypothesis, `Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.CardEqCardRangeNsmulMulCardKer, `Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.CountO, `Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.DedekindLFunctions, `Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.DetIndexProductHyperbolicInequality, `Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.OmegaPow, `Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.ProdInfinitePlaceLeOfIntegral, `Formalism.HyperbolicPlaceProducts.SubgroupIndexCounts.SubgroupCount, `Formalism.IncomingBounds.FlowDegreeBounds.LemmaFd, `Formalism.IncomingBounds.FlowDegreeBounds.MaxFlowValueAttained, `Formalism.IncomingBounds.IndexLastStep, `Formalism.IncomingBounds.LevelTail, `Formalism.IncomingBounds.StatementThmP, `Formalism.JumpKernelCokernel.JumpShiftProofs.KerCokerEq, `Formalism.LagrangeIdealLifts.CocyclePolynomialDivision.CoeffSumXPowMulExpand, `Formalism.LagrangeIdealLifts.CocyclePolynomialDivision.CompsOfMemMap, `Formalism.LagrangeIdealLifts.CocyclePolynomialDivision.Graded, `Formalism.LagrangeIdealLifts.CocyclePolynomialDivision.LagrangeIdeal, `Formalism.LatticeLocalGlobal.LatticeLocalGlobalOfGlobal, `Formalism.LatticeRigidity.HeightMinimum.BlockEquationHolds, `Formalism.LatticeRigidity.HeightMinimum.ChebyshevLeadingCoeffHolds, `Formalism.LatticeRigidity.HeightMinimum.PackingCountGeometricMean, `Formalism.LatticeRigidity.HeightMinimum.SqrtAbsNormLeProd, `Formalism.LatticeRigidity.StatementD, `Formalism.LatticeSlopes.CovolAntiSameRank, `Formalism.LatticeSlopes.LatticeSlopesProofs.CovolEqGram, `Formalism.LatticeSlopes.LatticeSlopesProofs.DiscreteTopologyOfLe]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

