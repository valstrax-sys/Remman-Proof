import Lean
import Development.WeilBound.ThetaLifts.SphericalLattices.ExistsVBallSubset
import Development.WeilBound.ThetaLifts.SphericalLattices.LattEq
import Formalism.ArtinHasse.ArtinHasseProofs.SymmSeries
import Formalism.BehrendSets.BehrendVariance.MulAbsSubLt
import Formalism.BehrendSets.BehrendVariance.ProbEqSumIte
import Formalism.BehrendSets.BehrendVariance.Select
import Formalism.BehrendSets.BehrendVariance.TwoLeCastOfTwoLe
import Formalism.BehrendSets.BehrendVariance.TwoPowDvdPowTwoPowSubOne
import Formalism.BehrendSets.StatementE
import Formalism.BranchSandwichDivisors.BranchIsometryProofs.MemBranchRangeOfDefectEq
import Formalism.BranchSandwichDivisors.BranchIsometryProofs.StepDiii
import Formalism.BranchSandwichDivisors.BranchIsometryProofs.TransferMean
import Formalism.BranchSandwichDivisors.NormLog
import Formalism.CharacterColumnKernels.Assemble
import Formalism.CharacterColumnKernels.CharacterColumnKernelLengthBound
import Formalism.CharacterColumnKernels.IdempotentNormalForms.CongMem
import Formalism.CharacterColumnKernels.IdempotentNormalForms.DetTri
import Formalism.CharacterColumnKernels.IdempotentNormalForms.LengthKerOfDetEqZero
import Formalism.CharacterColumnKernels.IdempotentNormalForms.ProdEraseZero
import Formalism.CharacterColumnKernels.IdempotentNormalForms.SingleEqSmul
import Formalism.CharacterColumnKernels.StatementG
import Formalism.CharacterColumnKernels.StatementX
import Formalism.CoboundaryTransfers.StatementAPI
import Formalism.ConjugateSelfDual.StatementRest
import Formalism.CorankShare.CorankShareProofs.LayerCakeFormula
import Formalism.CorankShare.CorankShareProofs.SumNormSqLeHilbertSchmidt
import Formalism.CyclotomicNorms.NonsquarefreeBounds.Central
import Formalism.CyclotomicNorms.NonsquarefreeBounds.Cycles
import Formalism.CyclotomicNorms.NonsquarefreeBounds.LowDegreePowerSeries
import Formalism.CyclotomicNorms.NonsquarefreeBounds.Newton
import Formalism.CyclotomicNorms.NonsquarefreeBounds.NonsquarefreeMonicBoundHolds
import Formalism.CyclotomicNorms.NonsquarefreeBounds.ResModule
import Formalism.CyclotomicNorms.NonsquarefreeBounds.SpanQuadraticOfImage
import Formalism.CyclotomicNorms.NonsquarefreeBounds.SubstitutionBound
import Formalism.CyclotomicNorms.NonsquarefreeBounds.TwoMulNumDerangementsLeFactorial
import Formalism.CyclotomicNorms.StatementT
import Formalism.CyclotomicNorms.TWAbsUniform
import Formalism.DegreeFormula.PointDegree.FlagDeg
import Formalism.DegreeFormula.PointDegree.PermExpInj
import Formalism.DistinguishedUnitIdeals.CoprimeProd
import Formalism.DistinguishedUnitIdeals.IsCocycle
import Formalism.DistinguishedUnitIdeals.UnivPart
import Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.DoubleCosetEqPreimage
import Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.ExistsContinuousLowerUpperEntry
import Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.IsIntOfLatOfLe
import Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.IsOpenIsIntSet
import Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.LowUniMulVecELast
import Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.MulInvBlockDiagApplySameBlock
import Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.TwoSided
import Formalism.DoubleCosetMeasures.StatementZ
import Formalism.EisensteinCokernelLengths.ExponentChainBound
import Formalism.EisensteinCokernelLengths.StatementLIFTV
import Formalism.EllipticTorsion.EllipticTorsionProofs.IsogenyExpansion
import Formalism.EllipticTorsion.WChordSeries
import Formalism.FilteredPoleLength.LocalDescentLevels.DetMulEqSumPrincipal
import Formalism.FilteredPoleLength.LocalDescentLevels.ExistsSumOfMemSpanImage
import Formalism.FilteredPoleLength.LocalDescentLevels.FourTermSumBoundOfParameters
import Formalism.FilteredPoleLength.LocalDescentLevels.GAdjugateNormBound
import Formalism.FilteredPoleLength.LocalDescentLevels.IntegralMulExpNegSq
import Formalism.FilteredPoleLength.LocalDescentLevels.MinimumChainBounds
import Formalism.FilteredPoleLength.ReducedBasisBounds.BetaSesquilinearity
import Formalism.FilteredPoleLength.ReducedBasisBounds.FilteredPoleLength
import Formalism.FilteredPoleLength.ReducedBasisBounds.ReductionQuotient
import Formalism.FlagUnipotentLattices.CardSubmodulesAndLinearEquivBounds

open Lean Elab Command

def auditTargets : Array Name := #[`Development.WeilBound.ThetaLifts.SphericalLattices.ExistsVBallSubset, `Development.WeilBound.ThetaLifts.SphericalLattices.LattEq, `Formalism.ArtinHasse.ArtinHasseProofs.SymmSeries, `Formalism.BehrendSets.BehrendVariance.MulAbsSubLt, `Formalism.BehrendSets.BehrendVariance.ProbEqSumIte, `Formalism.BehrendSets.BehrendVariance.Select, `Formalism.BehrendSets.BehrendVariance.TwoLeCastOfTwoLe, `Formalism.BehrendSets.BehrendVariance.TwoPowDvdPowTwoPowSubOne, `Formalism.BehrendSets.StatementE, `Formalism.BranchSandwichDivisors.BranchIsometryProofs.MemBranchRangeOfDefectEq, `Formalism.BranchSandwichDivisors.BranchIsometryProofs.StepDiii, `Formalism.BranchSandwichDivisors.BranchIsometryProofs.TransferMean, `Formalism.BranchSandwichDivisors.NormLog, `Formalism.CharacterColumnKernels.Assemble, `Formalism.CharacterColumnKernels.CharacterColumnKernelLengthBound, `Formalism.CharacterColumnKernels.IdempotentNormalForms.CongMem, `Formalism.CharacterColumnKernels.IdempotentNormalForms.DetTri, `Formalism.CharacterColumnKernels.IdempotentNormalForms.LengthKerOfDetEqZero, `Formalism.CharacterColumnKernels.IdempotentNormalForms.ProdEraseZero, `Formalism.CharacterColumnKernels.IdempotentNormalForms.SingleEqSmul, `Formalism.CharacterColumnKernels.StatementG, `Formalism.CharacterColumnKernels.StatementX, `Formalism.CoboundaryTransfers.StatementAPI, `Formalism.ConjugateSelfDual.StatementRest, `Formalism.CorankShare.CorankShareProofs.LayerCakeFormula, `Formalism.CorankShare.CorankShareProofs.SumNormSqLeHilbertSchmidt, `Formalism.CyclotomicNorms.NonsquarefreeBounds.Central, `Formalism.CyclotomicNorms.NonsquarefreeBounds.Cycles, `Formalism.CyclotomicNorms.NonsquarefreeBounds.LowDegreePowerSeries, `Formalism.CyclotomicNorms.NonsquarefreeBounds.Newton, `Formalism.CyclotomicNorms.NonsquarefreeBounds.NonsquarefreeMonicBoundHolds, `Formalism.CyclotomicNorms.NonsquarefreeBounds.ResModule, `Formalism.CyclotomicNorms.NonsquarefreeBounds.SpanQuadraticOfImage, `Formalism.CyclotomicNorms.NonsquarefreeBounds.SubstitutionBound, `Formalism.CyclotomicNorms.NonsquarefreeBounds.TwoMulNumDerangementsLeFactorial, `Formalism.CyclotomicNorms.StatementT, `Formalism.CyclotomicNorms.TWAbsUniform, `Formalism.DegreeFormula.PointDegree.FlagDeg, `Formalism.DegreeFormula.PointDegree.PermExpInj, `Formalism.DistinguishedUnitIdeals.CoprimeProd, `Formalism.DistinguishedUnitIdeals.IsCocycle, `Formalism.DistinguishedUnitIdeals.UnivPart, `Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.DoubleCosetEqPreimage, `Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.ExistsContinuousLowerUpperEntry, `Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.IsIntOfLatOfLe, `Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.IsOpenIsIntSet, `Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.LowUniMulVecELast, `Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.MulInvBlockDiagApplySameBlock, `Formalism.DoubleCosetMeasures.LowerUnipotentOrbits.TwoSided, `Formalism.DoubleCosetMeasures.StatementZ, `Formalism.EisensteinCokernelLengths.ExponentChainBound, `Formalism.EisensteinCokernelLengths.StatementLIFTV, `Formalism.EllipticTorsion.EllipticTorsionProofs.IsogenyExpansion, `Formalism.EllipticTorsion.WChordSeries, `Formalism.FilteredPoleLength.LocalDescentLevels.DetMulEqSumPrincipal, `Formalism.FilteredPoleLength.LocalDescentLevels.ExistsSumOfMemSpanImage, `Formalism.FilteredPoleLength.LocalDescentLevels.FourTermSumBoundOfParameters, `Formalism.FilteredPoleLength.LocalDescentLevels.GAdjugateNormBound, `Formalism.FilteredPoleLength.LocalDescentLevels.IntegralMulExpNegSq, `Formalism.FilteredPoleLength.LocalDescentLevels.MinimumChainBounds, `Formalism.FilteredPoleLength.ReducedBasisBounds.BetaSesquilinearity, `Formalism.FilteredPoleLength.ReducedBasisBounds.FilteredPoleLength, `Formalism.FilteredPoleLength.ReducedBasisBounds.ReductionQuotient, `Formalism.FlagUnipotentLattices.CardSubmodulesAndLinearEquivBounds]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

