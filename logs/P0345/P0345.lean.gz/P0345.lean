import Lean
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.RigidityTheorems.DiagSubIsKIrrHW
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.ExponentConditionNeg
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.TailFinOf
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.CsqDdPt
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.LowFockA
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.Residue
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.Transported
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ExistsTeichmullerRepModPrime
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModEvalSer
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModFrobSer
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModLocC
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModLocD
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModPerm
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModPrincNorm
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModQPrin
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModSepInt
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModVanish
import ReciprocityTheory.SemistableReduction.AlgAll
import ReciprocityTheory.SemistableReduction.ApproxGraph
import ReciprocityTheory.SemistableReduction.HeightLowerBound
import ReciprocityTheory.SemistableReduction.SJCore
import ReciprocityTheory.SemistableReduction.SemiDegAB
import ReciprocityTheory.SemistableReduction.SemiDegBB
import ReciprocityTheory.SemistableReduction.SemiDegCE
import ReciprocityTheory.SemistableReduction.SemiDegD
import ReciprocityTheory.SemistableReduction.SemiDegF
import ReciprocityTheory.SemistableReduction.TorusMean

open Lean Elab Command

def auditTargets : Array Name := #[`ReciprocityTheory.ReductiveGroups.DiscreteSeries.RigidityTheorems.DiagSubIsKIrrHW, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.ExponentConditionNeg, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TailIntegrals.TailFinOf, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.CsqDdPt, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.LowFockA, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.Residue, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.Transported, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ExistsTeichmullerRepModPrime, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModEvalSer, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModFrobSer, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModLocC, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModLocD, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModPerm, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModPrincNorm, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModQPrin, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModSepInt, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModVanish, `ReciprocityTheory.SemistableReduction.AlgAll, `ReciprocityTheory.SemistableReduction.ApproxGraph, `ReciprocityTheory.SemistableReduction.HeightLowerBound, `ReciprocityTheory.SemistableReduction.SJCore, `ReciprocityTheory.SemistableReduction.SemiDegAB, `ReciprocityTheory.SemistableReduction.SemiDegBB, `ReciprocityTheory.SemistableReduction.SemiDegCE, `ReciprocityTheory.SemistableReduction.SemiDegD, `ReciprocityTheory.SemistableReduction.SemiDegF, `ReciprocityTheory.SemistableReduction.TorusMean]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

