import Lean
import GroundTheory.AutomorphicForms.AffineBruhat
import GroundTheory.AutomorphicForms.Cartan
import GroundTheory.AutomorphicForms.CuspidalDiscreteness.Counting
import GroundTheory.AutomorphicForms.DiscreteSpectrumAbstract
import GroundTheory.AutomorphicForms.DixmierMalliavinHaar
import GroundTheory.AutomorphicForms.DixmierMalliavinLine
import GroundTheory.AutomorphicForms.DixmierMalliavinProducts
import GroundTheory.AutomorphicForms.DixmierMalliavinSeries
import GroundTheory.AutomorphicForms.GKModules.GKModule
import GroundTheory.AutomorphicForms.GKModules.Garding
import GroundTheory.AutomorphicForms.GKModules.RightRegular
import GroundTheory.AutomorphicForms.HarishChandraCentre.Triangular
import GroundTheory.AutomorphicForms.HeckeAlgebra
import GroundTheory.AutomorphicForms.HermitianWitt
import GroundTheory.AutomorphicForms.Iwasawa
import GroundTheory.AutomorphicForms.MeasuresChart
import GroundTheory.AutomorphicForms.PartialDifferential.SobolevFriedrichs
import GroundTheory.AutomorphicForms.RealGroupsIwasawaHaar
import GroundTheory.AutomorphicForms.StableConjTorus
import GroundTheory.AutomorphicForms.TensorProductTheorem.LocalComponent
import GroundTheory.AutomorphicForms.TensorProductTheorem.Smooth
import GroundTheory.AutomorphicForms.TraceStrongLimit
import GroundTheory.AutomorphicForms.UnitaryGroupEquations
import GroundTheory.AutomorphicForms.UnitarySplit
import GroundTheory.AutomorphicForms.WhittakerOrbit
import GroundTheory.Brauer.CrossedProductInj
import GroundTheory.Brauer.CrossedProductRegular
import GroundTheory.Brauer.Splitting
import GroundTheory.FunctionField.PlaceSum
import GroundTheory.FunctionField.ValuationAevalSubCoeffZeroLe
import GroundTheory.GlobalFields.Adele.Compact
import GroundTheory.GlobalFields.Adele.IdeleBasis
import GroundTheory.GlobalFields.Artin.MackeyFrobenius
import GroundTheory.GlobalFields.CompletionAtPlace.Integers
import GroundTheory.GlobalFields.ComplexMultiplication.EllipticDegree
import GroundTheory.GlobalFields.ComplexMultiplication.IdeleActionQuotient
import GroundTheory.GlobalFields.CyclotomicCharacters.ClosedSubgroups
import GroundTheory.GlobalFields.CyclotomicCharacters.PadicUnitsLog
import GroundTheory.GlobalFields.HerbrandQuotients.LatticeBridge
import GroundTheory.GlobalFields.IdeleGroups.IndexFormula
import GroundTheory.GlobalFields.IdeleGroups.LocalConditionIndex
import GroundTheory.GlobalFields.IdeleGroups.Rational
import GroundTheory.GlobalFields.IdeleGroups.SIdeleHerbrand.Product
import GroundTheory.GlobalFields.KummerTheory.Degree
import GroundTheory.GlobalFields.KummerTheory.KummerIndexLemma.HasEnoughRootsOfUnityOfRingHom
import GroundTheory.GlobalFields.SemilocalAlgebras.Galois
import GroundTheory.GlobalFields.SemilocalAlgebras.NormTrace
import GroundTheory.GlobalFields.TateThesis.AdelicCharLocal
import GroundTheory.GlobalFields.TateThesis.ConductorIdeal
import GroundTheory.GlobalFields.TateThesis.TraceDualLattice
import GroundTheory.HeightsAndTheta.Heights.Antisymmetric.LocallyFreeSpreadHyp
import GroundTheory.HeightsAndTheta.Heights.Antisymmetric.StatementsGluing
import GroundTheory.HeightsAndTheta.Heights.Antisymmetric.StatementsNefRelabel
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ChowFormHomog
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.HeightMul
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LogIntSphere
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LowerBoundConditional
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PClosedPointConeCoord
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeFsLogIntegrable
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeHyperplaneNull
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeIntegralMass
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeMapArea
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeMeetNull
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PDominantPrimitiveFibres

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.AutomorphicForms.AffineBruhat, `GroundTheory.AutomorphicForms.Cartan, `GroundTheory.AutomorphicForms.CuspidalDiscreteness.Counting, `GroundTheory.AutomorphicForms.DiscreteSpectrumAbstract, `GroundTheory.AutomorphicForms.DixmierMalliavinHaar, `GroundTheory.AutomorphicForms.DixmierMalliavinLine, `GroundTheory.AutomorphicForms.DixmierMalliavinProducts, `GroundTheory.AutomorphicForms.DixmierMalliavinSeries, `GroundTheory.AutomorphicForms.GKModules.GKModule, `GroundTheory.AutomorphicForms.GKModules.Garding, `GroundTheory.AutomorphicForms.GKModules.RightRegular, `GroundTheory.AutomorphicForms.HarishChandraCentre.Triangular, `GroundTheory.AutomorphicForms.HeckeAlgebra, `GroundTheory.AutomorphicForms.HermitianWitt, `GroundTheory.AutomorphicForms.Iwasawa, `GroundTheory.AutomorphicForms.MeasuresChart, `GroundTheory.AutomorphicForms.PartialDifferential.SobolevFriedrichs, `GroundTheory.AutomorphicForms.RealGroupsIwasawaHaar, `GroundTheory.AutomorphicForms.StableConjTorus, `GroundTheory.AutomorphicForms.TensorProductTheorem.LocalComponent, `GroundTheory.AutomorphicForms.TensorProductTheorem.Smooth, `GroundTheory.AutomorphicForms.TraceStrongLimit, `GroundTheory.AutomorphicForms.UnitaryGroupEquations, `GroundTheory.AutomorphicForms.UnitarySplit, `GroundTheory.AutomorphicForms.WhittakerOrbit, `GroundTheory.Brauer.CrossedProductInj, `GroundTheory.Brauer.CrossedProductRegular, `GroundTheory.Brauer.Splitting, `GroundTheory.FunctionField.PlaceSum, `GroundTheory.FunctionField.ValuationAevalSubCoeffZeroLe, `GroundTheory.GlobalFields.Adele.Compact, `GroundTheory.GlobalFields.Adele.IdeleBasis, `GroundTheory.GlobalFields.Artin.MackeyFrobenius, `GroundTheory.GlobalFields.CompletionAtPlace.Integers, `GroundTheory.GlobalFields.ComplexMultiplication.EllipticDegree, `GroundTheory.GlobalFields.ComplexMultiplication.IdeleActionQuotient, `GroundTheory.GlobalFields.CyclotomicCharacters.ClosedSubgroups, `GroundTheory.GlobalFields.CyclotomicCharacters.PadicUnitsLog, `GroundTheory.GlobalFields.HerbrandQuotients.LatticeBridge, `GroundTheory.GlobalFields.IdeleGroups.IndexFormula, `GroundTheory.GlobalFields.IdeleGroups.LocalConditionIndex, `GroundTheory.GlobalFields.IdeleGroups.Rational, `GroundTheory.GlobalFields.IdeleGroups.SIdeleHerbrand.Product, `GroundTheory.GlobalFields.KummerTheory.Degree, `GroundTheory.GlobalFields.KummerTheory.KummerIndexLemma.HasEnoughRootsOfUnityOfRingHom, `GroundTheory.GlobalFields.SemilocalAlgebras.Galois, `GroundTheory.GlobalFields.SemilocalAlgebras.NormTrace, `GroundTheory.GlobalFields.TateThesis.AdelicCharLocal, `GroundTheory.GlobalFields.TateThesis.ConductorIdeal, `GroundTheory.GlobalFields.TateThesis.TraceDualLattice, `GroundTheory.HeightsAndTheta.Heights.Antisymmetric.LocallyFreeSpreadHyp, `GroundTheory.HeightsAndTheta.Heights.Antisymmetric.StatementsGluing, `GroundTheory.HeightsAndTheta.Heights.Antisymmetric.StatementsNefRelabel, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ChowFormHomog, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.HeightMul, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LogIntSphere, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LowerBoundConditional, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PClosedPointConeCoord, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeFsLogIntegrable, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeHyperplaneNull, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeIntegralMass, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeMapArea, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeMeetNull, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PDominantPrimitiveFibres]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

