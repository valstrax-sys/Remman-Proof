import Lean
import GroundTheory.TateCohomology.InfRes
import GroundTheory.TateCohomology.TateLow
import Lemmata.MiscLemmasF.Imports
import PositivityTheory.AutomorphicForms.PublishedInputs.BorelInjectivity.EquivariantProjections.ExistsEquivariantProjOfLeSumIrreducible
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ARpowHalfSq
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ActionIntegralSwapProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.BNeg
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.CayleyTransformProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.CountingMeasureInvarianceProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.DiagonalIntegrandVanishesProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ExistsFix
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ExtendMatrixByIdentityAlongIndicesMul
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.FiniteSystemProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.HalfPlaneMeasureInvariantProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.HyperbolicBallVolumeProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.HyperbolicKappaPropertiesProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.Imports
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.InverseSeriesSummable
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.MultivariableReproducingFormula
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfLinTr
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.RSubPowApply
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.RadialIntegralUnitCircleEq
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.UpperHalfPlaneCoordinatesProof
import PositivityTheory.PublishedTheorems.WeilRepresentations.ZariskiDensity.QiCoreDefs
import ReciprocityTheory.AnalyticForms.AnalyticCharts.MaDensCompEqZeroOfRankLt
import ReciprocityTheory.AnalyticForms.AnalyticCharts.Osgood
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.ComplexHessianIsHermitianOfContDiffAt
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.CovLog
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.GreenOfPoincareLelongHyperplane
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.GreenSt
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.IsPshLocallyIntegrableStatement
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.LogInt
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.MdiscPos
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PartsSt
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshExtA
import ReciprocityTheory.AnalyticForms.PotentialTheory.IntegralIoiFsDensRadial
import ReciprocityTheory.AnalyticForms.PotentialTheory.IsPotentialOfFun
import ReciprocityTheory.AnalyticForms.PotentialTheory.PshShiftA
import ReciprocityTheory.AnalyticForms.RegularLocalRings.DivSheafA
import ReciprocityTheory.AnalyticForms.RegularLocalRings.FinTypeQE
import ReciprocityTheory.AnalyticForms.RegularLocalRings.JacChartA
import ReciprocityTheory.AnalyticForms.RegularLocalRings.LogResStC
import ReciprocityTheory.AnalyticForms.RegularLocalRings.RegDom
import ReciprocityTheory.Automorphisms.SplitCoeAlgebraMap
import ReciprocityTheory.BasicDefinitions.AdRep
import ReciprocityTheory.Chebotarev.CasimirPowerSurjectiveSymmetric
import ReciprocityTheory.Chebotarev.CycOrth
import ReciprocityTheory.Chebotarev.CycTail
import ReciprocityTheory.Chebotarev.EulerFac
import ReciprocityTheory.Chebotarev.EulerSum
import ReciprocityTheory.Chebotarev.ExistsUnitOrderOfEq
import ReciprocityTheory.Chebotarev.SplitDef
import ReciprocityTheory.Chebotarev.Ucoord
import ReciprocityTheory.ClassFieldTheory.GlobalClassField.AsGabLim
import ReciprocityTheory.ClassFieldTheory.GlobalClassField.IsFrobAtMulOfMemInertiaGroup
import ReciprocityTheory.ClassFieldTheory.LocalClassField.HerbrandB
import ReciprocityTheory.ClassFieldTheory.LocalClassField.UnitsHerbrandB
import ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.ModDepthGE
import ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.RegGens
import ReciprocityTheory.CommutativeAlgebra.PolynomialHeights.PolyMax
import ReciprocityTheory.CommutativeAlgebra.PolynomialHeights.PolyStep
import ReciprocityTheory.CommutativeAlgebra.PowerSeriesPresentations.PresentationStatement
import ReciprocityTheory.CommutativeAlgebra.SaturatedChains.IsSaturatedChain
import ReciprocityTheory.CommutativeAlgebra.WeakRegularity.GorIndepStatement

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.TateCohomology.InfRes, `GroundTheory.TateCohomology.TateLow, `Lemmata.MiscLemmasF.Imports, `PositivityTheory.AutomorphicForms.PublishedInputs.BorelInjectivity.EquivariantProjections.ExistsEquivariantProjOfLeSumIrreducible, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ARpowHalfSq, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ActionIntegralSwapProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.BNeg, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.CayleyTransformProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.CountingMeasureInvarianceProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.DiagonalIntegrandVanishesProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ExistsFix, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ExtendMatrixByIdentityAlongIndicesMul, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.FiniteSystemProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.HalfPlaneMeasureInvariantProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.HyperbolicBallVolumeProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.HyperbolicKappaPropertiesProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.Imports, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.InverseSeriesSummable, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.MultivariableReproducingFormula, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfLinTr, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.RSubPowApply, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.RadialIntegralUnitCircleEq, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.UpperHalfPlaneCoordinatesProof, `PositivityTheory.PublishedTheorems.WeilRepresentations.ZariskiDensity.QiCoreDefs, `ReciprocityTheory.AnalyticForms.AnalyticCharts.MaDensCompEqZeroOfRankLt, `ReciprocityTheory.AnalyticForms.AnalyticCharts.Osgood, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.ComplexHessianIsHermitianOfContDiffAt, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.CovLog, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.GreenOfPoincareLelongHyperplane, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.GreenSt, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.IsPshLocallyIntegrableStatement, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.LogInt, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.MdiscPos, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PartsSt, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshExtA, `ReciprocityTheory.AnalyticForms.PotentialTheory.IntegralIoiFsDensRadial, `ReciprocityTheory.AnalyticForms.PotentialTheory.IsPotentialOfFun, `ReciprocityTheory.AnalyticForms.PotentialTheory.PshShiftA, `ReciprocityTheory.AnalyticForms.RegularLocalRings.DivSheafA, `ReciprocityTheory.AnalyticForms.RegularLocalRings.FinTypeQE, `ReciprocityTheory.AnalyticForms.RegularLocalRings.JacChartA, `ReciprocityTheory.AnalyticForms.RegularLocalRings.LogResStC, `ReciprocityTheory.AnalyticForms.RegularLocalRings.RegDom, `ReciprocityTheory.Automorphisms.SplitCoeAlgebraMap, `ReciprocityTheory.BasicDefinitions.AdRep, `ReciprocityTheory.Chebotarev.CasimirPowerSurjectiveSymmetric, `ReciprocityTheory.Chebotarev.CycOrth, `ReciprocityTheory.Chebotarev.CycTail, `ReciprocityTheory.Chebotarev.EulerFac, `ReciprocityTheory.Chebotarev.EulerSum, `ReciprocityTheory.Chebotarev.ExistsUnitOrderOfEq, `ReciprocityTheory.Chebotarev.SplitDef, `ReciprocityTheory.Chebotarev.Ucoord, `ReciprocityTheory.ClassFieldTheory.GlobalClassField.AsGabLim, `ReciprocityTheory.ClassFieldTheory.GlobalClassField.IsFrobAtMulOfMemInertiaGroup, `ReciprocityTheory.ClassFieldTheory.LocalClassField.HerbrandB, `ReciprocityTheory.ClassFieldTheory.LocalClassField.UnitsHerbrandB, `ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.ModDepthGE, `ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.RegGens, `ReciprocityTheory.CommutativeAlgebra.PolynomialHeights.PolyMax, `ReciprocityTheory.CommutativeAlgebra.PolynomialHeights.PolyStep, `ReciprocityTheory.CommutativeAlgebra.PowerSeriesPresentations.PresentationStatement, `ReciprocityTheory.CommutativeAlgebra.SaturatedChains.IsSaturatedChain, `ReciprocityTheory.CommutativeAlgebra.WeakRegularity.GorIndepStatement]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

