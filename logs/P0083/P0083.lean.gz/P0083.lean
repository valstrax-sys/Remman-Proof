import Lean
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLengthLocalizedLocalized
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLengthLocalizedQuotient
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLocalizationAtPrimeQuotient
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLocalizeQuotientStages
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNonIsolatedFibreCurve
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalModel
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StParametricCircleIntegralAnalytic
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPerfectFieldExtensionFormallySmooth
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPolyKaehlerFree
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPolynomialChartInjective
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPolynomialRootPredicateFactor
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPowerSumsEsymmAnalytic
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimitiveFormRemainder
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProjDimSpread
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProperHolomorphicSurjective
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProperOpenProjectionBranchLocus
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProperOpenProjectionCover
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProperOpenProjectionLocalCover
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProperOpenProjectionLocalUnbranched
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProperSheetedFibreEsymm
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRankDeficientFibreInfinite
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRegularSequenceLengthLeDim
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRemovableHyperplane
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRiemannExtensionAnalytic
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRiemannExtensionPolynomial
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRootSumHolomorphic
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRueckertNullstellensatz
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSeparateWeierstrassDivision
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSimpleRootBranch
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSliceMatricesOpen
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StTubeDeepWeightMass
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StUnbranchedProperCountConstant
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StUnbranchedProperCountLocallyConstant
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StUnitaryZariskiDense
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StWeierstrassFiniteness
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StWeightedAreaFormula
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.Statements
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StatementsPowerUnitCount
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.CutoffModelMinMeasurable
import GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.Statements
import GroundTheory.HeightsAndTheta.Heights.CovolumeGram
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.Objects
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsAdjoinTrdegAdd
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsDimensionInequality
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsDimensionInequalitySteps
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsMaxHeight
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsPowReductionCut
import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsReesAlgebraDim
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.JetOfMonomialSumStatement
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PConstants
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PCurvature
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.StatementsLocUnifAnalytic
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.StatementsShare
import GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.StatementsShellPolar
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.GramDetSandwich
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PDivisionNearSLocal
import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.StatementsLaplacianHoloComp
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.LengthSumLocalizations
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.NoetherCharPLemmas
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.NoetherReduction
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsFiniteAlgebraLengthSum
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsLocalizedQuotientLength
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsNoetherIntegralClosure
import GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.PStabilizerLeviMatrices

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLengthLocalizedLocalized, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLengthLocalizedQuotient, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLocalizationAtPrimeQuotient, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLocalizeQuotientStages, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNonIsolatedFibreCurve, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StNormalModel, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StParametricCircleIntegralAnalytic, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPerfectFieldExtensionFormallySmooth, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPolyKaehlerFree, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPolynomialChartInjective, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPolynomialRootPredicateFactor, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPowerSumsEsymmAnalytic, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimitiveFormRemainder, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProjDimSpread, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProperHolomorphicSurjective, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProperOpenProjectionBranchLocus, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProperOpenProjectionCover, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProperOpenProjectionLocalCover, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProperOpenProjectionLocalUnbranched, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProperSheetedFibreEsymm, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRankDeficientFibreInfinite, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRegularSequenceLengthLeDim, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRemovableHyperplane, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRiemannExtensionAnalytic, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRiemannExtensionPolynomial, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRootSumHolomorphic, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StRueckertNullstellensatz, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSeparateWeierstrassDivision, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSimpleRootBranch, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSliceMatricesOpen, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StTubeDeepWeightMass, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StUnbranchedProperCountConstant, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StUnbranchedProperCountLocallyConstant, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StUnitaryZariskiDense, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StWeierstrassFiniteness, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StWeightedAreaFormula, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.Statements, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StatementsPowerUnitCount, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.CutoffModelMinMeasurable, `GroundTheory.HeightsAndTheta.Heights.CountingLowerBound.Statements, `GroundTheory.HeightsAndTheta.Heights.CovolumeGram, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.Objects, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsAdjoinTrdegAdd, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsDimensionInequality, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsDimensionInequalitySteps, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsMaxHeight, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsPowReductionCut, `GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsReesAlgebraDim, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.JetOfMonomialSumStatement, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PConstants, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.PCurvature, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.StatementsLocUnifAnalytic, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.StatementsShare, `GroundTheory.HeightsAndTheta.Heights.EffectiveHilbertSamuel.StatementsShellPolar, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.GramDetSandwich, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PDivisionNearSLocal, `GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.StatementsLaplacianHoloComp, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.LengthSumLocalizations, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.NoetherCharPLemmas, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.NoetherReduction, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsFiniteAlgebraLengthSum, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsLocalizedQuotientLength, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.StatementsNoetherIntegralClosure, `GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.PStabilizerLeviMatrices]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

