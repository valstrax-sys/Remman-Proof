import Lean
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.EndomorphismPullbackRigid
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.PerfectPairings
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.KernelCharacterDelta
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.OnePlusPowerAssembly
import Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.PluriharmonicHolomorphic
import Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.RealPointModes
import Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.TorusMarkingPhase
import Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.TorusThetaNorms
import Development.AbelianVarietyTheory.BlockTheory.SiegelWeilLocal.SiegelWeilGramDensity
import Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.GL2CharacterZeros
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.PlusPolynomialInclusion
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.SemilinearExtensionBases
import Development.AbelianVarietyTheory.Counterexamples.AdelicSplittingExamples.LfacDenominatorNeZero
import Development.AbelianVarietyTheory.Counterexamples.AdelicSplittingExamples.LocalConditionsOfGlobal
import Development.AbelianVarietyTheory.Counterexamples.DegenerateExamples.ExistsStrictAnti
import Development.AbelianVarietyTheory.Counterexamples.DegenerateExamples.PremisesModel
import Development.AbelianVarietyTheory.Counterexamples.JetSurvey.LowKAddStrictAnti
import Development.AbelianVarietyTheory.Counterexamples.LevelGroupExamples.ChosenEqOfAllRules
import Development.AbelianVarietyTheory.Counterexamples.LevelGroupExamples.JetTruncNotInjective
import Development.AbelianVarietyTheory.Counterexamples.UpperHalfSurvey.WeightEqZeroOfOneIsSec
import Development.AbelianVarietyTheory.Definitions.AdelicHermitianForms.IsHermForm
import Development.AbelianVarietyTheory.Definitions.AdelicHermitianForms.MemPowSub
import Development.AbelianVarietyTheory.Definitions.AdelicHermitianForms.NontrivialTransvection
import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.IsClosedFlagsIff
import Development.AbelianVarietyTheory.Definitions.CommutativeAlgebra.CompletionDVR
import Development.AbelianVarietyTheory.Definitions.Divisors.CircleAsphGNontrivial
import Development.AbelianVarietyTheory.Definitions.Divisors.EllFamNontrivial
import Development.AbelianVarietyTheory.Definitions.Divisors.ExistsAlgHomOfIsBaseChange
import Development.AbelianVarietyTheory.Definitions.Divisors.HilbertNinetyQuotientHomEqIff
import Development.AbelianVarietyTheory.Definitions.Divisors.IsFlatLift
import Development.AbelianVarietyTheory.Definitions.Divisors.IsKMOne
import Development.AbelianVarietyTheory.Definitions.Divisors.LeTwoMulOfForallScale
import Development.AbelianVarietyTheory.Definitions.Divisors.LogAbsVpOfNormalised
import Development.AbelianVarietyTheory.Definitions.Divisors.MemShaKernelIffLocallyTrivial
import Development.AbelianVarietyTheory.Definitions.Divisors.OrthSubrepresentation
import Development.AbelianVarietyTheory.Definitions.Divisors.PointHeight
import Development.AbelianVarietyTheory.Definitions.Divisors.SubsingletonComplex
import Development.AbelianVarietyTheory.Definitions.Divisors.ZeroMemSolSet
import Development.AbelianVarietyTheory.Definitions.Divisors.ZetaActRefl
import Development.AbelianVarietyTheory.Definitions.ExistenceOfLattices.SmulBasisMemHatIff
import Development.AbelianVarietyTheory.Definitions.Foundations.AltCoeffRho
import Development.AbelianVarietyTheory.Definitions.Foundations.CurveCl
import Development.AbelianVarietyTheory.Definitions.Foundations.DiagUnitsEqLocalIdele
import Development.AbelianVarietyTheory.Definitions.Foundations.EtaSixProductDifferentiable
import Development.AbelianVarietyTheory.Definitions.Foundations.Imports
import Development.AbelianVarietyTheory.Definitions.Foundations.IsHilbertSchmidtOfFiniteDimensional
import Development.AbelianVarietyTheory.Definitions.Foundations.IsIwasawaOfIsCompact
import Development.AbelianVarietyTheory.Definitions.Foundations.IsSatFrame
import Development.AbelianVarietyTheory.Definitions.Foundations.IsTopWTopWOfExists
import Development.AbelianVarietyTheory.Definitions.Foundations.Letter
import Development.AbelianVarietyTheory.Definitions.Foundations.LocallyConstantTwoCochain
import Development.AbelianVarietyTheory.Definitions.Foundations.Mdl
import Development.AbelianVarietyTheory.Definitions.Foundations.MultipliableAndSgNeZero
import Development.AbelianVarietyTheory.Definitions.Foundations.NotIsTrDataGaussianIntOne
import Development.AbelianVarietyTheory.Definitions.Foundations.PetIPSmulRight
import Development.AbelianVarietyTheory.Definitions.Foundations.PieceEqPieceT
import Development.AbelianVarietyTheory.Definitions.Foundations.SecondCountableAndT2LocalField
import Development.AbelianVarietyTheory.Definitions.Foundations.SimpleSum
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.CohomZeroEquivContinuous
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsDPMorphismBot
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsSepClosedResidueFieldPowerSeriesComplex
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsStrictlySemistableAlt
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.PolyApproxZeroPadic
import Development.AbelianVarietyTheory.Definitions.GlobalTwisting.LinkExactAff

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.BlockTheory.JetGauges.EndomorphismPullbackRigid, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.PerfectPairings, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.KernelCharacterDelta, `Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.OnePlusPowerAssembly, `Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.PluriharmonicHolomorphic, `Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.RealPointModes, `Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.TorusMarkingPhase, `Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.TorusThetaNorms, `Development.AbelianVarietyTheory.BlockTheory.SiegelWeilLocal.SiegelWeilGramDensity, `Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.GL2CharacterZeros, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.PlusPolynomialInclusion, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.SemilinearExtensionBases, `Development.AbelianVarietyTheory.Counterexamples.AdelicSplittingExamples.LfacDenominatorNeZero, `Development.AbelianVarietyTheory.Counterexamples.AdelicSplittingExamples.LocalConditionsOfGlobal, `Development.AbelianVarietyTheory.Counterexamples.DegenerateExamples.ExistsStrictAnti, `Development.AbelianVarietyTheory.Counterexamples.DegenerateExamples.PremisesModel, `Development.AbelianVarietyTheory.Counterexamples.JetSurvey.LowKAddStrictAnti, `Development.AbelianVarietyTheory.Counterexamples.LevelGroupExamples.ChosenEqOfAllRules, `Development.AbelianVarietyTheory.Counterexamples.LevelGroupExamples.JetTruncNotInjective, `Development.AbelianVarietyTheory.Counterexamples.UpperHalfSurvey.WeightEqZeroOfOneIsSec, `Development.AbelianVarietyTheory.Definitions.AdelicHermitianForms.IsHermForm, `Development.AbelianVarietyTheory.Definitions.AdelicHermitianForms.MemPowSub, `Development.AbelianVarietyTheory.Definitions.AdelicHermitianForms.NontrivialTransvection, `Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.IsClosedFlagsIff, `Development.AbelianVarietyTheory.Definitions.CommutativeAlgebra.CompletionDVR, `Development.AbelianVarietyTheory.Definitions.Divisors.CircleAsphGNontrivial, `Development.AbelianVarietyTheory.Definitions.Divisors.EllFamNontrivial, `Development.AbelianVarietyTheory.Definitions.Divisors.ExistsAlgHomOfIsBaseChange, `Development.AbelianVarietyTheory.Definitions.Divisors.HilbertNinetyQuotientHomEqIff, `Development.AbelianVarietyTheory.Definitions.Divisors.IsFlatLift, `Development.AbelianVarietyTheory.Definitions.Divisors.IsKMOne, `Development.AbelianVarietyTheory.Definitions.Divisors.LeTwoMulOfForallScale, `Development.AbelianVarietyTheory.Definitions.Divisors.LogAbsVpOfNormalised, `Development.AbelianVarietyTheory.Definitions.Divisors.MemShaKernelIffLocallyTrivial, `Development.AbelianVarietyTheory.Definitions.Divisors.OrthSubrepresentation, `Development.AbelianVarietyTheory.Definitions.Divisors.PointHeight, `Development.AbelianVarietyTheory.Definitions.Divisors.SubsingletonComplex, `Development.AbelianVarietyTheory.Definitions.Divisors.ZeroMemSolSet, `Development.AbelianVarietyTheory.Definitions.Divisors.ZetaActRefl, `Development.AbelianVarietyTheory.Definitions.ExistenceOfLattices.SmulBasisMemHatIff, `Development.AbelianVarietyTheory.Definitions.Foundations.AltCoeffRho, `Development.AbelianVarietyTheory.Definitions.Foundations.CurveCl, `Development.AbelianVarietyTheory.Definitions.Foundations.DiagUnitsEqLocalIdele, `Development.AbelianVarietyTheory.Definitions.Foundations.EtaSixProductDifferentiable, `Development.AbelianVarietyTheory.Definitions.Foundations.Imports, `Development.AbelianVarietyTheory.Definitions.Foundations.IsHilbertSchmidtOfFiniteDimensional, `Development.AbelianVarietyTheory.Definitions.Foundations.IsIwasawaOfIsCompact, `Development.AbelianVarietyTheory.Definitions.Foundations.IsSatFrame, `Development.AbelianVarietyTheory.Definitions.Foundations.IsTopWTopWOfExists, `Development.AbelianVarietyTheory.Definitions.Foundations.Letter, `Development.AbelianVarietyTheory.Definitions.Foundations.LocallyConstantTwoCochain, `Development.AbelianVarietyTheory.Definitions.Foundations.Mdl, `Development.AbelianVarietyTheory.Definitions.Foundations.MultipliableAndSgNeZero, `Development.AbelianVarietyTheory.Definitions.Foundations.NotIsTrDataGaussianIntOne, `Development.AbelianVarietyTheory.Definitions.Foundations.PetIPSmulRight, `Development.AbelianVarietyTheory.Definitions.Foundations.PieceEqPieceT, `Development.AbelianVarietyTheory.Definitions.Foundations.SecondCountableAndT2LocalField, `Development.AbelianVarietyTheory.Definitions.Foundations.SimpleSum, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.CohomZeroEquivContinuous, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsDPMorphismBot, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsSepClosedResidueFieldPowerSeriesComplex, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsStrictlySemistableAlt, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.PolyApproxZeroPadic, `Development.AbelianVarietyTheory.Definitions.GlobalTwisting.LinkExactAff]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

