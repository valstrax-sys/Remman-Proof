import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasHoloImmOfFiniteClosedCover
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasSumFourierSeriesOfExpDecayStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasTotalBiChains
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HeckeEisensteinWeightTwoQExpansion
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HeckeEisensteinZeroFrequencyPartIsSmoothHolomorphic
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HeckeFourierTermWirtingerWordDifferentiableOn
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianMatrixColumnPairingAlgebraicProperties
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianMatrixColumnPairingDiagonalNorm
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HighDegreeInPowerSumIdeal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HilbertCoordinateMapBijectiveOfLeAffineStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HilbertEisensteinNonconstantTermsHasSum
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HodgeCurvatureDualMetricPointwiseBoundStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HodgeFrameFlagCurvatureStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HodgeFrameGramPositiveStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HodgeMetricGramMatrixLocalHolomorphicImPartStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HolomorphicConnectionAddSection
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HomogeneousMeasureEqSmulAddHaarLocalField
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HookQuotientCoefficientBoundStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HyperbolicFiniteVolumeIntegralBound
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HyperplaneFixerSumVanishesHarishChandraInductionStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HypersurfacePartGeometricIrreducibleSpreadsStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdealMapEqSpanPowUniformizerDvrStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdempotentMatrixLocalSplit
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsSideFurther
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsSideMore
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InCellIffDetNeZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InducedScalarIrreducible
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InductionFiniteLength
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InfinitePlaceCompletionNhdsNEZeroNeBotStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegrableHeckeTermDecayIntegrandStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegrableOnPeriodicFundamentalDomain
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralClosureOverGenericFibreHartogsStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralFunctionalExtension
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralZeroOfTwistedPeriodic
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InterpolatedConnectionDifference
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InterpolatedFormConstantFormula
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InterpolatedFormDichotomy
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InterpolatedMetricPositive
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InterpolationPositiveFrame
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvTransposeInvTranspose
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvariantFunctionalLargeRankVanishStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.InverseUnipotentVolumeConjDiagonalUnitsGLMul
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IrreducibleAnalyticInFiniteUnion
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAlgClosedFractionRingAtPrimeOfEtaleStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsClosedOfLocalIdealPointPropertyStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsDomainMonicRootsOfIsIndEtaleLocalStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsFamConstLevelOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsHilbertSchemeRepresentableOfOpenCover
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsIntegrallyClosedInClosureLocalizationStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsModularFormLevelOneOfInvariantQExpansion
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsOfFinOrderPicOfIsReducedFiniteIntStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsOpenStabilizerSchwartzBruhat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsReducedNormOfReducedNorm
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsSelfDualBicharacterPairingOfSymmBilinForm
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsSubquotSmIndCongr
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsZeroChains
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IterPrincipalSpec
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.JacTwistMapSurjective
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.KappaFormulaHookSchurStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.KerAffineHilbertTensorPullbackEqMap
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.KeyOriginRetractionLocalises
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LatticeCocycleZeroOfGeneratorsStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LeviBlocksParabolicInductionFiniteLength
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LimitsOfShiftFunctionals

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasHoloImmOfFiniteClosedCover, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasSumFourierSeriesOfExpDecayStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasTotalBiChains, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HeckeEisensteinWeightTwoQExpansion, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HeckeEisensteinZeroFrequencyPartIsSmoothHolomorphic, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HeckeFourierTermWirtingerWordDifferentiableOn, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianMatrixColumnPairingAlgebraicProperties, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianMatrixColumnPairingDiagonalNorm, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HighDegreeInPowerSumIdeal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HilbertCoordinateMapBijectiveOfLeAffineStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HilbertEisensteinNonconstantTermsHasSum, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HodgeCurvatureDualMetricPointwiseBoundStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HodgeFrameFlagCurvatureStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HodgeFrameGramPositiveStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HodgeMetricGramMatrixLocalHolomorphicImPartStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HolomorphicConnectionAddSection, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HomogeneousMeasureEqSmulAddHaarLocalField, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HookQuotientCoefficientBoundStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HyperbolicFiniteVolumeIntegralBound, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HyperplaneFixerSumVanishesHarishChandraInductionStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.HypersurfacePartGeometricIrreducibleSpreadsStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdealMapEqSpanPowUniformizerDvrStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IdempotentMatrixLocalSplit, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsSideFurther, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ImportsSideMore, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InCellIffDetNeZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InducedScalarIrreducible, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InductionFiniteLength, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InfinitePlaceCompletionNhdsNEZeroNeBotStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegrableHeckeTermDecayIntegrandStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegrableOnPeriodicFundamentalDomain, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralClosureOverGenericFibreHartogsStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralFunctionalExtension, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IntegralZeroOfTwistedPeriodic, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InterpolatedConnectionDifference, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InterpolatedFormConstantFormula, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InterpolatedFormDichotomy, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InterpolatedMetricPositive, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InterpolationPositiveFrame, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvTransposeInvTranspose, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InvariantFunctionalLargeRankVanishStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.InverseUnipotentVolumeConjDiagonalUnitsGLMul, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IrreducibleAnalyticInFiniteUnion, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsAlgClosedFractionRingAtPrimeOfEtaleStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsClosedOfLocalIdealPointPropertyStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsDomainMonicRootsOfIsIndEtaleLocalStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsFamConstLevelOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsHilbertSchemeRepresentableOfOpenCover, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsIntegrallyClosedInClosureLocalizationStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsModularFormLevelOneOfInvariantQExpansion, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsOfFinOrderPicOfIsReducedFiniteIntStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsOpenStabilizerSchwartzBruhat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsReducedNormOfReducedNorm, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsSelfDualBicharacterPairingOfSymmBilinForm, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsSubquotSmIndCongr, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsZeroChains, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.IterPrincipalSpec, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.JacTwistMapSurjective, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.KappaFormulaHookSchurStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.KerAffineHilbertTensorPullbackEqMap, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.KeyOriginRetractionLocalises, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LatticeCocycleZeroOfGeneratorsStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LeviBlocksParabolicInductionFiniteLength, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LimitsOfShiftFunctionals]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

