import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanRangeEmbeddingEqTop
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanRangeInfKerEqSpanRationalKer
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpecLocalHomFactorsAffineOpen
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpecTensorPreimmersion
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpecWidePushoutIsoWidePullbackYoneda
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpecializesLiftClosedFibreStalkBaseChange
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SqId
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SqScalarCharacterOfDoubleCoverUnitary
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SquareZeroDeformationFactorsThroughLinear
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.StabilizerEqCentralizer
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.StabilizerRelIndexNeZeroParabolic
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.StableComplementOfKernelExists
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.StalkMapFlatFormallyEtaleEssFiniteTypeOfEtaleRes
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.StandardEtaleMvPolynomialHypersurface
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.StepFunctionIndicatorSpan
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.StoneWeierstrassFiniteRep
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubMemPowSucc
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubNatCompSubIncl
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubRepApply
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubmoduleFgOfLocallyLeFg
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubsingletonOfAdicCompletionTensor
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubsingletonOfResidueFieldFibres
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubspaceAdaptedBasisChangeExists
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumBoundOfStepDiff
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumFourReorder
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumFourSwap
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumHadamardPosDefPosSemidef
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumInnerMulInnerProj
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumLeOfNonarch
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumLogDivSqPrimesTail
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumLogDivSubOneLeThreeMulLogAddOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumMemSpanRangeLeOfIsSimpleModule
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumNormEntriesMulLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumPadicValNatLogEqLog
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumTracePowMulSubMulPowTelescope
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumTranslatesEqDoubleCosetAverage
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumTransversalLeftTranslateInvariant
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SummableNormMulPowOfBounded
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SupMeas
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SupportOfQuotientFlatModule
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SymmetricFunctionInverseInvariant
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SymmetricTwoCocycleSumPowMul
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TailLogIntegralBoundOfDistribution
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TemperedFunctionalSeminormBound
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TendstoLintegralPoissonKernelBoundary
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TendstoRankDivPowOfChooseBounds
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TensorCentralizerInjectiveCommutantEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TensorInvolutionAlgebraProperties
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TensorPointsSeparate
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TensorQuotientOntoAndInjectiveModIdealPow
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TensorRatAlgebraDecompFactorwise
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThickFibIsPullback
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ToEndDApply
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TopologicalKrullDimAddOneLeOfSsubset
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TopologicalKrullDimDropAndFiniteOfDimZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionBasisRelationsDivisible
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionBySetPowFreeOfCardPowNumberField
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionCountLogConcavePrimePowers
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionCountMultiplicativePrimePowers
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionFreeOver
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionLiftNumberFieldModule
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionOfLocalizationFlat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionTwoGeneratorsGlobal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionTwoGeneratorsModPrime

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanRangeEmbeddingEqTop, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpanRangeInfKerEqSpanRationalKer, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpecLocalHomFactorsAffineOpen, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpecTensorPreimmersion, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpecWidePushoutIsoWidePullbackYoneda, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SpecializesLiftClosedFibreStalkBaseChange, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SqId, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SqScalarCharacterOfDoubleCoverUnitary, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SquareZeroDeformationFactorsThroughLinear, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.StabilizerEqCentralizer, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.StabilizerRelIndexNeZeroParabolic, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.StableComplementOfKernelExists, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.StalkMapFlatFormallyEtaleEssFiniteTypeOfEtaleRes, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.StandardEtaleMvPolynomialHypersurface, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.StepFunctionIndicatorSpan, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.StoneWeierstrassFiniteRep, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubMemPowSucc, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubNatCompSubIncl, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubRepApply, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubmoduleFgOfLocallyLeFg, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubsingletonOfAdicCompletionTensor, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubsingletonOfResidueFieldFibres, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SubspaceAdaptedBasisChangeExists, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumBoundOfStepDiff, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumFourReorder, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumFourSwap, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumHadamardPosDefPosSemidef, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumInnerMulInnerProj, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumLeOfNonarch, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumLogDivSqPrimesTail, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumLogDivSubOneLeThreeMulLogAddOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumMemSpanRangeLeOfIsSimpleModule, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumNormEntriesMulLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumPadicValNatLogEqLog, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumTracePowMulSubMulPowTelescope, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumTranslatesEqDoubleCosetAverage, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SumTransversalLeftTranslateInvariant, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SummableNormMulPowOfBounded, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SupMeas, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SupportOfQuotientFlatModule, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SymmetricFunctionInverseInvariant, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SymmetricTwoCocycleSumPowMul, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TailLogIntegralBoundOfDistribution, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TemperedFunctionalSeminormBound, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TendstoLintegralPoissonKernelBoundary, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TendstoRankDivPowOfChooseBounds, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TensorCentralizerInjectiveCommutantEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TensorInvolutionAlgebraProperties, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TensorPointsSeparate, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TensorQuotientOntoAndInjectiveModIdealPow, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TensorRatAlgebraDecompFactorwise, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThickFibIsPullback, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ToEndDApply, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TopologicalKrullDimAddOneLeOfSsubset, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TopologicalKrullDimDropAndFiniteOfDimZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionBasisRelationsDivisible, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionBySetPowFreeOfCardPowNumberField, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionCountLogConcavePrimePowers, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionCountMultiplicativePrimePowers, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionFreeOver, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionLiftNumberFieldModule, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionOfLocalizationFlat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionTwoGeneratorsGlobal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.TorsionTwoGeneratorsModPrime]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

