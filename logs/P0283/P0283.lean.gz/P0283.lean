import Lean
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PFiniteFibresDimLe
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PFundCycleBaseChange
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PHolomorphicImplicitGraph
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PPolyLocalGeneratorsDiff
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PPrimeQuasiFiniteSheets
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PProjSecDegree
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PThroughTwoPointsTrdeg
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.SectionLineAnyField
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.SphereMeanSlice
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChowDegreeSection
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChowFormBirationalAlgClosed
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChowFormSectionAlgClosed
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsConeFibreAverage
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsGraphAreaIntegral
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsMahler
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsProjChowNonzero
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsProjSecDomain
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSectionCycleReduced
import GroundTheory.HeightsAndTheta.Heights.ChowForms.ImportsBis
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PChartChoice
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PChartLength
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PChowFormBirational
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PEmultiplicityOrd
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PGenericLinearTrdeg
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PIncIdealBelow
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PLengthFiniteAlgebra
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PLocalizationPrimeDVR
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PSectionOrder
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PSpecFirstMemIncIdeal
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PSpecFirstNe
import GroundTheory.HeightsAndTheta.Heights.ChowForms.StatementsChartFirstGroup
import GroundTheory.HeightsAndTheta.Heights.ChowForms.StatementsChartIncOrd
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.AuslanderBuchsbaumDepthBound
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.EqZeroOfMemZeroLocusLineOriginIdeal
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.HolomorphicZerosNotIsolated
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.ImportsAlt
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.OsgoodSeparate
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAnalyticGermComponents
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAreaGraph
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAreaGraphBound
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PBranchContainsNormalPoint
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PConeAvoidsExists
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PConeAvoidsFinite
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PConeAvoidsOpen
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PCotangentBasisInPrime
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PDerivationAdicCompletion
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PDerivationCotangentIndependent
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteGermProjectionCover
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteModuloEliminate
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteModuloGeneralEquation
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjHomInjective
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjectionCluster
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjectionsContainOpen
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFlatNormalFibres
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFormalFibreQuotient
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFormalFibresRegular
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFormalFibresRegularPolynomial
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFrameJacobianSum
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFunctionFieldDegree
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericFreenessClosed
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGermMinimalPolynomialDivides
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGraphAreaHolomorphic
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PHomogDimZeroPow
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PIrreducibleFiniteGermProjectionOpenAt

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PFiniteFibresDimLe, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PFundCycleBaseChange, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PHolomorphicImplicitGraph, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PPolyLocalGeneratorsDiff, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PPrimeQuasiFiniteSheets, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PProjSecDegree, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PThroughTwoPointsTrdeg, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.SectionLineAnyField, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.SphereMeanSlice, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChowDegreeSection, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChowFormBirationalAlgClosed, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChowFormSectionAlgClosed, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsConeFibreAverage, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsGraphAreaIntegral, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsMahler, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsProjChowNonzero, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsProjSecDomain, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSectionCycleReduced, `GroundTheory.HeightsAndTheta.Heights.ChowForms.ImportsBis, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PChartChoice, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PChartLength, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PChowFormBirational, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PEmultiplicityOrd, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PGenericLinearTrdeg, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PIncIdealBelow, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PLengthFiniteAlgebra, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PLocalizationPrimeDVR, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PSectionOrder, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PSpecFirstMemIncIdeal, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PSpecFirstNe, `GroundTheory.HeightsAndTheta.Heights.ChowForms.StatementsChartFirstGroup, `GroundTheory.HeightsAndTheta.Heights.ChowForms.StatementsChartIncOrd, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.AuslanderBuchsbaumDepthBound, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.EqZeroOfMemZeroLocusLineOriginIdeal, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.HolomorphicZerosNotIsolated, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.ImportsAlt, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.OsgoodSeparate, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAnalyticGermComponents, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAreaGraph, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAreaGraphBound, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PBranchContainsNormalPoint, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PConeAvoidsExists, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PConeAvoidsFinite, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PConeAvoidsOpen, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PCotangentBasisInPrime, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PDerivationAdicCompletion, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PDerivationCotangentIndependent, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteGermProjectionCover, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteModuloEliminate, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteModuloGeneralEquation, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjHomInjective, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjectionCluster, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjectionsContainOpen, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFlatNormalFibres, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFormalFibreQuotient, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFormalFibresRegular, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFormalFibresRegularPolynomial, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFrameJacobianSum, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFunctionFieldDegree, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericFreenessClosed, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGermMinimalPolynomialDivides, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGraphAreaHolomorphic, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PHomogDimZeroPow, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PIrreducibleFiniteGermProjectionOpenAt]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

