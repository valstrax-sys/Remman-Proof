import Lean
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ResidueFieldIsAlgebraicOfEtale
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ResidueFieldIsoInvCompSpec
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ResidueFieldMapFiniteOfQuasiFinite
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.RiemannZetaNeZeroOfMemIoo
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.RightTranslationCurveSqLeAndIntegralDerivEqZeroA
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.RingKrullDimLtTopOfEssFiniteType
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SchurComplementBlockQuadraticLowerBound
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SchurOrthogonalitySubgroupMeasureOne
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SelfDualLatticeStandardAtRationalPrime
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SpanMkQOneTmul
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SpanValuationLe
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.StalkGenerizationGermCompat
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.StalkLocalizationEqGenerization
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SubrepTopToSubmodule
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SumLogEmbeddingAddFinsumLogAdicAbvEqZero
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SymmetricFormSumOfSquares
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.TendstoOfForallIntegral
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.TensorDomainBirational
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.TensorResidueUnramifiedFinite
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.TotalDegreeAevalLeOfLinear
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.TracePowEq
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.TrdegLeGenerators
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.TrdegResidueFieldEq
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.UnitaryFamilyEqCayleyOfSkewFamily
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.UnitriangularInductionTransvection
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.UpperTriangularMul
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ValuationPowSubPowLe
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.VecMulVecComm
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.CardFilterLeSuccAndSqSumLePow
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.CoeffProdXSubCNormLe
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ContDiffOnIffLocalExtension
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.DerivationMemPowOfMemPowSucc
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsCutIntoBoundedGroupsFinset
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsDualFormsOfSeparatedTypes
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsExtensionCharacter
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsIntCoordsOfRegularParam
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsIsLocalHomExtension
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsIsUnitSubOfRingHomNe
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsIsometryOfIntertwinerOfIrreducible
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsNormSubEqOne
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.GroupLikeIntegralOfFiniteFree
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.HomValueCongruentIntModPrime
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.Imports
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ImportsAlt
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.IteratedFDerivProdCoordAt
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.MeasurePreservingSnocMeasurableEquiv
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.MemLpAndTendstoIntegralInnerOfEventuallyEq
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.MemLpTwoAndTendstoOfCauchyOfAeTendsto
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.MonicEqProd
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.MvPowerSeriesCoeffEqZeroOfMulCoeffEqZero
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.NormEigenLePowMulNormSum
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.NormSqAdjointAddGeOfJointEigenspaces
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.NormSumEigenprojectorLeOfResolventBound
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.NotLeSqSup
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.PolarisationOnSubspace
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.PowSubSelfMemSpanOfSplitsCompletely
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ProdLeOfInterlacingPairing
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ReInnerLeOnImageOfIntertwining
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.SideSucc
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.SumEigenvectorsOfAevalProdLinearEqZero
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.SumNormAddSqLeOfBounds
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.SumPosOfTensorPos
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.SumPrimeLogDivPredLeLogAdd
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.SumStarProjectionEigenspaceEqSelfOfEigenvaluesLi

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ResidueFieldIsAlgebraicOfEtale, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ResidueFieldIsoInvCompSpec, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ResidueFieldMapFiniteOfQuasiFinite, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.RiemannZetaNeZeroOfMemIoo, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.RightTranslationCurveSqLeAndIntegralDerivEqZeroA, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.RingKrullDimLtTopOfEssFiniteType, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SchurComplementBlockQuadraticLowerBound, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SchurOrthogonalitySubgroupMeasureOne, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SelfDualLatticeStandardAtRationalPrime, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SpanMkQOneTmul, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SpanValuationLe, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.StalkGenerizationGermCompat, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.StalkLocalizationEqGenerization, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SubrepTopToSubmodule, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SumLogEmbeddingAddFinsumLogAdicAbvEqZero, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SymmetricFormSumOfSquares, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.TendstoOfForallIntegral, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.TensorDomainBirational, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.TensorResidueUnramifiedFinite, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.TotalDegreeAevalLeOfLinear, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.TracePowEq, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.TrdegLeGenerators, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.TrdegResidueFieldEq, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.UnitaryFamilyEqCayleyOfSkewFamily, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.UnitriangularInductionTransvection, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.UpperTriangularMul, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ValuationPowSubPowLe, `Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.VecMulVecComm, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.CardFilterLeSuccAndSqSumLePow, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.CoeffProdXSubCNormLe, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.ContDiffOnIffLocalExtension, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.DerivationMemPowOfMemPowSucc, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsCutIntoBoundedGroupsFinset, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsDualFormsOfSeparatedTypes, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsExtensionCharacter, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsIntCoordsOfRegularParam, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsIsLocalHomExtension, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsIsUnitSubOfRingHomNe, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsIsometryOfIntertwinerOfIrreducible, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsNormSubEqOne, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.GroupLikeIntegralOfFiniteFree, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.HomValueCongruentIntModPrime, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.Imports, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.ImportsAlt, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.IteratedFDerivProdCoordAt, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.MeasurePreservingSnocMeasurableEquiv, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.MemLpAndTendstoIntegralInnerOfEventuallyEq, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.MemLpTwoAndTendstoOfCauchyOfAeTendsto, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.MonicEqProd, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.MvPowerSeriesCoeffEqZeroOfMulCoeffEqZero, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.NormEigenLePowMulNormSum, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.NormSqAdjointAddGeOfJointEigenspaces, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.NormSumEigenprojectorLeOfResolventBound, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.NotLeSqSup, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.PolarisationOnSubspace, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.PowSubSelfMemSpanOfSplitsCompletely, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.ProdLeOfInterlacingPairing, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.ReInnerLeOnImageOfIntertwining, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.SideSucc, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.SumEigenvectorsOfAevalProdLinearEqZero, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.SumNormAddSqLeOfBounds, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.SumPosOfTensorPos, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.SumPrimeLogDivPredLeLogAdd, `Development.AbelianVarietyTheory.Proofs.JetHarmonics.SumStarProjectionEigenspaceEqSelfOfEigenvaluesLi]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

