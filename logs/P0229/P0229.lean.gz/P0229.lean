import Lean
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.ChartHessHolo
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PChartMassInvariant
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussConstant
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussDetFactor
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussDualMin
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussFourierSelf
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussLatticeCoords
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussLatticeCovolume
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussLatticeIsLattice
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussPacking
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussPoissonBound
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussPoissonDual
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussShell
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussShellSum
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussSqrt
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussTermBound
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussTop
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplBoxVolume
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplCons
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplDetBound
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplDetSchur
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplExtMem
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplExtVecMul
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplFirstRow
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplGcd
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplGramMem
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplMinBound
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplMinExists
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplMinkowskiBox
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplOmegaMem
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplOrbit
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplQuadDiag
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplReduceConj
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplReduceMem
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplReducePosDef
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplReduceStep
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplShortPrim
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplStep
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplTop
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplTwoRow
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaCharIntegral
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaConstants
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaCubeParseval
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaSummandNorm
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaTop
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StandardInnerSingleNe
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartCutoffEnergy
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartDensityIntegrable
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartEnergy
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartHessCompare
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartIbpSymm
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsLocallyPrincipalCoprime
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsOrderIdealIndexExtension
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsRest
import GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.Statements
import GroundTheory.HeightsAndTheta.Heights.HermitianEuclidean
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.BergmanObjects
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.GenericComplexPoint
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.PPieceCoefficientsHolomorphic
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.PPieceRootProductPolynomial
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PConjIntNum
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PHilbertModule
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PHilbertPrime
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PLeviCompHol

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.HeightKernels.ChartHessHolo, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PChartMassInvariant, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussConstant, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussDetFactor, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussDualMin, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussFourierSelf, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussLatticeCoords, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussLatticeCovolume, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussLatticeIsLattice, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussPacking, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussPoissonBound, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussPoissonDual, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussShell, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussShellSum, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussSqrt, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussTermBound, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGaussTop, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplBoxVolume, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplCons, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplDetBound, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplDetSchur, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplExtMem, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplExtVecMul, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplFirstRow, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplGcd, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplGramMem, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplMinBound, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplMinExists, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplMinkowskiBox, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplOmegaMem, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplOrbit, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplQuadDiag, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplReduceConj, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplReduceMem, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplReducePosDef, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplReduceStep, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplShortPrim, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplStep, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplTop, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PSymplTwoRow, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaCharIntegral, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaConstants, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaCubeParseval, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaSummandNorm, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaTop, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StandardInnerSingleNe, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartCutoffEnergy, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartDensityIntegrable, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartEnergy, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartHessCompare, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsChartIbpSymm, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsLocallyPrincipalCoprime, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsOrderIdealIndexExtension, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsRest, `GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.Statements, `GroundTheory.HeightsAndTheta.Heights.HermitianEuclidean, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.BergmanObjects, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.GenericComplexPoint, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.PPieceCoefficientsHolomorphic, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.PPieceRootProductPolynomial, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PConjIntNum, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PHilbertModule, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PHilbertPrime, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PLeviCompHol]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

