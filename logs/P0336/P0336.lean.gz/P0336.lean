import Lean
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PRiemannExtensionAnalytic
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PRiemannExtensionPolynomial
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PSheetImageAreaSetFrame
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PSheetPieceReachesCentre
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PVarietyProjectionMass
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PWeierstrassDivisionAtPoint
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PZariskiAnalyticNormality
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StBranchChartInt
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StBranchSheetAE
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StChartChangeSheetNull
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StChartIntSumOffHyperplane
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StChartMassCompact
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StChartMassCompare
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StConePolar
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StContinuousSectionHolomorphic
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StCutOffBoundaryBound
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StCutOffBoundaryParts
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StCutOffDominated
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StCutOffLimit
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StDerivationMinorOfDetection
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StDiscriminantSheetCover
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StDivisorGeneralPointBranches
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StDivisorGoodPoint
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StFiniteMapOpen
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StGermCentredIntegralEquation
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StGermGeneralCoordinates
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StGermWeierstrassPreparation
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StHessCCompPluri
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StHolomorphicFibreSumInt
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StIsolatedFibreOpen
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLelongRegularise
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLocalGeneratorsClearDenominators
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLogLogCut
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLogNormGradDensNonneg
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StMaDensChain
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StMaDensLogPow
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StParamChartInt
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPlaneSliceMass
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPointSliceMass
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPolydiscLelongLimit
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPosPartIndependent
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimeGermFiniteProjection
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimeTubeVolume
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimitiveFormMinimalFactorPoints
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimitiveFormSheetedLocusCutOut
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimitiveFormSheetedPointsNear
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimitivePresentationCover
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProjectionCoordinateEquation
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPuncturedCoverCycles
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSectionDegreeSum
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSectionHyperplaneAvoid
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSheetComass
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSheetLogNormDens
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSheetOnlyNull
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSliceIdeal
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSliceObjects
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSliceSectionMass
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSmallSetBallCover
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSmallSetTubeVolume
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StStokesOffDiscriminant
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StStokesOnChart
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StVanishNearPoint
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StVarIntAdd
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StVarIntChartChange

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PRiemannExtensionAnalytic, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PRiemannExtensionPolynomial, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PSheetImageAreaSetFrame, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PSheetPieceReachesCentre, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PVarietyProjectionMass, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PWeierstrassDivisionAtPoint, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PZariskiAnalyticNormality, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StBranchChartInt, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StBranchSheetAE, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StChartChangeSheetNull, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StChartIntSumOffHyperplane, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StChartMassCompact, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StChartMassCompare, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StConePolar, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StContinuousSectionHolomorphic, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StCutOffBoundaryBound, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StCutOffBoundaryParts, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StCutOffDominated, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StCutOffLimit, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StDerivationMinorOfDetection, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StDiscriminantSheetCover, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StDivisorGeneralPointBranches, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StDivisorGoodPoint, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StFiniteMapOpen, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StGermCentredIntegralEquation, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StGermGeneralCoordinates, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StGermWeierstrassPreparation, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StHessCCompPluri, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StHolomorphicFibreSumInt, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StIsolatedFibreOpen, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLelongRegularise, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLocalGeneratorsClearDenominators, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLogLogCut, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StLogNormGradDensNonneg, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StMaDensChain, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StMaDensLogPow, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StParamChartInt, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPlaneSliceMass, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPointSliceMass, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPolydiscLelongLimit, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPosPartIndependent, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimeGermFiniteProjection, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimeTubeVolume, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimitiveFormMinimalFactorPoints, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimitiveFormSheetedLocusCutOut, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimitiveFormSheetedPointsNear, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPrimitivePresentationCover, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StProjectionCoordinateEquation, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StPuncturedCoverCycles, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSectionDegreeSum, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSectionHyperplaneAvoid, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSheetComass, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSheetLogNormDens, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSheetOnlyNull, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSliceIdeal, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSliceObjects, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSliceSectionMass, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSmallSetBallCover, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StSmallSetTubeVolume, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StStokesOffDiscriminant, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StStokesOnChart, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StVanishNearPoint, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StVarIntAdd, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.StVarIntChartChange]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

