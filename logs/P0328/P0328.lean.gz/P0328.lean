import Lean
import Formalism.LocalToGlobal.NormalizedHeckeFactors.ExpDefs
import Formalism.LocalToGlobal.ProjectiveLattices.ArchimedeanQuadraticData.LenDescentOfLengthBaseChangeLocal
import Formalism.LocalToGlobal.ProjectiveLattices.BetaAtSymm
import Formalism.LocalToGlobal.ProjectiveLattices.GenSectT
import Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.MeasurablePhiInv
import Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.WithZeroLeOneEqExp
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.ConvGGG
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsFolner
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsTrunc
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.Elliptic
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.OnePole
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.PDeriv
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.SigmaAdd
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.SigmaOrder
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.ThreeTermNumEqTwistedGammaOfSigmaZero
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.QuasiPeriodConstUnique
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.TranslateProduct
import Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CayleyGaussianIntegrals.CayleyIdentity
import Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CayleyGaussianIntegrals.ExtensionFiltrationStable
import Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CayleyGaussianIntegrals.GaloisDescentSubspaces
import Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.SecondCoeffConsistency
import Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.ThirdJetIntegral
import Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.CardEqOfMulEqOne
import Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.ConjMatrixApply
import Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.NormAddLeKur
import Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.NormIntKur
import Formalism.LocalToGlobal.UnitaryNorms.CharExGen
import Formalism.LocalToGlobal.UnitaryNorms.UnrAe
import Formalism.LogVandermondeBounds.HookGammaAmgmMultinomialBounds
import Formalism.MahlerMeasure.CsSaturated
import Formalism.MahlerMeasure.GamInt
import Formalism.MahlerMeasure.LevelConst
import Formalism.MahlerMeasure.MahlerMeasureProofs.LevelDecomp
import Formalism.MahlerMeasure.MahlerMeasureProofs.LieMat
import Formalism.MahlerMeasure.MahlerMeasureProofs.LieRoots
import Formalism.MahlerMeasure.MahlerMeasureProofs.SmithBall
import Formalism.MahlerMeasure.MahlerMeasureProofs.SmithZp
import Formalism.MahlerMeasure.MahlerMeasureProofs.WindowAP
import Formalism.MahlerMeasure.MahlerMeasureProofs.WindowMeanAP
import Formalism.MoebiusJetDuality.StatementS
import Formalism.NormUnitaryBounds.DetPolynomialWeights.ShortIndependentVectorsOfDualMinimum
import Formalism.PadicSubsetSums.StableGradedCounts.IRRBBCard
import Formalism.PadicSubsetSums.StableGradedCounts.IRRSamePartCount
import Formalism.PadicSubsetSums.StableGradedCounts.TWCutOperator
import Formalism.PadicSubsetSums.StableGradedCounts.TWIndexDet
import Formalism.PadicSubsetSums.StableGradedCounts.ZReuse
import Formalism.PeriodIntegrals.AlgValsFin
import Formalism.PeriodIntegrals.BesselL2FixAtZero
import Formalism.PeriodIntegrals.BesselMapUniq
import Formalism.PeriodIntegrals.BesselPeriodGGP
import Formalism.PeriodIntegrals.BordInv
import Formalism.PeriodIntegrals.BordSlice
import Formalism.PeriodIntegrals.CdHaarScale
import Formalism.PeriodIntegrals.DSInfCharCap
import Formalism.PeriodIntegrals.EtaInfGen
import Formalism.PeriodIntegrals.ExplicitFormulaCounts.UMultOne
import Formalism.PeriodIntegrals.HermitianGenusExtension.SemilocalHermitianLattices.ExistsIsomFrame
import Formalism.PeriodIntegrals.HodgeOfFon
import Formalism.PeriodIntegrals.HookBound
import Formalism.PeriodIntegrals.InfTypeChar
import Formalism.PeriodIntegrals.NUnimodLoc
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.AdjointTensorOfSingleValid
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.BesselLevi
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.BiaddZpLin

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.LocalToGlobal.NormalizedHeckeFactors.ExpDefs, `Formalism.LocalToGlobal.ProjectiveLattices.ArchimedeanQuadraticData.LenDescentOfLengthBaseChangeLocal, `Formalism.LocalToGlobal.ProjectiveLattices.BetaAtSymm, `Formalism.LocalToGlobal.ProjectiveLattices.GenSectT, `Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.MeasurablePhiInv, `Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.WithZeroLeOneEqExp, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.ConvGGG, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsFolner, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsTrunc, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.Elliptic, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.OnePole, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.PDeriv, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.SigmaAdd, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.SigmaOrder, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.ThreeTermNumEqTwistedGammaOfSigmaZero, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.QuasiPeriodConstUnique, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.TranslateProduct, `Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CayleyGaussianIntegrals.CayleyIdentity, `Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CayleyGaussianIntegrals.ExtensionFiltrationStable, `Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CayleyGaussianIntegrals.GaloisDescentSubspaces, `Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.SecondCoeffConsistency, `Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.ThirdJetIntegral, `Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.CardEqOfMulEqOne, `Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.ConjMatrixApply, `Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.NormAddLeKur, `Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.NormIntKur, `Formalism.LocalToGlobal.UnitaryNorms.CharExGen, `Formalism.LocalToGlobal.UnitaryNorms.UnrAe, `Formalism.LogVandermondeBounds.HookGammaAmgmMultinomialBounds, `Formalism.MahlerMeasure.CsSaturated, `Formalism.MahlerMeasure.GamInt, `Formalism.MahlerMeasure.LevelConst, `Formalism.MahlerMeasure.MahlerMeasureProofs.LevelDecomp, `Formalism.MahlerMeasure.MahlerMeasureProofs.LieMat, `Formalism.MahlerMeasure.MahlerMeasureProofs.LieRoots, `Formalism.MahlerMeasure.MahlerMeasureProofs.SmithBall, `Formalism.MahlerMeasure.MahlerMeasureProofs.SmithZp, `Formalism.MahlerMeasure.MahlerMeasureProofs.WindowAP, `Formalism.MahlerMeasure.MahlerMeasureProofs.WindowMeanAP, `Formalism.MoebiusJetDuality.StatementS, `Formalism.NormUnitaryBounds.DetPolynomialWeights.ShortIndependentVectorsOfDualMinimum, `Formalism.PadicSubsetSums.StableGradedCounts.IRRBBCard, `Formalism.PadicSubsetSums.StableGradedCounts.IRRSamePartCount, `Formalism.PadicSubsetSums.StableGradedCounts.TWCutOperator, `Formalism.PadicSubsetSums.StableGradedCounts.TWIndexDet, `Formalism.PadicSubsetSums.StableGradedCounts.ZReuse, `Formalism.PeriodIntegrals.AlgValsFin, `Formalism.PeriodIntegrals.BesselL2FixAtZero, `Formalism.PeriodIntegrals.BesselMapUniq, `Formalism.PeriodIntegrals.BesselPeriodGGP, `Formalism.PeriodIntegrals.BordInv, `Formalism.PeriodIntegrals.BordSlice, `Formalism.PeriodIntegrals.CdHaarScale, `Formalism.PeriodIntegrals.DSInfCharCap, `Formalism.PeriodIntegrals.EtaInfGen, `Formalism.PeriodIntegrals.ExplicitFormulaCounts.UMultOne, `Formalism.PeriodIntegrals.HermitianGenusExtension.SemilocalHermitianLattices.ExistsIsomFrame, `Formalism.PeriodIntegrals.HodgeOfFon, `Formalism.PeriodIntegrals.HookBound, `Formalism.PeriodIntegrals.InfTypeChar, `Formalism.PeriodIntegrals.NUnimodLoc, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.AdjointTensorOfSingleValid, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.BesselLevi, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.BiaddZpLin]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

