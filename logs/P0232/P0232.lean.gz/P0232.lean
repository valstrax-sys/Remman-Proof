import Lean
import GroundTheory.ProfiniteCohomology.ContinuousCochains
import GroundTheory.ProfiniteCohomology.GlobalEulerCharacteristic.ArtinDefs
import GroundTheory.ProfiniteCohomology.IsProPGroupSubgroupIffIsPGroupMap
import GroundTheory.ProfiniteCohomology.KummerCorrespondence
import GroundTheory.ProfiniteCohomology.LocalClassFormation.OrderScalars
import GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.Additive
import GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.UnitsPower
import GroundTheory.ProfiniteCohomology.RealPlaces.InvolutionDuality
import GroundTheory.ProfiniteCohomology.RestrictedRamification.SPicFinite
import GroundTheory.ProfiniteCohomology.RestrictedRamification.Unramified
import GroundTheory.TateCohomology.CupConnecting
import GroundTheory.TateCohomology.CupFunctorial
import GroundTheory.TateCohomology.DimensionShift
import GroundTheory.TateCohomology.HerbrandTate
import GroundTheory.TateCohomology.PGroupFree
import GroundTheory.TateCohomology.TateZeroClass
import GroundTheory.TateCohomology.UniquelyDivisible
import Lemmata.DetNormLeProdRows.DetNormLeProdRows
import Lemmata.IdempotentTraceVanishing.TraceAevalEqZero
import Lemmata.PaddedFamilies.PadFam
import Lemmata.SimultaneousEigenvectors.BlSimeig
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ActionsPreserveMeasuresProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.AutomorphyFactorKernelAlgebraProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.AutomorphyFactorScalarMatrix
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ConjNeOne
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ContinuousCompTorusMap
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.CuspRegionVolumeFiniteProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.DiagonalTermsContributionProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.DiagonalTruncatedIntegral
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.E5OfReproducingFormula
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.E6OfLinearTraceIdentity
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.EllipticTermsContributionProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.HeightsOnQuotientProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.HolomorphicOnHalfPlaneFinsetSum
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ImaginaryPartBoundProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.KernelInverseSymmetry
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.KernelSeriesConvergesProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.KernelSumBoundedProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.KernelTermsInvariantBoundedProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.KernelTraceBoundProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.MultivariableReproducingFormulaProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.OrbitCoverProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfEcut
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfFcen
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfFell
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfFhyp
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfFsum
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfKapInt
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfKapSum
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfMult
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfPack
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.SplitTsum
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.UnipotentIntegrandVanishesProof
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.UnipotentTermsContributionProof
import ReciprocityTheory.AnalyticForms.LeviForms.IsRegFamilyInhabitStatement
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.ContinuousTmaxShift
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.GreenPolar
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.MdiscSt
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshExtB
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshMean
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshMollA
import ReciprocityTheory.AnalyticForms.PotentialTheory.ContDiffOnFubiniStudyProfileInvNormSqFirst
import ReciprocityTheory.AnalyticForms.PotentialTheory.IsPotentialPullbackStatement
import ReciprocityTheory.AnalyticForms.RegularLocalRings.DivSheaf

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.ProfiniteCohomology.ContinuousCochains, `GroundTheory.ProfiniteCohomology.GlobalEulerCharacteristic.ArtinDefs, `GroundTheory.ProfiniteCohomology.IsProPGroupSubgroupIffIsPGroupMap, `GroundTheory.ProfiniteCohomology.KummerCorrespondence, `GroundTheory.ProfiniteCohomology.LocalClassFormation.OrderScalars, `GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.Additive, `GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.UnitsPower, `GroundTheory.ProfiniteCohomology.RealPlaces.InvolutionDuality, `GroundTheory.ProfiniteCohomology.RestrictedRamification.SPicFinite, `GroundTheory.ProfiniteCohomology.RestrictedRamification.Unramified, `GroundTheory.TateCohomology.CupConnecting, `GroundTheory.TateCohomology.CupFunctorial, `GroundTheory.TateCohomology.DimensionShift, `GroundTheory.TateCohomology.HerbrandTate, `GroundTheory.TateCohomology.PGroupFree, `GroundTheory.TateCohomology.TateZeroClass, `GroundTheory.TateCohomology.UniquelyDivisible, `Lemmata.DetNormLeProdRows.DetNormLeProdRows, `Lemmata.IdempotentTraceVanishing.TraceAevalEqZero, `Lemmata.PaddedFamilies.PadFam, `Lemmata.SimultaneousEigenvectors.BlSimeig, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ActionsPreserveMeasuresProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.AutomorphyFactorKernelAlgebraProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.AutomorphyFactorScalarMatrix, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ConjNeOne, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ContinuousCompTorusMap, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.CuspRegionVolumeFiniteProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.DiagonalTermsContributionProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.DiagonalTruncatedIntegral, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.E5OfReproducingFormula, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.E6OfLinearTraceIdentity, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.EllipticTermsContributionProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.HeightsOnQuotientProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.HolomorphicOnHalfPlaneFinsetSum, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ImaginaryPartBoundProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.KernelInverseSymmetry, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.KernelSeriesConvergesProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.KernelSumBoundedProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.KernelTermsInvariantBoundedProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.KernelTraceBoundProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.MultivariableReproducingFormulaProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.OrbitCoverProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfEcut, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfFcen, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfFell, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfFhyp, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfFsum, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfKapInt, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfKapSum, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfMult, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.PfPack, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.SplitTsum, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.UnipotentIntegrandVanishesProof, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.UnipotentTermsContributionProof, `ReciprocityTheory.AnalyticForms.LeviForms.IsRegFamilyInhabitStatement, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.ContinuousTmaxShift, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.GreenPolar, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.MdiscSt, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshExtB, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshMean, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshMollA, `ReciprocityTheory.AnalyticForms.PotentialTheory.ContDiffOnFubiniStudyProfileInvNormSqFirst, `ReciprocityTheory.AnalyticForms.PotentialTheory.IsPotentialPullbackStatement, `ReciprocityTheory.AnalyticForms.RegularLocalRings.DivSheaf]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

