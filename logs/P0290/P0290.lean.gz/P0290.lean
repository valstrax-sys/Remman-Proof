import Lean
import ReciprocityTheory.DualLattices.SumValCoord
import ReciprocityTheory.DualLattices.TangentPairingStatement
import ReciprocityTheory.DualLattices.ToSigmaAddFstZeroFst
import ReciprocityTheory.DualLattices.UnramifiedCokernelLowerBoundStatement
import ReciprocityTheory.DualLattices.WtGtRowSubstXSub
import ReciprocityTheory.GaloisValuations.ArithOfA
import ReciprocityTheory.GeometryOfNumbers.AsymptoticSequences.ClosingHS
import ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.ArakelovDegreeEqDegreeOfFamily
import ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.MorseGenStB
import ReciprocityTheory.GeometryOfNumbers.SphericalMonomials.MonomSt
import ReciprocityTheory.GroupCohomology.ComapZeroCoboundariesEqBot
import ReciprocityTheory.GroupCohomology.CupConnRightStatement
import ReciprocityTheory.GroupCohomology.HomogExistsStatement
import ReciprocityTheory.Hypotheses.Descent
import ReciprocityTheory.Hypotheses.GalCohDefs
import ReciprocityTheory.L2DbarEstimates.LeviForms.BasicExpBound
import ReciprocityTheory.L2DbarEstimates.LeviForms.CovDet
import ReciprocityTheory.L2DbarEstimates.LeviForms.Cutoff
import ReciprocityTheory.L2DbarEstimates.LeviForms.HoloClosedNeed
import ReciprocityTheory.L2DbarEstimates.LeviForms.LogNormSq
import ReciprocityTheory.L2DbarEstimates.LeviForms.PolarBallReal
import ReciprocityTheory.L2DbarEstimates.LeviForms.Vanish
import ReciprocityTheory.L2DbarEstimates.Localization.Imports
import ReciprocityTheory.L2DbarEstimates.Localization.IntegrableFd
import ReciprocityTheory.L2DbarEstimates.Localization.PrimZeroOfNonpos
import ReciprocityTheory.L2DbarEstimates.MinimalSolutions.HilbertLemmas
import ReciprocityTheory.L2DbarEstimates.Mollifiers.MollTendstoOfContinuous
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.AExact
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.APrimeA
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.APrimeW
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.DerivDerivNonposOfIsLocalMax
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.FourBasic
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.FourIndep
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.FourSum
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.GrowSumIndicatorLe
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.IndCount
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.RegMaxA
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.UniNilp
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.ZLocLower
import ReciprocityTheory.L2DbarEstimates.SymmetricSections.SymmDiff
import ReciprocityTheory.L2DbarEstimates.SymmetricSections.SymmVanish
import ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.ExtCut
import ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.IntegralMollProfBall
import ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.RegIndep
import ReciprocityTheory.ReducedBases.NormGsoCompSwapRightSqMul
import ReciprocityTheory.ReducedBases.SizeReduce
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.AMassStA
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.BasisOfLinearIndependentOfCardEqFinrank
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.KleimanNefness.AlgCechSt
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.KleimanNefness.AlgFiltSt
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.KleimanNefness.KleimanSt
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.FirstMinimumPos
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.IntegralModuleBases.NormGsoSqLeTwoPowMulOfValEqAdd
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.UpperBounds.DescentStatement
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.UpperBounds.PolyGrowthStatementPf
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.UpperBounds.SCoordStatementPfG
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.UpperBounds.SumBoundStatement
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArithmeticIntersection.DiagonalDivisors.InhabitBaseStatement
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArithmeticIntersection.KappaB
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArithmeticIntersection.KrullDimQuotientEqOneIffEqBot
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArithmeticIntersection.LengthTwoGeneratorQuotient
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArithmeticIntersection.MixedFieldContraction.GenericFibreKerTarget
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArithmeticIntersection.MultihomogeneousIdeals.CycDim
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArithmeticIntersection.MultihomogeneousIdeals.ExistsMonomialNotMem

open Lean Elab Command

def auditTargets : Array Name := #[`ReciprocityTheory.DualLattices.SumValCoord, `ReciprocityTheory.DualLattices.TangentPairingStatement, `ReciprocityTheory.DualLattices.ToSigmaAddFstZeroFst, `ReciprocityTheory.DualLattices.UnramifiedCokernelLowerBoundStatement, `ReciprocityTheory.DualLattices.WtGtRowSubstXSub, `ReciprocityTheory.GaloisValuations.ArithOfA, `ReciprocityTheory.GeometryOfNumbers.AsymptoticSequences.ClosingHS, `ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.ArakelovDegreeEqDegreeOfFamily, `ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.MorseGenStB, `ReciprocityTheory.GeometryOfNumbers.SphericalMonomials.MonomSt, `ReciprocityTheory.GroupCohomology.ComapZeroCoboundariesEqBot, `ReciprocityTheory.GroupCohomology.CupConnRightStatement, `ReciprocityTheory.GroupCohomology.HomogExistsStatement, `ReciprocityTheory.Hypotheses.Descent, `ReciprocityTheory.Hypotheses.GalCohDefs, `ReciprocityTheory.L2DbarEstimates.LeviForms.BasicExpBound, `ReciprocityTheory.L2DbarEstimates.LeviForms.CovDet, `ReciprocityTheory.L2DbarEstimates.LeviForms.Cutoff, `ReciprocityTheory.L2DbarEstimates.LeviForms.HoloClosedNeed, `ReciprocityTheory.L2DbarEstimates.LeviForms.LogNormSq, `ReciprocityTheory.L2DbarEstimates.LeviForms.PolarBallReal, `ReciprocityTheory.L2DbarEstimates.LeviForms.Vanish, `ReciprocityTheory.L2DbarEstimates.Localization.Imports, `ReciprocityTheory.L2DbarEstimates.Localization.IntegrableFd, `ReciprocityTheory.L2DbarEstimates.Localization.PrimZeroOfNonpos, `ReciprocityTheory.L2DbarEstimates.MinimalSolutions.HilbertLemmas, `ReciprocityTheory.L2DbarEstimates.Mollifiers.MollTendstoOfContinuous, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.AExact, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.APrimeA, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.APrimeW, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.DerivDerivNonposOfIsLocalMax, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.FourBasic, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.FourIndep, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.FourSum, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.GrowSumIndicatorLe, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.IndCount, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.RegMaxA, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.UniNilp, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.ZLocLower, `ReciprocityTheory.L2DbarEstimates.SymmetricSections.SymmDiff, `ReciprocityTheory.L2DbarEstimates.SymmetricSections.SymmVanish, `ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.ExtCut, `ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.IntegralMollProfBall, `ReciprocityTheory.L2DbarEstimates.WeakHolomorphy.RegIndep, `ReciprocityTheory.ReducedBases.NormGsoCompSwapRightSqMul, `ReciprocityTheory.ReducedBases.SizeReduce, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.AMassStA, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.BasisOfLinearIndependentOfCardEqFinrank, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.KleimanNefness.AlgCechSt, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.KleimanNefness.AlgFiltSt, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.KleimanNefness.KleimanSt, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.FirstMinimumPos, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.IntegralModuleBases.NormGsoSqLeTwoPowMulOfValEqAdd, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.UpperBounds.DescentStatement, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.UpperBounds.PolyGrowthStatementPf, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.UpperBounds.SCoordStatementPfG, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovVolumes.UpperBounds.SumBoundStatement, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArithmeticIntersection.DiagonalDivisors.InhabitBaseStatement, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArithmeticIntersection.KappaB, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArithmeticIntersection.KrullDimQuotientEqOneIffEqBot, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArithmeticIntersection.LengthTwoGeneratorQuotient, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArithmeticIntersection.MixedFieldContraction.GenericFibreKerTarget, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArithmeticIntersection.MultihomogeneousIdeals.CycDim, `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArithmeticIntersection.MultihomogeneousIdeals.ExistsMonomialNotMem]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

