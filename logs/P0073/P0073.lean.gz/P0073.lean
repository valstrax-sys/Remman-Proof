import Lean
import Formalism.PeriodIntegrals.DiscIn
import Formalism.PeriodIntegrals.EagonNorthcott
import Formalism.PeriodIntegrals.EllipticRegularity2
import Formalism.PeriodIntegrals.EmbPerm
import Formalism.PeriodIntegrals.EmbTraceSum
import Formalism.PeriodIntegrals.ExistsGaugeMeasureForEachRank
import Formalism.PeriodIntegrals.ExpIntW
import Formalism.PeriodIntegrals.ExpTri
import Formalism.PeriodIntegrals.ExplicitFormula
import Formalism.PeriodIntegrals.FglChordFactor
import Formalism.PeriodIntegrals.FglGram
import Formalism.PeriodIntegrals.FglPhSplit
import Formalism.PeriodIntegrals.FglPtW
import Formalism.PeriodIntegrals.FglTriFactor
import Formalism.PeriodIntegrals.FiltLen
import Formalism.PeriodIntegrals.FiltLenF
import Formalism.PeriodIntegrals.FinExtTop
import Formalism.PeriodIntegrals.FinOrdRedOne
import Formalism.PeriodIntegrals.FlagGramNonneg
import Formalism.PeriodIntegrals.FockRBlock
import Formalism.PeriodIntegrals.FunEqAll
import Formalism.PeriodIntegrals.GalTorsConj
import Formalism.PeriodIntegrals.GaussIntegral
import Formalism.PeriodIntegrals.GeometricProductPowers.GaussianProductPowerBound
import Formalism.PeriodIntegrals.HeisDefs
import Formalism.PeriodIntegrals.Hensel
import Formalism.PeriodIntegrals.HermLatFin
import Formalism.PeriodIntegrals.HermitianGenusExtension.SemilocalHermitianLattices.ExistsNormOneOfPair
import Formalism.PeriodIntegrals.IndexUBound
import Formalism.PeriodIntegrals.InertPrime
import Formalism.PeriodIntegrals.InvIdealIdxPi
import Formalism.PeriodIntegrals.IsoDerivB
import Formalism.PeriodIntegrals.IsoDet
import Formalism.PeriodIntegrals.IsoDualPair
import Formalism.PeriodIntegrals.IsoFunV
import Formalism.PeriodIntegrals.IsoInvMetric
import Formalism.PeriodIntegrals.IsoScaleA
import Formalism.PeriodIntegrals.JetsPhW
import Formalism.PeriodIntegrals.JointBlockShapes.MinusPart
import Formalism.PeriodIntegrals.KerIso
import Formalism.PeriodIntegrals.KerLat
import Formalism.PeriodIntegrals.KoszulExact
import Formalism.PeriodIntegrals.LatDefs
import Formalism.PeriodIntegrals.LatLocGlob
import Formalism.PeriodIntegrals.LatMin
import Formalism.PeriodIntegrals.LeafCoeffVal
import Formalism.PeriodIntegrals.LocBasisPlace
import Formalism.PeriodIntegrals.LocBasisSemi
import Formalism.PeriodIntegrals.LocFramePrim
import Formalism.PeriodIntegrals.LocalEnd
import Formalism.PeriodIntegrals.LongWeylElementSquare
import Formalism.PeriodIntegrals.LpLower
import Formalism.PeriodIntegrals.Minkowski
import Formalism.PeriodIntegrals.MinorSpanCompl
import Formalism.PeriodIntegrals.MirabIndex
import Formalism.PeriodIntegrals.MiracleFlat
import Formalism.PeriodIntegrals.NablaSpans.ExpansionCoeffValuationGe
import Formalism.PeriodIntegrals.NormGramAtOrigin
import Formalism.PeriodIntegrals.NormOnePow
import Formalism.PeriodIntegrals.OddDualWeyl
import Formalism.PeriodIntegrals.OkpInert
import Formalism.PeriodIntegrals.OneCosetSharp
import Formalism.PeriodIntegrals.PhConvProj
import Formalism.PeriodIntegrals.PhMeasCore

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.PeriodIntegrals.DiscIn, `Formalism.PeriodIntegrals.EagonNorthcott, `Formalism.PeriodIntegrals.EllipticRegularity2, `Formalism.PeriodIntegrals.EmbPerm, `Formalism.PeriodIntegrals.EmbTraceSum, `Formalism.PeriodIntegrals.ExistsGaugeMeasureForEachRank, `Formalism.PeriodIntegrals.ExpIntW, `Formalism.PeriodIntegrals.ExpTri, `Formalism.PeriodIntegrals.ExplicitFormula, `Formalism.PeriodIntegrals.FglChordFactor, `Formalism.PeriodIntegrals.FglGram, `Formalism.PeriodIntegrals.FglPhSplit, `Formalism.PeriodIntegrals.FglPtW, `Formalism.PeriodIntegrals.FglTriFactor, `Formalism.PeriodIntegrals.FiltLen, `Formalism.PeriodIntegrals.FiltLenF, `Formalism.PeriodIntegrals.FinExtTop, `Formalism.PeriodIntegrals.FinOrdRedOne, `Formalism.PeriodIntegrals.FlagGramNonneg, `Formalism.PeriodIntegrals.FockRBlock, `Formalism.PeriodIntegrals.FunEqAll, `Formalism.PeriodIntegrals.GalTorsConj, `Formalism.PeriodIntegrals.GaussIntegral, `Formalism.PeriodIntegrals.GeometricProductPowers.GaussianProductPowerBound, `Formalism.PeriodIntegrals.HeisDefs, `Formalism.PeriodIntegrals.Hensel, `Formalism.PeriodIntegrals.HermLatFin, `Formalism.PeriodIntegrals.HermitianGenusExtension.SemilocalHermitianLattices.ExistsNormOneOfPair, `Formalism.PeriodIntegrals.IndexUBound, `Formalism.PeriodIntegrals.InertPrime, `Formalism.PeriodIntegrals.InvIdealIdxPi, `Formalism.PeriodIntegrals.IsoDerivB, `Formalism.PeriodIntegrals.IsoDet, `Formalism.PeriodIntegrals.IsoDualPair, `Formalism.PeriodIntegrals.IsoFunV, `Formalism.PeriodIntegrals.IsoInvMetric, `Formalism.PeriodIntegrals.IsoScaleA, `Formalism.PeriodIntegrals.JetsPhW, `Formalism.PeriodIntegrals.JointBlockShapes.MinusPart, `Formalism.PeriodIntegrals.KerIso, `Formalism.PeriodIntegrals.KerLat, `Formalism.PeriodIntegrals.KoszulExact, `Formalism.PeriodIntegrals.LatDefs, `Formalism.PeriodIntegrals.LatLocGlob, `Formalism.PeriodIntegrals.LatMin, `Formalism.PeriodIntegrals.LeafCoeffVal, `Formalism.PeriodIntegrals.LocBasisPlace, `Formalism.PeriodIntegrals.LocBasisSemi, `Formalism.PeriodIntegrals.LocFramePrim, `Formalism.PeriodIntegrals.LocalEnd, `Formalism.PeriodIntegrals.LongWeylElementSquare, `Formalism.PeriodIntegrals.LpLower, `Formalism.PeriodIntegrals.Minkowski, `Formalism.PeriodIntegrals.MinorSpanCompl, `Formalism.PeriodIntegrals.MirabIndex, `Formalism.PeriodIntegrals.MiracleFlat, `Formalism.PeriodIntegrals.NablaSpans.ExpansionCoeffValuationGe, `Formalism.PeriodIntegrals.NormGramAtOrigin, `Formalism.PeriodIntegrals.NormOnePow, `Formalism.PeriodIntegrals.OddDualWeyl, `Formalism.PeriodIntegrals.OkpInert, `Formalism.PeriodIntegrals.OneCosetSharp, `Formalism.PeriodIntegrals.PhConvProj, `Formalism.PeriodIntegrals.PhMeasCore]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

