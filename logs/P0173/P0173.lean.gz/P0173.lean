import Lean
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.SplittingOfSandwichAndPairingStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.TorusConjugationPreservesCongruence
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.TorusStatementStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.UpperTriangularInverseIsUpper
import CompanionTheory.ThickeningEstimates.LieGroupReduction.SiegelHaar
import Development.AbelianVarietyTheory.BlockTheory.AbelianSchemeLaw.HomExtendsOverDVR
import Development.AbelianVarietyTheory.BlockTheory.AbelianSchemeLaw.PolarizedAbelianVarieties
import Development.AbelianVarietyTheory.BlockTheory.AbelianSchemeLaw.SemiAbelianModels
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.BoundaryPolynomialFunctions
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.FramedLatticeZeroCycleHeight
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.ModelDdcForms
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.SiegelReframe
import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.ActionCoordinates
import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.AdelicUnitaryHaarMeasure
import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.DualExponentDensity
import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.PerpendicularEmbedding
import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.SelfDualLatticeActions
import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.SelfDualUnramifiedPlaces
import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.UnitaryLatticeOrthogonal
import Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.EtaDualPairing
import Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.ProperlyDiscontinuousFlags
import Development.AbelianVarietyTheory.BlockTheory.SiegelWeilLocal.FullySplitStabilizers
import Development.AbelianVarietyTheory.BlockTheory.SiegelWeilLocal.GramDensityRealCoordinates
import Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.BottomMinor
import Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.HermitianLattices
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.ExponentTerms
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.FourierJacobiAverage
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.HalfPowerSpherical
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.PositiveTwistAverage
import Development.AbelianVarietyTheory.Counterexamples.AdelicSplittingExamples.TwoPrimesOfSplitPl
import Development.AbelianVarietyTheory.Counterexamples.UpperHalfSurvey.HasColenNotUniqueWithoutGuard
import Development.AbelianVarietyTheory.Definitions.Divisors.CupPair
import Development.AbelianVarietyTheory.Definitions.Divisors.EtaleEmpty
import Development.AbelianVarietyTheory.Definitions.Divisors.ExtFormAdjEqNegSecondForm
import Development.AbelianVarietyTheory.Definitions.Divisors.FstTszeSec
import Development.AbelianVarietyTheory.Definitions.Divisors.GalMapMul
import Development.AbelianVarietyTheory.Definitions.Divisors.IotaScalarOne
import Development.AbelianVarietyTheory.Definitions.Divisors.IsAlgLowZero
import Development.AbelianVarietyTheory.Definitions.Divisors.IsStrictlySemistableIff
import Development.AbelianVarietyTheory.Definitions.Divisors.KerIdealCompOfSurjective
import Development.AbelianVarietyTheory.Definitions.Divisors.OneMemH0WeightZero
import Development.AbelianVarietyTheory.Definitions.Divisors.SecMapApply
import Development.AbelianVarietyTheory.Definitions.Divisors.T2SpaceGeneralLinearGroup
import Development.AbelianVarietyTheory.Definitions.Divisors.TorusNoLeClassNoRankOne
import Development.AbelianVarietyTheory.Definitions.Foundations.CoPtMu
import Development.AbelianVarietyTheory.Definitions.Foundations.CyclotomicDvdExpandOfCoprime
import Development.AbelianVarietyTheory.Definitions.Foundations.ExistsRootOfIsAlgClosed
import Development.AbelianVarietyTheory.Definitions.Foundations.HahnPowOrderLeadingCoeff
import Development.AbelianVarietyTheory.Definitions.Foundations.IntegralLocallyConstCochainModPow
import Development.AbelianVarietyTheory.Definitions.Foundations.IsHermND
import Development.AbelianVarietyTheory.Definitions.Foundations.MemSiegelOfIffRightAct
import Development.AbelianVarietyTheory.Definitions.Foundations.OpLDOneSubMemTriv
import Development.AbelianVarietyTheory.Definitions.Foundations.RepL
import Development.AbelianVarietyTheory.Definitions.Foundations.RowRawRange
import Development.AbelianVarietyTheory.Definitions.Foundations.SamePartIffOfNeZero
import Development.AbelianVarietyTheory.Definitions.Foundations.SgC
import Development.AbelianVarietyTheory.Definitions.Foundations.SimpleSumRowCol
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.CohomZeroEquivSections
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsStrictlySemistableModel
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.NegOnePowBoundaryTermsCancel
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.PreservesFiniteLimitsTensorLeftSheafify
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.SectionOfFreeOnUnitComp
import Development.AbelianVarietyTheory.Definitions.GlobalTwisting.LatIntZero
import Development.AbelianVarietyTheory.Definitions.HermitianLattices.ExistsZsmulMemOfIsLattice

open Lean Elab Command

def auditTargets : Array Name := #[`CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.SplittingOfSandwichAndPairingStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.TorusConjugationPreservesCongruence, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.TorusStatementStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.UpperTriangularInverseIsUpper, `CompanionTheory.ThickeningEstimates.LieGroupReduction.SiegelHaar, `Development.AbelianVarietyTheory.BlockTheory.AbelianSchemeLaw.HomExtendsOverDVR, `Development.AbelianVarietyTheory.BlockTheory.AbelianSchemeLaw.PolarizedAbelianVarieties, `Development.AbelianVarietyTheory.BlockTheory.AbelianSchemeLaw.SemiAbelianModels, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.BoundaryPolynomialFunctions, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.FramedLatticeZeroCycleHeight, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.ModelDdcForms, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.SiegelReframe, `Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.ActionCoordinates, `Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.AdelicUnitaryHaarMeasure, `Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.DualExponentDensity, `Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.PerpendicularEmbedding, `Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.SelfDualLatticeActions, `Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.SelfDualUnramifiedPlaces, `Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.UnitaryLatticeOrthogonal, `Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.EtaDualPairing, `Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.ProperlyDiscontinuousFlags, `Development.AbelianVarietyTheory.BlockTheory.SiegelWeilLocal.FullySplitStabilizers, `Development.AbelianVarietyTheory.BlockTheory.SiegelWeilLocal.GramDensityRealCoordinates, `Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.BottomMinor, `Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.HermitianLattices, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.ExponentTerms, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.FourierJacobiAverage, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.HalfPowerSpherical, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.PositiveTwistAverage, `Development.AbelianVarietyTheory.Counterexamples.AdelicSplittingExamples.TwoPrimesOfSplitPl, `Development.AbelianVarietyTheory.Counterexamples.UpperHalfSurvey.HasColenNotUniqueWithoutGuard, `Development.AbelianVarietyTheory.Definitions.Divisors.CupPair, `Development.AbelianVarietyTheory.Definitions.Divisors.EtaleEmpty, `Development.AbelianVarietyTheory.Definitions.Divisors.ExtFormAdjEqNegSecondForm, `Development.AbelianVarietyTheory.Definitions.Divisors.FstTszeSec, `Development.AbelianVarietyTheory.Definitions.Divisors.GalMapMul, `Development.AbelianVarietyTheory.Definitions.Divisors.IotaScalarOne, `Development.AbelianVarietyTheory.Definitions.Divisors.IsAlgLowZero, `Development.AbelianVarietyTheory.Definitions.Divisors.IsStrictlySemistableIff, `Development.AbelianVarietyTheory.Definitions.Divisors.KerIdealCompOfSurjective, `Development.AbelianVarietyTheory.Definitions.Divisors.OneMemH0WeightZero, `Development.AbelianVarietyTheory.Definitions.Divisors.SecMapApply, `Development.AbelianVarietyTheory.Definitions.Divisors.T2SpaceGeneralLinearGroup, `Development.AbelianVarietyTheory.Definitions.Divisors.TorusNoLeClassNoRankOne, `Development.AbelianVarietyTheory.Definitions.Foundations.CoPtMu, `Development.AbelianVarietyTheory.Definitions.Foundations.CyclotomicDvdExpandOfCoprime, `Development.AbelianVarietyTheory.Definitions.Foundations.ExistsRootOfIsAlgClosed, `Development.AbelianVarietyTheory.Definitions.Foundations.HahnPowOrderLeadingCoeff, `Development.AbelianVarietyTheory.Definitions.Foundations.IntegralLocallyConstCochainModPow, `Development.AbelianVarietyTheory.Definitions.Foundations.IsHermND, `Development.AbelianVarietyTheory.Definitions.Foundations.MemSiegelOfIffRightAct, `Development.AbelianVarietyTheory.Definitions.Foundations.OpLDOneSubMemTriv, `Development.AbelianVarietyTheory.Definitions.Foundations.RepL, `Development.AbelianVarietyTheory.Definitions.Foundations.RowRawRange, `Development.AbelianVarietyTheory.Definitions.Foundations.SamePartIffOfNeZero, `Development.AbelianVarietyTheory.Definitions.Foundations.SgC, `Development.AbelianVarietyTheory.Definitions.Foundations.SimpleSumRowCol, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.CohomZeroEquivSections, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsStrictlySemistableModel, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.NegOnePowBoundaryTermsCancel, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.PreservesFiniteLimitsTensorLeftSheafify, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.SectionOfFreeOnUnitComp, `Development.AbelianVarietyTheory.Definitions.GlobalTwisting.LatIntZero, `Development.AbelianVarietyTheory.Definitions.HermitianLattices.ExistsZsmulMemOfIsLattice]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

