import Lean
import Formalism.GaussJetBounds.GaussJetProofs.PureCrossTermWeight
import Formalism.GaussJetBounds.OneLetterGaussJets.OneLetterGaussProofs.CapLeOddShiftBound
import Formalism.GaussJetBounds.StatementG
import Formalism.GaussJetBounds.StatementR
import Formalism.GaussValuationBounds.GaussValueContraction.GaussValueContractionProofFactBis
import Formalism.GaussValuationBounds.GaussValueContraction.GaussValueContractionProofFactVariant
import Formalism.GaussValuationBounds.GaussValueContraction.KapBoundProof
import Formalism.GaussValuationBounds.GaussValueContraction.PhiIterXProof
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.BideterminantDominance
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.ColLexInitMinor
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.ColSums
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.ColumnLexBideterminant
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylMap
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylMul
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylNonDom
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylPoint
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylRowGraded
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylRowStable
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylSat
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockDiagBound
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockPos
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockSubAdj
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.HWRaise
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.HWRowWeight
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.HighestWeightVectorNeZero
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LBidetMinor
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LCcompLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LCdegLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LCpeelLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LCpleadLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LCssytLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LFockqLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LGradedLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LHwinLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LeadComp
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LeadInterlaced
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.MinorExpLt
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.RowDivStable
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.StandardMonomialSpanOf
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.TwoColumn
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.WeylLeDual
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.WeylRowDivStable
import Formalism.GrowthSums.FactorialBaseGrowth.NextEvenTopHolds
import Formalism.GrowthSums.FactorialBaseGrowth.Segment
import Formalism.HermitianCurvature.HermitianCurvatureProofs.AverageOne
import Formalism.HermitianCurvature.HermitianCurvatureProofs.BetaBoundOnBoundary
import Formalism.HermitianCurvature.HermitianCurvatureProofs.BlockEstimatesSumForm
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ChainAndRowSums
import Formalism.HermitianCurvature.HermitianCurvatureProofs.DegreeOfProdLinearLe
import Formalism.HermitianCurvature.HermitianCurvatureProofs.DetRowsZero
import Formalism.HermitianCurvature.HermitianCurvatureProofs.EntryCommuteTransposedRMatrix
import Formalism.HermitianCurvature.HermitianCurvatureProofs.FinrankLeOfMapLe
import Formalism.HermitianCurvature.HermitianCurvatureProofs.FrameLevelIndices
import Formalism.HermitianCurvature.HermitianCurvatureProofs.GaussSumModulusOfLattice
import Formalism.HermitianCurvature.HermitianCurvatureProofs.KroneckerEmbedMulApply
import Formalism.HermitianCurvature.HermitianCurvatureProofs.LemmaEprimeFromSteps
import Formalism.HermitianCurvature.HermitianCurvatureProofs.LocalisationScaledIdealMemIff
import Formalism.HermitianCurvature.HermitianCurvatureProofs.LocalisationTypedIndependentExponent
import Formalism.HermitianCurvature.HermitianCurvatureProofs.MajorantIntegrals
import Formalism.HermitianCurvature.HermitianCurvatureProofs.MeanBoundsLimits
import Formalism.HermitianCurvature.HermitianCurvatureProofs.MeasIterDeriv
import Formalism.HermitianCurvature.HermitianCurvatureProofs.OneLevelInequality
import Formalism.HermitianCurvature.HermitianCurvatureProofs.OneLevelInequalitySplitBySize
import Formalism.HermitianCurvature.HermitianCurvatureProofs.OrderIndexAndStrata

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.GaussJetBounds.GaussJetProofs.PureCrossTermWeight, `Formalism.GaussJetBounds.OneLetterGaussJets.OneLetterGaussProofs.CapLeOddShiftBound, `Formalism.GaussJetBounds.StatementG, `Formalism.GaussJetBounds.StatementR, `Formalism.GaussValuationBounds.GaussValueContraction.GaussValueContractionProofFactBis, `Formalism.GaussValuationBounds.GaussValueContraction.GaussValueContractionProofFactVariant, `Formalism.GaussValuationBounds.GaussValueContraction.KapBoundProof, `Formalism.GaussValuationBounds.GaussValueContraction.PhiIterXProof, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.BideterminantDominance, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.ColLexInitMinor, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.ColSums, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.ColumnLexBideterminant, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylMap, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylMul, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylNonDom, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylPoint, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylRowGraded, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylRowStable, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.DualWeylSat, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockDiagBound, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockPos, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockSubAdj, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.HWRaise, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.HWRowWeight, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.HighestWeightVectorNeZero, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LBidetMinor, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LCcompLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LCdegLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LCpeelLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LCpleadLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LCssytLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LFockqLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LGradedLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LHwinLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LeadComp, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LeadInterlaced, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.MinorExpLt, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.RowDivStable, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.StandardMonomialSpanOf, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.TwoColumn, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.WeylLeDual, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.WeylRowDivStable, `Formalism.GrowthSums.FactorialBaseGrowth.NextEvenTopHolds, `Formalism.GrowthSums.FactorialBaseGrowth.Segment, `Formalism.HermitianCurvature.HermitianCurvatureProofs.AverageOne, `Formalism.HermitianCurvature.HermitianCurvatureProofs.BetaBoundOnBoundary, `Formalism.HermitianCurvature.HermitianCurvatureProofs.BlockEstimatesSumForm, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ChainAndRowSums, `Formalism.HermitianCurvature.HermitianCurvatureProofs.DegreeOfProdLinearLe, `Formalism.HermitianCurvature.HermitianCurvatureProofs.DetRowsZero, `Formalism.HermitianCurvature.HermitianCurvatureProofs.EntryCommuteTransposedRMatrix, `Formalism.HermitianCurvature.HermitianCurvatureProofs.FinrankLeOfMapLe, `Formalism.HermitianCurvature.HermitianCurvatureProofs.FrameLevelIndices, `Formalism.HermitianCurvature.HermitianCurvatureProofs.GaussSumModulusOfLattice, `Formalism.HermitianCurvature.HermitianCurvatureProofs.KroneckerEmbedMulApply, `Formalism.HermitianCurvature.HermitianCurvatureProofs.LemmaEprimeFromSteps, `Formalism.HermitianCurvature.HermitianCurvatureProofs.LocalisationScaledIdealMemIff, `Formalism.HermitianCurvature.HermitianCurvatureProofs.LocalisationTypedIndependentExponent, `Formalism.HermitianCurvature.HermitianCurvatureProofs.MajorantIntegrals, `Formalism.HermitianCurvature.HermitianCurvatureProofs.MeanBoundsLimits, `Formalism.HermitianCurvature.HermitianCurvatureProofs.MeasIterDeriv, `Formalism.HermitianCurvature.HermitianCurvatureProofs.OneLevelInequality, `Formalism.HermitianCurvature.HermitianCurvatureProofs.OneLevelInequalitySplitBySize, `Formalism.HermitianCurvature.HermitianCurvatureProofs.OrderIndexAndStrata]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

