import Lean
import Formalism.TorsionNormIteration.Statement
import Formalism.TruncatedSeriesCounting.LemmaDetPoly
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.AprimeArith
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.ArcExp
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.ColTwoStep
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.CountBd
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.CutsExist
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.LengthQuotientLeOfPowSMul
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.QNumericalIdentity
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.RrBound
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.SaturationCriterion
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.ThmEExp
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.TruncSig
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.TruncationRemainderBound
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.UnitCoefficientPowerMod
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.Decompose
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.KernGr
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.StepCore
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.WeightedNormFinite
import Formalism.WachLatticeTwists.HodgeTateChains.AdicPerturbationFixedFreeAndCoboundary
import Formalism.WachLatticeTwists.HodgeTateChains.HodgeTateFiltrations.CycLen
import Formalism.WachLatticeTwists.HodgeTateChains.HodgeTateFiltrations.FiltPow
import Formalism.WachLatticeTwists.LagrangeExtensionCocycles.ExtensionCocycleProofs.PhiOnto
import Formalism.WachLatticeTwists.LagrangeExtensionCocycles.ExtensionCocycleProofs.ResidueSeriesExpansionHolds
import Formalism.WachLatticeTwists.LagrangeExtensionCocycles.ExtensionCocycleProofs.SizeBoundSecondCase
import Formalism.WachLatticeTwists.LagrangeExtensionCocycles.StatWPrimeExt
import Formalism.WachLatticeTwists.SplitLocalLifts.Statement
import Formalism.WachLatticeTwists.WachProductBases.NontrivialWachExample
import Formalism.WachLatticeTwists.WachProductBases.StatementTop
import Formalism.WachLatticeTwists.WachProductBases.WachProductProofs.FreeMembershipHeightOne
import Formalism.WachLatticeTwists.WachProductBases.WachProductProofs.InvariantBasisAverage
import Formalism.WachLatticeTwists.WachProductBases.WachProductProofs.LemmaThreeTameExponent
import Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.ExLattice
import Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.ExistsPeriodRingDataHolds
import Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.ExwaFiltrationNegOneEqSpanSingle
import Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.Galois
import Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.JumpsPFilAntitoneOfLe
import Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.RankOne
import Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.TrivCrys
import Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.WachCol
import Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.Window
import Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.WindowCountIcoTelescope
import Formalism.WeaklyAdmissibleFiltrations.DpcrisStable
import Formalism.WindowSums.PowerSeriesRelationList
import Formalism.YangianSpanCharacter.StatementB
import Formalism.YangianSpanCharacter.YangianRTTProofs.MinusFrameIdentity
import Formalism.ZeroFreeRegion.SmallHeightLogDeriv
import Formalism.ZetaNonvanishing.GzLipschitz
import Formalism.ZetaNonvanishing.LandauEq
import Formalism.ZetaNonvanishing.MeasurableGchi
import Formalism.ZetaNonvanishing.MellinSgen
import Formalism.ZetaNonvanishingGeneralWeights
import GroundTheory.ArithmeticGeometry.AbelianVarieties.FunctionFieldPoint
import GroundTheory.ArithmeticGeometry.AbelianVarieties.Torsion
import GroundTheory.ArithmeticGeometry.SchemeCohomology.CechToDerived
import GroundTheory.ArithmeticGeometry.SchemeCohomology.LocalizingCech
import GroundTheory.ArithmeticGeometry.SchemeCohomology.Picard
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProjLaurent
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProjectiveCohomology.ImmersionPullback
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProjectiveSpaceChart
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.PullbackBaseChange
import GroundTheory.ArithmeticGeometry.SchemeCohomology.RegularUFD
import GroundTheory.ArithmeticGeometry.SchemeCohomology.WeilDivisorSheafIso
import GroundTheory.ArithmeticGeometry.ToricVarieties.Affine

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.TorsionNormIteration.Statement, `Formalism.TruncatedSeriesCounting.LemmaDetPoly, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.AprimeArith, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.ArcExp, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.ColTwoStep, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.CountBd, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.CutsExist, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.LengthQuotientLeOfPowSMul, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.QNumericalIdentity, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.RrBound, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.SaturationCriterion, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.ThmEExp, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.TruncSig, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.TruncationRemainderBound, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.UnitCoefficientPowerMod, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.Decompose, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.KernGr, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.StepCore, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.WeightedNormFinite, `Formalism.WachLatticeTwists.HodgeTateChains.AdicPerturbationFixedFreeAndCoboundary, `Formalism.WachLatticeTwists.HodgeTateChains.HodgeTateFiltrations.CycLen, `Formalism.WachLatticeTwists.HodgeTateChains.HodgeTateFiltrations.FiltPow, `Formalism.WachLatticeTwists.LagrangeExtensionCocycles.ExtensionCocycleProofs.PhiOnto, `Formalism.WachLatticeTwists.LagrangeExtensionCocycles.ExtensionCocycleProofs.ResidueSeriesExpansionHolds, `Formalism.WachLatticeTwists.LagrangeExtensionCocycles.ExtensionCocycleProofs.SizeBoundSecondCase, `Formalism.WachLatticeTwists.LagrangeExtensionCocycles.StatWPrimeExt, `Formalism.WachLatticeTwists.SplitLocalLifts.Statement, `Formalism.WachLatticeTwists.WachProductBases.NontrivialWachExample, `Formalism.WachLatticeTwists.WachProductBases.StatementTop, `Formalism.WachLatticeTwists.WachProductBases.WachProductProofs.FreeMembershipHeightOne, `Formalism.WachLatticeTwists.WachProductBases.WachProductProofs.InvariantBasisAverage, `Formalism.WachLatticeTwists.WachProductBases.WachProductProofs.LemmaThreeTameExponent, `Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.ExLattice, `Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.ExistsPeriodRingDataHolds, `Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.ExwaFiltrationNegOneEqSpanSingle, `Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.Galois, `Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.JumpsPFilAntitoneOfLe, `Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.RankOne, `Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.TrivCrys, `Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.WachCol, `Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.Window, `Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.WindowCountIcoTelescope, `Formalism.WeaklyAdmissibleFiltrations.DpcrisStable, `Formalism.WindowSums.PowerSeriesRelationList, `Formalism.YangianSpanCharacter.StatementB, `Formalism.YangianSpanCharacter.YangianRTTProofs.MinusFrameIdentity, `Formalism.ZeroFreeRegion.SmallHeightLogDeriv, `Formalism.ZetaNonvanishing.GzLipschitz, `Formalism.ZetaNonvanishing.LandauEq, `Formalism.ZetaNonvanishing.MeasurableGchi, `Formalism.ZetaNonvanishing.MellinSgen, `Formalism.ZetaNonvanishingGeneralWeights, `GroundTheory.ArithmeticGeometry.AbelianVarieties.FunctionFieldPoint, `GroundTheory.ArithmeticGeometry.AbelianVarieties.Torsion, `GroundTheory.ArithmeticGeometry.SchemeCohomology.CechToDerived, `GroundTheory.ArithmeticGeometry.SchemeCohomology.LocalizingCech, `GroundTheory.ArithmeticGeometry.SchemeCohomology.Picard, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProjLaurent, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProjectiveCohomology.ImmersionPullback, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProjectiveSpaceChart, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.PullbackBaseChange, `GroundTheory.ArithmeticGeometry.SchemeCohomology.RegularUFD, `GroundTheory.ArithmeticGeometry.SchemeCohomology.WeilDivisorSheafIso, `GroundTheory.ArithmeticGeometry.ToricVarieties.Affine]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

