import Lean
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.TailMertens
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.TailNum
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.TpCoeffNorm
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.CardFiberMulCardRange
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.CardFilterResCharLe
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.DetMulLeftCompMulRight
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.DiscreteTopologyOfZsmul
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsMulSubOneMemPow
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsNormOneOfPair
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.FundamentalDomainPiBasis
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.IsLocUnif
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.MassLandDA
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.RelIndexEqOfCover
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.SummableSqGeom
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.TendstoTsumDivPow
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.VolumeNormSqLeOne
import Formalism.GaloisIrreducibility.Statement
import Formalism.GammaFactorNonvanishing.RhOfRight
import Formalism.GaussIdealIdentity.StatementLA
import Formalism.GaussJetBounds.StatementH
import Formalism.GelfandTransference.EnergyIdentity
import Formalism.GelfandTransference.GelfandCentral
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LCassemLemmas
import Formalism.GrowthSums.FactorialBaseGrowth.KapPrime
import Formalism.GrowthSums.FactorialBaseGrowth.Length
import Formalism.HermitianCurvature.HermitianCurvatureProofs.CoeffOfValues
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ContinuousOnG2SymmetricInterval
import Formalism.HermitianCurvature.HermitianCurvatureProofs.HasDerivAtTMul
import Formalism.HermitianCurvature.HermitianCurvatureProofs.IntegralIteratedFDerivEqZero
import Formalism.HermitianCurvature.HermitianCurvatureProofs.MomentIntegrable
import Formalism.HermitianCurvature.HermitianCurvatureProofs.NormSumLeOfForm
import Formalism.HermitianCurvature.HermitianCurvatureProofs.NormSumLeOfGram
import Formalism.HermitianCurvature.Statement
import Formalism.HermitianCurvature.StatementE
import Formalism.HermitianCurvature.StatementG
import Formalism.HermitianCurvature.StatementH
import Formalism.HermitianCurvature.StatementI
import Formalism.HermitianCurvature.StatementL
import Formalism.HermitianCurvature.StatementR
import Formalism.HermitianCurvature.StatementSz
import Formalism.HermitianCurvature.StatementX
import Formalism.HermitianLattices.StatementJac
import Formalism.HyperbolicPlaceProducts.DetIndexProductHyperbolicInequality
import Formalism.HyperbolicPlaceProducts.Statement
import Formalism.IncomingBounds.FrobOrbitPeriod
import Formalism.IncomingBounds.IncomingBound
import Formalism.JacquetSubsetSums.JacquetSubsetSum
import Formalism.JumpKernelCokernel.KerCokerEq
import Formalism.LagrangeIdealLifts.Statement
import Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.AbsZeroTermSecondDifferenceLe
import Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.LeOfSecondDifferenceBound
import Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.SumVonMangoldtNotCoprimeLe
import Formalism.LandauZeroFreeBounds.Statement
import Formalism.LatticeLocalGlobal.Statement
import Formalism.LatticeRigidity.HeightMin
import Formalism.LatticeRigidity.PackCount
import Formalism.LatticeRigidity.StatementA
import Formalism.LatticeRigidity.StatementC
import Formalism.LatticeSlopes.Statement
import Formalism.LatticeTheta.Statement
import Formalism.LocalRingCardinality.SpanPowerMembership.BasisOfBasisF
import Formalism.LocalRingCardinality.SpanPowerMembership.GatRing
import Formalism.LocalRingCardinality.SpanPowerMembership.HasStrictFDerivAtExpZero
import Formalism.LocalRingCardinality.SpanPowerMembership.LeOfEventuallyDown

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.TailMertens, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.TailNum, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.JacobiCharacterSums.TpCoeffNorm, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.CardFiberMulCardRange, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.CardFilterResCharLe, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.DetMulLeftCompMulRight, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.DiscreteTopologyOfZsmul, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsMulSubOneMemPow, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsNormOneOfPair, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.FundamentalDomainPiBasis, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.IsLocUnif, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.MassLandDA, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.RelIndexEqOfCover, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.SummableSqGeom, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.TendstoTsumDivPow, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.VolumeNormSqLeOne, `Formalism.GaloisIrreducibility.Statement, `Formalism.GammaFactorNonvanishing.RhOfRight, `Formalism.GaussIdealIdentity.StatementLA, `Formalism.GaussJetBounds.StatementH, `Formalism.GelfandTransference.EnergyIdentity, `Formalism.GelfandTransference.GelfandCentral, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LCassemLemmas, `Formalism.GrowthSums.FactorialBaseGrowth.KapPrime, `Formalism.GrowthSums.FactorialBaseGrowth.Length, `Formalism.HermitianCurvature.HermitianCurvatureProofs.CoeffOfValues, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ContinuousOnG2SymmetricInterval, `Formalism.HermitianCurvature.HermitianCurvatureProofs.HasDerivAtTMul, `Formalism.HermitianCurvature.HermitianCurvatureProofs.IntegralIteratedFDerivEqZero, `Formalism.HermitianCurvature.HermitianCurvatureProofs.MomentIntegrable, `Formalism.HermitianCurvature.HermitianCurvatureProofs.NormSumLeOfForm, `Formalism.HermitianCurvature.HermitianCurvatureProofs.NormSumLeOfGram, `Formalism.HermitianCurvature.Statement, `Formalism.HermitianCurvature.StatementE, `Formalism.HermitianCurvature.StatementG, `Formalism.HermitianCurvature.StatementH, `Formalism.HermitianCurvature.StatementI, `Formalism.HermitianCurvature.StatementL, `Formalism.HermitianCurvature.StatementR, `Formalism.HermitianCurvature.StatementSz, `Formalism.HermitianCurvature.StatementX, `Formalism.HermitianLattices.StatementJac, `Formalism.HyperbolicPlaceProducts.DetIndexProductHyperbolicInequality, `Formalism.HyperbolicPlaceProducts.Statement, `Formalism.IncomingBounds.FrobOrbitPeriod, `Formalism.IncomingBounds.IncomingBound, `Formalism.JacquetSubsetSums.JacquetSubsetSum, `Formalism.JumpKernelCokernel.KerCokerEq, `Formalism.LagrangeIdealLifts.Statement, `Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.AbsZeroTermSecondDifferenceLe, `Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.LeOfSecondDifferenceBound, `Formalism.LandauZeroFreeBounds.ExceptionalZeroBounds.SumVonMangoldtNotCoprimeLe, `Formalism.LandauZeroFreeBounds.Statement, `Formalism.LatticeLocalGlobal.Statement, `Formalism.LatticeRigidity.HeightMin, `Formalism.LatticeRigidity.PackCount, `Formalism.LatticeRigidity.StatementA, `Formalism.LatticeRigidity.StatementC, `Formalism.LatticeSlopes.Statement, `Formalism.LatticeTheta.Statement, `Formalism.LocalRingCardinality.SpanPowerMembership.BasisOfBasisF, `Formalism.LocalRingCardinality.SpanPowerMembership.GatRing, `Formalism.LocalRingCardinality.SpanPowerMembership.HasStrictFDerivAtExpZero, `Formalism.LocalRingCardinality.SpanPowerMembership.LeOfEventuallyDown]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

