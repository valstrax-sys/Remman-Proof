import Lean
import Development.AutomorphicSpectrum.Definitions.DivisibilityTowers.CompactGapsGE
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.ExistsUnitFormLocalizationEtaleNbhd
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.InstBorelGL
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.IsCptGen
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.LieModel
import Development.AutomorphicSpectrum.Definitions.MembershipCriteria.LaEqSqrtSmulLam
import Development.AutomorphicSpectrum.Definitions.MetricPeriods.EtaCut
import Development.AutomorphicSpectrum.Definitions.MetricPeriods.InFlagDomainOne
import Development.AutomorphicSpectrum.Definitions.MetricPeriods.PairRelationOfScaledRatio
import Development.AutomorphicSpectrum.Definitions.MetricPeriods.RegularFormsIsBundleProjectiveCover
import Development.AutomorphicSpectrum.Definitions.SemilocalProjection.HidaSetting
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.EqOneOfPowEqLeExponent
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.MapMulRightEqOfMemCompactSubgroup
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.RelIndexInfEqOfMemMul
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.RelIndexNeZeroOfIsCompactOfRelOpen
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.RelIndexRatioCocycle
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.UnitLogOrthogonalWeightConstant
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.BlockGLSupportedMemMirabolicSupported
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.CentralizerCmFieldInvolution
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ComapFgOfValuationRing
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.CompactCentralizerTranslate
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DetFromColsFrameChange
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DetMulMapDetEqOneOfSesq
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DetOneAddCompCommField
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DvrOrderExistsUnitEqUnitMulZpowIff
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.EqZeroOfMemMapPow
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsAdaptedUnimodular
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsMaxRatioCleared
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsSurjectiveZmodOfNeZero
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FcIndepDetNeZeroOfRank
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FibrePowerMapOfTotalSpacesIsPullback
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FiniteFreeHom
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FromRowsMulFromColsSplit
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.IdealInfSmulTopOfProjective
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.IdealSheafComapIdealAffineOpenOfIsAffine
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocalRingModTEmbedsStrictHenselian
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.MemIdealSmulTopIffForallDual
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.MemMaxSmulTopIff
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.MultilinearSubMem
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.NatDegreeMinpolyEqOfClosed
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.NormalNoethLocalDimOneIsDVR
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.PowEqOneOfIsIntegralOfMulComplexConjEqOne
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.PowEqOneOfIsIntegralOfMulComplexConjEqOneAlt
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ProdNormEmbeddingsEqAbsNorm
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.RealOfFixedByConjugations
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.RootOfUnityEqOneOfSubOneMemSpan
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SeparatedOfFiniteSurjectiveQuotient
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SymplecticUnipotentShape
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.TeichmullerCharacterOrderGenerates
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.TelescopingCoordinateDifference
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ZarhinBundleKernelSecondCoordEquations
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AePolynomialNonvanishing
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AesmIteratedDerivReal
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AnalyticOrthogonalVanishing
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AnnihilatorCompactWithinNhds
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AntitoneDiagonalConjugate
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AntitoneWeightedSumZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ApplyMulOfCoprime
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ApproximateIdentityProductBumps
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.BlkConjTranspose
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardComapEqCardKerMulCardRangeInf
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardCosetRepsEqRelIndex
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardDivisorsSqLeTwoMul
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardEqCardKerMulCardRange

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Definitions.DivisibilityTowers.CompactGapsGE, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.ExistsUnitFormLocalizationEtaleNbhd, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.InstBorelGL, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.IsCptGen, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.LieModel, `Development.AutomorphicSpectrum.Definitions.MembershipCriteria.LaEqSqrtSmulLam, `Development.AutomorphicSpectrum.Definitions.MetricPeriods.EtaCut, `Development.AutomorphicSpectrum.Definitions.MetricPeriods.InFlagDomainOne, `Development.AutomorphicSpectrum.Definitions.MetricPeriods.PairRelationOfScaledRatio, `Development.AutomorphicSpectrum.Definitions.MetricPeriods.RegularFormsIsBundleProjectiveCover, `Development.AutomorphicSpectrum.Definitions.SemilocalProjection.HidaSetting, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.EqOneOfPowEqLeExponent, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.MapMulRightEqOfMemCompactSubgroup, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.RelIndexInfEqOfMemMul, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.RelIndexNeZeroOfIsCompactOfRelOpen, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.RelIndexRatioCocycle, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.UnitLogOrthogonalWeightConstant, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.BlockGLSupportedMemMirabolicSupported, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.CentralizerCmFieldInvolution, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ComapFgOfValuationRing, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.CompactCentralizerTranslate, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DetFromColsFrameChange, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DetMulMapDetEqOneOfSesq, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DetOneAddCompCommField, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.DvrOrderExistsUnitEqUnitMulZpowIff, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.EqZeroOfMemMapPow, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsAdaptedUnimodular, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsMaxRatioCleared, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsSurjectiveZmodOfNeZero, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FcIndepDetNeZeroOfRank, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FibrePowerMapOfTotalSpacesIsPullback, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FiniteFreeHom, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FromRowsMulFromColsSplit, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.IdealInfSmulTopOfProjective, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.IdealSheafComapIdealAffineOpenOfIsAffine, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.LocalRingModTEmbedsStrictHenselian, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.MemIdealSmulTopIffForallDual, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.MemMaxSmulTopIff, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.MultilinearSubMem, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.NatDegreeMinpolyEqOfClosed, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.NormalNoethLocalDimOneIsDVR, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.PowEqOneOfIsIntegralOfMulComplexConjEqOne, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.PowEqOneOfIsIntegralOfMulComplexConjEqOneAlt, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ProdNormEmbeddingsEqAbsNorm, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.RealOfFixedByConjugations, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.RootOfUnityEqOneOfSubOneMemSpan, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SeparatedOfFiniteSurjectiveQuotient, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SymplecticUnipotentShape, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.TeichmullerCharacterOrderGenerates, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.TelescopingCoordinateDifference, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ZarhinBundleKernelSecondCoordEquations, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AePolynomialNonvanishing, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AesmIteratedDerivReal, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AnalyticOrthogonalVanishing, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AnnihilatorCompactWithinNhds, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AntitoneDiagonalConjugate, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AntitoneWeightedSumZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ApplyMulOfCoprime, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ApproximateIdentityProductBumps, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.BlkConjTranspose, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardComapEqCardKerMulCardRangeInf, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardCosetRepsEqRelIndex, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardDivisorsSqLeTwoMul, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardEqCardKerMulCardRange]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

