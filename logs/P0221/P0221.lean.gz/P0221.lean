import Lean
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittUnramified.WittUnramMain
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ZeroWindow.FinsumMemLeFinsumMem
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ZeroWindow.Jensen
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ZeroWindow.RightChi
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ZeroWindow.Transfer
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.projection2.AllowColLt
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.projection2.Assemble
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.projection2.EntryEmbedMatrix
import Formalism.PeriodIntegrals.WPhDefs
import Formalism.PeriodIntegrals.ZuckTensor
import Formalism.PieriBlockIdeals.JointCW5
import Formalism.PieriBlockIdeals.JointTheoremALoc
import Formalism.PieriBlockIdeals.LatticeInclusionFormsInjective
import Formalism.PieriBlockIdeals.LemmaWAssembled
import Formalism.PieriBlockIdeals.MertensReciprocalElementary
import Formalism.PieriBlockIdeals.PieriColumnMinors.LocalComponentGL
import Formalism.PieriBlockIdeals.PieriColumnMinors.LogarithmEquivalence
import Formalism.PieriBlockIdeals.PieriColumnMinors.MaxValEqZeroOfLt
import Formalism.PieriBlockIdeals.PieriColumnMinors.WeightExchangeChainHolds
import Formalism.PieriBlockIdeals.StatementJ
import Formalism.PolynomialDimension.DetMulEqSumAdjugate
import Formalism.PolynomialDimension.DigitSumValuationBound
import Formalism.PolynomialDimension.EdgeSumGoodRank
import Formalism.PolynomialDimension.MultinomialDepth.BinomialSeriesBound
import Formalism.PolynomialDimension.MultinomialDepth.FrameMultinomialBoundHolds
import Formalism.PolynomialDimension.MultinomialDepth.HarmonicLevelCountRec
import Formalism.PolynomialDimension.MultinomialDepth.HockeyStickIdentity
import Formalism.PolynomialDimension.MultinomialDepth.LemmaS
import Formalism.PolynomialDimension.MultinomialDepth.ParamsI
import Formalism.PolynomialDimension.MultinomialDepth.SecondParameterSizeBoundsHolds
import Formalism.PolynomialDimension.MultinomialDepth.SecondParameterSlackBoundsHolds
import Formalism.PolynomialDimension.MultinomialDepth.SqrtFockGaussLatticeComparisonHolds
import Formalism.PolynomialDimension.MultinomialDepth.WeylDimPosOfAntitone
import Formalism.RankGapBounds.RankGapProofs.FormsTensorLocalization
import Formalism.RankGapBounds.RankGapProofs.RankGapDecayHypothesis
import Formalism.RankGapBounds.RankGapProofs.UniformMeanTopLine
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.CartanInvolutionConjTransposeMul
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.CasComm
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.CompactCasimirHighestWeight
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.ComplexifiedDerivativeCommutator
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.GeneratorPowUpperVanishHolds
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.HWDiag
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.IsCompactInvariantCompactSpan
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.IsCompactInvariantOrthogonalInf
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.KoszulLowersPower
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.LeadingMinorEqDetSubmatrix
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.ProdFactorialSupportSubSingle
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.SatisfiesGlRelationsBilinearLeft
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.TrPowSumFilterZero
import Formalism.RealPlaceAnalysis.StatementC
import Formalism.RealPlaceAnalysis.StatementE
import Formalism.ResultantValuation.PrimePairDyadicDisjointAlt
import Formalism.ResultantValuation.ResultantAdjugateProofs.Mobius
import Formalism.ResultantValuation.ResultantAdjugateProofs.Parabolic
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.AfsplitA
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Cartan
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.FSatakeA
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.HeckeActionLevelMemHolds
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.HeckeAssoc
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.HeckeConvolutionMemHolds
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.LevelSubgroupFiniteAdelicStandard
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Levelaf
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Levelv
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Levelvsplit

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittUnramified.WittUnramMain, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ZeroWindow.FinsumMemLeFinsumMem, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ZeroWindow.Jensen, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ZeroWindow.RightChi, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ZeroWindow.Transfer, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.projection2.AllowColLt, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.projection2.Assemble, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.projection2.EntryEmbedMatrix, `Formalism.PeriodIntegrals.WPhDefs, `Formalism.PeriodIntegrals.ZuckTensor, `Formalism.PieriBlockIdeals.JointCW5, `Formalism.PieriBlockIdeals.JointTheoremALoc, `Formalism.PieriBlockIdeals.LatticeInclusionFormsInjective, `Formalism.PieriBlockIdeals.LemmaWAssembled, `Formalism.PieriBlockIdeals.MertensReciprocalElementary, `Formalism.PieriBlockIdeals.PieriColumnMinors.LocalComponentGL, `Formalism.PieriBlockIdeals.PieriColumnMinors.LogarithmEquivalence, `Formalism.PieriBlockIdeals.PieriColumnMinors.MaxValEqZeroOfLt, `Formalism.PieriBlockIdeals.PieriColumnMinors.WeightExchangeChainHolds, `Formalism.PieriBlockIdeals.StatementJ, `Formalism.PolynomialDimension.DetMulEqSumAdjugate, `Formalism.PolynomialDimension.DigitSumValuationBound, `Formalism.PolynomialDimension.EdgeSumGoodRank, `Formalism.PolynomialDimension.MultinomialDepth.BinomialSeriesBound, `Formalism.PolynomialDimension.MultinomialDepth.FrameMultinomialBoundHolds, `Formalism.PolynomialDimension.MultinomialDepth.HarmonicLevelCountRec, `Formalism.PolynomialDimension.MultinomialDepth.HockeyStickIdentity, `Formalism.PolynomialDimension.MultinomialDepth.LemmaS, `Formalism.PolynomialDimension.MultinomialDepth.ParamsI, `Formalism.PolynomialDimension.MultinomialDepth.SecondParameterSizeBoundsHolds, `Formalism.PolynomialDimension.MultinomialDepth.SecondParameterSlackBoundsHolds, `Formalism.PolynomialDimension.MultinomialDepth.SqrtFockGaussLatticeComparisonHolds, `Formalism.PolynomialDimension.MultinomialDepth.WeylDimPosOfAntitone, `Formalism.RankGapBounds.RankGapProofs.FormsTensorLocalization, `Formalism.RankGapBounds.RankGapProofs.RankGapDecayHypothesis, `Formalism.RankGapBounds.RankGapProofs.UniformMeanTopLine, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.CartanInvolutionConjTransposeMul, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.CasComm, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.CompactCasimirHighestWeight, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.ComplexifiedDerivativeCommutator, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.GeneratorPowUpperVanishHolds, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.HWDiag, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.IsCompactInvariantCompactSpan, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.IsCompactInvariantOrthogonalInf, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.KoszulLowersPower, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.LeadingMinorEqDetSubmatrix, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.ProdFactorialSupportSubSingle, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.SatisfiesGlRelationsBilinearLeft, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.TrPowSumFilterZero, `Formalism.RealPlaceAnalysis.StatementC, `Formalism.RealPlaceAnalysis.StatementE, `Formalism.ResultantValuation.PrimePairDyadicDisjointAlt, `Formalism.ResultantValuation.ResultantAdjugateProofs.Mobius, `Formalism.ResultantValuation.ResultantAdjugateProofs.Parabolic, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.AfsplitA, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Cartan, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.FSatakeA, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.HeckeActionLevelMemHolds, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.HeckeAssoc, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.HeckeConvolutionMemHolds, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.LevelSubgroupFiniteAdelicStandard, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Levelaf, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Levelv, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Levelvsplit]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

