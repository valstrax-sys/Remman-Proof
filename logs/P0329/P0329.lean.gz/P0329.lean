import Lean
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.CharIdem
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ClassNumImQInt
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.CoefExt
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DefPosDef
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DensSplit
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DiaFixDim
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DiscrNe
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.EfRankSum
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ExistsGaugeNormalizedStabilizer
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ExpIntW
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ExpTri
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FglPhSplit
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FockHarmSplit
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FockWtDeg
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FoldMult
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FoldUnfold
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.IsoDerivB
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.JetsPhW
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KerDetFin
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KerFourSq
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KerSelfDual
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.LowSmooth
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.Minkowski
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PrimeCount
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SSAscent
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.TrDualLoc
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.TwNormLat
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.UnfoldEquiv
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.UnitKron
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.UnitaryDense
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.WeilQuotMeas
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.WfRing
import Formalism.PeriodIntegrals.QmBorderES
import Formalism.PeriodIntegrals.QmBorderFull
import Formalism.PeriodIntegrals.QmColExp
import Formalism.PeriodIntegrals.QmMove
import Formalism.PeriodIntegrals.QmRowExp
import Formalism.PeriodIntegrals.QmRowForm
import Formalism.PeriodIntegrals.QmSkip
import Formalism.PeriodIntegrals.QmStar
import Formalism.PeriodIntegrals.QuotProdK
import Formalism.PeriodIntegrals.UJUnimod
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdditiveIntegralGroups.ThirdRootSubVarZeroNeZero
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicLocalCompactness.T2SpaceTensorProductFiniteExtension
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnitaryOrbits.HformEntry
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnitaryOrbits.InclRAlgebraMap
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnitaryOrbits.LocalSum
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnitaryOrbits.StFix
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnitaryOrbits.StLamOf
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.BaseLatticeIsUnimodular
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.PjCong
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.BlockEigenvalues.PhiUZero
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CMLatticeAreaFormula.AreaFormula
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ConjugationInvariance.SecondRowsBlockDiagMul
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.DualCountBound.MatIdxB
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.DualGramSubstitution.HasSubstRen
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.DyadicPrimeIntervals.FloorHalf
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.EagonNorthcottIntegral.AugmentationDegreeZero
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.EagonNorthcottIntegral.BasisZeroEqSingle
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.EagonNorthcottIntegral.CardFilterLtInsert
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.EagonNorthcottIntegral.DivisionLowersSecondDegree
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.EagonNorthcottIntegral.EagonNorthcottExactOf
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.EagonNorthcottIntegral.ExactSecondDegreeZeroOf
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.EagonNorthcottIntegral.LatticeInjective

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.PeriodIntegrals.OrbitalBoundsConclusion.CharIdem, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ClassNumImQInt, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.CoefExt, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DefPosDef, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DensSplit, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DiaFixDim, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DiscrNe, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.EfRankSum, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ExistsGaugeNormalizedStabilizer, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ExpIntW, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ExpTri, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FglPhSplit, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FockHarmSplit, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FockWtDeg, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FoldMult, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FoldUnfold, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.IsoDerivB, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.JetsPhW, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KerDetFin, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KerFourSq, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.KerSelfDual, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.LowSmooth, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.Minkowski, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PrimeCount, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SSAscent, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.TrDualLoc, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.TwNormLat, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.UnfoldEquiv, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.UnitKron, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.UnitaryDense, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.WeilQuotMeas, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.WfRing, `Formalism.PeriodIntegrals.QmBorderES, `Formalism.PeriodIntegrals.QmBorderFull, `Formalism.PeriodIntegrals.QmColExp, `Formalism.PeriodIntegrals.QmMove, `Formalism.PeriodIntegrals.QmRowExp, `Formalism.PeriodIntegrals.QmRowForm, `Formalism.PeriodIntegrals.QmSkip, `Formalism.PeriodIntegrals.QmStar, `Formalism.PeriodIntegrals.QuotProdK, `Formalism.PeriodIntegrals.UJUnimod, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdditiveIntegralGroups.ThirdRootSubVarZeroNeZero, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicLocalCompactness.T2SpaceTensorProductFiniteExtension, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnitaryOrbits.HformEntry, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnitaryOrbits.InclRAlgebraMap, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnitaryOrbits.LocalSum, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnitaryOrbits.StFix, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnitaryOrbits.StLamOf, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.BaseLatticeIsUnimodular, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.PjCong, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.BlockEigenvalues.PhiUZero, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.CMLatticeAreaFormula.AreaFormula, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ConjugationInvariance.SecondRowsBlockDiagMul, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.DualCountBound.MatIdxB, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.DualGramSubstitution.HasSubstRen, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.DyadicPrimeIntervals.FloorHalf, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.EagonNorthcottIntegral.AugmentationDegreeZero, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.EagonNorthcottIntegral.BasisZeroEqSingle, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.EagonNorthcottIntegral.CardFilterLtInsert, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.EagonNorthcottIntegral.DivisionLowersSecondDegree, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.EagonNorthcottIntegral.EagonNorthcottExactOf, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.EagonNorthcottIntegral.ExactSecondDegreeZeroOf, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.EagonNorthcottIntegral.LatticeInjective]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

