import Lean
import Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.GoodOf
import Formalism.DistinguishedUnitIdeals.ExistsConstOfInvariantMod
import Formalism.DistinguishedUnitIdeals.FinalE
import Formalism.DistinguishedUnitIdeals.LemmaCFull
import Formalism.DistinguishedUnitIdeals.WordConsts
import Formalism.DoubleCosetMeasures.LatticeCoset
import Formalism.EisensteinCokernelLengths.FactorialValuationBounds.FactorialValuationBoundsProofFact
import Formalism.EisensteinCokernelLengths.FactorialValuationBounds.GaussRam
import Formalism.EisensteinCokernelLengths.FactorialValuationBounds.LagrangeIdealSgProof
import Formalism.EisensteinCokernelLengths.FactorialValuationBounds.PadicValNatFactorialLeReal
import Formalism.EisensteinCokernelLengths.FactorialValuationBounds.RationalTailBoundCubic
import Formalism.EllipticTorsion.EllipticTorsionProofs.Change
import Formalism.EllipticTorsion.EllipticTorsionProofs.CompExp
import Formalism.EllipticTorsion.EllipticTorsionProofs.Deuring
import Formalism.EllipticTorsion.EllipticTorsionProofs.ExpWeight
import Formalism.EllipticTorsion.EllipticTorsionProofs.FormalGroupPointsNoPrimeToPTorsion
import Formalism.EllipticTorsion.EllipticTorsionProofs.FormalGroupPointsSubgroupHolds
import Formalism.EllipticTorsion.EllipticTorsionProofs.JetsCube
import Formalism.EllipticTorsion.EllipticTorsionProofs.JetsOne
import Formalism.EllipticTorsion.EllipticTorsionProofs.JetsTwo
import Formalism.EllipticTorsion.EllipticTorsionProofs.Legendre
import Formalism.EllipticTorsion.EllipticTorsionProofs.LogWeight
import Formalism.EllipticTorsion.EllipticTorsionProofs.TorInt
import Formalism.EllipticTorsion.EllipticTorsionProofs.UnitCancel
import Formalism.EllipticTorsion.EllipticTorsionProofs.VeluInt
import Formalism.EllipticTorsion.EllipticTorsionWeights
import Formalism.EllipticTorsion.FormalGroupPointsParametrisation
import Formalism.FilteredPoleLength.LocalDescentLevels.InvFromBlocksApplyZero
import Formalism.FilteredPoleLength.LocalDescentLevels.LengthResidueFieldBase
import Formalism.FilteredPoleLength.LocalDescentLevels.LevelsChain
import Formalism.FilteredPoleLength.LocalDescentLevels.LocalStepDescent
import Formalism.FilteredPoleLength.ReducedBasisBounds.GradedFreeLengthFiltered
import Formalism.FlagUnipotentLattices.LatticeDeterminantIndexSq
import Formalism.FlagUnipotentLattices.MemLpTwoOfOneTop
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.ComplexMultiplicationRoot
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.ConstantProductFormula
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.LatticeSumTupleOfLatticeSumTuple
import Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.SuperdiagonalAdditionInvariance
import Formalism.FlagUnipotentLattices.OmSumLong
import Formalism.FlagUnipotentLattices.UnipotentStabiliserCharacterisation
import Formalism.FormalDegreeBessel.FinalBF
import Formalism.FormalDegreeBessel.FinalG
import Formalism.FormalDegreeBessel.FormalDegreeRatio.DSFdeg
import Formalism.FormalDegreeBessel.FormalDegreeRatio.DSLowK
import Formalism.FormalDegreeBessel.FormalDegreeRatio.DSRatio
import Formalism.FormalDegreeBessel.HolDimLowK
import Formalism.FormalGroupWitt.FormalGroupWittProofs.AdditiveLawExample
import Formalism.FormalGroupWitt.FormalGroupWittProofs.ShiftFE
import Formalism.FormalGroupWitt.FormalGroupWittProofs.WittTeichmullerRoot
import Formalism.FormalGroupWitt.ShiftSOneLetter
import Formalism.FormalGroupWitt.SubstInjectiveV
import Formalism.FrobeniusBaseCase.FrobeniusBaseCaseProofs.SecondWayHolds
import Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.DiscriminantRealSubfield
import Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.SplitK
import Formalism.FrobeniusOrbits.HostOrbitCountSg
import Formalism.FrobeniusOrbits.HostThickExists
import Formalism.GL3MeanSquares.AffineFibreCountComparison
import Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsIsomFrame
import Formalism.GL3MeanSquares.HookFormulaTorsion.ColumnParametrizationOffDiagonal
import Formalism.GL3MeanSquares.HookFormulaTorsion.FibreCardinalityOfModuliMap
import Formalism.GL3MeanSquares.HookFormulaTorsion.LengthQuotientBoundGeneral
import Formalism.GL3MeanSquares.TraceIntegralityResults
import Formalism.GaussJetBounds.GaussJetProofs.AsmRDotAddRight
import Formalism.GaussJetBounds.GaussJetProofs.NormNatCastEqPowPadicValNat

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.DistinguishedUnitIdeals.DistinguishedOrderProofs.GoodOf, `Formalism.DistinguishedUnitIdeals.ExistsConstOfInvariantMod, `Formalism.DistinguishedUnitIdeals.FinalE, `Formalism.DistinguishedUnitIdeals.LemmaCFull, `Formalism.DistinguishedUnitIdeals.WordConsts, `Formalism.DoubleCosetMeasures.LatticeCoset, `Formalism.EisensteinCokernelLengths.FactorialValuationBounds.FactorialValuationBoundsProofFact, `Formalism.EisensteinCokernelLengths.FactorialValuationBounds.GaussRam, `Formalism.EisensteinCokernelLengths.FactorialValuationBounds.LagrangeIdealSgProof, `Formalism.EisensteinCokernelLengths.FactorialValuationBounds.PadicValNatFactorialLeReal, `Formalism.EisensteinCokernelLengths.FactorialValuationBounds.RationalTailBoundCubic, `Formalism.EllipticTorsion.EllipticTorsionProofs.Change, `Formalism.EllipticTorsion.EllipticTorsionProofs.CompExp, `Formalism.EllipticTorsion.EllipticTorsionProofs.Deuring, `Formalism.EllipticTorsion.EllipticTorsionProofs.ExpWeight, `Formalism.EllipticTorsion.EllipticTorsionProofs.FormalGroupPointsNoPrimeToPTorsion, `Formalism.EllipticTorsion.EllipticTorsionProofs.FormalGroupPointsSubgroupHolds, `Formalism.EllipticTorsion.EllipticTorsionProofs.JetsCube, `Formalism.EllipticTorsion.EllipticTorsionProofs.JetsOne, `Formalism.EllipticTorsion.EllipticTorsionProofs.JetsTwo, `Formalism.EllipticTorsion.EllipticTorsionProofs.Legendre, `Formalism.EllipticTorsion.EllipticTorsionProofs.LogWeight, `Formalism.EllipticTorsion.EllipticTorsionProofs.TorInt, `Formalism.EllipticTorsion.EllipticTorsionProofs.UnitCancel, `Formalism.EllipticTorsion.EllipticTorsionProofs.VeluInt, `Formalism.EllipticTorsion.EllipticTorsionWeights, `Formalism.EllipticTorsion.FormalGroupPointsParametrisation, `Formalism.FilteredPoleLength.LocalDescentLevels.InvFromBlocksApplyZero, `Formalism.FilteredPoleLength.LocalDescentLevels.LengthResidueFieldBase, `Formalism.FilteredPoleLength.LocalDescentLevels.LevelsChain, `Formalism.FilteredPoleLength.LocalDescentLevels.LocalStepDescent, `Formalism.FilteredPoleLength.ReducedBasisBounds.GradedFreeLengthFiltered, `Formalism.FlagUnipotentLattices.LatticeDeterminantIndexSq, `Formalism.FlagUnipotentLattices.MemLpTwoOfOneTop, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.ComplexMultiplicationRoot, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.ConstantProductFormula, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.LatticeSumTupleOfLatticeSumTuple, `Formalism.FlagUnipotentLattices.MinkowskiFactorialBounds.SuperdiagonalAdditionInvariance, `Formalism.FlagUnipotentLattices.OmSumLong, `Formalism.FlagUnipotentLattices.UnipotentStabiliserCharacterisation, `Formalism.FormalDegreeBessel.FinalBF, `Formalism.FormalDegreeBessel.FinalG, `Formalism.FormalDegreeBessel.FormalDegreeRatio.DSFdeg, `Formalism.FormalDegreeBessel.FormalDegreeRatio.DSLowK, `Formalism.FormalDegreeBessel.FormalDegreeRatio.DSRatio, `Formalism.FormalDegreeBessel.HolDimLowK, `Formalism.FormalGroupWitt.FormalGroupWittProofs.AdditiveLawExample, `Formalism.FormalGroupWitt.FormalGroupWittProofs.ShiftFE, `Formalism.FormalGroupWitt.FormalGroupWittProofs.WittTeichmullerRoot, `Formalism.FormalGroupWitt.ShiftSOneLetter, `Formalism.FormalGroupWitt.SubstInjectiveV, `Formalism.FrobeniusBaseCase.FrobeniusBaseCaseProofs.SecondWayHolds, `Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.DiscriminantRealSubfield, `Formalism.FrobeniusOrbits.FrobeniusOrbitsProofs.SplitK, `Formalism.FrobeniusOrbits.HostOrbitCountSg, `Formalism.FrobeniusOrbits.HostThickExists, `Formalism.GL3MeanSquares.AffineFibreCountComparison, `Formalism.GL3MeanSquares.GenusMeanAsymptotics.UnimodularClassRepresentatives.ExistsIsomFrame, `Formalism.GL3MeanSquares.HookFormulaTorsion.ColumnParametrizationOffDiagonal, `Formalism.GL3MeanSquares.HookFormulaTorsion.FibreCardinalityOfModuliMap, `Formalism.GL3MeanSquares.HookFormulaTorsion.LengthQuotientBoundGeneral, `Formalism.GL3MeanSquares.TraceIntegralityResults, `Formalism.GaussJetBounds.GaussJetProofs.AsmRDotAddRight, `Formalism.GaussJetBounds.GaussJetProofs.NormNatCastEqPowPadicValNat]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

