import Lean
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.TwoMulFinrank
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.UltrametricDetNormLeStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.UltrametricDetNormStable
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AbsolutelyClosedUnitCoefficientRootStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AdicCompleteTensorFiniteStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AnnihilatorOpenCompact
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ArtinianLimitLiftOfCompatibleStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AverageOverMaximalCompactResidueStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.BlockDeterminantLawStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CancelLTensor
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardFibreGramDifferential
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardHermitianMatricesModPow
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardRangeMulQuotientBoundedLevel
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ChangeVariablesZeroCountStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousUnitaryMultiplicativeEqArgPowStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ConvergenceGroupOfBlockDetStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetOff
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CrossingOfWallsAndHeightsStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CyclicAlgebraHilbertNinetyStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DFormMem
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DeterminantMonotonicity
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EqZeroOfSumApplyEqZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EtaleSurjectiveLocalSection
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCharacterSeparatingLattice
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsIrreducibleOfFixed
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsMemInfConjOfIsDom
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsNcardEntrywiseBoxLe
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsRetraction
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsSchwartzBruhatCharacterIntegralOneStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsSmoothLogMemLieAlg
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExtensionLawStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteLengthOfLseqFirst
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteOutNeZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteProjectionPushforward
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FinsumOutTranslate
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FractionFieldTranscendenceBasisExt
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GalleryOfTubesAndCrossing
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussSumHermitianNormLevelOne
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussSumHermitianNormLevelShift
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussianDetSquareIntegralStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GeneralLinearTopologicalGroupStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HeckeCharacterExistsUniqueStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianCharacterOrthogonality
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianMatrixDiagonalizable
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianRepCountFourierExpansionStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianVectorValuesCard
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HkMemFixed
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HuaDeterminantIntegrableOfLt
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InvariantFunctionalEqHaarMultipleStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InverseTransformHolomorphicLinesStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InverseTransformLocallyBounded
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InverseTransformRecoversFunction
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IrreducibleHomFixedVectors
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsDomMonoid
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IwahoriContraction
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.JacquetTraceFourthProperty
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.JhMultMulLeOfSteps
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeThirdPropertyStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LeviDecompOfBlockDetStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LeviQuotientOfBlockDetStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralSplitColumnStatement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LseqOfLevelIsos
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MatrixGaussSumCongrInvariance
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MatrixGaussSumDiagonalFactor

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.AlgebraProofs.TwoMulFinrank, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.UltrametricDetNormLeStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.UltrametricDetNormStable, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AbsolutelyClosedUnitCoefficientRootStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AdicCompleteTensorFiniteStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AnnihilatorOpenCompact, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ArtinianLimitLiftOfCompatibleStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AverageOverMaximalCompactResidueStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.BlockDeterminantLawStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CancelLTensor, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardFibreGramDifferential, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardHermitianMatricesModPow, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CardRangeMulQuotientBoundedLevel, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ChangeVariablesZeroCountStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousUnitaryMultiplicativeEqArgPowStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ConvergenceGroupOfBlockDetStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetOff, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CrossingOfWallsAndHeightsStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CyclicAlgebraHilbertNinetyStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DFormMem, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DeterminantMonotonicity, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EqZeroOfSumApplyEqZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EtaleSurjectiveLocalSection, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCharacterSeparatingLattice, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsIrreducibleOfFixed, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsMemInfConjOfIsDom, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsNcardEntrywiseBoxLe, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsRetraction, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsSchwartzBruhatCharacterIntegralOneStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsSmoothLogMemLieAlg, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExtensionLawStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteLengthOfLseqFirst, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteOutNeZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteProjectionPushforward, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FinsumOutTranslate, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FractionFieldTranscendenceBasisExt, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GalleryOfTubesAndCrossing, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussSumHermitianNormLevelOne, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussSumHermitianNormLevelShift, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GaussianDetSquareIntegralStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.GeneralLinearTopologicalGroupStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HeckeCharacterExistsUniqueStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianCharacterOrthogonality, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianMatrixDiagonalizable, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianRepCountFourierExpansionStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HermitianVectorValuesCard, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HkMemFixed, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.HuaDeterminantIntegrableOfLt, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InvariantFunctionalEqHaarMultipleStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InverseTransformHolomorphicLinesStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InverseTransformLocallyBounded, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.InverseTransformRecoversFunction, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IrreducibleHomFixedVectors, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IsDomMonoid, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.IwahoriContraction, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.JacquetTraceFourthProperty, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.JhMultMulLeOfSteps, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LatticeThirdPropertyStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LeviDecompOfBlockDetStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LeviQuotientOfBlockDetStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LintegralSplitColumnStatement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.LseqOfLevelIsos, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MatrixGaussSumCongrInvariance, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.MatrixGaussSumDiagonalFactor]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

