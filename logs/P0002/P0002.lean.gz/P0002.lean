import Lean
import Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.WordDerivativeBlocks
import Development.AbelianVarietyTheory.BlockTheory.SiegelWeilLocal.FrameCoefficientData
import Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.EulerProductSatake
import Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.FlatZetaIntegral
import Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.IwahoriSubgroup
import Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.LowerUnipotentMinors
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.AdjointRadical
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.GaussianBinomialFormula
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.IntegralMatrixTranslation
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.LatticeCosetUniformizer
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.MinorOrderedEntries
import Development.AbelianVarietyTheory.Counterexamples.JetSurvey.PremisesInhabited
import Development.AbelianVarietyTheory.Counterexamples.LevelGroupExamples.RightInvariantOfCovolume
import Development.AbelianVarietyTheory.Definitions.AdelicHermitianForms.AdelicPair
import Development.AbelianVarietyTheory.Definitions.AdelicHermitianForms.IsHermHyperbolic
import Development.AbelianVarietyTheory.Definitions.AdelicHermitianForms.SqSubLeNormSub
import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.NonemptyRayDataOfNeZero
import Development.AbelianVarietyTheory.Definitions.CommutativeAlgebra.AbByPOfComm
import Development.AbelianVarietyTheory.Definitions.CommutativeAlgebra.InvariantSubspaceMobiusInverseRecEqOfFinrankLt
import Development.AbelianVarietyTheory.Definitions.Divisors.AltPullApply
import Development.AbelianVarietyTheory.Definitions.Divisors.ChainComp
import Development.AbelianVarietyTheory.Definitions.Divisors.CommAlgFunctorCoboundaryZeroMemCocyclesOne
import Development.AbelianVarietyTheory.Definitions.Divisors.FderivFnCongr
import Development.AbelianVarietyTheory.Definitions.Divisors.FormalModule
import Development.AbelianVarietyTheory.Definitions.Divisors.HasQIff
import Development.AbelianVarietyTheory.Definitions.Divisors.IsCyclotomicExtensionQI
import Development.AbelianVarietyTheory.Definitions.Divisors.IsRightActFunPull
import Development.AbelianVarietyTheory.Definitions.Divisors.IsSimplicial
import Development.AbelianVarietyTheory.Definitions.Divisors.LandherrCSA
import Development.AbelianVarietyTheory.Definitions.Divisors.NormSub
import Development.AbelianVarietyTheory.Definitions.Divisors.PerFactor
import Development.AbelianVarietyTheory.Definitions.Divisors.PlacesOverU
import Development.AbelianVarietyTheory.Definitions.Divisors.TCoefMInMMul
import Development.AbelianVarietyTheory.Definitions.Divisors.XiMulNu
import Development.AbelianVarietyTheory.Definitions.Divisors.ZetaPair
import Development.AbelianVarietyTheory.Definitions.ExistenceOfLattices.Hat1
import Development.AbelianVarietyTheory.Definitions.Foundations.CobOn
import Development.AbelianVarietyTheory.Definitions.Foundations.CosetTrace
import Development.AbelianVarietyTheory.Definitions.Foundations.CthFac
import Development.AbelianVarietyTheory.Definitions.Foundations.ExistsFinsetOfEventually
import Development.AbelianVarietyTheory.Definitions.Foundations.ExpUpper
import Development.AbelianVarietyTheory.Definitions.Foundations.InFrameStabilizer
import Development.AbelianVarietyTheory.Definitions.Foundations.Integral
import Development.AbelianVarietyTheory.Definitions.Foundations.IsDCReps
import Development.AbelianVarietyTheory.Definitions.Foundations.IsFirstChernClassOfLineBundle
import Development.AbelianVarietyTheory.Definitions.Foundations.IsOneCocycleOnSubgroup
import Development.AbelianVarietyTheory.Definitions.Foundations.MatrixMeasurableSpace
import Development.AbelianVarietyTheory.Definitions.Foundations.MemPuncturedRingIffPowerSeriesPart
import Development.AbelianVarietyTheory.Definitions.Foundations.MemUnitaryGroupIffIsIsometry
import Development.AbelianVarietyTheory.Definitions.Foundations.NotCoboundaryConstantOne
import Development.AbelianVarietyTheory.Definitions.Foundations.PetEqRelIndexMulPetProd
import Development.AbelianVarietyTheory.Definitions.Foundations.ShCocOn
import Development.AbelianVarietyTheory.Definitions.Foundations.SmoothPartStable
import Development.AbelianVarietyTheory.Definitions.Foundations.TableDegreeElevenProduct
import Development.AbelianVarietyTheory.Definitions.Foundations.ValuedAlgebraMapEqOne
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.FiniteResidueFieldPadicInt
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsGrothendieckAbelianPresheaf
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsMatrixForm
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.OfNatTrans
import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.ReductionUniformizerPoint
import Development.AbelianVarietyTheory.Definitions.GlobalTwisting.BasicForm
import Development.AbelianVarietyTheory.Definitions.GlobalTwisting.CocyclesCyclotomicFinrankThree
import Development.AbelianVarietyTheory.Definitions.GlobalTwisting.ContFromConst
import Development.AbelianVarietyTheory.Definitions.GlobalTwisting.PermRepSingle

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.WordDerivativeBlocks, `Development.AbelianVarietyTheory.BlockTheory.SiegelWeilLocal.FrameCoefficientData, `Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.EulerProductSatake, `Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.FlatZetaIntegral, `Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.IwahoriSubgroup, `Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.LowerUnipotentMinors, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.AdjointRadical, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.GaussianBinomialFormula, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.IntegralMatrixTranslation, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.LatticeCosetUniformizer, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.MinorOrderedEntries, `Development.AbelianVarietyTheory.Counterexamples.JetSurvey.PremisesInhabited, `Development.AbelianVarietyTheory.Counterexamples.LevelGroupExamples.RightInvariantOfCovolume, `Development.AbelianVarietyTheory.Definitions.AdelicHermitianForms.AdelicPair, `Development.AbelianVarietyTheory.Definitions.AdelicHermitianForms.IsHermHyperbolic, `Development.AbelianVarietyTheory.Definitions.AdelicHermitianForms.SqSubLeNormSub, `Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.NonemptyRayDataOfNeZero, `Development.AbelianVarietyTheory.Definitions.CommutativeAlgebra.AbByPOfComm, `Development.AbelianVarietyTheory.Definitions.CommutativeAlgebra.InvariantSubspaceMobiusInverseRecEqOfFinrankLt, `Development.AbelianVarietyTheory.Definitions.Divisors.AltPullApply, `Development.AbelianVarietyTheory.Definitions.Divisors.ChainComp, `Development.AbelianVarietyTheory.Definitions.Divisors.CommAlgFunctorCoboundaryZeroMemCocyclesOne, `Development.AbelianVarietyTheory.Definitions.Divisors.FderivFnCongr, `Development.AbelianVarietyTheory.Definitions.Divisors.FormalModule, `Development.AbelianVarietyTheory.Definitions.Divisors.HasQIff, `Development.AbelianVarietyTheory.Definitions.Divisors.IsCyclotomicExtensionQI, `Development.AbelianVarietyTheory.Definitions.Divisors.IsRightActFunPull, `Development.AbelianVarietyTheory.Definitions.Divisors.IsSimplicial, `Development.AbelianVarietyTheory.Definitions.Divisors.LandherrCSA, `Development.AbelianVarietyTheory.Definitions.Divisors.NormSub, `Development.AbelianVarietyTheory.Definitions.Divisors.PerFactor, `Development.AbelianVarietyTheory.Definitions.Divisors.PlacesOverU, `Development.AbelianVarietyTheory.Definitions.Divisors.TCoefMInMMul, `Development.AbelianVarietyTheory.Definitions.Divisors.XiMulNu, `Development.AbelianVarietyTheory.Definitions.Divisors.ZetaPair, `Development.AbelianVarietyTheory.Definitions.ExistenceOfLattices.Hat1, `Development.AbelianVarietyTheory.Definitions.Foundations.CobOn, `Development.AbelianVarietyTheory.Definitions.Foundations.CosetTrace, `Development.AbelianVarietyTheory.Definitions.Foundations.CthFac, `Development.AbelianVarietyTheory.Definitions.Foundations.ExistsFinsetOfEventually, `Development.AbelianVarietyTheory.Definitions.Foundations.ExpUpper, `Development.AbelianVarietyTheory.Definitions.Foundations.InFrameStabilizer, `Development.AbelianVarietyTheory.Definitions.Foundations.Integral, `Development.AbelianVarietyTheory.Definitions.Foundations.IsDCReps, `Development.AbelianVarietyTheory.Definitions.Foundations.IsFirstChernClassOfLineBundle, `Development.AbelianVarietyTheory.Definitions.Foundations.IsOneCocycleOnSubgroup, `Development.AbelianVarietyTheory.Definitions.Foundations.MatrixMeasurableSpace, `Development.AbelianVarietyTheory.Definitions.Foundations.MemPuncturedRingIffPowerSeriesPart, `Development.AbelianVarietyTheory.Definitions.Foundations.MemUnitaryGroupIffIsIsometry, `Development.AbelianVarietyTheory.Definitions.Foundations.NotCoboundaryConstantOne, `Development.AbelianVarietyTheory.Definitions.Foundations.PetEqRelIndexMulPetProd, `Development.AbelianVarietyTheory.Definitions.Foundations.ShCocOn, `Development.AbelianVarietyTheory.Definitions.Foundations.SmoothPartStable, `Development.AbelianVarietyTheory.Definitions.Foundations.TableDegreeElevenProduct, `Development.AbelianVarietyTheory.Definitions.Foundations.ValuedAlgebraMapEqOne, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.FiniteResidueFieldPadicInt, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsGrothendieckAbelianPresheaf, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsMatrixForm, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.OfNatTrans, `Development.AbelianVarietyTheory.Definitions.GaloisGeometry.ReductionUniformizerPoint, `Development.AbelianVarietyTheory.Definitions.GlobalTwisting.BasicForm, `Development.AbelianVarietyTheory.Definitions.GlobalTwisting.CocyclesCyclotomicFinrankThree, `Development.AbelianVarietyTheory.Definitions.GlobalTwisting.ContFromConst, `Development.AbelianVarietyTheory.Definitions.GlobalTwisting.PermRepSingle]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

