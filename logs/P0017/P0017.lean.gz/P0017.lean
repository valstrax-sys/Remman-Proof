import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LatticeVectorPairingOneIdealMultiple
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LaurentSeriesAdaptedBasisCoordsVanishBeyondFinra
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LeAddMulLogSqOfLeAddMulLog
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LeMulSetIntegralImage2OfForallLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LeNatCastOfAddOneLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LeSupKerMulOfLeSupMaximalMulSection
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LeftInverseOfIntegralSolutions
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LengthEqKerAddRange
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LengthKerCokerLsmulQuotientSpanSwap
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LiftModMaximalSkew
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LinIndepIntBilinFormCharZeroCombinationEqZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LinearIndepOnPowOfIsDomainTensorPurelyInseparabl
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LinearIndependentComplexMap
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LinearIndependentKaehlerDOfAlgebraicIndependent
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LinearIndependentOfDistinctValuationLike
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LintegralComplexInvPowAddNormSq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LintegralInvLeOfSupportCompact
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LintegralNormPowMulLeSqrtWeightedSq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LintegralPositiveNegativeParts
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LintegralSublevelTailLeOfFinite
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LintegralUnitBallRayAverageLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ListProdUpdateConjugate
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocHomAlgebraMap
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalDensitiesBoundedAlmostAll
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalFactorAtAugmentationCounitalComul
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalFreeLagrangianComplement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalHermitianDiagonalizationUnits
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalRingPointFiniteDescent
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalRingPointsIdealCriterion
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalSmoothPotentialGlue
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationAwayInjectiveAtPrimeOfDvd
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationAwayRangeLeOfDvdOfComp
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationIntegralClosureArtinianReducedDomain
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationMaximalIdealEqSpanNilpotentArtinian
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationProjectiveKernelFinite
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationQuotientComapEquiv
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationSubalgebraFrac
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationTensorMapInjectiveCokerKilled
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizedModuleMemAnnSpanSmulTop
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizedPresentationEvalQuotientFraction
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocallyConstantCompactSupportInvariantOpenAddSub
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocallyIntegrableRep
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogCardEqFinsumLengthLocalizedMaximal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogCardQuotSpanEqFinsumLogNormEmbeddings
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogConcaveMultiplicativeGrowthBound
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogHeightBoundFromInequality
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogNormSqGradientIdentity
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogOfExpContinuity
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogPowerSqrtLeCubeRoot
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogSingularityBallIntegralBound
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogSizeBoundsClassNumberVolume
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogThetaWeightSizeLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LowerBoundAlongResidues
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LowerBoundNumericalEnd
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LowerUnitriangularMulUpperTriangularOfIsUnitLead
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LtNatCastOfAddOneLtSucc
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LuDecompositionUnitriangularUnique
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapComapMaximalIdealEqOfFormallyUnramified
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapDomainRelationLiftCommutingSquare
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapEqZeroOfCommuteDoubling
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapHaarEqOfLattice
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapMkOfComp
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapOfRealAdd
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapOfRealOne

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.LatticeVectorPairingOneIdealMultiple, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LaurentSeriesAdaptedBasisCoordsVanishBeyondFinra, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LeAddMulLogSqOfLeAddMulLog, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LeMulSetIntegralImage2OfForallLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LeNatCastOfAddOneLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LeSupKerMulOfLeSupMaximalMulSection, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LeftInverseOfIntegralSolutions, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LengthEqKerAddRange, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LengthKerCokerLsmulQuotientSpanSwap, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LiftModMaximalSkew, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LinIndepIntBilinFormCharZeroCombinationEqZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LinearIndepOnPowOfIsDomainTensorPurelyInseparabl, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LinearIndependentComplexMap, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LinearIndependentKaehlerDOfAlgebraicIndependent, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LinearIndependentOfDistinctValuationLike, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LintegralComplexInvPowAddNormSq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LintegralInvLeOfSupportCompact, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LintegralNormPowMulLeSqrtWeightedSq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LintegralPositiveNegativeParts, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LintegralSublevelTailLeOfFinite, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LintegralUnitBallRayAverageLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ListProdUpdateConjugate, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocHomAlgebraMap, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalDensitiesBoundedAlmostAll, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalFactorAtAugmentationCounitalComul, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalFreeLagrangianComplement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalHermitianDiagonalizationUnits, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalRingPointFiniteDescent, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalRingPointsIdealCriterion, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalSmoothPotentialGlue, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationAwayInjectiveAtPrimeOfDvd, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationAwayRangeLeOfDvdOfComp, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationIntegralClosureArtinianReducedDomain, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationMaximalIdealEqSpanNilpotentArtinian, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationProjectiveKernelFinite, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationQuotientComapEquiv, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationSubalgebraFrac, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizationTensorMapInjectiveCokerKilled, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizedModuleMemAnnSpanSmulTop, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocalizedPresentationEvalQuotientFraction, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocallyConstantCompactSupportInvariantOpenAddSub, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LocallyIntegrableRep, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogCardEqFinsumLengthLocalizedMaximal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogCardQuotSpanEqFinsumLogNormEmbeddings, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogConcaveMultiplicativeGrowthBound, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogHeightBoundFromInequality, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogNormSqGradientIdentity, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogOfExpContinuity, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogPowerSqrtLeCubeRoot, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogSingularityBallIntegralBound, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogSizeBoundsClassNumberVolume, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LogThetaWeightSizeLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LowerBoundAlongResidues, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LowerBoundNumericalEnd, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LowerUnitriangularMulUpperTriangularOfIsUnitLead, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LtNatCastOfAddOneLtSucc, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.LuDecompositionUnitriangularUnique, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapComapMaximalIdealEqOfFormallyUnramified, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapDomainRelationLiftCommutingSquare, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapEqZeroOfCommuteDoubling, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapHaarEqOfLattice, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapMkOfComp, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapOfRealAdd, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapOfRealOne]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

