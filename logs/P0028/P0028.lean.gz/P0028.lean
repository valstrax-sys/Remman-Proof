import Lean
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ConstMulRpowMulLogPowLeRpow
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.DifferentiableAtMellinSummatory
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.EqOneOfNormSubOneLt
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.EqOneOfPowClose
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.EqXMulShiftAdd
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsComapPrime
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsConductorAdicCompletion
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsFactorOrder
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsInterpolationExteriorSmallCoeffs
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsIsPrimitiveRootOfAddCharNeOne
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsIsPrimitiveRootOfInjectiveCharacter
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsLeNormLFunctionOne
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsMultiplicativeLiftCharZero
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsProdAbsSubGeOnSegment
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.FiltLePow
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.FiniteOfFiniteQuotMapOfIsPrecomplete
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.FinitePointsDetect
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.FourierInversionHaarSymmForm
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ImageSqIoi
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.Imports
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ImportsAlt
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ImportsBis
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ImportsExtra
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ImportsTer
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.IntegralNormSqLp
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.IsPrincipalIdealRingLoc
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.LFunctionEqTsumOfOneLt
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.LinearEquivDescendsOfPreservesImage
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.LintegralTsumOrbitUnfold
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.LogAddRpowMulLogPowLeRpow
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.LogDerivEqOrderDivAddAnalytic
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.LogDerivativeBound
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.MaximalIdealLeFiltOne
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.MeasureEqZeroOfFiniteInterLines
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.MemPowOfCoeffMem
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.MonomialOneMem
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.NegSumLogDerivNonneg
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.NoethLocalHausdorff
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.NormSubOneMulRiemannZetaLe
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.PlaneLatticeShortBasisOfBoundPowTwo
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.QuadraticAtMostTwoPrimesOver
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.QuadraticUnramifiedIffInertOrSplit
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.QuotientSpanRange
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.SplitsAlgebraMap
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.SumCosetRepsNeZeroIffCommensurable
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.SumIntervalIntegralLeOfSpaced
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.SumPiFinsetFinSuccCons
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.SumRangeMulOfPeriodic
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.SummableExpNegMulSq
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.SummableNinePowMulInvSqSucc
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.TendstoCoeffZero
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.TruncatedPerronKernel
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.TsumOneDivRpowLe
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ValuationIntegerLeOne
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ValuationOfGeneratorOfPow
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.WeightedFejerPositivity
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ZetaEqSubIntegralFract
import Development.AbelianVarietyTheory.Proofs.HeightProofs.BddAboveOfSpanningPeriods
import Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsHyperbolicCompletion
import Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsIsAddHaarMeasureIsAddFundamentalDomainPrei
import Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsNatMulIsIntegral
import Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsNatMulMemRingOfIntegers
import Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsNhdsZeroPrincipalEqZero
import Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsProdXSubCOfMonic

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ConstMulRpowMulLogPowLeRpow, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.DifferentiableAtMellinSummatory, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.EqOneOfNormSubOneLt, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.EqOneOfPowClose, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.EqXMulShiftAdd, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsComapPrime, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsConductorAdicCompletion, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsFactorOrder, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsInterpolationExteriorSmallCoeffs, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsIsPrimitiveRootOfAddCharNeOne, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsIsPrimitiveRootOfInjectiveCharacter, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsLeNormLFunctionOne, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsMultiplicativeLiftCharZero, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsProdAbsSubGeOnSegment, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.FiltLePow, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.FiniteOfFiniteQuotMapOfIsPrecomplete, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.FinitePointsDetect, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.FourierInversionHaarSymmForm, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ImageSqIoi, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.Imports, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ImportsAlt, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ImportsBis, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ImportsExtra, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ImportsTer, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.IntegralNormSqLp, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.IsPrincipalIdealRingLoc, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.LFunctionEqTsumOfOneLt, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.LinearEquivDescendsOfPreservesImage, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.LintegralTsumOrbitUnfold, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.LogAddRpowMulLogPowLeRpow, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.LogDerivEqOrderDivAddAnalytic, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.LogDerivativeBound, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.MaximalIdealLeFiltOne, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.MeasureEqZeroOfFiniteInterLines, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.MemPowOfCoeffMem, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.MonomialOneMem, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.NegSumLogDerivNonneg, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.NoethLocalHausdorff, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.NormSubOneMulRiemannZetaLe, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.PlaneLatticeShortBasisOfBoundPowTwo, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.QuadraticAtMostTwoPrimesOver, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.QuadraticUnramifiedIffInertOrSplit, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.QuotientSpanRange, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.SplitsAlgebraMap, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.SumCosetRepsNeZeroIffCommensurable, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.SumIntervalIntegralLeOfSpaced, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.SumPiFinsetFinSuccCons, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.SumRangeMulOfPeriodic, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.SummableExpNegMulSq, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.SummableNinePowMulInvSqSucc, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.TendstoCoeffZero, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.TruncatedPerronKernel, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.TsumOneDivRpowLe, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ValuationIntegerLeOne, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ValuationOfGeneratorOfPow, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.WeightedFejerPositivity, `Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ZetaEqSubIntegralFract, `Development.AbelianVarietyTheory.Proofs.HeightProofs.BddAboveOfSpanningPeriods, `Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsHyperbolicCompletion, `Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsIsAddHaarMeasureIsAddFundamentalDomainPrei, `Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsNatMulIsIntegral, `Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsNatMulMemRingOfIntegers, `Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsNhdsZeroPrincipalEqZero, `Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsProdXSubCOfMonic]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

