import Lean
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittEndomorphism.FlogConstantCoeff
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittLogarithm.CoefWfIff
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittSubstitution.CoeffMapMem
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ZeroWindow.Assemble
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ZuckermanTensor.DualChoice
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.projection2.GaStep
import Formalism.PieriBlockIdeals.BranchingBoundLastGradedOneRow
import Formalism.PieriBlockIdeals.ExZTranslate
import Formalism.PieriBlockIdeals.ExponentBoundCounterexample
import Formalism.PieriBlockIdeals.IntegralQuotient
import Formalism.PieriBlockIdeals.MultiplicityZeroThickEmbedding
import Formalism.PieriBlockIdeals.PieriColumnMinors.HeckeLFunctionIdealEulerProduct
import Formalism.PolynomialDimension.ChangeLatticeGoodRank
import Formalism.PolynomialDimension.FinalNum
import Formalism.PolynomialDimension.MultinomialKLog
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.FirstSlotSliceSlotMixedCasimirZero
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.FrobeniusBoundOfMulNearOne
import Formalism.RealPlaceAnalysis.RealPlaceTaylor.ModularCharacterEqOneOnExpHermitian
import Formalism.RealPlaceAnalysis.SmoothVectorGrowthBound
import Formalism.RealPlaceAnalysis.ThirdArithmeticHolds
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.AdelstabL
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.AfsplitC
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Bridge
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.FIwasawaB
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.FSatakeC
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Tjcosets
import Formalism.SatakeDualWeyl.DefsCS
import Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.HarProjEqZeroIff
import Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.Monomial
import Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.PrimedEmbeddingInjective
import Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.ProjKeepsLetter
import Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.SegDefs
import Formalism.SharpRestriction.GrowthBounds.RootWeights.SumFinsuppAntidiagEqSumPiFinset
import Formalism.SharpRestriction.GrowthBounds.TwistedSubstitution.TwistedMonomialFiltration.MaxTwistDegreePderivLeAddOne
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.EigenRingInvariants
import Formalism.SharpRestriction.LevelLetterCocycles.JointConditionsZpowers.BaseCoefJumpProof
import Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.RkMultVOfNotJump
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.DvdCoeffsOfMemSpanDistinguished
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.Numerics
import Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.ConjEMemHostFIff
import Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.EvalFrameOrd
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleMono
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleSmall
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleUB
import Formalism.SubspaceCounting.ChoiceOfTopsRefined
import Formalism.TameInertiaTowers.TowerFieldFoundations
import Formalism.ThetaLiftIndependence.Statement
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.DualWeylProofs.BCoreW
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.DualWeylProofs.QcEvGLGenPtInt
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.DualWeylProofs.QhEquivOfCount
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.DualWeylProofs.QsMnTranspose
import Formalism.ThetaLogCoordinates.JacobiPathWeights.IndexWeightsDominance
import Formalism.ThetaLogCoordinates.JacobiPathWeights.JacobiMinorProofs.GenSpace
import Formalism.ThetaLogCoordinates.JacobiPathWeights.JacobiMinorProofs.IsWeightedHomogeneousZeroStripPathWord
import Formalism.ThetaLogCoordinates.JacobiPathWeights.JacobiMinorProofs.PathProductHighestWeight
import Formalism.ThetaLogCoordinates.ProductIdealMonotone.ProductIdealProofs.ElementarySymmetricExpBound
import Formalism.ThetaLogCoordinates.UniformThetaSubstitution.IsLawOfLog
import Formalism.TorsionNormIteration.InverseIntegralClasses.CoeffSubstAddCMulXPow
import Formalism.TorsionNormIteration.InverseIntegralClasses.IsHomOfSubstEqSmul
import Formalism.TorsionNormIteration.InverseIntegralClasses.MapSubtypeInjective
import Formalism.TorsionNormIteration.InverseIntegralClasses.NormNatCastOfNotDvd
import Formalism.TorsionNormIteration.InverseIntegralClasses.TorsionNormIterProof
import Formalism.TorsionNormIteration.LTLemma
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.BridgeDet

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittEndomorphism.FlogConstantCoeff, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittLogarithm.CoefWfIff, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.WittSubstitution.CoeffMapMem, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ZeroWindow.Assemble, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ZuckermanTensor.DualChoice, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.projection2.GaStep, `Formalism.PieriBlockIdeals.BranchingBoundLastGradedOneRow, `Formalism.PieriBlockIdeals.ExZTranslate, `Formalism.PieriBlockIdeals.ExponentBoundCounterexample, `Formalism.PieriBlockIdeals.IntegralQuotient, `Formalism.PieriBlockIdeals.MultiplicityZeroThickEmbedding, `Formalism.PieriBlockIdeals.PieriColumnMinors.HeckeLFunctionIdealEulerProduct, `Formalism.PolynomialDimension.ChangeLatticeGoodRank, `Formalism.PolynomialDimension.FinalNum, `Formalism.PolynomialDimension.MultinomialKLog, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.FirstSlotSliceSlotMixedCasimirZero, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.FrobeniusBoundOfMulNearOne, `Formalism.RealPlaceAnalysis.RealPlaceTaylor.ModularCharacterEqOneOnExpHermitian, `Formalism.RealPlaceAnalysis.SmoothVectorGrowthBound, `Formalism.RealPlaceAnalysis.ThirdArithmeticHolds, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.AdelstabL, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.AfsplitC, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Bridge, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.FIwasawaB, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.FSatakeC, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Tjcosets, `Formalism.SatakeDualWeyl.DefsCS, `Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.HarProjEqZeroIff, `Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.Monomial, `Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.PrimedEmbeddingInjective, `Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.ProjKeepsLetter, `Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.SegDefs, `Formalism.SharpRestriction.GrowthBounds.RootWeights.SumFinsuppAntidiagEqSumPiFinset, `Formalism.SharpRestriction.GrowthBounds.TwistedSubstitution.TwistedMonomialFiltration.MaxTwistDegreePderivLeAddOne, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.EigenRingInvariants, `Formalism.SharpRestriction.LevelLetterCocycles.JointConditionsZpowers.BaseCoefJumpProof, `Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.RkMultVOfNotJump, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.DvdCoeffsOfMemSpanDistinguished, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.Numerics, `Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.ConjEMemHostFIff, `Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.EvalFrameOrd, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleMono, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleSmall, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleUB, `Formalism.SubspaceCounting.ChoiceOfTopsRefined, `Formalism.TameInertiaTowers.TowerFieldFoundations, `Formalism.ThetaLiftIndependence.Statement, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.DualWeylProofs.BCoreW, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.DualWeylProofs.QcEvGLGenPtInt, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.DualWeylProofs.QhEquivOfCount, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.DualWeylProofs.QsMnTranspose, `Formalism.ThetaLogCoordinates.JacobiPathWeights.IndexWeightsDominance, `Formalism.ThetaLogCoordinates.JacobiPathWeights.JacobiMinorProofs.GenSpace, `Formalism.ThetaLogCoordinates.JacobiPathWeights.JacobiMinorProofs.IsWeightedHomogeneousZeroStripPathWord, `Formalism.ThetaLogCoordinates.JacobiPathWeights.JacobiMinorProofs.PathProductHighestWeight, `Formalism.ThetaLogCoordinates.ProductIdealMonotone.ProductIdealProofs.ElementarySymmetricExpBound, `Formalism.ThetaLogCoordinates.UniformThetaSubstitution.IsLawOfLog, `Formalism.TorsionNormIteration.InverseIntegralClasses.CoeffSubstAddCMulXPow, `Formalism.TorsionNormIteration.InverseIntegralClasses.IsHomOfSubstEqSmul, `Formalism.TorsionNormIteration.InverseIntegralClasses.MapSubtypeInjective, `Formalism.TorsionNormIteration.InverseIntegralClasses.NormNatCastOfNotDvd, `Formalism.TorsionNormIteration.InverseIntegralClasses.TorsionNormIterProof, `Formalism.TorsionNormIteration.LTLemma, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.BridgeDet]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

