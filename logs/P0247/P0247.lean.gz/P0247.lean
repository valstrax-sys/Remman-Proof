import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MobiusChangeOfVariablesStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModDepthGEQuotientMapSpanSingleton
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModDepthGEThreeOfFreeRegularLocal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModDepthGETwoOfIsIntegrallyClosedOfIsRegularLoca
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModDepthGETwoOfRegularQuotientNoSocleStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModularGroupRowVecAndConjRightActionsStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MonoPullbackMapOfFlat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MuCoeffZeroNeZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MultiplierExponentialHolomorphicLocal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MvPolynomialEqZeroOfEvalEqZeroOnOpen
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NarrowGaussConvolutionDense
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NatDegreeMulEsymmRootsPowStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NonemptyEquivOfCardHomStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NonvanishingHolomorphicExpLogConvex
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormApproximationFiltration
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormApproximationFirstLevel
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormCoefficientIdealFamilyEqTopOfDisjoint
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormFiltrationComplete
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormFormCoefficientIdealMapLocalizationAway
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivHeckeFourierFactorLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivProdCoordLeLeibniz
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormLeLintegralRayIteratedFDerivStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormSectionSqSmooth
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormalisationDvrTensorSeparableFiniteStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormalisationMulEqAevalRootStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OpNormLeOpNormBlockDiagonal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OrthogonalSymplecticFixesSiegelPointI
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicRingHomEqCanonical
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ParameterFunctionEqZeroOfComposable
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PartialOperatorSchwartzSeminormBound
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PartialZetaTotallyRealAtMostSimplePoleStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodFlatMapRealAnalytic
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodMapFlatDerivative
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodMapSymplecticTransform
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodTorusFlatCoordsInverse
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodicSectionContinuousLimitStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PicIsOfFinOrderOfFiniteIntStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PicardTorsionTrivialOfTorsorsHaveSections
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluriharmonicHolomorphicDerivative
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluriharmonicPeriodicConstant
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PoissonIntegralSmoothOffAxesStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialEvalBoundOnCircleFamily
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialGrowthOfPeriodicIntegralSpansStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialLipschitzCoefficientBound
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialReductionModElementary
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialSystemSpecializationStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PositivePotentialFormPos
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PositivePotentialMinusSmallMultiplePshStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PotentialSmoothInChart
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PotentialSmoothOnOpen
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PotentialsBoundedByPositive
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PowMulMemSubalgebraOfResBasicOpen
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreimageEqOfSquareZeroThickening
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrimeMapPrimeMap
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdImIteratedWirtingerDerivWordDifferentiableOn
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProjectiveReductionOfFlatLiftStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PscoTCore
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QExpansionsCoeffwiseConjugateRingClosureStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuadraticFormTwoSidedBound
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuotientMeasureConjugationInvariant
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RankOneLatticeSpanSingletonStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RationalSymplecticPreservesOrbits
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReQuad
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReductionUniformizerNilpotent

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.MobiusChangeOfVariablesStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModDepthGEQuotientMapSpanSingleton, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModDepthGEThreeOfFreeRegularLocal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModDepthGETwoOfIsIntegrallyClosedOfIsRegularLoca, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModDepthGETwoOfRegularQuotientNoSocleStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ModularGroupRowVecAndConjRightActionsStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MonoPullbackMapOfFlat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MuCoeffZeroNeZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MultiplierExponentialHolomorphicLocal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MvPolynomialEqZeroOfEvalEqZeroOnOpen, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NarrowGaussConvolutionDense, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NatDegreeMulEsymmRootsPowStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NonemptyEquivOfCardHomStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NonvanishingHolomorphicExpLogConvex, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormApproximationFiltration, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormApproximationFirstLevel, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormCoefficientIdealFamilyEqTopOfDisjoint, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormFiltrationComplete, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormFormCoefficientIdealMapLocalizationAway, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivHeckeFourierFactorLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivProdCoordLeLeibniz, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormLeLintegralRayIteratedFDerivStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormSectionSqSmooth, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormalisationDvrTensorSeparableFiniteStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormalisationMulEqAevalRootStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OpNormLeOpNormBlockDiagonal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OrthogonalSymplecticFixesSiegelPointI, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicRingHomEqCanonical, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ParameterFunctionEqZeroOfComposable, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PartialOperatorSchwartzSeminormBound, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PartialZetaTotallyRealAtMostSimplePoleStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodFlatMapRealAnalytic, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodMapFlatDerivative, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodMapSymplecticTransform, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodTorusFlatCoordsInverse, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodicSectionContinuousLimitStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PicIsOfFinOrderOfFiniteIntStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PicardTorsionTrivialOfTorsorsHaveSections, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluriharmonicHolomorphicDerivative, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluriharmonicPeriodicConstant, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PoissonIntegralSmoothOffAxesStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialEvalBoundOnCircleFamily, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialGrowthOfPeriodicIntegralSpansStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialLipschitzCoefficientBound, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialReductionModElementary, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialSystemSpecializationStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PositivePotentialFormPos, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PositivePotentialMinusSmallMultiplePshStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PotentialSmoothInChart, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PotentialSmoothOnOpen, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PotentialsBoundedByPositive, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PowMulMemSubalgebraOfResBasicOpen, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreimageEqOfSquareZeroThickening, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrimeMapPrimeMap, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdImIteratedWirtingerDerivWordDifferentiableOn, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProjectiveReductionOfFlatLiftStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PscoTCore, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QExpansionsCoeffwiseConjugateRingClosureStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuadraticFormTwoSidedBound, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuotientMeasureConjugationInvariant, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RankOneLatticeSpanSingletonStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RationalSymplecticPreservesOrbits, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReQuad, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReductionUniformizerNilpotent]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

