import Lean
import Formalism.PeriodIntegrals.PhNormLimit
import Formalism.PeriodIntegrals.PhNormUnits
import Formalism.PeriodIntegrals.PhProdConv
import Formalism.PeriodIntegrals.PhSchurConv
import Formalism.PeriodIntegrals.PhiCubeOfFactor
import Formalism.PeriodIntegrals.PolydiscInt
import Formalism.PeriodIntegrals.PowBddInt
import Formalism.PeriodIntegrals.PrimeCount
import Formalism.PeriodIntegrals.PrimeSums
import Formalism.PeriodIntegrals.PrimesDyadicRS
import Formalism.PeriodIntegrals.ProdUnitInert
import Formalism.PeriodIntegrals.QuadDiff
import Formalism.PeriodIntegrals.QuotInv
import Formalism.PeriodIntegrals.QuotNuSigma
import Formalism.PeriodIntegrals.RamBound
import Formalism.PeriodIntegrals.RayBoundIQ
import Formalism.PeriodIntegrals.RegSeqQuasiReg
import Formalism.PeriodIntegrals.Residue
import Formalism.PeriodIntegrals.RhsWLim
import Formalism.PeriodIntegrals.RowLetter
import Formalism.PeriodIntegrals.RowWtSpan
import Formalism.PeriodIntegrals.SDiffGram
import Formalism.PeriodIntegrals.SSAscent
import Formalism.PeriodIntegrals.SameFormAllLevels
import Formalism.PeriodIntegrals.ScGapBig
import Formalism.PeriodIntegrals.ScalDeg
import Formalism.PeriodIntegrals.SelfDualLoc
import Formalism.PeriodIntegrals.SimeqPdInt
import Formalism.PeriodIntegrals.SmithMat
import Formalism.PeriodIntegrals.SplitIntLoc
import Formalism.PeriodIntegrals.SplitZeroG
import Formalism.PeriodIntegrals.SqfLab
import Formalism.PeriodIntegrals.SumAntidiagonalTuple
import Formalism.PeriodIntegrals.SymplZ
import Formalism.PeriodIntegrals.TayInvPow
import Formalism.PeriodIntegrals.Transference
import Formalism.PeriodIntegrals.TransferenceCoverRad
import Formalism.PeriodIntegrals.TwChrOne
import Formalism.PeriodIntegrals.TwNormLat
import Formalism.PeriodIntegrals.TwistedEisensteinNonvanishing
import Formalism.PeriodIntegrals.UJClassFin
import Formalism.PeriodIntegrals.UMultOne
import Formalism.PeriodIntegrals.UnfoldEquiv
import Formalism.PeriodIntegrals.UnimodGenus
import Formalism.PeriodIntegrals.UnimodIdx
import Formalism.PeriodIntegrals.UnimodLocStd
import Formalism.PeriodIntegrals.UnimodularOrthogonalQ2
import Formalism.PeriodIntegrals.UnipVal
import Formalism.PeriodIntegrals.UnitDetRoot
import Formalism.PeriodIntegrals.UnitKron
import Formalism.PeriodIntegrals.UnitaryApprox
import Formalism.PeriodIntegrals.UnitaryDense
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdditiveIntegralGroups.SubstMem
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicClassFiniteness.IdealMulPrincipal
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicLocalCompactness.AdeleLC
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnimodularity.CartierFrobeniusFormLocal
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnimodularity.CoordTmulOneMul
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnimodularity.ExistsNatLocal
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AlgebraicValuesFinite.PowCardSubOneMem
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.BlockEmb
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.ChartChg
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.ExistsLocalSolutionContDiffAt
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.ExistsLocalSolve
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.ImgLim

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.PeriodIntegrals.PhNormLimit, `Formalism.PeriodIntegrals.PhNormUnits, `Formalism.PeriodIntegrals.PhProdConv, `Formalism.PeriodIntegrals.PhSchurConv, `Formalism.PeriodIntegrals.PhiCubeOfFactor, `Formalism.PeriodIntegrals.PolydiscInt, `Formalism.PeriodIntegrals.PowBddInt, `Formalism.PeriodIntegrals.PrimeCount, `Formalism.PeriodIntegrals.PrimeSums, `Formalism.PeriodIntegrals.PrimesDyadicRS, `Formalism.PeriodIntegrals.ProdUnitInert, `Formalism.PeriodIntegrals.QuadDiff, `Formalism.PeriodIntegrals.QuotInv, `Formalism.PeriodIntegrals.QuotNuSigma, `Formalism.PeriodIntegrals.RamBound, `Formalism.PeriodIntegrals.RayBoundIQ, `Formalism.PeriodIntegrals.RegSeqQuasiReg, `Formalism.PeriodIntegrals.Residue, `Formalism.PeriodIntegrals.RhsWLim, `Formalism.PeriodIntegrals.RowLetter, `Formalism.PeriodIntegrals.RowWtSpan, `Formalism.PeriodIntegrals.SDiffGram, `Formalism.PeriodIntegrals.SSAscent, `Formalism.PeriodIntegrals.SameFormAllLevels, `Formalism.PeriodIntegrals.ScGapBig, `Formalism.PeriodIntegrals.ScalDeg, `Formalism.PeriodIntegrals.SelfDualLoc, `Formalism.PeriodIntegrals.SimeqPdInt, `Formalism.PeriodIntegrals.SmithMat, `Formalism.PeriodIntegrals.SplitIntLoc, `Formalism.PeriodIntegrals.SplitZeroG, `Formalism.PeriodIntegrals.SqfLab, `Formalism.PeriodIntegrals.SumAntidiagonalTuple, `Formalism.PeriodIntegrals.SymplZ, `Formalism.PeriodIntegrals.TayInvPow, `Formalism.PeriodIntegrals.Transference, `Formalism.PeriodIntegrals.TransferenceCoverRad, `Formalism.PeriodIntegrals.TwChrOne, `Formalism.PeriodIntegrals.TwNormLat, `Formalism.PeriodIntegrals.TwistedEisensteinNonvanishing, `Formalism.PeriodIntegrals.UJClassFin, `Formalism.PeriodIntegrals.UMultOne, `Formalism.PeriodIntegrals.UnfoldEquiv, `Formalism.PeriodIntegrals.UnimodGenus, `Formalism.PeriodIntegrals.UnimodIdx, `Formalism.PeriodIntegrals.UnimodLocStd, `Formalism.PeriodIntegrals.UnimodularOrthogonalQ2, `Formalism.PeriodIntegrals.UnipVal, `Formalism.PeriodIntegrals.UnitDetRoot, `Formalism.PeriodIntegrals.UnitKron, `Formalism.PeriodIntegrals.UnitaryApprox, `Formalism.PeriodIntegrals.UnitaryDense, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdditiveIntegralGroups.SubstMem, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicClassFiniteness.IdealMulPrincipal, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicLocalCompactness.AdeleLC, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnimodularity.CartierFrobeniusFormLocal, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnimodularity.CoordTmulOneMul, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicUnimodularity.ExistsNatLocal, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AlgebraicValuesFinite.PowCardSubOneMem, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.BlockEmb, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.ChartChg, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.ExistsLocalSolutionContDiffAt, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.ExistsLocalSolve, `Formalism.PeriodIntegrals.UnitaryGroupMassFormula.ArchimedeanOrbitMeasures.ImgLim]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

