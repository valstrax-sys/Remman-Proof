import Lean
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CayleySignature
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CayleyTransformPreservesForm
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ChainLength
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CharacterEigenspaceAddMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CharpolyCoeffValuation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CharpolyPowersRatios
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CharpolySmul
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ChoiceFunction
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ChoiceOfModulusAndDiscriminant
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ClearDenominatorsLattice
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ClosureSpanCoefficients
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ClosureUpperUni
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CoboundaryCriterion
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CoboundaryOfGenerator
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CochainInjectiveExact
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CocycleCoboundaryFiniteIndex
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CocycleMultiplicative
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CoeffProdOneAdd
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CoerciveOfPositiveDefinite
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CommonDenom
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CommonEigenvalue
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CommonEigenvectorBis
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CommonField
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CommonMajorizingLattice
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CompactQuotientSubmodule
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ComplementSubspace
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ComplexNormedInstanceCompat
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CompositionMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CongruenceMulOfUnitFactor
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CongruenceSubgroupEventually
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjEqNegOfSq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjEqNegOfSquare
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjInvariantCharacterMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjInvariantCharacterTransport
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjOfSq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjOfSqNeg
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjugateElement
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjugateOfRoots
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjugateSqrtNeg
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Conjugation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjugationByInvolution
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ContDiffHerm
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ContinuousHom
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ContinuousToZModPow
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConvSqLe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CoproductAdjoin
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CoproductGeometry
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CosetOfCover
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CountingPairs
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CovariantDegrees
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CubeSignEmb
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CurveDVRPrecompleteFinite
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CuspidalIrreducibleSubrep
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CutSub
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclicSubtraction
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclicTrivialInductionRing
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclotomicBarContinuous
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclotomicCharacterContinuous
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclotomicCharacterFirst
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclotomicCharacterFourth
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclotomicCharacterSecond
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclotomicCharacterThird
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DcAevalIntertwine
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DcAevalIntertwineAlt

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CayleySignature, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CayleyTransformPreservesForm, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ChainLength, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CharacterEigenspaceAddMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CharpolyCoeffValuation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CharpolyPowersRatios, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CharpolySmul, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ChoiceFunction, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ChoiceOfModulusAndDiscriminant, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ClearDenominatorsLattice, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ClosureSpanCoefficients, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ClosureUpperUni, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CoboundaryCriterion, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CoboundaryOfGenerator, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CochainInjectiveExact, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CocycleCoboundaryFiniteIndex, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CocycleMultiplicative, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CoeffProdOneAdd, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CoerciveOfPositiveDefinite, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CommonDenom, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CommonEigenvalue, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CommonEigenvectorBis, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CommonField, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CommonMajorizingLattice, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CompactQuotientSubmodule, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ComplementSubspace, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ComplexNormedInstanceCompat, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CompositionMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CongruenceMulOfUnitFactor, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CongruenceSubgroupEventually, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjEqNegOfSq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjEqNegOfSquare, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjInvariantCharacterMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjInvariantCharacterTransport, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjOfSq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjOfSqNeg, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjugateElement, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjugateOfRoots, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjugateSqrtNeg, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Conjugation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjugationByInvolution, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ContDiffHerm, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ContinuousHom, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ContinuousToZModPow, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConvSqLe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CoproductAdjoin, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CoproductGeometry, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CosetOfCover, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CountingPairs, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CovariantDegrees, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CubeSignEmb, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CurveDVRPrecompleteFinite, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CuspidalIrreducibleSubrep, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CutSub, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclicSubtraction, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclicTrivialInductionRing, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclotomicBarContinuous, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclotomicCharacterContinuous, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclotomicCharacterFirst, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclotomicCharacterFourth, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclotomicCharacterSecond, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CyclotomicCharacterThird, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DcAevalIntertwine, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DcAevalIntertwineAlt]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

