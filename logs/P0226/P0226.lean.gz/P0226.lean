import Lean
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsConeMapAreaOne
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsConeMass
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsConeMeetNull
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsConeSlab
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsFiniteFibresDimLe
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsHolomorphicImplicitGraph
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsIncIdealSeparate
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsPolyLocalGenerators
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsProjSecDegree
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSecDegreeGe
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSecDegreeLe
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSecFiniteUnit
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSecRankSpecialize
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsThroughTwoPointsTrdeg
import GroundTheory.HeightsAndTheta.Heights.ChowForms.Imports
import GroundTheory.HeightsAndTheta.Heights.ChowForms.ImportsAlt
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PChowFormSection
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PFGNullstellensatz
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PIncIdealPrime
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PIncidenceGeneric
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PLengthQuotientDet
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PLocalMultOrd
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PMinimalPrimeHomog
import GroundTheory.HeightsAndTheta.Heights.ChowForms.POrdPolynomialLocalization
import GroundTheory.HeightsAndTheta.Heights.ChowForms.PProjNullstellensatz
import GroundTheory.HeightsAndTheta.Heights.ChowForms.StatementsSectionOrder
import GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.PDeltaIntSeries
import GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.PIntSeriesInv
import GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.PIntSeriesNorm
import GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.PIntSeriesRing
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.DetEqZeroOfMulVecEqZero
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.Imports
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAreaLinear
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PCauchyBinetMinors
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PComplexJacobian
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PDiscrAdjoin
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PDiscriminantCover
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PDominantFibreBound
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteFibreGermIntegral
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteGermProjectionOpenAt
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteModuloIntegral
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjectionProperBall
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjectionsGeneric
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFlatLocalRegularElement
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFlatLocalRegularSequence
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericFibreRadicalAway
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericNoetherNormalisation
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericProjectionFinite
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGermFiniteProjection
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PHolGermsDomain
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PHypersurfacePresentation
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PInjectiveHolomorphicJacobianNeZero
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PIrreducibleGermProjectionOpenNear
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PIsolatedFibreNear
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNormalBoundedQuotient
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNormalMaximumPrinciple
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNormalModelExists
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNormalModelProper
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNormalRiemannExtension
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNullSmaller
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PPerfectFieldExtensionFormallySmoothExtensionStep
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PPowerUnitCount
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PPrimitiveElementFibres
import GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PProperOpenProjectionBranchLocus

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsConeMapAreaOne, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsConeMass, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsConeMeetNull, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsConeSlab, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsFiniteFibresDimLe, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsHolomorphicImplicitGraph, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsIncIdealSeparate, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsPolyLocalGenerators, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsProjSecDegree, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSecDegreeGe, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSecDegreeLe, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSecFiniteUnit, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsSecRankSpecialize, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsThroughTwoPointsTrdeg, `GroundTheory.HeightsAndTheta.Heights.ChowForms.Imports, `GroundTheory.HeightsAndTheta.Heights.ChowForms.ImportsAlt, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PChowFormSection, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PFGNullstellensatz, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PIncIdealPrime, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PIncidenceGeneric, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PLengthQuotientDet, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PLocalMultOrd, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PMinimalPrimeHomog, `GroundTheory.HeightsAndTheta.Heights.ChowForms.POrdPolynomialLocalization, `GroundTheory.HeightsAndTheta.Heights.ChowForms.PProjNullstellensatz, `GroundTheory.HeightsAndTheta.Heights.ChowForms.StatementsSectionOrder, `GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.PDeltaIntSeries, `GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.PIntSeriesInv, `GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.PIntSeriesNorm, `GroundTheory.HeightsAndTheta.Heights.ChowlaSelberg.PIntSeriesRing, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.DetEqZeroOfMulVecEqZero, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.Imports, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PAreaLinear, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PCauchyBinetMinors, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PComplexJacobian, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PDiscrAdjoin, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PDiscriminantCover, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PDominantFibreBound, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteFibreGermIntegral, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteGermProjectionOpenAt, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteModuloIntegral, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjectionProperBall, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFiniteProjectionsGeneric, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFlatLocalRegularElement, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PFlatLocalRegularSequence, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericFibreRadicalAway, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericNoetherNormalisation, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGenericProjectionFinite, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PGermFiniteProjection, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PHolGermsDomain, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PHypersurfacePresentation, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PInjectiveHolomorphicJacobianNeZero, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PIrreducibleGermProjectionOpenNear, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PIsolatedFibreNear, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNormalBoundedQuotient, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNormalMaximumPrinciple, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNormalModelExists, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNormalModelProper, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNormalRiemannExtension, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PNullSmaller, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PPerfectFieldExtensionFormallySmoothExtensionStep, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PPowerUnitCount, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PPrimitiveElementFibres, `GroundTheory.HeightsAndTheta.Heights.ComplexAnalyticSets.PProperOpenProjectionBranchLocus]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

