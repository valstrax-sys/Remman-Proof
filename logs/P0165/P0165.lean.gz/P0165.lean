import Lean
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.ProjectiveSpaceIncrementHyp
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsComplexTaylor
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsConjIntNum
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsEventualPolyLine
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsHilbert
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsSectionNormSqLevi
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.LintegralFibSum
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PFlagIntMuOneCoeff
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PFlagIntMuProdSlice
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PHookFactorBranch
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PInvDerivDecay
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PLaplacianDecayZero
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PLevelSetLocalInj
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PVandermondeBranch
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsBlockAltUnique
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsBlocksLeadSandwich
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsFlagIntMuDegree
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsFlagIntMuProd
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsFsPotLaplacian
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.FiniteIntegralClosureCharZero
import GroundTheory.HeightsAndTheta.Heights.Intersections.PAdjoinIndepRelfinrank
import GroundTheory.HeightsAndTheta.Heights.Intersections.PChartPrimElt
import GroundTheory.HeightsAndTheta.Heights.Intersections.PChartSpecCount
import GroundTheory.HeightsAndTheta.Heights.Intersections.PFIntZeroMixed
import GroundTheory.HeightsAndTheta.Heights.Intersections.PFinrankAdjoinRange
import GroundTheory.HeightsAndTheta.Heights.Intersections.PLinearQuotient
import GroundTheory.HeightsAndTheta.Heights.Intersections.PLocAwaySpec
import GroundTheory.HeightsAndTheta.Heights.Intersections.PRankAdjoinFrac
import GroundTheory.HeightsAndTheta.Heights.Intersections.PRankFracDegree
import GroundTheory.HeightsAndTheta.Heights.Intersections.PRelAlgClosureFinite
import GroundTheory.HeightsAndTheta.Heights.Intersections.PRelBaseChange
import GroundTheory.HeightsAndTheta.Heights.Intersections.PTrdegAdjoinFrac
import GroundTheory.HeightsAndTheta.Heights.Intersections.StatementsFibreLocal
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CohMkEqZero
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.ExistsPolyBackDiffPow
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.GraphEquiv
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.Objects
import GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PDedekindFibreRank
import GroundTheory.HeightsAndTheta.Heights.LocalDensities.LeviLine
import GroundTheory.HeightsAndTheta.Heights.LocalDensities.PKrullHeightOne
import GroundTheory.HeightsAndTheta.Heights.LocalDensities.StatementsClosedPointGenericFibre
import GroundTheory.HeightsAndTheta.Heights.LocalDensities.StatementsFSDensity
import GroundTheory.HeightsAndTheta.Heights.LocalDensities.StatementsIntegralPointAlgebraic
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.ImportsBis
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.SecondVolumeConstantNonneg
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PCovolumeRelIndex
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PEmbeddingSumPlaces
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PLatticeCountVolume
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PMixedBoxCount
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StComponentsGenericCount
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StConeSliceIdeal
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StConeVanishingHomog
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsNumberFieldBoxCount
import GroundTheory.HeightsAndTheta.Heights.ReducedTensors.PBaseChangeReduced
import GroundTheory.HeightsAndTheta.Heights.Regularisation.PPuncturedExpOrder
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.AltCoeff
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.Elementary
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.Expand
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.FlagBasic
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.Inhabitants
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.IsFlagIntegralOne
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.JacobiTrudi
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.Pluecker
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PowerSums

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.ProjectiveSpaceIncrementHyp, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsComplexTaylor, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsConjIntNum, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsEventualPolyLine, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsHilbert, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsSectionNormSqLevi, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.LintegralFibSum, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PFlagIntMuOneCoeff, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PFlagIntMuProdSlice, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PHookFactorBranch, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PInvDerivDecay, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PLaplacianDecayZero, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PLevelSetLocalInj, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PVandermondeBranch, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsBlockAltUnique, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsBlocksLeadSandwich, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsFlagIntMuDegree, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsFlagIntMuProd, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsFsPotLaplacian, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.FiniteIntegralClosureCharZero, `GroundTheory.HeightsAndTheta.Heights.Intersections.PAdjoinIndepRelfinrank, `GroundTheory.HeightsAndTheta.Heights.Intersections.PChartPrimElt, `GroundTheory.HeightsAndTheta.Heights.Intersections.PChartSpecCount, `GroundTheory.HeightsAndTheta.Heights.Intersections.PFIntZeroMixed, `GroundTheory.HeightsAndTheta.Heights.Intersections.PFinrankAdjoinRange, `GroundTheory.HeightsAndTheta.Heights.Intersections.PLinearQuotient, `GroundTheory.HeightsAndTheta.Heights.Intersections.PLocAwaySpec, `GroundTheory.HeightsAndTheta.Heights.Intersections.PRankAdjoinFrac, `GroundTheory.HeightsAndTheta.Heights.Intersections.PRankFracDegree, `GroundTheory.HeightsAndTheta.Heights.Intersections.PRelAlgClosureFinite, `GroundTheory.HeightsAndTheta.Heights.Intersections.PRelBaseChange, `GroundTheory.HeightsAndTheta.Heights.Intersections.PTrdegAdjoinFrac, `GroundTheory.HeightsAndTheta.Heights.Intersections.StatementsFibreLocal, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.CohMkEqZero, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.ExistsPolyBackDiffPow, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.GraphEquiv, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.Objects, `GroundTheory.HeightsAndTheta.Heights.KleimanAmpleness.PDedekindFibreRank, `GroundTheory.HeightsAndTheta.Heights.LocalDensities.LeviLine, `GroundTheory.HeightsAndTheta.Heights.LocalDensities.PKrullHeightOne, `GroundTheory.HeightsAndTheta.Heights.LocalDensities.StatementsClosedPointGenericFibre, `GroundTheory.HeightsAndTheta.Heights.LocalDensities.StatementsFSDensity, `GroundTheory.HeightsAndTheta.Heights.LocalDensities.StatementsIntegralPointAlgebraic, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.ImportsBis, `GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.SecondVolumeConstantNonneg, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PCovolumeRelIndex, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PEmbeddingSumPlaces, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PLatticeCountVolume, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PMixedBoxCount, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StComponentsGenericCount, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StConeSliceIdeal, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StConeVanishingHomog, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsNumberFieldBoxCount, `GroundTheory.HeightsAndTheta.Heights.ReducedTensors.PBaseChangeReduced, `GroundTheory.HeightsAndTheta.Heights.Regularisation.PPuncturedExpOrder, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.AltCoeff, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.Elementary, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.Expand, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.FlagBasic, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.Inhabitants, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.IsFlagIntegralOne, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.JacobiTrudi, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.Pluecker, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PowerSums]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

