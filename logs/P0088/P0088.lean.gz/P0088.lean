import Lean
import Lemmata.GeneralBFactRightAltForm.Imports
import Lemmata.GeneralBFactRightBis.Imports
import Lemmata.GeneralBFactRightBisAlt.Imports
import Lemmata.GeneralBFactRightBisForm.Imports
import Lemmata.GeneralBFactRightExtra.Imports
import Lemmata.GeneralBFactRightForm.Imports
import Lemmata.GeneralBFactRightFurther.Imports
import Lemmata.GeneralBFactRightLast.Slot
import Lemmata.GeneralBFactRightMore.Imports
import Lemmata.GeneralBFactRightRest.Imports
import Lemmata.GeneralBFactRightSide.Imports
import Lemmata.GeneralBFactRightTer.Imports
import Lemmata.GeneralBFactRightTerForm.Imports
import Lemmata.GeneralBFactRightVariant.Imports
import Lemmata.GeneralBFactRightVersion.Imports
import Lemmata.GeneralBFactSecond.Imports
import Lemmata.GeneralBFactSecondAlt.Imports
import Lemmata.GeneralBFactSecondAltForm.Imports
import Lemmata.GeneralBFactSecondBisAlt.Imports
import Lemmata.GeneralBFactSecondBisForm.Goal1
import Lemmata.GeneralBFactSecondExtra.Key
import Lemmata.GeneralBFactSecondForm.Imports
import Lemmata.GeneralBFactSecondFurther.Imports
import Lemmata.GeneralBFactSecondLast.Imports
import Lemmata.GeneralBFactSecondMore.Imports
import Lemmata.GeneralBFactSecondRest.Imports
import Lemmata.GeneralBFactSecondSide.Imports
import Lemmata.GeneralBFactSecondTail.Imports
import Lemmata.GeneralBFactSecondTer.Imports
import Lemmata.GeneralBFactSecondTerForm.Imports
import Lemmata.GeneralBFactSecondVariant.Imports
import Lemmata.GeneralBFactSecondVersion.Imports
import Lemmata.GeneralBFactSide.Imports
import Lemmata.GeneralBFactTail.Imports
import Lemmata.GeneralBFactTer.Imports
import Lemmata.GeneralBFactTerForm.Imports
import Lemmata.GeneralBFactThird.Imports
import Lemmata.GeneralBFactThirdAlt.Imports
import Lemmata.GeneralBFactThirdAltForm.Imports
import Lemmata.GeneralBFactThirdBis.Imports
import Lemmata.GeneralBFactThirdBisAlt.Imports
import Lemmata.GeneralBFactThirdBisForm.Imports
import Lemmata.GeneralBFactThirdForm.Imports
import Lemmata.GeneralBFactThirdFurther.Imports
import Lemmata.GeneralBFactThirdLast.Imports
import Lemmata.GeneralBFactThirdMore.Key
import Lemmata.GeneralBFactThirdSide.Imports
import Lemmata.GeneralBFactThirdTail.Imports
import Lemmata.GeneralBFactThirdTer.Imports
import Lemmata.GeneralBFactThirdTerForm.Imports
import Lemmata.GeneralBFactThirdVariant.Imports
import Lemmata.GeneralBFactThirdVersion.Imports
import Lemmata.GeneralBFactUpper.Imports
import Lemmata.GeneralBFactUpperAltForm.Imports
import Lemmata.GeneralBFactUpperBis.Imports
import Lemmata.GeneralBFactUpperForm.Imports
import Lemmata.GeneralBFactUpperTerForm.Imports
import Lemmata.GeneralBFactUpperVariant.Imports
import Lemmata.GeneralBFactUpperVersion.Imports
import Lemmata.GeneralBFactVariant.Imports
import Lemmata.GeneralBFactVersion.Imports
import Lemmata.IntegerMulIntegral.IntMulIntegral
import Lemmata.IterateZero.IterZero
import Lemmata.MiscLemmasA.Imports

open Lean Elab Command

def auditTargets : Array Name := #[`Lemmata.GeneralBFactRightAltForm.Imports, `Lemmata.GeneralBFactRightBis.Imports, `Lemmata.GeneralBFactRightBisAlt.Imports, `Lemmata.GeneralBFactRightBisForm.Imports, `Lemmata.GeneralBFactRightExtra.Imports, `Lemmata.GeneralBFactRightForm.Imports, `Lemmata.GeneralBFactRightFurther.Imports, `Lemmata.GeneralBFactRightLast.Slot, `Lemmata.GeneralBFactRightMore.Imports, `Lemmata.GeneralBFactRightRest.Imports, `Lemmata.GeneralBFactRightSide.Imports, `Lemmata.GeneralBFactRightTer.Imports, `Lemmata.GeneralBFactRightTerForm.Imports, `Lemmata.GeneralBFactRightVariant.Imports, `Lemmata.GeneralBFactRightVersion.Imports, `Lemmata.GeneralBFactSecond.Imports, `Lemmata.GeneralBFactSecondAlt.Imports, `Lemmata.GeneralBFactSecondAltForm.Imports, `Lemmata.GeneralBFactSecondBisAlt.Imports, `Lemmata.GeneralBFactSecondBisForm.Goal1, `Lemmata.GeneralBFactSecondExtra.Key, `Lemmata.GeneralBFactSecondForm.Imports, `Lemmata.GeneralBFactSecondFurther.Imports, `Lemmata.GeneralBFactSecondLast.Imports, `Lemmata.GeneralBFactSecondMore.Imports, `Lemmata.GeneralBFactSecondRest.Imports, `Lemmata.GeneralBFactSecondSide.Imports, `Lemmata.GeneralBFactSecondTail.Imports, `Lemmata.GeneralBFactSecondTer.Imports, `Lemmata.GeneralBFactSecondTerForm.Imports, `Lemmata.GeneralBFactSecondVariant.Imports, `Lemmata.GeneralBFactSecondVersion.Imports, `Lemmata.GeneralBFactSide.Imports, `Lemmata.GeneralBFactTail.Imports, `Lemmata.GeneralBFactTer.Imports, `Lemmata.GeneralBFactTerForm.Imports, `Lemmata.GeneralBFactThird.Imports, `Lemmata.GeneralBFactThirdAlt.Imports, `Lemmata.GeneralBFactThirdAltForm.Imports, `Lemmata.GeneralBFactThirdBis.Imports, `Lemmata.GeneralBFactThirdBisAlt.Imports, `Lemmata.GeneralBFactThirdBisForm.Imports, `Lemmata.GeneralBFactThirdForm.Imports, `Lemmata.GeneralBFactThirdFurther.Imports, `Lemmata.GeneralBFactThirdLast.Imports, `Lemmata.GeneralBFactThirdMore.Key, `Lemmata.GeneralBFactThirdSide.Imports, `Lemmata.GeneralBFactThirdTail.Imports, `Lemmata.GeneralBFactThirdTer.Imports, `Lemmata.GeneralBFactThirdTerForm.Imports, `Lemmata.GeneralBFactThirdVariant.Imports, `Lemmata.GeneralBFactThirdVersion.Imports, `Lemmata.GeneralBFactUpper.Imports, `Lemmata.GeneralBFactUpperAltForm.Imports, `Lemmata.GeneralBFactUpperBis.Imports, `Lemmata.GeneralBFactUpperForm.Imports, `Lemmata.GeneralBFactUpperTerForm.Imports, `Lemmata.GeneralBFactUpperVariant.Imports, `Lemmata.GeneralBFactUpperVersion.Imports, `Lemmata.GeneralBFactVariant.Imports, `Lemmata.GeneralBFactVersion.Imports, `Lemmata.IntegerMulIntegral.IntMulIntegral, `Lemmata.IterateZero.IterZero, `Lemmata.MiscLemmasA.Imports]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

