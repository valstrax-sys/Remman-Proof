import Lean
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DcCons
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DeRhamEllipticIdentity
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DegLESum
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DegreeOneStatement
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DenLE
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DenominatorOfSpan
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DerivZeroOut
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DerivationMemPowOfMemPowSucc
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DerivativeLocallyConstant
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DetEmbUnitriA
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DetMulExpand
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DetNormLe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DetSqEqOneOfPreservesBilin
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DetT
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DeterminantNonzero
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DfExistsPrime
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DiagonalConjugateMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DiagonalEntries
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DiagonalMultiplication
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DiagonalizationExistence
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DiagonalizeThreeByThree
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Diagz
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DigitExpansionLattice
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DiscriminantMulIntegralMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DivisibilityFiltration
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DualIntegralLattice
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DualLatticeDenominator
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DualMemSpanEvalOfFiniteDimensional
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DvdOfAeval
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DvrOfNormIntegral
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DzExistsPrime
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DzExistsPrimeAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EMulSubMulCapelliMatrixPow
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EcField
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EigEx
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EigenMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EigenvalueSquare
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ElementDenominator
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ElementarySymmetricInverse
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EmbTwo
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EpEqOneIff
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EqOfNatCastMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EqOneOfForallZpow
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EqOneOfNear
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EqOneOfPowNear
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EqZeroOfAevalEqZero
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EqZeroOfForallIntegralCoeff
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EvDecomp
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EvalDet
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EvalFg
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EvalProd
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EvalSmulOfIsHomogeneous
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EvalSmulOfIsHomogeneousAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EvaluationMap
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EventualValue
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExComp
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExLift
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsAnti
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsAverage
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsBasisOfPid
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsBoundPolyMulExp
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsBoundPolyMulExpAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsCharNeOne
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsColumnVector

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DcCons, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DeRhamEllipticIdentity, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DegLESum, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DegreeOneStatement, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DenLE, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DenominatorOfSpan, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DerivZeroOut, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DerivationMemPowOfMemPowSucc, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DerivativeLocallyConstant, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DetEmbUnitriA, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DetMulExpand, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DetNormLe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DetSqEqOneOfPreservesBilin, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DetT, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DeterminantNonzero, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DfExistsPrime, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DiagonalConjugateMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DiagonalEntries, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DiagonalMultiplication, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DiagonalizationExistence, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DiagonalizeThreeByThree, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Diagz, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DigitExpansionLattice, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DiscriminantMulIntegralMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DivisibilityFiltration, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DualIntegralLattice, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DualLatticeDenominator, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DualMemSpanEvalOfFiniteDimensional, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DvdOfAeval, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DvrOfNormIntegral, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DzExistsPrime, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DzExistsPrimeAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EMulSubMulCapelliMatrixPow, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EcField, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EigEx, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EigenMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EigenvalueSquare, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ElementDenominator, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ElementarySymmetricInverse, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EmbTwo, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EpEqOneIff, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EqOfNatCastMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EqOneOfForallZpow, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EqOneOfNear, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EqOneOfPowNear, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EqZeroOfAevalEqZero, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EqZeroOfForallIntegralCoeff, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EvDecomp, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EvalDet, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EvalFg, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EvalProd, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EvalSmulOfIsHomogeneous, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EvalSmulOfIsHomogeneousAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EvaluationMap, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.EventualValue, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExComp, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExLift, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsAnti, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsAverage, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsBasisOfPid, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsBoundPolyMulExp, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsBoundPolyMulExpAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsCharNeOne, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsColumnVector]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

