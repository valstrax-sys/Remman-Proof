import Lean
import Formalism.SuccessiveMinima.SuccessiveMinimaProofs.MeasureEqCovolumeMulVolumeImage
import Formalism.SuccessiveMinima.SuccessiveMinimaProofs.MinkCore
import Formalism.SuccessiveMinima.SuccessiveMinimaProofs.MinkowskiIILowerOf
import Formalism.SuccessiveMinima.SuccessiveMinimaProofs.NPUnit
import Formalism.SuccessiveMinima.SuccessiveMinimaProofs.NPWDivision
import Formalism.SuccessiveMinima.SuccessiveMinimaProofs.SuccMin
import Formalism.TameInertiaTowers.CentralOrderTwo.ConjEqInvOfPowEqOne
import Formalism.TameInertiaTowers.CentralOrderTwo.DecompositionSubgroupIndex
import Formalism.TameInertiaTowers.CentralOrderTwo.Galois
import Formalism.TameInertiaTowers.CentralOrderTwo.NegOneNeOneUnitsZmodFour
import Formalism.TameInertiaTowers.CentralOrderTwo.NormalOrderTwoCentral
import Formalism.TameInertiaTowers.CentralOrderTwo.OrderOfThreeUnitsTwoPow
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.StatementA
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.StatementB
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.StatementC
import Formalism.ThetaLogCoordinates.DualWeylCoordinates.StatementH
import Formalism.ThetaLogCoordinates.JacobiPathWeights.JacobiMinorProofs.ExistsSuppOfEvalNe
import Formalism.ThetaLogCoordinates.JacobiPathWeights.StatementA
import Formalism.ThetaLogCoordinates.JacobiPathWeights.StatementC
import Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.AtypicalWeightBoundOf
import Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.Branch
import Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.LogBinomialProperties
import Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.LogWeylDimensionEstimate
import Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.N0LeNs
import Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.TTotal
import Formalism.ThetaLogCoordinates.TraceIsometryWeights.SchurTraceProofs.HomRelationHolds
import Formalism.ThetaLogCoordinates.TraceIsometryWeights.SchurTraceProofs.InvInt
import Formalism.ThetaLogCoordinates.TraceIsometryWeights.SchurTraceProofs.InvInv
import Formalism.ThetaLogCoordinates.UniformThetaSubstitution.EdgeExponent
import Formalism.ThetaLogCoordinates.UniformThetaSubstitution.FrobeniusLiftNorms.GaussElementarySymmetric
import Formalism.ThetaLogCoordinates.UniformThetaSubstitution.HeckeOneLift
import Formalism.ThetaLogCoordinates.UniformThetaSubstitution.OddLogRelation
import Formalism.ThetaSupremumBounds.GaussianShiftBounds.Assembly
import Formalism.ThetaSupremumBounds.GaussianShiftBounds.BlockIntegralOf
import Formalism.ThetaSupremumBounds.GaussianShiftBounds.ClassSchur
import Formalism.ThetaSupremumBounds.GaussianShiftBounds.DominanceMono
import Formalism.ThetaSupremumBounds.GaussianShiftBounds.FockJet
import Formalism.ThetaSupremumBounds.GaussianShiftBounds.HeightsoundOf
import Formalism.ThetaSupremumBounds.StatementE
import Formalism.TorsionNormIteration.InvIntegralOfClass
import Formalism.TowerValuationBounds.TowerValuationProofs.ValuationRatioIndex
import Formalism.TranslateCocycles.TranslateCocycleProofs.NetGLMapSurjective
import Formalism.TruncatedSeriesCounting.AprimeArith
import Formalism.TruncatedSeriesCounting.PowMemSpanOfMemSpanLinearDistinguished
import Formalism.TruncatedSeriesCounting.StatementX
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.ColAssembly
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.ColChain
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.ExpBound
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.HCoefficientBound
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.KappaSecondExponentBound
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.RamifiedValuationInequality
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.SubGen
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.SubSmulOneInjective
import Formalism.TruncatedSeriesCounting.WindowSeparated
import Formalism.UnipotentAdelicQuotients.EllRegStep
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.BaseLevel
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.ConvolutionBound
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.IteratedPartialFourierChar
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.KernDecay
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.KernDil
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.Moments
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.PairingFourier
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.PairingLocal
import Formalism.UnipotentAdelicQuotients.EllipticRegularity.SmoothOfLocallySmooth

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.SuccessiveMinima.SuccessiveMinimaProofs.MeasureEqCovolumeMulVolumeImage, `Formalism.SuccessiveMinima.SuccessiveMinimaProofs.MinkCore, `Formalism.SuccessiveMinima.SuccessiveMinimaProofs.MinkowskiIILowerOf, `Formalism.SuccessiveMinima.SuccessiveMinimaProofs.NPUnit, `Formalism.SuccessiveMinima.SuccessiveMinimaProofs.NPWDivision, `Formalism.SuccessiveMinima.SuccessiveMinimaProofs.SuccMin, `Formalism.TameInertiaTowers.CentralOrderTwo.ConjEqInvOfPowEqOne, `Formalism.TameInertiaTowers.CentralOrderTwo.DecompositionSubgroupIndex, `Formalism.TameInertiaTowers.CentralOrderTwo.Galois, `Formalism.TameInertiaTowers.CentralOrderTwo.NegOneNeOneUnitsZmodFour, `Formalism.TameInertiaTowers.CentralOrderTwo.NormalOrderTwoCentral, `Formalism.TameInertiaTowers.CentralOrderTwo.OrderOfThreeUnitsTwoPow, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.StatementA, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.StatementB, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.StatementC, `Formalism.ThetaLogCoordinates.DualWeylCoordinates.StatementH, `Formalism.ThetaLogCoordinates.JacobiPathWeights.JacobiMinorProofs.ExistsSuppOfEvalNe, `Formalism.ThetaLogCoordinates.JacobiPathWeights.StatementA, `Formalism.ThetaLogCoordinates.JacobiPathWeights.StatementC, `Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.AtypicalWeightBoundOf, `Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.Branch, `Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.LogBinomialProperties, `Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.LogWeylDimensionEstimate, `Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.N0LeNs, `Formalism.ThetaLogCoordinates.ResidueClassEstimates.VandermondeRankEstimates.TTotal, `Formalism.ThetaLogCoordinates.TraceIsometryWeights.SchurTraceProofs.HomRelationHolds, `Formalism.ThetaLogCoordinates.TraceIsometryWeights.SchurTraceProofs.InvInt, `Formalism.ThetaLogCoordinates.TraceIsometryWeights.SchurTraceProofs.InvInv, `Formalism.ThetaLogCoordinates.UniformThetaSubstitution.EdgeExponent, `Formalism.ThetaLogCoordinates.UniformThetaSubstitution.FrobeniusLiftNorms.GaussElementarySymmetric, `Formalism.ThetaLogCoordinates.UniformThetaSubstitution.HeckeOneLift, `Formalism.ThetaLogCoordinates.UniformThetaSubstitution.OddLogRelation, `Formalism.ThetaSupremumBounds.GaussianShiftBounds.Assembly, `Formalism.ThetaSupremumBounds.GaussianShiftBounds.BlockIntegralOf, `Formalism.ThetaSupremumBounds.GaussianShiftBounds.ClassSchur, `Formalism.ThetaSupremumBounds.GaussianShiftBounds.DominanceMono, `Formalism.ThetaSupremumBounds.GaussianShiftBounds.FockJet, `Formalism.ThetaSupremumBounds.GaussianShiftBounds.HeightsoundOf, `Formalism.ThetaSupremumBounds.StatementE, `Formalism.TorsionNormIteration.InvIntegralOfClass, `Formalism.TowerValuationBounds.TowerValuationProofs.ValuationRatioIndex, `Formalism.TranslateCocycles.TranslateCocycleProofs.NetGLMapSurjective, `Formalism.TruncatedSeriesCounting.AprimeArith, `Formalism.TruncatedSeriesCounting.PowMemSpanOfMemSpanLinearDistinguished, `Formalism.TruncatedSeriesCounting.StatementX, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.ColAssembly, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.ColChain, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.ExpBound, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.HCoefficientBound, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.KappaSecondExponentBound, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.RamifiedValuationInequality, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.SubGen, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.SubSmulOneInjective, `Formalism.TruncatedSeriesCounting.WindowSeparated, `Formalism.UnipotentAdelicQuotients.EllRegStep, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.BaseLevel, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.ConvolutionBound, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.IteratedPartialFourierChar, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.KernDecay, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.KernDil, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.Moments, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.PairingFourier, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.PairingLocal, `Formalism.UnipotentAdelicQuotients.EllipticRegularity.SmoothOfLocallySmooth]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

