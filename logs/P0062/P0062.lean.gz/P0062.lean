import Lean
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.QuotientMeasureByInvariantSubgroup
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RangeVecMulLinearEq
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RelIndexOpenCompactNeZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RetractBaseChangeKernelCompatible
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SaturatedFgOfPowerTorsionKerCoker
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzLinearChange
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SecondCountableHermC
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemidirectProductHomeomorphOfClosedComplement
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemistableGenericFibreLocalization
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemistableModelRingIsDomain
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemistableSpecialFibreProperty
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SesquilinearEqZeroOfDiagZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SkewAdjointCasimirSpectral
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SplitHomeoApply
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SplitQuadraticOrderPrincipal
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.StrictAntiOfTwoExceptions
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.StripOpenRealDiscs
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SumPerfectApply
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableLatticeHeightSeries
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableLatticeWeightThree
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableOfLatticeDecay
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableOverLatticeQuotientLocallyConstant
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableProdPowMultiIndex
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableTwistedSquareCoefficients
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TendstoOfAsymptoticBounds
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorEquivBaseChangeTensor
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorPrimeLocalizationCriterion
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorPrimeOverIdealCompletion
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorSumAnnihilator
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TraceDualDenominatorBounded
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UniformLowerBoundNearInjective
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitaryExtensionOfBlock
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitaryFramesPreserveNormSqSum
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitaryLiftCommutingInvolution
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedQuadraticOrderPrincipal
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ValZpowIff
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VandermondeSeparation
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VolumeSingularMatricesEqZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WeightedAntitoneLastNonpos
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WirtingerCombinationNeZero
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.MemSmulOfTmulEqZero
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.SemilinearFactorsThroughReduction
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.SumLogDivNSqLeTwo
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.AbelSummationBound
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.AddJFintype
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.AdjoinInverseElementForm
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.AdjoinInverseIsLocalizationAway
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.AlgIndepOfSameAdjoin
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.DualModuleFiniteProjective
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.EigenProjectorFieldEmbedding
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.EpInert
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.EpSplit
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsDualElements
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsElementSamePrimeCount
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsEqMulMultOfUnits
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsHomAdjoinInv
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsSectionNotInSet
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsUniqueValuationRingLift
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsUnitWedge
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsValuationSubringExtension
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExtFrameOfQuotientKernel
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrobeniusStableSubspaceElement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FundamentalDomainRiemannForm

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.BlockDecomposition.QuotientMeasureByInvariantSubgroup, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RangeVecMulLinearEq, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RelIndexOpenCompactNeZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.RetractBaseChangeKernelCompatible, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SaturatedFgOfPowerTorsionKerCoker, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SchwartzLinearChange, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SecondCountableHermC, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemidirectProductHomeomorphOfClosedComplement, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemistableGenericFibreLocalization, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemistableModelRingIsDomain, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SemistableSpecialFibreProperty, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SesquilinearEqZeroOfDiagZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SkewAdjointCasimirSpectral, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SplitHomeoApply, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SplitQuadraticOrderPrincipal, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.StrictAntiOfTwoExceptions, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.StripOpenRealDiscs, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SumPerfectApply, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableLatticeHeightSeries, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableLatticeWeightThree, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableOfLatticeDecay, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableOverLatticeQuotientLocallyConstant, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableProdPowMultiIndex, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.SummableTwistedSquareCoefficients, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TendstoOfAsymptoticBounds, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorEquivBaseChangeTensor, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorPrimeLocalizationCriterion, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorPrimeOverIdealCompletion, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TensorSumAnnihilator, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.TraceDualDenominatorBounded, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UniformLowerBoundNearInjective, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitaryExtensionOfBlock, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitaryFramesPreserveNormSqSum, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnitaryLiftCommutingInvolution, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.UnramifiedQuadraticOrderPrincipal, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ValZpowIff, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VandermondeSeparation, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.VolumeSingularMatricesEqZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WeightedAntitoneLastNonpos, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.WirtingerCombinationNeZero, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.MemSmulOfTmulEqZero, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.SemilinearFactorsThroughReduction, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.SumLogDivNSqLeTwo, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.AbelSummationBound, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.AddJFintype, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.AdjoinInverseElementForm, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.AdjoinInverseIsLocalizationAway, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.AlgIndepOfSameAdjoin, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.DualModuleFiniteProjective, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.EigenProjectorFieldEmbedding, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.EpInert, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.EpSplit, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsDualElements, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsElementSamePrimeCount, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsEqMulMultOfUnits, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsHomAdjoinInv, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsSectionNotInSet, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsUniqueValuationRingLift, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsUnitWedge, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsValuationSubringExtension, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExtFrameOfQuotientKernel, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrobeniusStableSubspaceElement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FundamentalDomainRiemannForm]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

