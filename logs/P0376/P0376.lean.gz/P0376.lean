import Lean
import Formalism.LocalToGlobal.CharacterGerms.Interface
import Formalism.LocalToGlobal.CharacterGerms.MfactMulCoeffMvExpLinF
import Formalism.LocalToGlobal.CyclotomicLocalNorms.NormLeOneIffIsIntegral
import Formalism.LocalToGlobal.GaloisLevelStructure.DefsAutLoc
import Formalism.LocalToGlobal.GaloisLevelStructure.DefsFinTyp
import Formalism.LocalToGlobal.GlobalTheory.BlockActions.AdelicLocalLattice
import Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.DifferentIdeal.CoeIdealDifferentNeZero
import Formalism.LocalToGlobal.GroupLattices.ComparisonMaps.ClsHypA
import Formalism.LocalToGlobal.IndefiniteReal.FinitePlaces.FourUniq
import Formalism.LocalToGlobal.NormalizedHeckeFactors.CoverStd
import Formalism.LocalToGlobal.NumberFieldFamilies.IdTransSM
import Formalism.LocalToGlobal.ProjectiveLattices.LocalIntegralPolynomials.ExistsValuationAdaptedIndex
import Formalism.LocalToGlobal.ProjectiveLattices.RegModelA
import Formalism.LocalToGlobal.ProjectiveLattices.TotalDegreePderivLt
import Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.EmbSInjective
import Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.IotaFIntMem
import Formalism.LocalToGlobal.SiegelLatticeTheory.FundamentalEquivalence.LevelIntersectParabolic
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsEnergy
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsEquiv
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsTail
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.IsogenyP
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.IsogenySigma
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.LatticeOnly
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.MulStableIntegral
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.WeierstrassPSecondDerivative
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.CMQuasiPeriodConst
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.EllipticOnePole
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.ThetaZeroTranslateProduct
import Formalism.LocalToGlobal.TorsionIntegrality.FrobeniusFibreCurves.CurveHyp
import Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CayleyGaussianIntegrals.CayleyGaussianIntegral
import Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CayleyGaussianIntegrals.MatrixFormFourfoldBlock
import Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.BinomialSeriesCoefficients.Closure
import Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.BlockDiagMulBlockShift
import Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.TransposeMulBlockDiagMul
import Formalism.LocalToGlobal.UnitaryNorms.CharTransport
import Formalism.LocalToGlobal.UnitaryNorms.UnrAEPf
import Formalism.MahlerMeasure.FinalD
import Formalism.MahlerMeasure.FinalM
import Formalism.MahlerMeasure.MahlerMeasureProofs.GamInt
import Formalism.MahlerMeasure.StatementT
import Formalism.MoebiusJetDuality.StatementV
import Formalism.NormUnitaryBounds.NormUnitary
import Formalism.PadicSubsetSums.StableGradedCounts.ARCReuse
import Formalism.PadicSubsetSums.StableGradedCounts.CardLtAddCardGtAddCardEq
import Formalism.PadicSubsetSums.StableGradedCounts.IRRExcludedCount
import Formalism.PadicSubsetSums.StableGradedCounts.TWIndexScale
import Formalism.PeriodIntegrals.AlgWtHwUnq
import Formalism.PeriodIntegrals.ContinuousExpLie
import Formalism.PeriodIntegrals.GoodTwo
import Formalism.PeriodIntegrals.HwConjInf
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DatumBlockEigen
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DatumConjInv
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DensInert
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FinOrdAd
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.IdealLattice
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.LocHaarRR
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.LocalEnd
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PinHostLoc
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PoincareSeriesFinite
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.QmIndep
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.QmLemD
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.Residue
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SelfDualLoc
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SigmaStarUniq

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.LocalToGlobal.CharacterGerms.Interface, `Formalism.LocalToGlobal.CharacterGerms.MfactMulCoeffMvExpLinF, `Formalism.LocalToGlobal.CyclotomicLocalNorms.NormLeOneIffIsIntegral, `Formalism.LocalToGlobal.GaloisLevelStructure.DefsAutLoc, `Formalism.LocalToGlobal.GaloisLevelStructure.DefsFinTyp, `Formalism.LocalToGlobal.GlobalTheory.BlockActions.AdelicLocalLattice, `Formalism.LocalToGlobal.GlobalTheory.GL3.CubicFields.DifferentIdeal.CoeIdealDifferentNeZero, `Formalism.LocalToGlobal.GroupLattices.ComparisonMaps.ClsHypA, `Formalism.LocalToGlobal.IndefiniteReal.FinitePlaces.FourUniq, `Formalism.LocalToGlobal.NormalizedHeckeFactors.CoverStd, `Formalism.LocalToGlobal.NumberFieldFamilies.IdTransSM, `Formalism.LocalToGlobal.ProjectiveLattices.LocalIntegralPolynomials.ExistsValuationAdaptedIndex, `Formalism.LocalToGlobal.ProjectiveLattices.RegModelA, `Formalism.LocalToGlobal.ProjectiveLattices.TotalDegreePderivLt, `Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.EmbSInjective, `Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.IotaFIntMem, `Formalism.LocalToGlobal.SiegelLatticeTheory.FundamentalEquivalence.LevelIntersectParabolic, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsEnergy, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsEquiv, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsTail, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.IsogenyP, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.IsogenySigma, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.LatticeOnly, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.MulStableIntegral, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.AnalyticIdentityTheorems.WeierstrassPSecondDerivative, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.CMQuasiPeriodConst, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.EllipticOnePole, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.ThetaZeroTranslateProduct, `Formalism.LocalToGlobal.TorsionIntegrality.FrobeniusFibreCurves.CurveHyp, `Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CayleyGaussianIntegrals.CayleyGaussianIntegral, `Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CayleyGaussianIntegrals.MatrixFormFourfoldBlock, `Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.BinomialSeriesCoefficients.Closure, `Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.BlockDiagMulBlockShift, `Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.TransposeMulBlockDiagMul, `Formalism.LocalToGlobal.UnitaryNorms.CharTransport, `Formalism.LocalToGlobal.UnitaryNorms.UnrAEPf, `Formalism.MahlerMeasure.FinalD, `Formalism.MahlerMeasure.FinalM, `Formalism.MahlerMeasure.MahlerMeasureProofs.GamInt, `Formalism.MahlerMeasure.StatementT, `Formalism.MoebiusJetDuality.StatementV, `Formalism.NormUnitaryBounds.NormUnitary, `Formalism.PadicSubsetSums.StableGradedCounts.ARCReuse, `Formalism.PadicSubsetSums.StableGradedCounts.CardLtAddCardGtAddCardEq, `Formalism.PadicSubsetSums.StableGradedCounts.IRRExcludedCount, `Formalism.PadicSubsetSums.StableGradedCounts.TWIndexScale, `Formalism.PeriodIntegrals.AlgWtHwUnq, `Formalism.PeriodIntegrals.ContinuousExpLie, `Formalism.PeriodIntegrals.GoodTwo, `Formalism.PeriodIntegrals.HwConjInf, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DatumBlockEigen, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DatumConjInv, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DensInert, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FinOrdAd, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.IdealLattice, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.LocHaarRR, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.LocalEnd, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PinHostLoc, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.PoincareSeriesFinite, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.QmIndep, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.QmLemD, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.Residue, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SelfDualLoc, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.SigmaStarUniq]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

