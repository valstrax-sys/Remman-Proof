import Lean
import ReciprocityTheory.AnalyticForms.RegularLocalRings.JacChartB
import ReciprocityTheory.AnalyticForms.RegularLocalRings.Monomial
import ReciprocityTheory.Chebotarev.DiscreteTopologyLatOf
import ReciprocityTheory.Chebotarev.EulerFin
import ReciprocityTheory.Chebotarev.PrimeCont
import ReciprocityTheory.Chebotarev.PrimeSum
import ReciprocityTheory.Chebotarev.SplitA
import ReciprocityTheory.Chebotarev.SplitD
import ReciprocityTheory.Chebotarev.UnitPart
import ReciprocityTheory.ClassFieldTheory.GlobalClassField.AsGabLimB
import ReciprocityTheory.ClassFieldTheory.GlobalClassField.LocPowB
import ReciprocityTheory.ClassFieldTheory.LocalClassField.Herbrand
import ReciprocityTheory.ClassFieldTheory.LocalClassField.MemZmultiplesOfAddOrderOf
import ReciprocityTheory.ClassFieldTheory.LocalClassField.UnitsHerbrandC
import ReciprocityTheory.ClassFieldTheory.LocalClassField.UnrDefs
import ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.AssDim
import ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.Bridge
import ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.ExistsIsRegularAppendOfModDepthGE
import ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.IsCMOfIsRegularLocalRing
import ReciprocityTheory.CommutativeAlgebra.PolynomialHeights.PolySeq
import ReciprocityTheory.CommutativeAlgebra.SaturatedChains.AlgStep
import ReciprocityTheory.CommutativeAlgebra.SaturatedChains.Integral
import ReciprocityTheory.DualLattices.CokernelLengthComparisonStatement
import ReciprocityTheory.DualLattices.CokernelsAgreeEquivariantly
import ReciprocityTheory.DualLattices.ColengthCotangentBoundStatement
import ReciprocityTheory.DualLattices.ConstantCoeffRowSubst
import ReciprocityTheory.DualLattices.DiscriminantColengthStatement
import ReciprocityTheory.DualLattices.ExistsFamilyValuationDetEqOne
import ReciprocityTheory.DualLattices.FourierMapSmulLambdaWeight
import ReciprocityTheory.DualLattices.IsLocalOfIntegers
import ReciprocityTheory.DualLattices.IsotypicAveragingStatement
import ReciprocityTheory.DualLattices.MemAugIdeal
import ReciprocityTheory.DualLattices.MemDualLat
import ReciprocityTheory.DualLattices.ModuliPointsState
import ReciprocityTheory.DualLattices.MonomialDeterminantStatement
import ReciprocityTheory.DualLattices.NsmulFstAddSnd
import ReciprocityTheory.DualLattices.PrimeHopfOrderStatement
import ReciprocityTheory.DualLattices.SgAlgebraMap
import ReciprocityTheory.DualLattices.UnramifiedCokernelLengthStatement
import ReciprocityTheory.DualLattices.UpSmith
import ReciprocityTheory.DualLattices.ValuationFourierLeOne
import ReciprocityTheory.DualLattices.VdetLeOfSpanLe
import ReciprocityTheory.DualLattices.ZmodTrichotomy
import ReciprocityTheory.GaloisValuations.Global
import ReciprocityTheory.GaloisValuations.SymplecticRankFourModularity
import ReciprocityTheory.GeometryOfNumbers.AsymptoticSequences.DefectSt
import ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.CountStA
import ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.DegStB
import ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.BergmanDerivSt
import ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.MorseNormSt
import ReciprocityTheory.GeometryOfNumbers.SphericalMonomials.MonomStA
import ReciprocityTheory.GroupCohomology.ContinuousContractNth
import ReciprocityTheory.L2DbarEstimates.LeviForms.BergmanExistsStatement
import ReciprocityTheory.L2DbarEstimates.LeviForms.OfRealNormSqSumMul
import ReciprocityTheory.L2DbarEstimates.Localization.UnweightBackStatement
import ReciprocityTheory.L2DbarEstimates.MinimalSolutions.HormanderLemma
import ReciprocityTheory.L2DbarEstimates.MinimalSolutions.OntoWithBoundTop
import ReciprocityTheory.L2DbarEstimates.Mollifiers.FderivMollApply
import ReciprocityTheory.L2DbarEstimates.Mollifiers.MollEnormSqLe
import ReciprocityTheory.L2DbarEstimates.NormFibrations.NormFib
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.GROWCountStatement
import ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.LintegralBallRpowLtTop
import ReciprocityTheory.L2DbarEstimates.SymmetricSections.EsymmZero
import ReciprocityTheory.L2DbarEstimates.SymmetricSections.LineFinite

open Lean Elab Command

def auditTargets : Array Name := #[`ReciprocityTheory.AnalyticForms.RegularLocalRings.JacChartB, `ReciprocityTheory.AnalyticForms.RegularLocalRings.Monomial, `ReciprocityTheory.Chebotarev.DiscreteTopologyLatOf, `ReciprocityTheory.Chebotarev.EulerFin, `ReciprocityTheory.Chebotarev.PrimeCont, `ReciprocityTheory.Chebotarev.PrimeSum, `ReciprocityTheory.Chebotarev.SplitA, `ReciprocityTheory.Chebotarev.SplitD, `ReciprocityTheory.Chebotarev.UnitPart, `ReciprocityTheory.ClassFieldTheory.GlobalClassField.AsGabLimB, `ReciprocityTheory.ClassFieldTheory.GlobalClassField.LocPowB, `ReciprocityTheory.ClassFieldTheory.LocalClassField.Herbrand, `ReciprocityTheory.ClassFieldTheory.LocalClassField.MemZmultiplesOfAddOrderOf, `ReciprocityTheory.ClassFieldTheory.LocalClassField.UnitsHerbrandC, `ReciprocityTheory.ClassFieldTheory.LocalClassField.UnrDefs, `ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.AssDim, `ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.Bridge, `ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.ExistsIsRegularAppendOfModDepthGE, `ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.IsCMOfIsRegularLocalRing, `ReciprocityTheory.CommutativeAlgebra.PolynomialHeights.PolySeq, `ReciprocityTheory.CommutativeAlgebra.SaturatedChains.AlgStep, `ReciprocityTheory.CommutativeAlgebra.SaturatedChains.Integral, `ReciprocityTheory.DualLattices.CokernelLengthComparisonStatement, `ReciprocityTheory.DualLattices.CokernelsAgreeEquivariantly, `ReciprocityTheory.DualLattices.ColengthCotangentBoundStatement, `ReciprocityTheory.DualLattices.ConstantCoeffRowSubst, `ReciprocityTheory.DualLattices.DiscriminantColengthStatement, `ReciprocityTheory.DualLattices.ExistsFamilyValuationDetEqOne, `ReciprocityTheory.DualLattices.FourierMapSmulLambdaWeight, `ReciprocityTheory.DualLattices.IsLocalOfIntegers, `ReciprocityTheory.DualLattices.IsotypicAveragingStatement, `ReciprocityTheory.DualLattices.MemAugIdeal, `ReciprocityTheory.DualLattices.MemDualLat, `ReciprocityTheory.DualLattices.ModuliPointsState, `ReciprocityTheory.DualLattices.MonomialDeterminantStatement, `ReciprocityTheory.DualLattices.NsmulFstAddSnd, `ReciprocityTheory.DualLattices.PrimeHopfOrderStatement, `ReciprocityTheory.DualLattices.SgAlgebraMap, `ReciprocityTheory.DualLattices.UnramifiedCokernelLengthStatement, `ReciprocityTheory.DualLattices.UpSmith, `ReciprocityTheory.DualLattices.ValuationFourierLeOne, `ReciprocityTheory.DualLattices.VdetLeOfSpanLe, `ReciprocityTheory.DualLattices.ZmodTrichotomy, `ReciprocityTheory.GaloisValuations.Global, `ReciprocityTheory.GaloisValuations.SymplecticRankFourModularity, `ReciprocityTheory.GeometryOfNumbers.AsymptoticSequences.DefectSt, `ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.CountStA, `ReciprocityTheory.GeometryOfNumbers.LatticeCovolumes.DegStB, `ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.BergmanDerivSt, `ReciprocityTheory.GeometryOfNumbers.PluriharmonicAnalysis.MorseNormSt, `ReciprocityTheory.GeometryOfNumbers.SphericalMonomials.MonomStA, `ReciprocityTheory.GroupCohomology.ContinuousContractNth, `ReciprocityTheory.L2DbarEstimates.LeviForms.BergmanExistsStatement, `ReciprocityTheory.L2DbarEstimates.LeviForms.OfRealNormSqSumMul, `ReciprocityTheory.L2DbarEstimates.Localization.UnweightBackStatement, `ReciprocityTheory.L2DbarEstimates.MinimalSolutions.HormanderLemma, `ReciprocityTheory.L2DbarEstimates.MinimalSolutions.OntoWithBoundTop, `ReciprocityTheory.L2DbarEstimates.Mollifiers.FderivMollApply, `ReciprocityTheory.L2DbarEstimates.Mollifiers.MollEnormSqLe, `ReciprocityTheory.L2DbarEstimates.NormFibrations.NormFib, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.GROWCountStatement, `ReciprocityTheory.L2DbarEstimates.PlurisubharmonicCharts.LintegralBallRpowLtTop, `ReciprocityTheory.L2DbarEstimates.SymmetricSections.EsymmZero, `ReciprocityTheory.L2DbarEstimates.SymmetricSections.LineFinite]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

