import Lean
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.SummableOneDivAbsNormSq
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.TensorInvolutionAlgebraProperties
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.TensorLocallyCompactRing
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.TotallyRealIntegralBasisExistsStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.UnitProductClosureProperties
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.UnitaryIsomOfIsometry
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.WittExtensionGlobal
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.GlobalTheory.ExistsExpUnitary
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.HermitianCharacters.SelfDualLatticeFiltrationCharacter
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.NefEffectiveCones.ExistsNsmulMulVecMemHat
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.AntiInvolutionSwapsUpperLowerStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.CongruenceEndomorphismInverseExistsStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.HermitianAdjointExistsStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.IwahoriUpperLowerFactorizationStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.QuantumDeterminantEquality
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.ShuffleOfPermImports
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.TorusConjugationPreservesCongruenceStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.UpperTriangularInverseIsUpperStatement
import CompanionTheory.ThickeningEstimates.InnerProductFactorization.EqOfInner
import Development.AbelianVarietyTheory.BlockTheory.CMModuli.LieCharpolyRootPairs
import Development.AbelianVarietyTheory.BlockTheory.CMModuli.PrimitiveExponentPullback
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.CovariantDbarLeibniz
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.HermitianCurvatureForms
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.HermitianInterpolation
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.HodgeFrameGram
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.HodgePeriodGram
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.QuasiPlurisubharmonic
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.TaylorCoefficientForms
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.TensorCoordinateForms
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.AdjointCanonicalGauge
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.BalancedFrameGauge
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.BiadditiveBalancedSeries
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.LogExpAdaptedGauge
import Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.UnitriangularCharts
import Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.LocalIntegralGL
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.BoundaryVanishingPullback
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.DepthZeroGoodLines
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.GodementJacquetZeta
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.IrreducibleTensorCharacter
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.OpenClosedSequences
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.SatakeTrivialRangeBound
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.WeilTensorLiftConclusion
import Development.AbelianVarietyTheory.BlockTheory.UniformisationCharts.PowerGroupDatum
import Development.AbelianVarietyTheory.BlockTheory.UniformisationCharts.RawDegreeForms
import Development.AbelianVarietyTheory.Counterexamples.AbelianLawCounterexamples.MulGenNegRight
import Development.AbelianVarietyTheory.Counterexamples.JetSurvey.ExistsIsCayleyUIff
import Development.AbelianVarietyTheory.Counterexamples.LevelGroupExamples.TransvMemZGam
import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.ExistsNotCongPow
import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.IsIrreducibleIff
import Development.AbelianVarietyTheory.Definitions.Divisors.BlockGLMap
import Development.AbelianVarietyTheory.Definitions.Divisors.CurvSubQuotTautPairGram
import Development.AbelianVarietyTheory.Definitions.Divisors.EqOfHasValueAtInfinite
import Development.AbelianVarietyTheory.Definitions.Divisors.FibreRankCompOfSurjective
import Development.AbelianVarietyTheory.Definitions.Divisors.IndEtOfForallFinset
import Development.AbelianVarietyTheory.Definitions.Divisors.IrreducibleOfIrreducibleMap
import Development.AbelianVarietyTheory.Definitions.Divisors.IsDetEltOne
import Development.AbelianVarietyTheory.Definitions.Divisors.IsEtCoord
import Development.AbelianVarietyTheory.Definitions.Divisors.ProdFam
import Development.AbelianVarietyTheory.Definitions.Divisors.PullHlComp
import Development.AbelianVarietyTheory.Definitions.Divisors.Pullback1MemHodgeFiltration
import Development.AbelianVarietyTheory.Definitions.Divisors.RankEqCardIffExistsFrameMatrixFirstColumnBlock
import Development.AbelianVarietyTheory.Definitions.Divisors.SameDiv
import Development.AbelianVarietyTheory.Definitions.Foundations.ColMeas
import Development.AbelianVarietyTheory.Definitions.Foundations.EeProd

open Lean Elab Command

def auditTargets : Array Name := #[`CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.SummableOneDivAbsNormSq, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.TensorInvolutionAlgebraProperties, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.TensorLocallyCompactRing, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.TotallyRealIntegralBasisExistsStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.UnitProductClosureProperties, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.UnitaryIsomOfIsometry, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.WittExtensionGlobal, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.GlobalTheory.ExistsExpUnitary, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.HermitianCharacters.SelfDualLatticeFiltrationCharacter, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.NefEffectiveCones.ExistsNsmulMulVecMemHat, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.AntiInvolutionSwapsUpperLowerStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.CongruenceEndomorphismInverseExistsStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.HermitianAdjointExistsStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.IwahoriUpperLowerFactorizationStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.QuantumDeterminantEquality, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.ShuffleOfPermImports, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.TorusConjugationPreservesCongruenceStatement, `CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.UpperTriangularInverseIsUpperStatement, `CompanionTheory.ThickeningEstimates.InnerProductFactorization.EqOfInner, `Development.AbelianVarietyTheory.BlockTheory.CMModuli.LieCharpolyRootPairs, `Development.AbelianVarietyTheory.BlockTheory.CMModuli.PrimitiveExponentPullback, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.CovariantDbarLeibniz, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.HermitianCurvatureForms, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.HermitianInterpolation, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.HodgeFrameGram, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.HodgePeriodGram, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.QuasiPlurisubharmonic, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.TaylorCoefficientForms, `Development.AbelianVarietyTheory.BlockTheory.DivisorBase.TensorCoordinateForms, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.AdjointCanonicalGauge, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.BalancedFrameGauge, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.BiadditiveBalancedSeries, `Development.AbelianVarietyTheory.BlockTheory.JetGauges.LogExpAdaptedGauge, `Development.AbelianVarietyTheory.BlockTheory.PoincareCuspForms.UnitriangularCharts, `Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.LocalIntegralGL, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.BoundaryVanishingPullback, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.DepthZeroGoodLines, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.GodementJacquetZeta, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.IrreducibleTensorCharacter, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.OpenClosedSequences, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.SatakeTrivialRangeBound, `Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.WeilTensorLiftConclusion, `Development.AbelianVarietyTheory.BlockTheory.UniformisationCharts.PowerGroupDatum, `Development.AbelianVarietyTheory.BlockTheory.UniformisationCharts.RawDegreeForms, `Development.AbelianVarietyTheory.Counterexamples.AbelianLawCounterexamples.MulGenNegRight, `Development.AbelianVarietyTheory.Counterexamples.JetSurvey.ExistsIsCayleyUIff, `Development.AbelianVarietyTheory.Counterexamples.LevelGroupExamples.TransvMemZGam, `Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.ExistsNotCongPow, `Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.IsIrreducibleIff, `Development.AbelianVarietyTheory.Definitions.Divisors.BlockGLMap, `Development.AbelianVarietyTheory.Definitions.Divisors.CurvSubQuotTautPairGram, `Development.AbelianVarietyTheory.Definitions.Divisors.EqOfHasValueAtInfinite, `Development.AbelianVarietyTheory.Definitions.Divisors.FibreRankCompOfSurjective, `Development.AbelianVarietyTheory.Definitions.Divisors.IndEtOfForallFinset, `Development.AbelianVarietyTheory.Definitions.Divisors.IrreducibleOfIrreducibleMap, `Development.AbelianVarietyTheory.Definitions.Divisors.IsDetEltOne, `Development.AbelianVarietyTheory.Definitions.Divisors.IsEtCoord, `Development.AbelianVarietyTheory.Definitions.Divisors.ProdFam, `Development.AbelianVarietyTheory.Definitions.Divisors.PullHlComp, `Development.AbelianVarietyTheory.Definitions.Divisors.Pullback1MemHodgeFiltration, `Development.AbelianVarietyTheory.Definitions.Divisors.RankEqCardIffExistsFrameMatrixFirstColumnBlock, `Development.AbelianVarietyTheory.Definitions.Divisors.SameDiv, `Development.AbelianVarietyTheory.Definitions.Foundations.ColMeas, `Development.AbelianVarietyTheory.Definitions.Foundations.EeProd]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

