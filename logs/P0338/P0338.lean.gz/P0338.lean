import Lean
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PPFDegree
import GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PSplitRelDeg
import GroundTheory.HeightsAndTheta.Heights.FubiniStudyCharts
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PChartDensityIntegrable
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PChartEnergy
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PChartEnergyDiagonal
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PChartEnergyInvariant
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PFsConjInvariant
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PFsLineSemipositive
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PFsLineSmooth
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGrassArithVar
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGrassHeightBound
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGrassLeRoot
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PMultiHomogMemCoord
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PNefOfNonneg
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRootAnchorNonzero
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRootDense
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRootLogNormBound
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaFirstCoordSplit
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaInnerMean
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaMean
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaNormMajorant
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.RestAssembly
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsGrassFibreDegree
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsGrassGeomDegChart
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsGrassHeightNE
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsGrassLinesProj
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsLines
import GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.Comparison
import GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.DenseChart
import GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.DenseHeight
import GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.FieldChange
import GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.LowerBound
import GroundTheory.HeightsAndTheta.Heights.HermitianDual
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.ColonSpanSingletonEqOfNotMem
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.PPrimeCoverPieceSheets
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PIntersectionRecursion
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PModulesFromPrimes
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PMultigradedFiltration
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PMultigradedHilbertPolynomial
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsClopenDegree
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsPieceIntegral
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsPiecesAdditive
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsSegre
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.CoordinateIdeals.FubiniLeviGen
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.CoordinateIdeals.MemMCoordIdealOfAevalEqZero
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PlueckerCoordinates.RhoExistsNeZero
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsGrassProdGeomDeg
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.ChartGlueLat
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.ComapEqMaximalIdeal
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.CpEqPrimeWeight
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.EquivAt
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.FiniteTypeSectionsOfIsFiniteTypeOverZ
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.GenericImageEqGermImage
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.GlueBundlesSecondOfFirst
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.GlueCoherence
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.IicEqRange
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.Imports
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.ImportsAlt
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.ImportsBis
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.IsVectorBundleIffModel
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.NonemptyPullbackIsoIff
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.PAwayHeightOne
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.PBlowUpChart

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PPFDegree, `GroundTheory.HeightsAndTheta.Heights.FieldsOfNumbers.PSplitRelDeg, `GroundTheory.HeightsAndTheta.Heights.FubiniStudyCharts, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PChartDensityIntegrable, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PChartEnergy, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PChartEnergyDiagonal, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PChartEnergyInvariant, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PFsConjInvariant, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PFsLineSemipositive, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PFsLineSmooth, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGrassArithVar, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGrassHeightBound, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PGrassLeRoot, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PMultiHomogMemCoord, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PNefOfNonneg, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRootAnchorNonzero, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRootDense, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PRootLogNormBound, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaFirstCoordSplit, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaInnerMean, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaMean, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.PThetaNormMajorant, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.RestAssembly, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsGrassFibreDegree, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsGrassGeomDegChart, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsGrassHeightNE, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsGrassLinesProj, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsLines, `GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.Comparison, `GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.DenseChart, `GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.DenseHeight, `GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.FieldChange, `GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.LowerBound, `GroundTheory.HeightsAndTheta.Heights.HermitianDual, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.ColonSpanSingletonEqOfNotMem, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.PPrimeCoverPieceSheets, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PIntersectionRecursion, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PModulesFromPrimes, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PMultigradedFiltration, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PMultigradedHilbertPolynomial, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsClopenDegree, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsPieceIntegral, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsPiecesAdditive, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsSegre, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.CoordinateIdeals.FubiniLeviGen, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.CoordinateIdeals.MemMCoordIdealOfAevalEqZero, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PlueckerCoordinates.RhoExistsNeZero, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsGrassProdGeomDeg, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.ChartGlueLat, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.ComapEqMaximalIdeal, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.CpEqPrimeWeight, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.EquivAt, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.FiniteTypeSectionsOfIsFiniteTypeOverZ, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.GenericImageEqGermImage, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.GlueBundlesSecondOfFirst, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.GlueCoherence, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.IicEqRange, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.Imports, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.ImportsAlt, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.ImportsBis, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.IsVectorBundleIffModel, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.NonemptyPullbackIsoIff, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.PAwayHeightOne, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.PBlowUpChart]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

