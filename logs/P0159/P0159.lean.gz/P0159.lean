import Lean
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.CancelC
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.CancelQ
import Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.TruncZero
import Formalism.UnipotentAdelicQuotients.EllRegCut
import Formalism.UnipotentAdelicQuotients.SiegelWeilUnitaryConvergent
import Formalism.UnipotentAdelicQuotients.UnipotentAdelicCocompact
import Formalism.UnipotentAdelicQuotients.UnipotentStrongApprox
import Formalism.WachLatticeTwists.HodgeTateChains.HodgeTateFiltrations.Complete
import Formalism.WachLatticeTwists.HodgeTateChains.InvariantsCohomologyData
import Formalism.WachLatticeTwists.HodgeTateChains.StatCharSum
import Formalism.WachLatticeTwists.LagrangeExtensionCocycles.Statement
import Formalism.WachLatticeTwists.Statement
import Formalism.WachLatticeTwists.StatementDual
import Formalism.WachLatticeTwists.WachProductBases.OneAddPowSubOne
import Formalism.WachModuleLifts.WachModuleProofs.LemmaCLower
import Formalism.WachModuleLifts.WachModuleProofs.LemmaCSharp
import Formalism.WachModuleLifts.WachModuleProofs.LemmaCSharpG
import Formalism.WachModuleLifts.WachModuleProofs.LemmaCSharpOddG
import Formalism.WachModuleLifts.WachModuleProofs.LemmaCSharpOddUnitInvHolds
import Formalism.WachModuleLifts.WachModuleProofs.LemmaHLift
import Formalism.WachModuleLifts.WachModuleProofs.WachModuleStatementHolds
import Formalism.WeaklyAdmissibleFiltrations.Statement
import Formalism.WeightedDeltaMeans.LogBaseHeightBound
import Formalism.WindowSums.AnnihilatorPolynomials.DistinctTerms
import Formalism.WindowSums.AnnihilatorPolynomials.EvalOneSmulDecomposition
import Formalism.WindowSums.AnnihilatorPolynomials.FirstCoefficientBoundHolds
import Formalism.WindowSums.AnnihilatorPolynomials.Lagrange
import Formalism.WindowSums.AnnihilatorPolynomials.ValProd
import Formalism.WindowSums.AnnihilatorPolynomials.WindowSum
import Formalism.WindowSums.AnnihilatorPolynomials.ZpowVal
import Formalism.WindowSums.StatementRelay
import Formalism.YangianSpanCharacter.ExchangeGen
import Formalism.YangianSpanCharacter.StatementY
import Formalism.YangianSpanCharacter.TJTrev
import Formalism.YangianSpanCharacter.YangianRTTProofs.RttRelation
import Formalism.YangianSpanCharacter.YangianRTTProofs.SpanCharacterIdentity
import Formalism.YangianSpanCharacter.YangianRTTProofs.TransposeSymplecticShift
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.DzDifferentiableOn
import Formalism.ZetaRealNonvanish
import GroundTheory.ArithmeticGeometry.AbelianVarieties.DivisionPoints
import GroundTheory.ArithmeticGeometry.AbelianVarieties.JacobianSmoothness.SmoothOfRegular
import GroundTheory.ArithmeticGeometry.EtaleCompletion.ArtinHenselCompletionNoetherian
import GroundTheory.ArithmeticGeometry.EtaleCompletion.PullbackAffine
import GroundTheory.ArithmeticGeometry.EtaleCompletion.QcohPresheaf
import GroundTheory.ArithmeticGeometry.ModularCurves.WeierstrassProj
import GroundTheory.ArithmeticGeometry.ModularCurves.WeierstrassXRing
import GroundTheory.ArithmeticGeometry.SchemeCohomology.CechNaturality.Chains
import GroundTheory.ArithmeticGeometry.SchemeCohomology.InjectiveCech
import GroundTheory.ArithmeticGeometry.SchemeCohomology.InvertibleSheaf
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProjTwistAway
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.IrreducibleImage
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.ReesScheme
import GroundTheory.ArithmeticGeometry.SchemeCohomology.RegularSmooth
import GroundTheory.ArithmeticGeometry.SchemeCohomology.RegularUFDSerre
import GroundTheory.ArithmeticGeometry.SchemeCohomology.SheafHFlasque
import GroundTheory.ArithmeticGeometry.SchemeCohomology.SheafHOver
import GroundTheory.ArithmeticGeometry.SchemeCohomology.WeilDivisorLocal
import GroundTheory.ArithmeticGeometry.ToricVarieties.IsFaceOfIffExistsEqExposedFace
import GroundTheory.ArithmeticGeometry.ToricVarieties.Lattice
import GroundTheory.AutomorphicForms.AdelicDixmierMalliavinLie
import GroundTheory.AutomorphicForms.CuspidalDiscreteness.MixedDifference
import GroundTheory.AutomorphicForms.DefiniteClassNumber.GramReduction
import GroundTheory.AutomorphicForms.DixmierMalliavinBasic
import GroundTheory.AutomorphicForms.DixmierMalliavinLineStage

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.CancelC, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.CancelQ, `Formalism.TruncatedSeriesCounting.TruncatedSeriesProofs.TruncZero, `Formalism.UnipotentAdelicQuotients.EllRegCut, `Formalism.UnipotentAdelicQuotients.SiegelWeilUnitaryConvergent, `Formalism.UnipotentAdelicQuotients.UnipotentAdelicCocompact, `Formalism.UnipotentAdelicQuotients.UnipotentStrongApprox, `Formalism.WachLatticeTwists.HodgeTateChains.HodgeTateFiltrations.Complete, `Formalism.WachLatticeTwists.HodgeTateChains.InvariantsCohomologyData, `Formalism.WachLatticeTwists.HodgeTateChains.StatCharSum, `Formalism.WachLatticeTwists.LagrangeExtensionCocycles.Statement, `Formalism.WachLatticeTwists.Statement, `Formalism.WachLatticeTwists.StatementDual, `Formalism.WachLatticeTwists.WachProductBases.OneAddPowSubOne, `Formalism.WachModuleLifts.WachModuleProofs.LemmaCLower, `Formalism.WachModuleLifts.WachModuleProofs.LemmaCSharp, `Formalism.WachModuleLifts.WachModuleProofs.LemmaCSharpG, `Formalism.WachModuleLifts.WachModuleProofs.LemmaCSharpOddG, `Formalism.WachModuleLifts.WachModuleProofs.LemmaCSharpOddUnitInvHolds, `Formalism.WachModuleLifts.WachModuleProofs.LemmaHLift, `Formalism.WachModuleLifts.WachModuleProofs.WachModuleStatementHolds, `Formalism.WeaklyAdmissibleFiltrations.Statement, `Formalism.WeightedDeltaMeans.LogBaseHeightBound, `Formalism.WindowSums.AnnihilatorPolynomials.DistinctTerms, `Formalism.WindowSums.AnnihilatorPolynomials.EvalOneSmulDecomposition, `Formalism.WindowSums.AnnihilatorPolynomials.FirstCoefficientBoundHolds, `Formalism.WindowSums.AnnihilatorPolynomials.Lagrange, `Formalism.WindowSums.AnnihilatorPolynomials.ValProd, `Formalism.WindowSums.AnnihilatorPolynomials.WindowSum, `Formalism.WindowSums.AnnihilatorPolynomials.ZpowVal, `Formalism.WindowSums.StatementRelay, `Formalism.YangianSpanCharacter.ExchangeGen, `Formalism.YangianSpanCharacter.StatementY, `Formalism.YangianSpanCharacter.TJTrev, `Formalism.YangianSpanCharacter.YangianRTTProofs.RttRelation, `Formalism.YangianSpanCharacter.YangianRTTProofs.SpanCharacterIdentity, `Formalism.YangianSpanCharacter.YangianRTTProofs.TransposeSymplecticShift, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.DzDifferentiableOn, `Formalism.ZetaRealNonvanish, `GroundTheory.ArithmeticGeometry.AbelianVarieties.DivisionPoints, `GroundTheory.ArithmeticGeometry.AbelianVarieties.JacobianSmoothness.SmoothOfRegular, `GroundTheory.ArithmeticGeometry.EtaleCompletion.ArtinHenselCompletionNoetherian, `GroundTheory.ArithmeticGeometry.EtaleCompletion.PullbackAffine, `GroundTheory.ArithmeticGeometry.EtaleCompletion.QcohPresheaf, `GroundTheory.ArithmeticGeometry.ModularCurves.WeierstrassProj, `GroundTheory.ArithmeticGeometry.ModularCurves.WeierstrassXRing, `GroundTheory.ArithmeticGeometry.SchemeCohomology.CechNaturality.Chains, `GroundTheory.ArithmeticGeometry.SchemeCohomology.InjectiveCech, `GroundTheory.ArithmeticGeometry.SchemeCohomology.InvertibleSheaf, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProjTwistAway, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.IrreducibleImage, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.ReesScheme, `GroundTheory.ArithmeticGeometry.SchemeCohomology.RegularSmooth, `GroundTheory.ArithmeticGeometry.SchemeCohomology.RegularUFDSerre, `GroundTheory.ArithmeticGeometry.SchemeCohomology.SheafHFlasque, `GroundTheory.ArithmeticGeometry.SchemeCohomology.SheafHOver, `GroundTheory.ArithmeticGeometry.SchemeCohomology.WeilDivisorLocal, `GroundTheory.ArithmeticGeometry.ToricVarieties.IsFaceOfIffExistsEqExposedFace, `GroundTheory.ArithmeticGeometry.ToricVarieties.Lattice, `GroundTheory.AutomorphicForms.AdelicDixmierMalliavinLie, `GroundTheory.AutomorphicForms.CuspidalDiscreteness.MixedDifference, `GroundTheory.AutomorphicForms.DefiniteClassNumber.GramReduction, `GroundTheory.AutomorphicForms.DixmierMalliavinBasic, `GroundTheory.AutomorphicForms.DixmierMalliavinLineStage]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

