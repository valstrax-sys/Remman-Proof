import Lean
import GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.PUnipotentModulusMatrix
import GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.StIntegralFormCovolume
import GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.StReducedBasisBound
import GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.StatementsDoubleCoset
import GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.StatementsTorusIntegral
import GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.StatementsUnitsInvHaar
import GroundTheory.HeightsAndTheta.Heights.FlagBundles.StatementsIntervalMoments
import GroundTheory.HeightsAndTheta.Heights.FlatDegree.FlatDegreeFormula
import GroundTheory.HeightsAndTheta.Heights.FlatDegree.Statements
import GroundTheory.HeightsAndTheta.Heights.FubiniStudyIntegral
import GroundTheory.HeightsAndTheta.Heights.HeightComparison.HeightLocalNormalIndex
import GroundTheory.HeightsAndTheta.Heights.HeightComparison.HeightPlacesRing
import GroundTheory.HeightsAndTheta.Heights.HeightComparison.HeightSemilocalQuotCard
import GroundTheory.HeightsAndTheta.Heights.HeightComparison.HeightSubringPrimeMaximal
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.ExtendedDataRemainder
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.IsSiegelReducedCoordinates
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.QuotientLiftInjective
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsGrass
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsHermFormCompare
import GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsLogCardLength
import GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.DenseIntegral
import GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.DenseLift
import GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.Points
import GroundTheory.HeightsAndTheta.Heights.HermitianLattice
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StClopenPieceSheetCount
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StEntirePolynomialGrowth
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StGrowthOffHypersurfacePolynomial
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StMonicRootGrowth
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StPieceRootProductPolynomial
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StatementsBasicOpen
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.LinearIndependentAdjoinOfTranscendental
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsChartSup
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsComplexMinimalPrimesContract
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsConstantsDescend
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsDoubleComplexVanish
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsFiniteSeparatingModel
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsIndependentModBaseChange
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsIrreducibleConnected
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsMixedTopAlgebra
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsNoetherProjection
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsPolyNonnegAtZero
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsPolyNonvanishDense
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsPolySandwich
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsPrimeComplexRadical
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsRatPrimeDense
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsRootGridLower
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsRootsBounded
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsRootsLiftToZeros
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsRootsNear
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsSerreGraded
import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsUnitApprox
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.Counterexample.OscWeight
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.FrameDefinitions.PermFinTwoUniv
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.LoewnerDetBound
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PFlagIntMuOneDet
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsHoloInjDerivInj
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsHookFactorBranch
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsInvDerivDecay
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsLaplacianDecayZero
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsLaplacianLogGrowth
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsLevelSetLocalInj
import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsVandermondeBranch
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.FiniteIntegralClosureCharP
import GroundTheory.HeightsAndTheta.Heights.IntegralModels.FiniteIntegralClosureLocal

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.PUnipotentModulusMatrix, `GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.StIntegralFormCovolume, `GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.StReducedBasisBound, `GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.StatementsDoubleCoset, `GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.StatementsTorusIntegral, `GroundTheory.HeightsAndTheta.Heights.FiniteCovolume.StatementsUnitsInvHaar, `GroundTheory.HeightsAndTheta.Heights.FlagBundles.StatementsIntervalMoments, `GroundTheory.HeightsAndTheta.Heights.FlatDegree.FlatDegreeFormula, `GroundTheory.HeightsAndTheta.Heights.FlatDegree.Statements, `GroundTheory.HeightsAndTheta.Heights.FubiniStudyIntegral, `GroundTheory.HeightsAndTheta.Heights.HeightComparison.HeightLocalNormalIndex, `GroundTheory.HeightsAndTheta.Heights.HeightComparison.HeightPlacesRing, `GroundTheory.HeightsAndTheta.Heights.HeightComparison.HeightSemilocalQuotCard, `GroundTheory.HeightsAndTheta.Heights.HeightComparison.HeightSubringPrimeMaximal, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.ExtendedDataRemainder, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.IsSiegelReducedCoordinates, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.QuotientLiftInjective, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsGrass, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsHermFormCompare, `GroundTheory.HeightsAndTheta.Heights.HeightKernels.StatementsLogCardLength, `GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.DenseIntegral, `GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.DenseLift, `GroundTheory.HeightsAndTheta.Heights.HeightsOfSets.Points, `GroundTheory.HeightsAndTheta.Heights.HermitianLattice, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StClopenPieceSheetCount, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StEntirePolynomialGrowth, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StGrowthOffHypersurfacePolynomial, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StMonicRootGrowth, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StPieceRootProductPolynomial, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.IrreducibleConnected.StatementsBasicOpen, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.LinearIndependentAdjoinOfTranscendental, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsChartSup, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsComplexMinimalPrimesContract, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsConstantsDescend, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsDoubleComplexVanish, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsFiniteSeparatingModel, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsIndependentModBaseChange, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsIrreducibleConnected, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsMixedTopAlgebra, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsNoetherProjection, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsPolyNonnegAtZero, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsPolyNonvanishDense, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsPolySandwich, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsPrimeComplexRadical, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsRatPrimeDense, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsRootGridLower, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsRootsBounded, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsRootsLiftToZeros, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsRootsNear, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsSerreGraded, `GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.StatementsUnitApprox, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.Counterexample.OscWeight, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.FrameDefinitions.PermFinTwoUniv, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.LoewnerDetBound, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PFlagIntMuOneDet, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsHoloInjDerivInj, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsHookFactorBranch, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsInvDerivDecay, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsLaplacianDecayZero, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsLaplacianLogGrowth, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsLevelSetLocalInj, `GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.StatementsVandermondeBranch, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.FiniteIntegralClosureCharP, `GroundTheory.HeightsAndTheta.Heights.IntegralModels.FiniteIntegralClosureLocal]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

