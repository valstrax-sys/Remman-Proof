import Lean
import GroundTheory.AutomorphicForms.RestrictedProductMatrix
import GroundTheory.AutomorphicForms.SmoothRepContragredient
import GroundTheory.AutomorphicForms.SmoothRepSchur
import GroundTheory.AutomorphicForms.TensorProductTheorem.OuterTensor
import GroundTheory.AutomorphicForms.TensorProductTheorem.Restricted
import GroundTheory.AutomorphicForms.TensorProductTheorem.Window
import GroundTheory.AutomorphicForms.TraceNormComp
import GroundTheory.AutomorphicForms.UnitaryGroupScheme
import GroundTheory.AutomorphicForms.UnitaryRepresentations
import GroundTheory.AutomorphicForms.WhittakerLSpace
import GroundTheory.Brauer.BaseChange
import GroundTheory.Brauer.CrossedProductMaps
import GroundTheory.Brauer.Degree
import GroundTheory.Brauer.DoubleCentralizer
import GroundTheory.FunctionField.Approximation
import GroundTheory.FunctionField.PlaceAbove
import GroundTheory.GlobalFields.Adele.Discrete
import GroundTheory.GlobalFields.Adele.Topology
import GroundTheory.GlobalFields.Artin.InflationTower
import GroundTheory.GlobalFields.Artin.Mackey
import GroundTheory.GlobalFields.CompletionAtPlace
import GroundTheory.GlobalFields.ComplexMultiplication.EllipticRational
import GroundTheory.GlobalFields.ComplexMultiplication.EllipticResidues
import GroundTheory.GlobalFields.ComplexMultiplication.IdeleAction
import GroundTheory.GlobalFields.ComplexMultiplication.WeberFunctionAutomorphisms
import GroundTheory.GlobalFields.CyclotomicCharacters.ProfinitePadic
import GroundTheory.GlobalFields.ExistenceTheorem.PowerIndex
import GroundTheory.GlobalFields.HerbrandQuotients.CycTateNegOneOrbitEquivSymmMk
import GroundTheory.GlobalFields.HerbrandQuotients.Lattice
import GroundTheory.GlobalFields.HerbrandQuotients.Permutation
import GroundTheory.GlobalFields.HerbrandQuotients.SUnitsExact
import GroundTheory.GlobalFields.IdeleGroups.SIdeleGroups
import GroundTheory.GlobalFields.IdeleGroups.StandardOpenEquiv
import GroundTheory.GlobalFields.InfiniteNormIndex.LocalSymbol
import GroundTheory.GlobalFields.KummerTheory.LocalIndexAtPlace
import GroundTheory.GlobalFields.SemilocalAlgebras.Finite
import GroundTheory.GlobalFields.SemilocalAlgebras.InfiniteAdeleTopology
import GroundTheory.GlobalFields.TateThesis.AdelicChar
import GroundTheory.GlobalFields.TateThesis.ArchCharsUnitary
import GroundTheory.GlobalFields.TateThesis.Conductor
import GroundTheory.GlobalFields.TateThesis.GaussianComplexFourier
import GroundTheory.GlobalFields.TateThesis.TraceFourier
import GroundTheory.HeightsAndTheta.Heights.AnalyticLimit.PGreenMassReplaceLevi
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ChowDegree
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ContinuousHermNormGroup
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.GaussSum
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LogIntPoly
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.MahlerSectionBasic
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PAreaMultiplicityWeight
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PBaseChangeAvoid
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChartGramMA
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowFormExtend
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeLogBound
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PMinimalPrimeComap
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PProjPrimeHasPoint
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PQuasiFiniteSheets
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PRadicalBaseChange
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PSectionLengthSum
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.SphereMeanDisc
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChowFormDim
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChowFormSectionPerfect
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsClosedPointChartField
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsClosedPointConeCoord
import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsConeMapArea

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.AutomorphicForms.RestrictedProductMatrix, `GroundTheory.AutomorphicForms.SmoothRepContragredient, `GroundTheory.AutomorphicForms.SmoothRepSchur, `GroundTheory.AutomorphicForms.TensorProductTheorem.OuterTensor, `GroundTheory.AutomorphicForms.TensorProductTheorem.Restricted, `GroundTheory.AutomorphicForms.TensorProductTheorem.Window, `GroundTheory.AutomorphicForms.TraceNormComp, `GroundTheory.AutomorphicForms.UnitaryGroupScheme, `GroundTheory.AutomorphicForms.UnitaryRepresentations, `GroundTheory.AutomorphicForms.WhittakerLSpace, `GroundTheory.Brauer.BaseChange, `GroundTheory.Brauer.CrossedProductMaps, `GroundTheory.Brauer.Degree, `GroundTheory.Brauer.DoubleCentralizer, `GroundTheory.FunctionField.Approximation, `GroundTheory.FunctionField.PlaceAbove, `GroundTheory.GlobalFields.Adele.Discrete, `GroundTheory.GlobalFields.Adele.Topology, `GroundTheory.GlobalFields.Artin.InflationTower, `GroundTheory.GlobalFields.Artin.Mackey, `GroundTheory.GlobalFields.CompletionAtPlace, `GroundTheory.GlobalFields.ComplexMultiplication.EllipticRational, `GroundTheory.GlobalFields.ComplexMultiplication.EllipticResidues, `GroundTheory.GlobalFields.ComplexMultiplication.IdeleAction, `GroundTheory.GlobalFields.ComplexMultiplication.WeberFunctionAutomorphisms, `GroundTheory.GlobalFields.CyclotomicCharacters.ProfinitePadic, `GroundTheory.GlobalFields.ExistenceTheorem.PowerIndex, `GroundTheory.GlobalFields.HerbrandQuotients.CycTateNegOneOrbitEquivSymmMk, `GroundTheory.GlobalFields.HerbrandQuotients.Lattice, `GroundTheory.GlobalFields.HerbrandQuotients.Permutation, `GroundTheory.GlobalFields.HerbrandQuotients.SUnitsExact, `GroundTheory.GlobalFields.IdeleGroups.SIdeleGroups, `GroundTheory.GlobalFields.IdeleGroups.StandardOpenEquiv, `GroundTheory.GlobalFields.InfiniteNormIndex.LocalSymbol, `GroundTheory.GlobalFields.KummerTheory.LocalIndexAtPlace, `GroundTheory.GlobalFields.SemilocalAlgebras.Finite, `GroundTheory.GlobalFields.SemilocalAlgebras.InfiniteAdeleTopology, `GroundTheory.GlobalFields.TateThesis.AdelicChar, `GroundTheory.GlobalFields.TateThesis.ArchCharsUnitary, `GroundTheory.GlobalFields.TateThesis.Conductor, `GroundTheory.GlobalFields.TateThesis.GaussianComplexFourier, `GroundTheory.GlobalFields.TateThesis.TraceFourier, `GroundTheory.HeightsAndTheta.Heights.AnalyticLimit.PGreenMassReplaceLevi, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ChowDegree, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.ContinuousHermNormGroup, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.GaussSum, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LogIntPoly, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.MahlerSectionBasic, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PAreaMultiplicityWeight, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PBaseChangeAvoid, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChartGramMA, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PChowFormExtend, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PConeLogBound, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PMinimalPrimeComap, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PProjPrimeHasPoint, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PQuasiFiniteSheets, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PRadicalBaseChange, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.PSectionLengthSum, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.SphereMeanDisc, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChowFormDim, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsChowFormSectionPerfect, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsClosedPointChartField, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsClosedPointConeCoord, `GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.StatementsConeMapArea]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

