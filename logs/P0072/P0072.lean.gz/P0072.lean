import Lean
import Formalism.LocalToGlobal.SiegelLatticeTheory.FlagStabilizerTensors.RootLatticeThresholds.RankUpdateMul
import Formalism.LocalToGlobal.SiegelLatticeTheory.FlagStabilizerTensors.RootLatticeThresholds.TensInt
import Formalism.LocalToGlobal.SiegelLatticeTheory.FlagStabilizerTensors.RootLatticeThresholds.ZeroOfBlk
import Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.FoldBound
import Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.UnitaryHaarProducts.LatExistsDefs
import Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.UnitaryHaarProducts.UnipLat
import Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.UnitaryHaarProducts.UnipTool
import Formalism.LocalToGlobal.SiegelLatticeTheory.SiegelMassRatios.DensExact
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsLower
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.LimitMemLpAndIntegralEq
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.PsiTrCoreApprox
import Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.PsiTrCoreTrace
import Formalism.LocalToGlobal.TorsionIntegrality.CMGoodModels.Statement
import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.SemiChar
import Formalism.LocalToGlobal.TorsionIntegrality.GaussianEigenFrames.StatementG
import Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.HasSecondLogDeriv
import Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.IsUnitaryK
import Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.LocAbs
import Formalism.LocalToGlobal.TorsionIntegrality.WeierstrassTwoTorsion.StatementF
import Formalism.LogFactorialBounds.DepthIIExponent
import Formalism.LogFactorialBounds.LocalFactorSplit
import Formalism.LogFactorialBounds.LogFactorialSandwich
import Formalism.LogFactorialIndices.StatementIdx
import Formalism.LogFactorialIndices.StatementNorm
import Formalism.LogFactorialIndices.StatementSize
import Formalism.LogSumExpBounds.StatementC
import Formalism.LogSumExpBounds.StatementD
import Formalism.LogSumExpBounds.StatementE
import Formalism.LogSumExpBounds.StatementZ
import Formalism.LogVandermondeBounds.EvenOddPowerQuotientEqualityCases
import Formalism.LogVandermondeBounds.FinrankFiberSumZero
import Formalism.LogVandermondeBounds.LogRatioLowerBound
import Formalism.LogVandermondeBounds.LogVandermondeProofs.LengthQuotientLeOfLatticeSandwich
import Formalism.LogVandermondeBounds.LogVandermondeVariationUnbounded
import Formalism.LogVandermondeBounds.MultinomialPowerBound
import Formalism.MahlerMeasure.LevelSum
import Formalism.MahlerMeasure.Statement
import Formalism.MeanHeightDescent.BadRowsNumeric
import Formalism.NormUnitaryBounds.Statement
import Formalism.PadicSubsetSums.CentralIdempotents.IsConstituent
import Formalism.PadicSubsetSums.CentralIdempotents.PrimitiveRootFifteenSubOneUnit
import Formalism.PadicSubsetSums.CentralIdempotents.ResidueAvoidanceOfPrimes
import Formalism.PadicSubsetSums.CentralIdempotents.WindowSums
import Formalism.PairingDivisors.StatementN
import Formalism.PeriodIntegrals.AdCpctDen
import Formalism.PeriodIntegrals.AddIntG
import Formalism.PeriodIntegrals.ArtSch
import Formalism.PeriodIntegrals.BeConjNorm
import Formalism.PeriodIntegrals.BeDiagZp
import Formalism.PeriodIntegrals.BiaddOfCube
import Formalism.PeriodIntegrals.BiaddZpLin
import Formalism.PeriodIntegrals.BlockRatReal
import Formalism.PeriodIntegrals.CMTraceOnto
import Formalism.PeriodIntegrals.CharExtend
import Formalism.PeriodIntegrals.CharIdem
import Formalism.PeriodIntegrals.Chebyshev
import Formalism.PeriodIntegrals.ChiExCM
import Formalism.PeriodIntegrals.ClassNumImQ
import Formalism.PeriodIntegrals.CubicExponentialFactor
import Formalism.PeriodIntegrals.CuspInfChar
import Formalism.PeriodIntegrals.DepthLegendre
import Formalism.PeriodIntegrals.DetIdPG
import Formalism.PeriodIntegrals.DiagRank
import Formalism.PeriodIntegrals.DiffGenLoc

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.LocalToGlobal.SiegelLatticeTheory.FlagStabilizerTensors.RootLatticeThresholds.RankUpdateMul, `Formalism.LocalToGlobal.SiegelLatticeTheory.FlagStabilizerTensors.RootLatticeThresholds.TensInt, `Formalism.LocalToGlobal.SiegelLatticeTheory.FlagStabilizerTensors.RootLatticeThresholds.ZeroOfBlk, `Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.FoldBound, `Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.UnitaryHaarProducts.LatExistsDefs, `Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.UnitaryHaarProducts.UnipLat, `Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.UnitaryHaarProducts.UnipTool, `Formalism.LocalToGlobal.SiegelLatticeTheory.SiegelMassRatios.DensExact, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.EnergyAbsLower, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.LimitMemLpAndIntegralEq, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.PsiTrCoreApprox, `Formalism.LocalToGlobal.SiegelLatticeTheory.TraceIntegralEstimates.PsiTrCoreTrace, `Formalism.LocalToGlobal.TorsionIntegrality.CMGoodModels.Statement, `Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.SemiChar, `Formalism.LocalToGlobal.TorsionIntegrality.GaussianEigenFrames.StatementG, `Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.HasSecondLogDeriv, `Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.IsUnitaryK, `Formalism.LocalToGlobal.TorsionIntegrality.UniformGaussModels.OrthogonalGaussModels.HermitianBlockFrames.LocAbs, `Formalism.LocalToGlobal.TorsionIntegrality.WeierstrassTwoTorsion.StatementF, `Formalism.LogFactorialBounds.DepthIIExponent, `Formalism.LogFactorialBounds.LocalFactorSplit, `Formalism.LogFactorialBounds.LogFactorialSandwich, `Formalism.LogFactorialIndices.StatementIdx, `Formalism.LogFactorialIndices.StatementNorm, `Formalism.LogFactorialIndices.StatementSize, `Formalism.LogSumExpBounds.StatementC, `Formalism.LogSumExpBounds.StatementD, `Formalism.LogSumExpBounds.StatementE, `Formalism.LogSumExpBounds.StatementZ, `Formalism.LogVandermondeBounds.EvenOddPowerQuotientEqualityCases, `Formalism.LogVandermondeBounds.FinrankFiberSumZero, `Formalism.LogVandermondeBounds.LogRatioLowerBound, `Formalism.LogVandermondeBounds.LogVandermondeProofs.LengthQuotientLeOfLatticeSandwich, `Formalism.LogVandermondeBounds.LogVandermondeVariationUnbounded, `Formalism.LogVandermondeBounds.MultinomialPowerBound, `Formalism.MahlerMeasure.LevelSum, `Formalism.MahlerMeasure.Statement, `Formalism.MeanHeightDescent.BadRowsNumeric, `Formalism.NormUnitaryBounds.Statement, `Formalism.PadicSubsetSums.CentralIdempotents.IsConstituent, `Formalism.PadicSubsetSums.CentralIdempotents.PrimitiveRootFifteenSubOneUnit, `Formalism.PadicSubsetSums.CentralIdempotents.ResidueAvoidanceOfPrimes, `Formalism.PadicSubsetSums.CentralIdempotents.WindowSums, `Formalism.PairingDivisors.StatementN, `Formalism.PeriodIntegrals.AdCpctDen, `Formalism.PeriodIntegrals.AddIntG, `Formalism.PeriodIntegrals.ArtSch, `Formalism.PeriodIntegrals.BeConjNorm, `Formalism.PeriodIntegrals.BeDiagZp, `Formalism.PeriodIntegrals.BiaddOfCube, `Formalism.PeriodIntegrals.BiaddZpLin, `Formalism.PeriodIntegrals.BlockRatReal, `Formalism.PeriodIntegrals.CMTraceOnto, `Formalism.PeriodIntegrals.CharExtend, `Formalism.PeriodIntegrals.CharIdem, `Formalism.PeriodIntegrals.Chebyshev, `Formalism.PeriodIntegrals.ChiExCM, `Formalism.PeriodIntegrals.ClassNumImQ, `Formalism.PeriodIntegrals.CubicExponentialFactor, `Formalism.PeriodIntegrals.CuspInfChar, `Formalism.PeriodIntegrals.DepthLegendre, `Formalism.PeriodIntegrals.DetIdPG, `Formalism.PeriodIntegrals.DiagRank, `Formalism.PeriodIntegrals.DiffGenLoc]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

