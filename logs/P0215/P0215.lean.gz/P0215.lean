import Lean
import Formalism.MahlerMeasure.IsIntegral
import Formalism.MahlerMeasure.MahlerMeasureProofs.Mahler
import Formalism.MahlerMeasure.StatementD
import Formalism.MahlerMeasure.TieVars
import Formalism.MeanHeightDescent.AverageDegreeBounds.CombinedAverageDegreeBoundOf
import Formalism.MoebiusJetDuality.Statement
import Formalism.MonomialMeanResidues.MonomialMean
import Formalism.NormUnitaryBounds.DetPolynomialWeights.GaussianCoefficientFactorialBound
import Formalism.NormUnitaryBounds.DetPolynomialWeights.LtSuccOfMemWeightCompositions
import Formalism.NormUnitaryBounds.DetPolynomialWeights.ShearHypothesisOneHolds
import Formalism.PadicSubsetSums.CentralIdempotents.CentralIdempotentIntegral
import Formalism.PadicSubsetSums.CentralIdempotents.EigenbasisOfDistinctRoots
import Formalism.PadicSubsetSums.CentralIdempotents.GL2UnipotentBruhatDecomposition
import Formalism.PadicSubsetSums.CentralIdempotents.HCDisjointO
import Formalism.PadicSubsetSums.CentralIdempotents.SchurOrthogonalityCompact
import Formalism.PadicSubsetSums.StableGradedCounts.IRRBBDivides
import Formalism.PadicSubsetSums.StableGradedCounts.IRRCentralIdemSelfAdjoint
import Formalism.PadicSubsetSums.StableGradedCounts.IRRCentralIdempotent
import Formalism.PadicSubsetSums.StableGradedCounts.IRRCycleProbPrime
import Formalism.PadicSubsetSums.StableGradedCounts.IRRCycleTypeProb
import Formalism.PadicSubsetSums.StableGradedCounts.IRRDivisorDegreeSubSum
import Formalism.PadicSubsetSums.StableGradedCounts.IRRFrobOrbitIrred
import Formalism.PadicSubsetSums.StableGradedCounts.IRRGoodDualStable
import Formalism.PadicSubsetSums.StableGradedCounts.IRRIrredCountUpper
import Formalism.PadicSubsetSums.StableGradedCounts.IRRJoints
import Formalism.PadicSubsetSums.StableGradedCounts.IRRLemmaLWeight
import Formalism.PadicSubsetSums.StableGradedCounts.IRRLemmaP
import Formalism.PadicSubsetSums.StableGradedCounts.IRRPrimeRecipSum
import Formalism.PadicSubsetSums.StableGradedCounts.IRRPrimeToPartSpec
import Formalism.PadicSubsetSums.StableGradedCounts.LagrangeBound
import Formalism.PadicSubsetSums.StableGradedCounts.ZBrauerNesbitt
import Formalism.PeriodIntegrals.AdelicOrbitU
import Formalism.PeriodIntegrals.BesselDeriv
import Formalism.PeriodIntegrals.BesselLevi
import Formalism.PeriodIntegrals.FdegScale
import Formalism.PeriodIntegrals.FockDegreeTwoParts
import Formalism.PeriodIntegrals.FoldDCUnfold
import Formalism.PeriodIntegrals.FoldMult
import Formalism.PeriodIntegrals.FoldUnfold
import Formalism.PeriodIntegrals.GoodLatCM
import Formalism.PeriodIntegrals.LevelProdIdx
import Formalism.PeriodIntegrals.LocJacOrd
import Formalism.PeriodIntegrals.LocJacTyp
import Formalism.PeriodIntegrals.LowCyc
import Formalism.PeriodIntegrals.NormPullG
import Formalism.PeriodIntegrals.NormTransG
import Formalism.PeriodIntegrals.OmFibreUniq
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ASGlue
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ASRoot
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ASSmall
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ASWitt
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.AdCpctDen
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.BiaddOfCube
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.CMTraceOnto
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.CharExtend
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DiagRank
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DiffGenLoc
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DvRatKer
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.EmbPerm
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.EmbTraceSum
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FinOrdRedOne
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.GelfConv
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.GeoProdPow
import Formalism.PeriodIntegrals.OrbitalBoundsConclusion.GramIso

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.MahlerMeasure.IsIntegral, `Formalism.MahlerMeasure.MahlerMeasureProofs.Mahler, `Formalism.MahlerMeasure.StatementD, `Formalism.MahlerMeasure.TieVars, `Formalism.MeanHeightDescent.AverageDegreeBounds.CombinedAverageDegreeBoundOf, `Formalism.MoebiusJetDuality.Statement, `Formalism.MonomialMeanResidues.MonomialMean, `Formalism.NormUnitaryBounds.DetPolynomialWeights.GaussianCoefficientFactorialBound, `Formalism.NormUnitaryBounds.DetPolynomialWeights.LtSuccOfMemWeightCompositions, `Formalism.NormUnitaryBounds.DetPolynomialWeights.ShearHypothesisOneHolds, `Formalism.PadicSubsetSums.CentralIdempotents.CentralIdempotentIntegral, `Formalism.PadicSubsetSums.CentralIdempotents.EigenbasisOfDistinctRoots, `Formalism.PadicSubsetSums.CentralIdempotents.GL2UnipotentBruhatDecomposition, `Formalism.PadicSubsetSums.CentralIdempotents.HCDisjointO, `Formalism.PadicSubsetSums.CentralIdempotents.SchurOrthogonalityCompact, `Formalism.PadicSubsetSums.StableGradedCounts.IRRBBDivides, `Formalism.PadicSubsetSums.StableGradedCounts.IRRCentralIdemSelfAdjoint, `Formalism.PadicSubsetSums.StableGradedCounts.IRRCentralIdempotent, `Formalism.PadicSubsetSums.StableGradedCounts.IRRCycleProbPrime, `Formalism.PadicSubsetSums.StableGradedCounts.IRRCycleTypeProb, `Formalism.PadicSubsetSums.StableGradedCounts.IRRDivisorDegreeSubSum, `Formalism.PadicSubsetSums.StableGradedCounts.IRRFrobOrbitIrred, `Formalism.PadicSubsetSums.StableGradedCounts.IRRGoodDualStable, `Formalism.PadicSubsetSums.StableGradedCounts.IRRIrredCountUpper, `Formalism.PadicSubsetSums.StableGradedCounts.IRRJoints, `Formalism.PadicSubsetSums.StableGradedCounts.IRRLemmaLWeight, `Formalism.PadicSubsetSums.StableGradedCounts.IRRLemmaP, `Formalism.PadicSubsetSums.StableGradedCounts.IRRPrimeRecipSum, `Formalism.PadicSubsetSums.StableGradedCounts.IRRPrimeToPartSpec, `Formalism.PadicSubsetSums.StableGradedCounts.LagrangeBound, `Formalism.PadicSubsetSums.StableGradedCounts.ZBrauerNesbitt, `Formalism.PeriodIntegrals.AdelicOrbitU, `Formalism.PeriodIntegrals.BesselDeriv, `Formalism.PeriodIntegrals.BesselLevi, `Formalism.PeriodIntegrals.FdegScale, `Formalism.PeriodIntegrals.FockDegreeTwoParts, `Formalism.PeriodIntegrals.FoldDCUnfold, `Formalism.PeriodIntegrals.FoldMult, `Formalism.PeriodIntegrals.FoldUnfold, `Formalism.PeriodIntegrals.GoodLatCM, `Formalism.PeriodIntegrals.LevelProdIdx, `Formalism.PeriodIntegrals.LocJacOrd, `Formalism.PeriodIntegrals.LocJacTyp, `Formalism.PeriodIntegrals.LowCyc, `Formalism.PeriodIntegrals.NormPullG, `Formalism.PeriodIntegrals.NormTransG, `Formalism.PeriodIntegrals.OmFibreUniq, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ASGlue, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ASRoot, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ASSmall, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.ASWitt, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.AdCpctDen, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.BiaddOfCube, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.CMTraceOnto, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.CharExtend, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DiagRank, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DiffGenLoc, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.DvRatKer, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.EmbPerm, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.EmbTraceSum, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.FinOrdRedOne, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.GelfConv, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.GeoProdPow, `Formalism.PeriodIntegrals.OrbitalBoundsConclusion.GramIso]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

