import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ChernFlatOfQuadraticDerivativeStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ClosureFiniteOverBase
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.CochainEqOfSameDegreeChartMorphism
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.CoeffSumPowMulFactorialStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.CoefficientReductionFirstChernClassTateTwistAltI
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.CohomologyContinuousOnConeOfWhiskerStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.CompactOpenSubgroupExhaustion
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ConjOfCharpolyEqOfCharpolySeparable
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ConjOfCharpolyLocal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ConnFormSmul
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ConnectionFormDegZeroCocycleClosed
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ConnectionMatrixGramOperatorNormLeStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ContinuousRhoApplyStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ContinuousUniMat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ConvEqOneOfForallPairing
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.CoveringsRefineOfCechConervePropertyStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.CurveClassDegreeComputations
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.CutWeightContDiffOnMemIcc
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.CutoffInterpolationAgreesFar
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.CutoffInterpolationUniformLimit
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.CyclicGeneratorsInvariantTopStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DUnitMemRangeOfMemKerIdeal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DbarAddVectorScalar
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DbarEqZeroOfHolomorphic
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DdbarFormInterpolatedHermitian
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DdcBoundaryPotentialEqFormStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DegISupMapRankOneLatticeOfGramStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DetRestrictScalarsTwoSidedMatrixMul
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DeterminantElementProductStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DeterminantLatticePrincipalStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DeterminantOrdersIndependentOfRootStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DeterminantVanishingAtZeroStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DifferentiableOnFourierCoeffFamilyStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DifferentiableOnSummableFourierSeriesStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DilationDifferenceMemSpanStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DualWeylEqBotOfNotAntitone
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DvdOfLeadOrdersEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.DvrDeterminantProductOrders
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.EigenDecompositionTraceMultipleStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.EmbeddingMatrixIndependent
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ErrorFunctionalCoefficientBounded
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.EtaleFaithfullyFlatRingHomBasicPropertiesStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.EventuallyFiniteBaseChangeFilteredColimit
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsAdjoinEqTopPadicInt
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsAffineCombinationSquareZeroLiftsChartStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsAlgHomCompEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsBaseChangeRetract
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsBasePointTwistedHermUnimodularEqSelfDualStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsBasisQuotientLatticeEigenStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsCocycleOfMapToDegreeOneTerm
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsCompactOpenNormClosedBallQuadratic
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsCyclicVectorOfSeparableCharpolyStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsEtaleLiftGenericFibreOfFactorizationStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFilteredColimitFiniteTypeIntRingsStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFiniteClassesModuloInvolutionNorms
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFiniteCoequifiberedSubalgebra
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFiniteDepthTwoHullOfEtalePuncturedSpectrum
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFiniteExtPointLiftOfSurjectiveLocFinTypeStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFinitePresentationModelOfIsColimit
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFinsetEqSumAddCosetIndicator
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFormalBranchesOfSeparableReductionStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFormalGermOpenAffine
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFrobeniusTwistedFrameStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsGLDiagonalCongruentHermitian

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.ChernFlatOfQuadraticDerivativeStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ClosureFiniteOverBase, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.CochainEqOfSameDegreeChartMorphism, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.CoeffSumPowMulFactorialStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.CoefficientReductionFirstChernClassTateTwistAltI, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.CohomologyContinuousOnConeOfWhiskerStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.CompactOpenSubgroupExhaustion, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ConjOfCharpolyEqOfCharpolySeparable, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ConjOfCharpolyLocal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ConnFormSmul, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ConnectionFormDegZeroCocycleClosed, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ConnectionMatrixGramOperatorNormLeStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ContinuousRhoApplyStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ContinuousUniMat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ConvEqOneOfForallPairing, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.CoveringsRefineOfCechConervePropertyStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.CurveClassDegreeComputations, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.CutWeightContDiffOnMemIcc, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.CutoffInterpolationAgreesFar, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.CutoffInterpolationUniformLimit, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.CyclicGeneratorsInvariantTopStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DUnitMemRangeOfMemKerIdeal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DbarAddVectorScalar, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DbarEqZeroOfHolomorphic, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DdbarFormInterpolatedHermitian, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DdcBoundaryPotentialEqFormStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DegISupMapRankOneLatticeOfGramStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DetRestrictScalarsTwoSidedMatrixMul, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DeterminantElementProductStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DeterminantLatticePrincipalStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DeterminantOrdersIndependentOfRootStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DeterminantVanishingAtZeroStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DifferentiableOnFourierCoeffFamilyStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DifferentiableOnSummableFourierSeriesStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DilationDifferenceMemSpanStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DualWeylEqBotOfNotAntitone, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DvdOfLeadOrdersEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.DvrDeterminantProductOrders, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.EigenDecompositionTraceMultipleStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.EmbeddingMatrixIndependent, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ErrorFunctionalCoefficientBounded, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.EtaleFaithfullyFlatRingHomBasicPropertiesStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.EventuallyFiniteBaseChangeFilteredColimit, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsAdjoinEqTopPadicInt, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsAffineCombinationSquareZeroLiftsChartStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsAlgHomCompEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsBaseChangeRetract, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsBasePointTwistedHermUnimodularEqSelfDualStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsBasisQuotientLatticeEigenStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsCocycleOfMapToDegreeOneTerm, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsCompactOpenNormClosedBallQuadratic, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsCyclicVectorOfSeparableCharpolyStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsEtaleLiftGenericFibreOfFactorizationStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFilteredColimitFiniteTypeIntRingsStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFiniteClassesModuloInvolutionNorms, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFiniteCoequifiberedSubalgebra, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFiniteDepthTwoHullOfEtalePuncturedSpectrum, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFiniteExtPointLiftOfSurjectiveLocFinTypeStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFinitePresentationModelOfIsColimit, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFinsetEqSumAddCosetIndicator, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFormalBranchesOfSeparableReductionStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFormalGermOpenAffine, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFrobeniusTwistedFrameStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsGLDiagonalCongruentHermitian]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

