import Lean
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.DominantPartialSumBoundsStatement
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.ExistsFlagDegreeOnePolysStatement
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FiniteNonunitMatrix
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreePowerSumMulZero
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreeSymmetriesStatement
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreeWeightFormulaStatement
import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.PolarizationPolynomialCoeffBoundStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.AlgebraicApproximationCompleteDvr
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.AlgebraicElementHomogRelation
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.BaseChangePointsCompatStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.BtOrderComapHomStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.BtOrderEqTopOfEtaleStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ChartLatticeNormMembership
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.DiscriminantValuationDifferentStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.EigenComponentMapCompatStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsDenominatorRegularStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsProperIntegralModelStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsReversedDualBasis
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsUniqueCentreLocalHomStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsUniqueTangentDualNumberStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FiniteOpenLeClosedFibre
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FinitePointExtendsSectionStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FinrankAdjoinVarsFieldStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenMapStalkMap
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.HomAddMulOfUnitSection
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsFinOpenSubBaseChangeStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsVBOnDualAndBidual
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsVBOneOfChartGenerators
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.KaehlerRankLocalizationBoundStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.KaehlerRankTranscendenceDegreeStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatRestrictComapSpan
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeGlueOverPrimes
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.PlaceEqOneOfNotMem
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrimeChartExistsUniquePointStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrimitiveDerivationPairingStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegAtIffChartLocalizationStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegAtNoetherianModelNoetherianStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularAtTranslateStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularFunctionIffSection
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularLatticeLocalFreeStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SectionEqZeroOfValues
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SncPts
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ValAtCompLocalHomStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ValuativeLiftExistsUniqueStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.WedgeEqSpanOfIsFrameAt
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.DigammaBoundVerticalStrip
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.DigammaLogBoundLeftRegion
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.KaehlerBasisOnLocalizationAway
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.KaehlerBasisSpreadsToNeighbourhood
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.MemIntegralGLIffIntegralUnitDet
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.PrimePowerNotDvdDifferentStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.RealMpData
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.RegularSequenceGermsRegularLocal
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.RelIndexBoxLatticesProduct
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.SmoothLocalRingFreeDifferentials
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.SphericalFunctionInvarianceProperties
import Development.AutomorphicSpectrum.Proofs.HermitianForms.IndicatorInSchrodingerSpan
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.BoundMulTranslate
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.BoxFunMemSB
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.ExistsEqMulApplyZero
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.ExistsSkewOfDiagonal
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.GoodCharIsLocallyConstant
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.NormIteratedFDerivCexpCompLe
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.SchrodingerModelSelfDualLattice

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.DominantPartialSumBoundsStatement, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.ExistsFlagDegreeOnePolysStatement, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FiniteNonunitMatrix, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreePowerSumMulZero, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreeSymmetriesStatement, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.FlagDegreeWeightFormulaStatement, `Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.PolarizationPolynomialCoeffBoundStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.AlgebraicApproximationCompleteDvr, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.AlgebraicElementHomogRelation, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.BaseChangePointsCompatStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.BtOrderComapHomStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.BtOrderEqTopOfEtaleStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ChartLatticeNormMembership, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.DiscriminantValuationDifferentStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.EigenComponentMapCompatStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsDenominatorRegularStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsProperIntegralModelStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsReversedDualBasis, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsUniqueCentreLocalHomStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsUniqueTangentDualNumberStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FiniteOpenLeClosedFibre, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FinitePointExtendsSectionStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FinrankAdjoinVarsFieldStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenMapStalkMap, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.HomAddMulOfUnitSection, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsFinOpenSubBaseChangeStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsVBOnDualAndBidual, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsVBOneOfChartGenerators, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.KaehlerRankLocalizationBoundStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.KaehlerRankTranscendenceDegreeStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatRestrictComapSpan, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LatticeGlueOverPrimes, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.PlaceEqOneOfNotMem, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrimeChartExistsUniquePointStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrimitiveDerivationPairingStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegAtIffChartLocalizationStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegAtNoetherianModelNoetherianStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularAtTranslateStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularFunctionIffSection, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularLatticeLocalFreeStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.SectionEqZeroOfValues, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.SncPts, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ValAtCompLocalHomStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ValuativeLiftExistsUniqueStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.WedgeEqSpanOfIsFrameAt, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.DigammaBoundVerticalStrip, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.DigammaLogBoundLeftRegion, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.KaehlerBasisOnLocalizationAway, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.KaehlerBasisSpreadsToNeighbourhood, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.MemIntegralGLIffIntegralUnitDet, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.PrimePowerNotDvdDifferentStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.RealMpData, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.RegularSequenceGermsRegularLocal, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.RelIndexBoxLatticesProduct, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.SmoothLocalRingFreeDifferentials, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.SphericalFunctionInvarianceProperties, `Development.AutomorphicSpectrum.Proofs.HermitianForms.IndicatorInSchrodingerSpan, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.BoundMulTranslate, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.BoxFunMemSB, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.ExistsEqMulApplyZero, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.ExistsSkewOfDiagonal, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.GoodCharIsLocallyConstant, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.NormIteratedFDerivCexpCompLe, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.SchrodingerModelSelfDualLattice]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

