import Lean
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCharacterBound
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCardYoungCells
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCellOfWordInj
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCellOfWordMem
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCellOfWordMono
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCfAtStair
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCfBound
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCfMonomialPsumOne
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCfUpdateZero
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCfVandermondePsumOne
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombDetDescFactorial
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombExtendWord
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombHookBranch
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombHookCount
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombHookShapeFacts
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombPcntAppend
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombSortLe
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombSortShift
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombSortShiftDistinct
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombStripSum
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombTableauOfWord
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombTableauRowCount
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombTableauRowLattice
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombTableauRowPrefix
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombVandermondeSucc
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombWordOfTableau
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombYoungRowCard
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFrobeniusDimensionFormula
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PHookDimensionSum
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PLemmaC
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PLinearTermValue
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.POtherFactorFormula
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PTotalIdentity
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.SumPderivRealApply
import GroundTheory.HeightsAndTheta.Heights.SemipositiveHeights.FibreIncompTrdeg
import GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.WeightedUnfoldingIntegral
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PChartDomain
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PChowFormHomog
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PNormIdentity
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PParFracIsFractionRing
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PResidueAlgIndep
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSpecCompDim
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSpecLength
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSpecMax
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSpecResidue
import GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.StatementsChowNorm
import GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.DedekindZetaEqSumRealEisenstein
import GroundTheory.LocalFields.AbstractLocalReciprocity.Frobenius
import GroundTheory.LocalFields.AbstractLocalReciprocity.Unramified
import GroundTheory.LocalFields.BrauerInductionLocal
import GroundTheory.LocalFields.FormalGroups.LubinTate
import GroundTheory.LocalFields.HerbrandLocalBase
import GroundTheory.LocalFields.LocalAxiomDictionary
import GroundTheory.LocalFields.Monogenic
import GroundTheory.LocalFields.PadicLogHom
import GroundTheory.LocalFields.RamificationUnits
import GroundTheory.LocalFields.SeparableClosureValuation
import GroundTheory.LocalFields.UnramifiedGalois
import GroundTheory.LocalFields.UnramifiedHensel
import GroundTheory.LocalFields.UnramifiedNormSurj
import GroundTheory.PAdicHodge.DMTeichBasic
import GroundTheory.PAdicHodge.ExtRobbaComplete
import GroundTheory.PAdicHodge.ExtRobbaDMLinear
import GroundTheory.PAdicHodge.ExtRobbaFixedUnif

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCharacterBound, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCardYoungCells, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCellOfWordInj, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCellOfWordMem, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCellOfWordMono, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCfAtStair, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCfBound, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCfMonomialPsumOne, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCfUpdateZero, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombCfVandermondePsumOne, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombDetDescFactorial, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombExtendWord, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombHookBranch, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombHookCount, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombHookShapeFacts, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombPcntAppend, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombSortLe, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombSortShift, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombSortShiftDistinct, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombStripSum, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombTableauOfWord, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombTableauRowCount, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombTableauRowLattice, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombTableauRowPrefix, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombVandermondeSucc, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombWordOfTableau, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PCombYoungRowCard, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFrobeniusDimensionFormula, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PHookDimensionSum, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PLemmaC, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PLinearTermValue, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.POtherFactorFormula, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PTotalIdentity, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.SumPderivRealApply, `GroundTheory.HeightsAndTheta.Heights.SemipositiveHeights.FibreIncompTrdeg, `GroundTheory.HeightsAndTheta.Heights.StabilizerCovolume.WeightedUnfoldingIntegral, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PChartDomain, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PChowFormHomog, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PNormIdentity, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PParFracIsFractionRing, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PResidueAlgIndep, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSpecCompDim, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSpecLength, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSpecMax, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.PSpecResidue, `GroundTheory.HeightsAndTheta.Heights.VerticalDivisors.StatementsChowNorm, `GroundTheory.HeightsAndTheta.Theta.EisensteinZeta.MirabolicInduction.DedekindZetaEqSumRealEisenstein, `GroundTheory.LocalFields.AbstractLocalReciprocity.Frobenius, `GroundTheory.LocalFields.AbstractLocalReciprocity.Unramified, `GroundTheory.LocalFields.BrauerInductionLocal, `GroundTheory.LocalFields.FormalGroups.LubinTate, `GroundTheory.LocalFields.HerbrandLocalBase, `GroundTheory.LocalFields.LocalAxiomDictionary, `GroundTheory.LocalFields.Monogenic, `GroundTheory.LocalFields.PadicLogHom, `GroundTheory.LocalFields.RamificationUnits, `GroundTheory.LocalFields.SeparableClosureValuation, `GroundTheory.LocalFields.UnramifiedGalois, `GroundTheory.LocalFields.UnramifiedHensel, `GroundTheory.LocalFields.UnramifiedNormSurj, `GroundTheory.PAdicHodge.DMTeichBasic, `GroundTheory.PAdicHodge.ExtRobbaComplete, `GroundTheory.PAdicHodge.ExtRobbaDMLinear, `GroundTheory.PAdicHodge.ExtRobbaFixedUnif]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

