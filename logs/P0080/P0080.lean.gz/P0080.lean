import Lean
import Formalism.UnipotentAdelicQuotients.SWXSDefs
import Formalism.UnipotentAdelicQuotients.SiegelSetsSL2Adelic
import Formalism.UnipotentAdelicQuotients.SmComplete
import Formalism.UnipotentAdelicQuotients.StdAdditiveCharExists
import Formalism.UnipotentAdelicQuotients.ThmBInHecke
import Formalism.UnipotentAdelicQuotients.ThmBInSatake
import Formalism.UnipotentAdelicQuotients.WeylLatDual
import Formalism.WachLatticeTwists.HodgeTateChains.Statement
import Formalism.WachModuleLifts.Statement
import Formalism.WachModuleLifts.StatementW
import Formalism.WeightedDeltaMeans.LowerBoundLinearPower
import Formalism.WindowSums.Statement
import Formalism.YangianSpanCharacter.StatementE
import Formalism.YangianSpanCharacter.StatementT
import Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.NormCpowSubLePoint
import GroundTheory.ArithmeticGeometry.AbelianVarieties.CompleteIntegralClosure
import GroundTheory.ArithmeticGeometry.AbelianVarieties.NormEDS
import GroundTheory.ArithmeticGeometry.EtaleCompletion.ArtinApproximationData
import GroundTheory.ArithmeticGeometry.EtaleCompletion.ModulesPullback
import GroundTheory.ArithmeticGeometry.IwasawaModules.SpanFinrankMaximalIdealLeTwo
import GroundTheory.ArithmeticGeometry.ModularCurves.WeierstrassCharts
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ConsCompSuccAboveZero
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ModulesTensor
import GroundTheory.ArithmeticGeometry.SchemeCohomology.OverShriek
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProjTwist
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.FormalAlgebra
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.FormalLimit
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.HasExtInstances
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.PullbackGamma
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.ReesSubmodule
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.RestrictIso
import GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.SchemeImage
import GroundTheory.ArithmeticGeometry.SchemeCohomology.RegularLocalDomain
import GroundTheory.ArithmeticGeometry.SchemeCohomology.SheafH
import GroundTheory.ArithmeticGeometry.SchemeCohomology.WeilDivisor
import GroundTheory.ArithmeticGeometry.ToricVarieties.ExistsDualNegOfNotMemHullFinset
import GroundTheory.ArithmeticGeometry.ToricVarieties.KrullDomain
import GroundTheory.AutomorphicForms.AnisotropicRestrict
import GroundTheory.AutomorphicForms.ArchimedeanWhittaker.WronskianEqZeroOfModerate
import GroundTheory.AutomorphicForms.CompactSelfAdjoint
import GroundTheory.AutomorphicForms.ContragredientTranspose.MatrixSimilarity
import GroundTheory.AutomorphicForms.CuspidalDiscreteness.AltSum
import GroundTheory.AutomorphicForms.CuspidalProjection.Unfold
import GroundTheory.AutomorphicForms.DefiniteClassNumber.Reduction
import GroundTheory.AutomorphicForms.DixmierMalliavinLineKernel
import GroundTheory.AutomorphicForms.DixmierMalliavinLineLimit
import GroundTheory.AutomorphicForms.FinePartition
import GroundTheory.AutomorphicForms.FiniteBruhat
import GroundTheory.AutomorphicForms.FiniteLengthLattice
import GroundTheory.AutomorphicForms.GKModules.ParametricIntegral
import GroundTheory.AutomorphicForms.GL2.GJGlobalEntire
import GroundTheory.AutomorphicForms.GL2.GJGlobalRank
import GroundTheory.AutomorphicForms.GL2.GJGlobalUnfoldCount
import GroundTheory.AutomorphicForms.GL2.GJLaurentIdeal
import GroundTheory.AutomorphicForms.GL2Classical.Iwasawa
import GroundTheory.AutomorphicForms.GL2Classical.Periodic
import GroundTheory.AutomorphicForms.GL2Classical.UnitaryEigenSpan
import GroundTheory.AutomorphicForms.GL2Classical.WeightOperators
import GroundTheory.AutomorphicForms.GeometricLemmaAverage
import GroundTheory.AutomorphicForms.GeometricLemmaOrbit
import GroundTheory.AutomorphicForms.HaarSK
import GroundTheory.AutomorphicForms.HarishChandraCentre.FischerForm
import GroundTheory.AutomorphicForms.HarishChandraCentre.MemCenterOfCommuteE
import GroundTheory.AutomorphicForms.HarishChandraCentre.RepBase

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.UnipotentAdelicQuotients.SWXSDefs, `Formalism.UnipotentAdelicQuotients.SiegelSetsSL2Adelic, `Formalism.UnipotentAdelicQuotients.SmComplete, `Formalism.UnipotentAdelicQuotients.StdAdditiveCharExists, `Formalism.UnipotentAdelicQuotients.ThmBInHecke, `Formalism.UnipotentAdelicQuotients.ThmBInSatake, `Formalism.UnipotentAdelicQuotients.WeylLatDual, `Formalism.WachLatticeTwists.HodgeTateChains.Statement, `Formalism.WachModuleLifts.Statement, `Formalism.WachModuleLifts.StatementW, `Formalism.WeightedDeltaMeans.LowerBoundLinearPower, `Formalism.WindowSums.Statement, `Formalism.YangianSpanCharacter.StatementE, `Formalism.YangianSpanCharacter.StatementT, `Formalism.ZeroFreeRegion.ZetaLogDerivativeBounds.NormCpowSubLePoint, `GroundTheory.ArithmeticGeometry.AbelianVarieties.CompleteIntegralClosure, `GroundTheory.ArithmeticGeometry.AbelianVarieties.NormEDS, `GroundTheory.ArithmeticGeometry.EtaleCompletion.ArtinApproximationData, `GroundTheory.ArithmeticGeometry.EtaleCompletion.ModulesPullback, `GroundTheory.ArithmeticGeometry.IwasawaModules.SpanFinrankMaximalIdealLeTwo, `GroundTheory.ArithmeticGeometry.ModularCurves.WeierstrassCharts, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ConsCompSuccAboveZero, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ModulesTensor, `GroundTheory.ArithmeticGeometry.SchemeCohomology.OverShriek, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProjTwist, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.FormalAlgebra, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.FormalLimit, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.HasExtInstances, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.PullbackGamma, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.ReesSubmodule, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.RestrictIso, `GroundTheory.ArithmeticGeometry.SchemeCohomology.ProperCohomology.SchemeImage, `GroundTheory.ArithmeticGeometry.SchemeCohomology.RegularLocalDomain, `GroundTheory.ArithmeticGeometry.SchemeCohomology.SheafH, `GroundTheory.ArithmeticGeometry.SchemeCohomology.WeilDivisor, `GroundTheory.ArithmeticGeometry.ToricVarieties.ExistsDualNegOfNotMemHullFinset, `GroundTheory.ArithmeticGeometry.ToricVarieties.KrullDomain, `GroundTheory.AutomorphicForms.AnisotropicRestrict, `GroundTheory.AutomorphicForms.ArchimedeanWhittaker.WronskianEqZeroOfModerate, `GroundTheory.AutomorphicForms.CompactSelfAdjoint, `GroundTheory.AutomorphicForms.ContragredientTranspose.MatrixSimilarity, `GroundTheory.AutomorphicForms.CuspidalDiscreteness.AltSum, `GroundTheory.AutomorphicForms.CuspidalProjection.Unfold, `GroundTheory.AutomorphicForms.DefiniteClassNumber.Reduction, `GroundTheory.AutomorphicForms.DixmierMalliavinLineKernel, `GroundTheory.AutomorphicForms.DixmierMalliavinLineLimit, `GroundTheory.AutomorphicForms.FinePartition, `GroundTheory.AutomorphicForms.FiniteBruhat, `GroundTheory.AutomorphicForms.FiniteLengthLattice, `GroundTheory.AutomorphicForms.GKModules.ParametricIntegral, `GroundTheory.AutomorphicForms.GL2.GJGlobalEntire, `GroundTheory.AutomorphicForms.GL2.GJGlobalRank, `GroundTheory.AutomorphicForms.GL2.GJGlobalUnfoldCount, `GroundTheory.AutomorphicForms.GL2.GJLaurentIdeal, `GroundTheory.AutomorphicForms.GL2Classical.Iwasawa, `GroundTheory.AutomorphicForms.GL2Classical.Periodic, `GroundTheory.AutomorphicForms.GL2Classical.UnitaryEigenSpan, `GroundTheory.AutomorphicForms.GL2Classical.WeightOperators, `GroundTheory.AutomorphicForms.GeometricLemmaAverage, `GroundTheory.AutomorphicForms.GeometricLemmaOrbit, `GroundTheory.AutomorphicForms.HaarSK, `GroundTheory.AutomorphicForms.HarishChandraCentre.FischerForm, `GroundTheory.AutomorphicForms.HarishChandraCentre.MemCenterOfCommuteE, `GroundTheory.AutomorphicForms.HarishChandraCentre.RepBase]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

