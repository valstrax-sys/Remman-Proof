import Lean
import GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.StatementsEnd
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PLatticeImageZLattice
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PNumberFieldBoxCount
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsDivPushMultComplex
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsFnDegRelDeg
import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsInvertibleIndexMulSteps
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.CoeffRenameProdCongrRight
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.IsPowerSumDecompositionHomogeneousComponent
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.OfHookCharacterSumIdentity
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagAltCoeffInjective
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagAltTopDegree
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagAntisymDecomposition
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagAntisymHomogeneous
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagCoeffBlockPermute
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagDiffNotDvd
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagDiffPrime
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagDividedDifferencePoly
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagHomogeneousComponentMul
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagInjSumBound
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralAntisymmetrize
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralKillsPowerSums
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralPermute
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralTopComponent
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralTopDegree
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralVandermondeMul
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralVandermondePos
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralViaQuotient
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagPowerSumPreimage
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagPowerSumSymmetric
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagProdPrimesDvd
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagQuotientHomogeneous
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagRestrictConstantCoeff
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagRestrictDecomposition
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagRestrictHomogeneous
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagRestrictPowerSum
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagRestrictSymmetric
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagStaircaseOrbit
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagSwapDivisible
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagSymmetricMulAntisym
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagVandermondeDvd
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagVandermondeHomogeneous
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFrobeniusCharacterFormula
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PHookTableauCount
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PIntegralIsDividedDifference
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PLemmaA
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PLemmaB
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestBoundOfPrimeBound
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestTermWellDefined
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSameFactorFormula
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchAevalSignedRename
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchAltPartitionExpansion
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchAlternantHomogeneous
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchAlternantRenamePlace
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchAntisymmetrizePlace
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchBlockVandermondeOne
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchCompleteAtRootsOfUnity
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchCompleteGenerating
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchConcatAlternant
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchConcatAlternantZero
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchConcatExponent
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchEvalPowerSumHom
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchHookResidues
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchJTMatrixDetAtRoots
import GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchNonHookResidues

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.HeightsAndTheta.Heights.MultinomialWeights.StatementsEnd, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PLatticeImageZLattice, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PNumberFieldBoxCount, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsDivPushMultComplex, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsFnDegRelDeg, `GroundTheory.HeightsAndTheta.Heights.OrbitLimits.StatementsInvertibleIndexMulSteps, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.CoeffRenameProdCongrRight, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.IsPowerSumDecompositionHomogeneousComponent, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.OfHookCharacterSumIdentity, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagAltCoeffInjective, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagAltTopDegree, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagAntisymDecomposition, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagAntisymHomogeneous, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagCoeffBlockPermute, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagDiffNotDvd, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagDiffPrime, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagDividedDifferencePoly, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagHomogeneousComponentMul, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagInjSumBound, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralAntisymmetrize, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralKillsPowerSums, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralPermute, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralTopComponent, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralTopDegree, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralVandermondeMul, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralVandermondePos, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagIntegralViaQuotient, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagPowerSumPreimage, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagPowerSumSymmetric, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagProdPrimesDvd, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagQuotientHomogeneous, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagRestrictConstantCoeff, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagRestrictDecomposition, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagRestrictHomogeneous, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagRestrictPowerSum, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagRestrictSymmetric, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagStaircaseOrbit, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagSwapDivisible, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagSymmetricMulAntisym, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagVandermondeDvd, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFlagVandermondeHomogeneous, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PFrobeniusCharacterFormula, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PHookTableauCount, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PIntegralIsDividedDifference, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PLemmaA, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PLemmaB, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestBoundOfPrimeBound, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PRestTermWellDefined, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSameFactorFormula, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchAevalSignedRename, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchAltPartitionExpansion, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchAlternantHomogeneous, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchAlternantRenamePlace, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchAntisymmetrizePlace, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchBlockVandermondeOne, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchCompleteAtRootsOfUnity, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchCompleteGenerating, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchConcatAlternant, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchConcatAlternantZero, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchConcatExponent, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchEvalPowerSumHom, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchHookResidues, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchJTMatrixDetAtRoots, `GroundTheory.HeightsAndTheta.Heights.RemainderTerms.PSchNonHookResidues]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

