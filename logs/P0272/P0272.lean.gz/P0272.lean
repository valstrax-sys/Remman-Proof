import Lean
import Formalism.GaloisIrreducibility.NoSolvableTransitive
import Formalism.GaussJetBounds.GaussJetProofs.CapacityLeReachCapacity
import Formalism.GaussJetBounds.GaussJetProofs.ExistsNeZeroOfFinsumNeZero
import Formalism.GaussJetBounds.GaussJetProofs.MinorProductSupportTop
import Formalism.GaussJetBounds.GaussJetProofs.NormDetLeOneOfEntries
import Formalism.GaussJetBounds.GaussJetProofs.OneLetterRadiusIdentity
import Formalism.GaussJetBounds.GaussJetProofs.Special
import Formalism.GaussJetBounds.GaussJetProofs.SubstitutionWeightBound
import Formalism.GaussJetBounds.OneLetterGaussJets.StatementA
import Formalism.GaussJetBounds.OneLetterGaussJets.StatementN
import Formalism.GaussJetBounds.StatementE
import Formalism.GaussJetBounds.StatementO
import Formalism.GaussValuationBounds.GaussValueContraction.GaussBasic
import Formalism.GaussValuationBounds.GaussValueContraction.GaussMul
import Formalism.GaussValuationBounds.GaussValueContraction.LemmaCVal
import Formalism.GaussValuationBounds.GaussValueContraction.ScaledPowMemSpanCeil
import Formalism.GelfandTransference.HadamardGelfand.Hadamard
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.DomPow
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockHerm
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockWeightOrth
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LBidetLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LBidetdomLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LFockbLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LFocksLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LHwrowLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LNondomLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LRowdivLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LRowstLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.LSatLemmas
import Formalism.GradedWeylDivisibility.FockSpaceTableaux.RowNuSum
import Formalism.GradedWeylDivisibility.StatementB
import Formalism.GradedWeylDivisibility.StatementC
import Formalism.GrowthSums.FactorialBaseGrowth.LogCoef
import Formalism.GrowthSums.FactorialBaseGrowth.PathBasisOfCount
import Formalism.GrowthSums.StatementB
import Formalism.HarderNarasimhan.HarderNarasimhanProofs.FinSup
import Formalism.HermitianCurvature.HermitianCurvatureProofs.AdicNeighbourhood
import Formalism.HermitianCurvature.HermitianCurvatureProofs.AveragedKernelSums
import Formalism.HermitianCurvature.HermitianCurvatureProofs.AveragedVectorChoices
import Formalism.HermitianCurvature.HermitianCurvatureProofs.BasePointMemHalfPlane
import Formalism.HermitianCurvature.HermitianCurvatureProofs.Block32EqZeroOfUnipotent
import Formalism.HermitianCurvature.HermitianCurvatureProofs.BlockStartPoints
import Formalism.HermitianCurvature.HermitianCurvatureProofs.BudgetLiftSquareRoot
import Formalism.HermitianCurvature.HermitianCurvatureProofs.CentreBlockStructure
import Formalism.HermitianCurvature.HermitianCurvatureProofs.CriticalThresholdLowerBound
import Formalism.HermitianCurvature.HermitianCurvatureProofs.CuspidalIrreducibleSubrep
import Formalism.HermitianCurvature.HermitianCurvatureProofs.CutGCoreGTRTopActAlg
import Formalism.HermitianCurvature.HermitianCurvatureProofs.DiagonalTopBlock
import Formalism.HermitianCurvature.HermitianCurvatureProofs.EqZeroOfIdealCompact
import Formalism.HermitianCurvature.HermitianCurvatureProofs.FiniteClassesPositiveSums
import Formalism.HermitianCurvature.HermitianCurvatureProofs.FinitePointSets
import Formalism.HermitianCurvature.HermitianCurvatureProofs.FiniteSumSwap
import Formalism.HermitianCurvature.HermitianCurvatureProofs.FirstEmbeddingOne
import Formalism.HermitianCurvature.HermitianCurvatureProofs.FmSmulLeft
import Formalism.HermitianCurvature.HermitianCurvatureProofs.FormDomination
import Formalism.HermitianCurvature.HermitianCurvatureProofs.FrameIntegralJacobian
import Formalism.HermitianCurvature.HermitianCurvatureProofs.GermExpansionOfSteps
import Formalism.HermitianCurvature.HermitianCurvatureProofs.GermSumLattices
import Formalism.HermitianCurvature.HermitianCurvatureProofs.GramConjugationNorm
import Formalism.HermitianCurvature.HermitianCurvatureProofs.GramKernelHermitian
import Formalism.HermitianCurvature.HermitianCurvatureProofs.HenselRootsBounded
import Formalism.HermitianCurvature.HermitianCurvatureProofs.HermitianFrameCount
import Formalism.HermitianCurvature.HermitianCurvatureProofs.HessianScalingIntegrals
import Formalism.HermitianCurvature.HermitianCurvatureProofs.IntegralLatticeRefinementIdentity

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.GaloisIrreducibility.NoSolvableTransitive, `Formalism.GaussJetBounds.GaussJetProofs.CapacityLeReachCapacity, `Formalism.GaussJetBounds.GaussJetProofs.ExistsNeZeroOfFinsumNeZero, `Formalism.GaussJetBounds.GaussJetProofs.MinorProductSupportTop, `Formalism.GaussJetBounds.GaussJetProofs.NormDetLeOneOfEntries, `Formalism.GaussJetBounds.GaussJetProofs.OneLetterRadiusIdentity, `Formalism.GaussJetBounds.GaussJetProofs.Special, `Formalism.GaussJetBounds.GaussJetProofs.SubstitutionWeightBound, `Formalism.GaussJetBounds.OneLetterGaussJets.StatementA, `Formalism.GaussJetBounds.OneLetterGaussJets.StatementN, `Formalism.GaussJetBounds.StatementE, `Formalism.GaussJetBounds.StatementO, `Formalism.GaussValuationBounds.GaussValueContraction.GaussBasic, `Formalism.GaussValuationBounds.GaussValueContraction.GaussMul, `Formalism.GaussValuationBounds.GaussValueContraction.LemmaCVal, `Formalism.GaussValuationBounds.GaussValueContraction.ScaledPowMemSpanCeil, `Formalism.GelfandTransference.HadamardGelfand.Hadamard, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.DomPow, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockHerm, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.FockWeightOrth, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LBidetLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LBidetdomLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LFockbLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LFocksLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LHwrowLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LNondomLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LRowdivLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LRowstLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.LSatLemmas, `Formalism.GradedWeylDivisibility.FockSpaceTableaux.RowNuSum, `Formalism.GradedWeylDivisibility.StatementB, `Formalism.GradedWeylDivisibility.StatementC, `Formalism.GrowthSums.FactorialBaseGrowth.LogCoef, `Formalism.GrowthSums.FactorialBaseGrowth.PathBasisOfCount, `Formalism.GrowthSums.StatementB, `Formalism.HarderNarasimhan.HarderNarasimhanProofs.FinSup, `Formalism.HermitianCurvature.HermitianCurvatureProofs.AdicNeighbourhood, `Formalism.HermitianCurvature.HermitianCurvatureProofs.AveragedKernelSums, `Formalism.HermitianCurvature.HermitianCurvatureProofs.AveragedVectorChoices, `Formalism.HermitianCurvature.HermitianCurvatureProofs.BasePointMemHalfPlane, `Formalism.HermitianCurvature.HermitianCurvatureProofs.Block32EqZeroOfUnipotent, `Formalism.HermitianCurvature.HermitianCurvatureProofs.BlockStartPoints, `Formalism.HermitianCurvature.HermitianCurvatureProofs.BudgetLiftSquareRoot, `Formalism.HermitianCurvature.HermitianCurvatureProofs.CentreBlockStructure, `Formalism.HermitianCurvature.HermitianCurvatureProofs.CriticalThresholdLowerBound, `Formalism.HermitianCurvature.HermitianCurvatureProofs.CuspidalIrreducibleSubrep, `Formalism.HermitianCurvature.HermitianCurvatureProofs.CutGCoreGTRTopActAlg, `Formalism.HermitianCurvature.HermitianCurvatureProofs.DiagonalTopBlock, `Formalism.HermitianCurvature.HermitianCurvatureProofs.EqZeroOfIdealCompact, `Formalism.HermitianCurvature.HermitianCurvatureProofs.FiniteClassesPositiveSums, `Formalism.HermitianCurvature.HermitianCurvatureProofs.FinitePointSets, `Formalism.HermitianCurvature.HermitianCurvatureProofs.FiniteSumSwap, `Formalism.HermitianCurvature.HermitianCurvatureProofs.FirstEmbeddingOne, `Formalism.HermitianCurvature.HermitianCurvatureProofs.FmSmulLeft, `Formalism.HermitianCurvature.HermitianCurvatureProofs.FormDomination, `Formalism.HermitianCurvature.HermitianCurvatureProofs.FrameIntegralJacobian, `Formalism.HermitianCurvature.HermitianCurvatureProofs.GermExpansionOfSteps, `Formalism.HermitianCurvature.HermitianCurvatureProofs.GermSumLattices, `Formalism.HermitianCurvature.HermitianCurvatureProofs.GramConjugationNorm, `Formalism.HermitianCurvature.HermitianCurvatureProofs.GramKernelHermitian, `Formalism.HermitianCurvature.HermitianCurvatureProofs.HenselRootsBounded, `Formalism.HermitianCurvature.HermitianCurvatureProofs.HermitianFrameCount, `Formalism.HermitianCurvature.HermitianCurvatureProofs.HessianScalingIntegrals, `Formalism.HermitianCurvature.HermitianCurvatureProofs.IntegralLatticeRefinementIdentity]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

