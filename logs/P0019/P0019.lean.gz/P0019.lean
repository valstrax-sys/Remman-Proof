import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormEigenvalueLeOneOfIntegralMatrixUltrametric
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIdeal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormInvLePowCardOfNormProdEqOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivCexpPhaseLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivIteratedFDeriv
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivRemCompLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivSchwartzCompClmLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormLeLintegralTaylorTailIteratedDeriv
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormLeOneOfExtension
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormMapRingOfIntegersLeOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormMultisetSumLeOfForallLeUltrametric
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormPowTwoPowSubOneGe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormRootLeMaxOneSumNormCoeff
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormUnitLeOfEsymm
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormalizationBasicOpenCover
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NsmulAevalMemLatticeOfIntRationalMatrix
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OneLeNormMulPowIdeal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OneSubProdLeSumOfLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OptionEquivLeftPderivNoneCoeff
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OptionEquivLeftRenameSomeComplexEqC
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OrbitCountParabolicUnfoldLevi
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OrbitMassFormulaFiniteIndexSubgroup
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OrderProdSubProd
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OverSchemeGrpObjOfMonoFactor
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PAdicAlgebraicApproximation
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PAdicEmbeddingsSameNormConjugate
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PAdicProductFormula
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicIntExistsLevelNotDvdMulLift
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicIntRingHomExtOfIsHausdorff
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicMemRangeCompleteDvrPadicAlgCl
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PencilOptionEquivLeftRenameSome
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PerfectionExistsUniqueSubMatrixFrobeniusEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PerfectionIsUnitOfCoeffZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodicContinuousIntegrableDomain
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodicIntegralLeFundamentalDomain
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodicNonnegIntegralPos
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PermInvariantOfConsSwapAndTail
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PermSumZeroOfPolynomialIdentity
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PicEqOneOfForallPrimeMaximal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PicPiIsOfFinOrder
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PiolaIdentityAdjugateDivergenceFree
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluckerMinorsProportional
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PointsGroup
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PointsOfSchemeOverArtinianFibreProduct
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolarizationDerivativeVanish
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolarizationSymmetricFormIdentity
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolyGrowthSpreadOfIntegralMonodromy
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolyMulGaussianBounded
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialMultipleInSubmodule
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialSolvabilityTransferAlgClosedFields
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PosDefEqMulTranspose
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PosDefExistsConjTransposeMulMulEqOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PosDefRealGramPairHermitianForms
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PosLowerBoundOnFinset
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PosOfPosMulInnerOnJointEigenvectors
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PosSemidefQuadraticAdjointPairBound
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PositiveFormOrthonormalBasisUnitary
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PositiveQuadraticLowerBound
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PowApplyEqZeroOfStrictUpper
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PowCardLeNormProd
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PowDivMemOfEsymmPowDivMem
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PowForm
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PowMapsTorsionIntoSmulTop
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreconnectedFibreAdjacentComponents

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormEigenvalueLeOneOfIntegralMatrixUltrametric, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIdeal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormInvLePowCardOfNormProdEqOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivCexpPhaseLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivIteratedFDeriv, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivRemCompLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivSchwartzCompClmLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormLeLintegralTaylorTailIteratedDeriv, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormLeOneOfExtension, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormMapRingOfIntegersLeOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormMultisetSumLeOfForallLeUltrametric, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormPowTwoPowSubOneGe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormRootLeMaxOneSumNormCoeff, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormUnitLeOfEsymm, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormalizationBasicOpenCover, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NsmulAevalMemLatticeOfIntRationalMatrix, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OneLeNormMulPowIdeal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OneSubProdLeSumOfLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OptionEquivLeftPderivNoneCoeff, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OptionEquivLeftRenameSomeComplexEqC, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OrbitCountParabolicUnfoldLevi, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OrbitMassFormulaFiniteIndexSubgroup, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OrderProdSubProd, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OverSchemeGrpObjOfMonoFactor, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PAdicAlgebraicApproximation, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PAdicEmbeddingsSameNormConjugate, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PAdicProductFormula, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicIntExistsLevelNotDvdMulLift, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicIntRingHomExtOfIsHausdorff, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicMemRangeCompleteDvrPadicAlgCl, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PencilOptionEquivLeftRenameSome, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PerfectionExistsUniqueSubMatrixFrobeniusEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PerfectionIsUnitOfCoeffZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodicContinuousIntegrableDomain, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodicIntegralLeFundamentalDomain, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodicNonnegIntegralPos, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PermInvariantOfConsSwapAndTail, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PermSumZeroOfPolynomialIdentity, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PicEqOneOfForallPrimeMaximal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PicPiIsOfFinOrder, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PiolaIdentityAdjugateDivergenceFree, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluckerMinorsProportional, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PointsGroup, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PointsOfSchemeOverArtinianFibreProduct, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolarizationDerivativeVanish, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolarizationSymmetricFormIdentity, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolyGrowthSpreadOfIntegralMonodromy, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolyMulGaussianBounded, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialMultipleInSubmodule, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialSolvabilityTransferAlgClosedFields, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PosDefEqMulTranspose, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PosDefExistsConjTransposeMulMulEqOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PosDefRealGramPairHermitianForms, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PosLowerBoundOnFinset, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PosOfPosMulInnerOnJointEigenvectors, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PosSemidefQuadraticAdjointPairBound, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PositiveFormOrthonormalBasisUnitary, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PositiveQuadraticLowerBound, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PowApplyEqZeroOfStrictUpper, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PowCardLeNormProd, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PowDivMemOfEsymmPowDivMem, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PowForm, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PowMapsTorsionIntoSmulTop, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreconnectedFibreAdjacentComponents]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

