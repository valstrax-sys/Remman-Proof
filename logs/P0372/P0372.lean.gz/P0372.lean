import Lean
import Development.ResolutionOfSingularities.EmbeddedResolution.IteratedBlowups.IsoAwayFromCenters
import Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.ClosedEmbeddingIntoAffineSpace
import Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.ExtendCoordinatesToAffineSpace
import Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.GraphChart
import Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.PullbackBlowupSequenceComposition
import Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.SmoothLocalChart
import Development.ResolutionOfSingularities.EmbeddedResolution.StrictTransformCharts.CoordinateBlowupChart
import Development.ResolutionOfSingularities.EmbeddedResolution.StrictTransformIsolation.SmoothOrderOneCenters
import Development.ResolutionOfSingularities.EmbeddedResolution.StrongResolution.EmbeddedStrictTransform
import Development.ResolutionOfSingularities.Foundations.Blowup.AffineBlowupUniversal
import Development.ResolutionOfSingularities.Foundations.Blowup.BlowupIsoOffCenter
import Development.WeilBound.CoreStatements.AbelianHeightsDuality.ZarhinTrick.QiPtsA
import Development.WeilBound.CoreStatements.AutomorphicKernels.BernsteinUnitaryProducts.BernsteinTheoremA.FiberLocalization.EqZeroOfFiberEquivariant
import Development.WeilBound.CoreStatements.AutomorphicKernels.BernsteinUnitaryProducts.BernsteinTheoremA.FrobeniusReciprocity.TensInduction
import Development.WeilBound.CoreStatements.CommonZeroEvaluation.LieLatticeActionStable
import Development.WeilBound.CoreStatements.CompactAveragingSplitting.EigenvectorLifting.LinearActAlg
import Development.WeilBound.CoreStatements.FlagImmersions.PshSumPotentialsSmallParameter
import Development.WeilBound.CoreStatements.HodgeTatePoints.CiGrAlg
import Development.WeilBound.CoreStatements.HodgeTatePoints.DetUpdateRowDiagonal
import Development.WeilBound.CoreStatements.HodgeTatePoints.EigFrob
import Development.WeilBound.CoreStatements.HodgeTatePoints.EqOfPowEqSelf
import Development.WeilBound.CoreStatements.HodgeTatePoints.FinClosure
import Development.WeilBound.CoreStatements.HodgeTatePoints.FlagbAlg
import Development.WeilBound.CoreStatements.HodgeTatePoints.Gamdel
import Development.WeilBound.CoreStatements.HodgeTatePoints.GenfibMap
import Development.WeilBound.CoreStatements.HodgeTatePoints.Gsplit
import Development.WeilBound.CoreStatements.HodgeTatePoints.HtatBcTors
import Development.WeilBound.CoreStatements.HodgeTatePoints.HtatBuild
import Development.WeilBound.CoreStatements.HodgeTatePoints.InChartOfMemCtrSet
import Development.WeilBound.CoreStatements.HodgeTatePoints.IsMaximalOfNeBot
import Development.WeilBound.CoreStatements.HodgeTatePoints.KftwoDefs
import Development.WeilBound.CoreStatements.HodgeTatePoints.MaBase
import Development.WeilBound.CoreStatements.HodgeTatePoints.McCramer
import Development.WeilBound.CoreStatements.HodgeTatePoints.NearMemSpan
import Development.WeilBound.CoreStatements.HodgeTatePoints.OfMem
import Development.WeilBound.CoreStatements.HodgeTatePoints.RaCpaf
import Development.WeilBound.CoreStatements.HodgeTatePoints.RfHopf
import Development.WeilBound.CoreStatements.HodgeTatePoints.RiEasy
import Development.WeilBound.CoreStatements.HodgeTatePoints.TensorSpanLe
import Development.WeilBound.CoreStatements.HomogeneousNonvanishing.ContinuousAtOfClosedRel
import Development.WeilBound.CoreStatements.HomogeneousNonvanishing.GMonomial
import Development.WeilBound.CoreStatements.HomogeneousNonvanishing.LGenflagFld
import Development.WeilBound.CoreStatements.IdealCycleValues.CycNumLinearInPolynomial
import Development.WeilBound.CoreStatements.IdealCycleValues.CycNumRenameVariables
import Development.WeilBound.CoreStatements.IdealCycleValues.GenNumLinearInPolynomial
import Development.WeilBound.CoreStatements.IdealCycleValues.HomogeneousSumLinearChangeClasses
import Development.WeilBound.CoreStatements.IdealCycleValues.IntersectionNumbersPermInvariant
import Development.WeilBound.CoreStatements.IdealCycleValues.ProjIdealIndependentOfBasis
import Development.WeilBound.CoreStatements.MinimalPrimeDimensions.IsProjPrimeOfRelComps
import Development.WeilBound.CoreStatements.OrbitDecayEstimates.CurveDerivativeDecay.OneLeHsG
import Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.BocksteinBaseChange.BocksteinSheafHomotopy.ComapSurjOfLift
import Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.BocksteinBaseChange.SmoothGaloisGeometry.IsOpenConnectedComponent
import Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.CechPairings.MapHComp
import Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.PerfectoidPullbacks.CapOComp
import Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.PerfectoidPullbacks.LocalSystemQuotients.FlatL
import Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.ZariskiEtaleLifting.XSmulSucc
import Development.WeilBound.CoreStatements.ProjectiveValuations.DifferentiableAtOfLines
import Development.WeilBound.CoreStatements.ProjectiveValuations.IsIsoOfIntegral
import Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.EtaleCohomologyNegativeVanishingDegreeZero
import Development.WeilBound.CoreStatements.PublishedTheorems.GlobalEulerCharacteristic.Narrow
import Development.WeilBound.CoreStatements.PublishedTheorems.NadelVanishingPairs.NadelVanishingLemmas.AlternatingProductIntegral
import Development.WeilBound.CoreStatements.PublishedTheorems.NadelVanishingPairs.NadelVanishingLemmas.CupProductFiltrationBound
import Development.WeilBound.CoreStatements.PublishedTheorems.NadelVanishingPairs.NadelVanishingLemmas.ResidueFieldFormallySmooth
import Development.WeilBound.CoreStatements.RationalSupMetrics.AevalCoordProd

open Lean Elab Command

def auditTargets : Array Name := #[`Development.ResolutionOfSingularities.EmbeddedResolution.IteratedBlowups.IsoAwayFromCenters, `Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.ClosedEmbeddingIntoAffineSpace, `Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.ExtendCoordinatesToAffineSpace, `Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.GraphChart, `Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.PullbackBlowupSequenceComposition, `Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.SmoothLocalChart, `Development.ResolutionOfSingularities.EmbeddedResolution.StrictTransformCharts.CoordinateBlowupChart, `Development.ResolutionOfSingularities.EmbeddedResolution.StrictTransformIsolation.SmoothOrderOneCenters, `Development.ResolutionOfSingularities.EmbeddedResolution.StrongResolution.EmbeddedStrictTransform, `Development.ResolutionOfSingularities.Foundations.Blowup.AffineBlowupUniversal, `Development.ResolutionOfSingularities.Foundations.Blowup.BlowupIsoOffCenter, `Development.WeilBound.CoreStatements.AbelianHeightsDuality.ZarhinTrick.QiPtsA, `Development.WeilBound.CoreStatements.AutomorphicKernels.BernsteinUnitaryProducts.BernsteinTheoremA.FiberLocalization.EqZeroOfFiberEquivariant, `Development.WeilBound.CoreStatements.AutomorphicKernels.BernsteinUnitaryProducts.BernsteinTheoremA.FrobeniusReciprocity.TensInduction, `Development.WeilBound.CoreStatements.CommonZeroEvaluation.LieLatticeActionStable, `Development.WeilBound.CoreStatements.CompactAveragingSplitting.EigenvectorLifting.LinearActAlg, `Development.WeilBound.CoreStatements.FlagImmersions.PshSumPotentialsSmallParameter, `Development.WeilBound.CoreStatements.HodgeTatePoints.CiGrAlg, `Development.WeilBound.CoreStatements.HodgeTatePoints.DetUpdateRowDiagonal, `Development.WeilBound.CoreStatements.HodgeTatePoints.EigFrob, `Development.WeilBound.CoreStatements.HodgeTatePoints.EqOfPowEqSelf, `Development.WeilBound.CoreStatements.HodgeTatePoints.FinClosure, `Development.WeilBound.CoreStatements.HodgeTatePoints.FlagbAlg, `Development.WeilBound.CoreStatements.HodgeTatePoints.Gamdel, `Development.WeilBound.CoreStatements.HodgeTatePoints.GenfibMap, `Development.WeilBound.CoreStatements.HodgeTatePoints.Gsplit, `Development.WeilBound.CoreStatements.HodgeTatePoints.HtatBcTors, `Development.WeilBound.CoreStatements.HodgeTatePoints.HtatBuild, `Development.WeilBound.CoreStatements.HodgeTatePoints.InChartOfMemCtrSet, `Development.WeilBound.CoreStatements.HodgeTatePoints.IsMaximalOfNeBot, `Development.WeilBound.CoreStatements.HodgeTatePoints.KftwoDefs, `Development.WeilBound.CoreStatements.HodgeTatePoints.MaBase, `Development.WeilBound.CoreStatements.HodgeTatePoints.McCramer, `Development.WeilBound.CoreStatements.HodgeTatePoints.NearMemSpan, `Development.WeilBound.CoreStatements.HodgeTatePoints.OfMem, `Development.WeilBound.CoreStatements.HodgeTatePoints.RaCpaf, `Development.WeilBound.CoreStatements.HodgeTatePoints.RfHopf, `Development.WeilBound.CoreStatements.HodgeTatePoints.RiEasy, `Development.WeilBound.CoreStatements.HodgeTatePoints.TensorSpanLe, `Development.WeilBound.CoreStatements.HomogeneousNonvanishing.ContinuousAtOfClosedRel, `Development.WeilBound.CoreStatements.HomogeneousNonvanishing.GMonomial, `Development.WeilBound.CoreStatements.HomogeneousNonvanishing.LGenflagFld, `Development.WeilBound.CoreStatements.IdealCycleValues.CycNumLinearInPolynomial, `Development.WeilBound.CoreStatements.IdealCycleValues.CycNumRenameVariables, `Development.WeilBound.CoreStatements.IdealCycleValues.GenNumLinearInPolynomial, `Development.WeilBound.CoreStatements.IdealCycleValues.HomogeneousSumLinearChangeClasses, `Development.WeilBound.CoreStatements.IdealCycleValues.IntersectionNumbersPermInvariant, `Development.WeilBound.CoreStatements.IdealCycleValues.ProjIdealIndependentOfBasis, `Development.WeilBound.CoreStatements.MinimalPrimeDimensions.IsProjPrimeOfRelComps, `Development.WeilBound.CoreStatements.OrbitDecayEstimates.CurveDerivativeDecay.OneLeHsG, `Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.BocksteinBaseChange.BocksteinSheafHomotopy.ComapSurjOfLift, `Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.BocksteinBaseChange.SmoothGaloisGeometry.IsOpenConnectedComponent, `Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.CechPairings.MapHComp, `Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.PerfectoidPullbacks.CapOComp, `Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.PerfectoidPullbacks.LocalSystemQuotients.FlatL, `Development.WeilBound.CoreStatements.PadicHodgeComparison.EtaleCohomologyComparison.ZariskiEtaleLifting.XSmulSucc, `Development.WeilBound.CoreStatements.ProjectiveValuations.DifferentiableAtOfLines, `Development.WeilBound.CoreStatements.ProjectiveValuations.IsIsoOfIntegral, `Development.WeilBound.CoreStatements.PublishedTheorems.CasselmanWallach.EtaleCohomologyNegativeVanishingDegreeZero, `Development.WeilBound.CoreStatements.PublishedTheorems.GlobalEulerCharacteristic.Narrow, `Development.WeilBound.CoreStatements.PublishedTheorems.NadelVanishingPairs.NadelVanishingLemmas.AlternatingProductIntegral, `Development.WeilBound.CoreStatements.PublishedTheorems.NadelVanishingPairs.NadelVanishingLemmas.CupProductFiltrationBound, `Development.WeilBound.CoreStatements.PublishedTheorems.NadelVanishingPairs.NadelVanishingLemmas.ResidueFieldFormallySmooth, `Development.WeilBound.CoreStatements.RationalSupMetrics.AevalCoordProd]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

