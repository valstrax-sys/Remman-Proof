import Lean
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InfiniteTraceAlgebraMap
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InnerProductFormulaField
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntMvPderiv
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntRing
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegerDenominator
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralCompContinuousLinearEquiv
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralExtensionAlgClosed
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralImagQuadraticHalfInt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralMv
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralOfNormBounded
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralPolynomialFifth
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralPolynomialFirst
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralPolynomialFourth
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralPolynomialSecond
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralPolynomialSixth
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralPolynomialThird
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralQuadraticHalfInt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralSumCosets
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntertwinerDiagonalization
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InvOfUnitCoeffMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InverseOmegaHolds
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InvolutionInvariants
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InvolutionMapCompactFinite
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IofAdd
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrrCases
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrrIff
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrrIffSpan
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrrMap
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrreducibleCoverForms
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrreducibleIffStable
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrreducibleInvariant
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrreducibleInvariantSubspaces
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrreducibleOfSpanningMatrices
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrreducibleProjectionExists
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrreducibleSubrep
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsCMOfConj
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsCMOfConjAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsClosedEmbeddingToM
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsDiscreteValuationRingIntegralClosure
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsDomainAway
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsInducingCoeMatrix
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsInfEmbUnique
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsIntConj
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsIntegralDetOfIsIntegral
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsIntegralIffNormLeOne
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsIntegralNatCast
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsIntegralOfNormLe
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsIntegralOfNormLeOne
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsLCProd
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsOpenRightInvariance
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsOpenStabilizer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsOpenStabilizerAddSmul
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsOpenStabilizerLinearMap
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsOpenValuationLtOne
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsPF
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsPrecompleteFiniteModule
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsSmooth
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsSmoothTwAct
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsUnitOfInvIntegral
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsotypicStableGlOperator
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsotypicStableOperator
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsotypicStableUnderOperators
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Iwa
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IwahoriEntryBound

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InfiniteTraceAlgebraMap, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InnerProductFormulaField, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntMvPderiv, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntRing, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegerDenominator, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralCompContinuousLinearEquiv, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralExtensionAlgClosed, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralImagQuadraticHalfInt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralMv, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralOfNormBounded, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralPolynomialFifth, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralPolynomialFirst, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralPolynomialFourth, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralPolynomialSecond, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralPolynomialSixth, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralPolynomialThird, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralQuadraticHalfInt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntegralSumCosets, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IntertwinerDiagonalization, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InvOfUnitCoeffMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InverseOmegaHolds, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InvolutionInvariants, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.InvolutionMapCompactFinite, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IofAdd, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrrCases, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrrIff, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrrIffSpan, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrrMap, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrreducibleCoverForms, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrreducibleIffStable, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrreducibleInvariant, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrreducibleInvariantSubspaces, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrreducibleOfSpanningMatrices, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrreducibleProjectionExists, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IrreducibleSubrep, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsCMOfConj, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsCMOfConjAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsClosedEmbeddingToM, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsDiscreteValuationRingIntegralClosure, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsDomainAway, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsInducingCoeMatrix, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsInfEmbUnique, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsIntConj, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsIntegralDetOfIsIntegral, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsIntegralIffNormLeOne, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsIntegralNatCast, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsIntegralOfNormLe, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsIntegralOfNormLeOne, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsLCProd, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsOpenRightInvariance, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsOpenStabilizer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsOpenStabilizerAddSmul, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsOpenStabilizerLinearMap, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsOpenValuationLtOne, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsPF, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsPrecompleteFiniteModule, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsSmooth, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsSmoothTwAct, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsUnitOfInvIntegral, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsotypicStableGlOperator, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsotypicStableOperator, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IsotypicStableUnderOperators, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Iwa, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.IwahoriEntryBound]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

