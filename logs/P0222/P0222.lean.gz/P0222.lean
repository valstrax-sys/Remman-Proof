import Lean
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.SatakeMat
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.SatakeRes
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.SphericalA
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Stdform
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.TjcosetsFF
import Formalism.SatakeDualWeyl.NablaRepApply
import Formalism.SatakeDualWeyl.StatementG
import Formalism.SharpRestriction.CuspSpanNormBounds.CayleyDegreeNondegeneracy.RowsRpowPow
import Formalism.SharpRestriction.CuspSpanNormBounds.LinQRawRange
import Formalism.SharpRestriction.CuspSpanNormBounds.PsiEDef
import Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrkaMeasKabRight
import Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrkbLeOneAddSq
import Formalism.SharpRestriction.Divisibility.GeneratorPowers.CPfSym
import Formalism.SharpRestriction.Divisibility.GeneratorPowers.PhiCMinD
import Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.QuotientParamNonneg
import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.FrameTransport
import Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.QuadraticBasis.OIsoOf
import Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.MemPolKIff
import Formalism.SharpRestriction.GrowthBounds.RootWeights.MatrixSubstTransvectionX
import Formalism.SharpRestriction.GrowthBounds.TwistedSubstitution.TwistedMonomialFiltration.AlmostEverywhereSpherical
import Formalism.SharpRestriction.LevelLetterCocycles.CohomologyScalarsVanish.PfCohScalarsVanish
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.MapEvalRingHomOfPiFamily
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.PowValMemPrimitiveRoots
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.ExistsInfFilVEqBot
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.FrMultVOfNotJump
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.FramePfMat
import Formalism.SharpRestriction.LevelLetterCocycles.JointConditionsZpowers.BaseCoefCrys
import Formalism.SharpRestriction.LevelLetterCocycles.JointConditionsZpowers.BaseCoefJump
import Formalism.SharpRestriction.LevelLetterCocycles.LevelKernelDetection.KerEqOfSpan
import Formalism.SharpRestriction.LevelLetterCocycles.LevelKernelDetection.PfLvBasisPhi
import Formalism.SharpRestriction.LevelLetterCocycles.PrimesOverLiterature.RayPrimeCountQ
import Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.ExistsInfFilVEqBot
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.FinalStep0
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.LogbNn
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.QuotientDistinguishedTorsionFree
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.ThetaAtRoot
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.PrimesOverExistence.Places
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.EulerRuleProductZero
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.EulerZeroSectionVanishing
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleCong
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleIrr
import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.UZGen
import Formalism.SizeWindowBrackets.ChainSlopeWindows.CorollaryModelSideCondition
import Formalism.SizeWindowBrackets.PowerBoundGivesRiemannHypothesis
import Formalism.SizeWindowBrackets.SecondKindBucket
import Formalism.SmithDeterminants.DivisibilityChains.SmithExists
import Formalism.SobolevGaussianKernels.GaussianKernelBounds.NeighbourhoodHilbertSchmidtHolds
import Formalism.StatementCM
import Formalism.StatementU
import Formalism.SubspaceCounting.GoodOrbitIntervalTileCondition
import Formalism.SubspaceCounting.SubspaceCountingProofs.AllButLESmith
import Formalism.SubspaceCounting.SubspaceCountingProofs.ChoiceOfTops
import Formalism.SubspaceCounting.SubspaceCountingProofs.DetQuotVal
import Formalism.SubspaceCounting.SubspaceCountingProofs.ManyOrbits
import Formalism.SubspaceCounting.SubspaceCountingProofs.TailSums
import Formalism.SubspaceCounting.SubspaceCountingProofs.TopsChoiceCount
import Formalism.SubspaceCounting.SubspaceCountingProofs.TopsChoicePartA
import Formalism.SubspaceCounting.SubspaceCountingProofs.TopsChoicePartB
import Formalism.SubspaceCounting.SubspaceCountingProofs.TopsChoicePartC
import Formalism.SubspaceCounting.SubspaceCountingProofs.TypeIIDown
import Formalism.SubspaceCounting.SubspaceCountingProofs.TypeIIUp
import Formalism.SuccessiveMinima.SuccessiveMinimaProofs.AdaptedBasis
import Formalism.SuccessiveMinima.SuccessiveMinimaProofs.GjLevel
import Formalism.SuccessiveMinima.SuccessiveMinimaProofs.GjScale

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.SatakeDualWeyl.AdelicIwasawaHecke.SatakeMat, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.SatakeRes, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.SphericalA, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.Stdform, `Formalism.SatakeDualWeyl.AdelicIwasawaHecke.TjcosetsFF, `Formalism.SatakeDualWeyl.NablaRepApply, `Formalism.SatakeDualWeyl.StatementG, `Formalism.SharpRestriction.CuspSpanNormBounds.CayleyDegreeNondegeneracy.RowsRpowPow, `Formalism.SharpRestriction.CuspSpanNormBounds.LinQRawRange, `Formalism.SharpRestriction.CuspSpanNormBounds.PsiEDef, `Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrkaMeasKabRight, `Formalism.SharpRestriction.CuspSpanNormBounds.UnimodularSchurMeasures.RrkbLeOneAddSq, `Formalism.SharpRestriction.Divisibility.GeneratorPowers.CPfSym, `Formalism.SharpRestriction.Divisibility.GeneratorPowers.PhiCMinD, `Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.QuotientParamNonneg, `Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.FrameTransport, `Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.QuadraticBasis.OIsoOf, `Formalism.SharpRestriction.GrowthBounds.MonomialOrderSegments.MemPolKIff, `Formalism.SharpRestriction.GrowthBounds.RootWeights.MatrixSubstTransvectionX, `Formalism.SharpRestriction.GrowthBounds.TwistedSubstitution.TwistedMonomialFiltration.AlmostEverywhereSpherical, `Formalism.SharpRestriction.LevelLetterCocycles.CohomologyScalarsVanish.PfCohScalarsVanish, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.MapEvalRingHomOfPiFamily, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.PowValMemPrimitiveRoots, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.ExistsInfFilVEqBot, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.FrMultVOfNotJump, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.FramePfMat, `Formalism.SharpRestriction.LevelLetterCocycles.JointConditionsZpowers.BaseCoefCrys, `Formalism.SharpRestriction.LevelLetterCocycles.JointConditionsZpowers.BaseCoefJump, `Formalism.SharpRestriction.LevelLetterCocycles.LevelKernelDetection.KerEqOfSpan, `Formalism.SharpRestriction.LevelLetterCocycles.LevelKernelDetection.PfLvBasisPhi, `Formalism.SharpRestriction.LevelLetterCocycles.PrimesOverLiterature.RayPrimeCountQ, `Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.ExistsInfFilVEqBot, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.FinalStep0, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.LogbNn, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.QuotientDistinguishedTorsionFree, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.ThetaAtRoot, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.PrimesOverExistence.Places, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.EulerRuleProductZero, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.EulerZeroSectionVanishing, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleCong, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.NoetherianQuotientCalc.RuleIrr, `Formalism.SharpRestriction.ValuationFrobeniusEpsilon.LeastPrimeTwists.QuotientShiftIrreducible.UZGen, `Formalism.SizeWindowBrackets.ChainSlopeWindows.CorollaryModelSideCondition, `Formalism.SizeWindowBrackets.PowerBoundGivesRiemannHypothesis, `Formalism.SizeWindowBrackets.SecondKindBucket, `Formalism.SmithDeterminants.DivisibilityChains.SmithExists, `Formalism.SobolevGaussianKernels.GaussianKernelBounds.NeighbourhoodHilbertSchmidtHolds, `Formalism.StatementCM, `Formalism.StatementU, `Formalism.SubspaceCounting.GoodOrbitIntervalTileCondition, `Formalism.SubspaceCounting.SubspaceCountingProofs.AllButLESmith, `Formalism.SubspaceCounting.SubspaceCountingProofs.ChoiceOfTops, `Formalism.SubspaceCounting.SubspaceCountingProofs.DetQuotVal, `Formalism.SubspaceCounting.SubspaceCountingProofs.ManyOrbits, `Formalism.SubspaceCounting.SubspaceCountingProofs.TailSums, `Formalism.SubspaceCounting.SubspaceCountingProofs.TopsChoiceCount, `Formalism.SubspaceCounting.SubspaceCountingProofs.TopsChoicePartA, `Formalism.SubspaceCounting.SubspaceCountingProofs.TopsChoicePartB, `Formalism.SubspaceCounting.SubspaceCountingProofs.TopsChoicePartC, `Formalism.SubspaceCounting.SubspaceCountingProofs.TypeIIDown, `Formalism.SubspaceCounting.SubspaceCountingProofs.TypeIIUp, `Formalism.SuccessiveMinima.SuccessiveMinimaProofs.AdaptedBasis, `Formalism.SuccessiveMinima.SuccessiveMinimaProofs.GjLevel, `Formalism.SuccessiveMinima.SuccessiveMinimaProofs.GjScale]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

