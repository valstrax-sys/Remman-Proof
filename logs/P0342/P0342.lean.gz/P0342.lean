import Lean
import GroundTheory.PAdicHodge.ExtRobbaLift
import GroundTheory.PAdicHodge.FWCyclotomicNorm
import GroundTheory.PAdicHodge.FactorizationFactorialLe
import GroundTheory.PAdicHodge.FieldOfNormsTower
import GroundTheory.PAdicHodge.FontaineLemmaAInf
import GroundTheory.PAdicHodge.RobbaClosed
import GroundTheory.PAdicHodge.TateNormalizedTrace
import GroundTheory.PAdicHodge.TiltAlgebra
import GroundTheory.ProfiniteCohomology.ClassFormationDefs
import GroundTheory.ProfiniteCohomology.CohomologyFunctoriality.Naturality
import GroundTheory.ProfiniteCohomology.CoinducedModules.Acyclic
import GroundTheory.ProfiniteCohomology.ColimitDefs
import GroundTheory.ProfiniteCohomology.ColimitUnion
import GroundTheory.ProfiniteCohomology.CompactSupportCohomology.HomApplyHomApplyEqOfCompEq
import GroundTheory.ProfiniteCohomology.ContinuousCochains.LongExactSequence
import GroundTheory.ProfiniteCohomology.CupProducts
import GroundTheory.ProfiniteCohomology.CyclicCupDefs
import GroundTheory.ProfiniteCohomology.GaloisCohomology.BrauerInflationDefs
import GroundTheory.ProfiniteCohomology.GlobalEulerCharacteristic.PowDefs
import GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.ModNEquivOfSurjectiveApplyModNRep
import GroundTheory.ProfiniteCohomology.RestrictedRamification.BaseChangeDefs
import GroundTheory.ProfiniteCohomology.RestrictedRamification.SUnitsDefs
import GroundTheory.ProfiniteCohomology.ShapiroDefs
import GroundTheory.TateCohomology.AugmentationSES
import GroundTheory.TateCohomology.CupGraded
import GroundTheory.TateCohomology.PGroupCohTrivial
import GroundTheory.TateCohomology.ResCores
import GroundTheory.TateCohomology.TateDeltaZero
import GroundTheory.TateCohomology.TateGroupIso
import GroundTheory.TateCohomology.TateUnique
import Lemmata.GeneralBFactSecondBis.Imports
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.FinalTF
import ReciprocityTheory.AnalyticForms.LeviForms.HomDensB
import ReciprocityTheory.AnalyticForms.LeviForms.ProjectiveLineSecondChartSymmOfNe
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.GreenCoord
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PartsCalc
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshMollB
import ReciprocityTheory.AnalyticForms.PotentialTheory.HomogeneousLiftHolomorphicOnSnd
import ReciprocityTheory.AnalyticForms.PotentialTheory.LocDens
import ReciprocityTheory.AnalyticForms.PotentialTheory.MaMeasureA
import ReciprocityTheory.AnalyticForms.PotentialTheory.ProjectiveLinePartitionContinuousCoe
import ReciprocityTheory.AnalyticForms.PotentialTheory.Pullback
import ReciprocityTheory.AnalyticForms.RegularLocalRings.ClosureFromSpecMemCompsH
import ReciprocityTheory.Chebotarev.AbsLogSubLogLeOfHalf
import ReciprocityTheory.Chebotarev.NormGsEmbZLe
import ReciprocityTheory.Chebotarev.PrimeAsymp
import ReciprocityTheory.Chebotarev.SplitE
import ReciprocityTheory.ClassFieldTheory.LocalClassField.MemOfPowQKSubOne
import ReciprocityTheory.ClassFieldTheory.LocalClassField.RecAbA
import ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.RingKrullDimQuotientOfMemAssociatedPrimes
import ReciprocityTheory.DualLattices.DotSingle
import ReciprocityTheory.DualLattices.EigenLengthFrobeniusStatement
import ReciprocityTheory.DualLattices.ExistsUnitMinor
import ReciprocityTheory.DualLattices.FischerSelfNeZero
import ReciprocityTheory.DualLattices.HeightFunctionalStatementOfPairingProperties
import ReciprocityTheory.DualLattices.ImportsAlt
import ReciprocityTheory.DualLattices.MemOfSumSingleEqZero
import ReciprocityTheory.DualLattices.MemSupOfRestrictToSubgroupMemSq
import ReciprocityTheory.DualLattices.NsmulTensorEqZero
import ReciprocityTheory.DualLattices.SmKerSurj
import ReciprocityTheory.DualLattices.StThmA
import ReciprocityTheory.DualLattices.SubMemSpan
import ReciprocityTheory.DualLattices.UnramifiedCokernelLowerBoundOf
import ReciprocityTheory.DualLattices.ValuationPairwiseDifferenceProductPowLeColengthS

open Lean Elab Command

def auditTargets : Array Name := #[`GroundTheory.PAdicHodge.ExtRobbaLift, `GroundTheory.PAdicHodge.FWCyclotomicNorm, `GroundTheory.PAdicHodge.FactorizationFactorialLe, `GroundTheory.PAdicHodge.FieldOfNormsTower, `GroundTheory.PAdicHodge.FontaineLemmaAInf, `GroundTheory.PAdicHodge.RobbaClosed, `GroundTheory.PAdicHodge.TateNormalizedTrace, `GroundTheory.PAdicHodge.TiltAlgebra, `GroundTheory.ProfiniteCohomology.ClassFormationDefs, `GroundTheory.ProfiniteCohomology.CohomologyFunctoriality.Naturality, `GroundTheory.ProfiniteCohomology.CoinducedModules.Acyclic, `GroundTheory.ProfiniteCohomology.ColimitDefs, `GroundTheory.ProfiniteCohomology.ColimitUnion, `GroundTheory.ProfiniteCohomology.CompactSupportCohomology.HomApplyHomApplyEqOfCompEq, `GroundTheory.ProfiniteCohomology.ContinuousCochains.LongExactSequence, `GroundTheory.ProfiniteCohomology.CupProducts, `GroundTheory.ProfiniteCohomology.CyclicCupDefs, `GroundTheory.ProfiniteCohomology.GaloisCohomology.BrauerInflationDefs, `GroundTheory.ProfiniteCohomology.GlobalEulerCharacteristic.PowDefs, `GroundTheory.ProfiniteCohomology.LocalEulerCharacteristic.ModNEquivOfSurjectiveApplyModNRep, `GroundTheory.ProfiniteCohomology.RestrictedRamification.BaseChangeDefs, `GroundTheory.ProfiniteCohomology.RestrictedRamification.SUnitsDefs, `GroundTheory.ProfiniteCohomology.ShapiroDefs, `GroundTheory.TateCohomology.AugmentationSES, `GroundTheory.TateCohomology.CupGraded, `GroundTheory.TateCohomology.PGroupCohTrivial, `GroundTheory.TateCohomology.ResCores, `GroundTheory.TateCohomology.TateDeltaZero, `GroundTheory.TateCohomology.TateGroupIso, `GroundTheory.TateCohomology.TateUnique, `Lemmata.GeneralBFactSecondBis.Imports, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.FinalTF, `ReciprocityTheory.AnalyticForms.LeviForms.HomDensB, `ReciprocityTheory.AnalyticForms.LeviForms.ProjectiveLineSecondChartSymmOfNe, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.GreenCoord, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PartsCalc, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshMollB, `ReciprocityTheory.AnalyticForms.PotentialTheory.HomogeneousLiftHolomorphicOnSnd, `ReciprocityTheory.AnalyticForms.PotentialTheory.LocDens, `ReciprocityTheory.AnalyticForms.PotentialTheory.MaMeasureA, `ReciprocityTheory.AnalyticForms.PotentialTheory.ProjectiveLinePartitionContinuousCoe, `ReciprocityTheory.AnalyticForms.PotentialTheory.Pullback, `ReciprocityTheory.AnalyticForms.RegularLocalRings.ClosureFromSpecMemCompsH, `ReciprocityTheory.Chebotarev.AbsLogSubLogLeOfHalf, `ReciprocityTheory.Chebotarev.NormGsEmbZLe, `ReciprocityTheory.Chebotarev.PrimeAsymp, `ReciprocityTheory.Chebotarev.SplitE, `ReciprocityTheory.ClassFieldTheory.LocalClassField.MemOfPowQKSubOne, `ReciprocityTheory.ClassFieldTheory.LocalClassField.RecAbA, `ReciprocityTheory.CommutativeAlgebra.CohenMacaulay.RingKrullDimQuotientOfMemAssociatedPrimes, `ReciprocityTheory.DualLattices.DotSingle, `ReciprocityTheory.DualLattices.EigenLengthFrobeniusStatement, `ReciprocityTheory.DualLattices.ExistsUnitMinor, `ReciprocityTheory.DualLattices.FischerSelfNeZero, `ReciprocityTheory.DualLattices.HeightFunctionalStatementOfPairingProperties, `ReciprocityTheory.DualLattices.ImportsAlt, `ReciprocityTheory.DualLattices.MemOfSumSingleEqZero, `ReciprocityTheory.DualLattices.MemSupOfRestrictToSubgroupMemSq, `ReciprocityTheory.DualLattices.NsmulTensorEqZero, `ReciprocityTheory.DualLattices.SmKerSurj, `ReciprocityTheory.DualLattices.StThmA, `ReciprocityTheory.DualLattices.SubMemSpan, `ReciprocityTheory.DualLattices.UnramifiedCokernelLowerBoundOf, `ReciprocityTheory.DualLattices.ValuationPairwiseDifferenceProductPowLeColengthS]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

