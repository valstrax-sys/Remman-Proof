import Lean
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.BlockMatrixMulBlocks
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.DigammaLogBoundRightHalfPlane
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.DirichletLogDerivReflectionFormulaStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.FiniteDimensionalOfCompactCoerciveStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.GeneralLinearIntegralCompactOpen
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.IwasawaDecompositionUpperTriangular
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.LocalFieldUniformizerNormProperties
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.MemConjSub
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.NearIdentityMatrixPositiveSolutionStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.ParabolicElementBlocks
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.ParahoricSubgroupCompactOpenMeasure
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.RamifiedPrimeContainsDiscriminantStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.SphericalFunctionTranslateProportional
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.TraceIdempotentNotDivisibleStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.UniqueReducedOrbitRepresentativeStatement
import Development.AutomorphicSpectrum.Proofs.HermitianForms.BijectiveLinearCombinationOfRankAtStalk
import Development.AutomorphicSpectrum.Proofs.JetProofs.ContinuousIteratedFDerivPartial
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.Irreducible
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.RationalFiniteIdeleFactorization
import Development.AutomorphicSpectrum.Proofs.MetricProofs.AbsCoeffProdXLeOne
import Development.AutomorphicSpectrum.Proofs.MetricProofs.AnalyticDoublingMapLocalInverseStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.AnalyticGroupLawBoundedCommutatorStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.DenseCoordinateTorus
import Development.AutomorphicSpectrum.Proofs.MetricProofs.DominatedConvergenceExhaustionStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.DoublingLimitLocalLogarithm
import Development.AutomorphicSpectrum.Proofs.MetricProofs.EqNegSumIicDifferencesStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.EtaleAwayOfIsEtaleAtOffSubmonoid
import Development.AutomorphicSpectrum.Proofs.MetricProofs.EtaleLocalizationAtPrimeTensorOfEtaleAway
import Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsBasisSubsetOfSaturatedSubmodule
import Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsHolomorphicNormalFrame
import Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsReversedTriangularFrameChangeStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.FcHoloDetDifferentiableAt
import Development.AutomorphicSpectrum.Proofs.MetricProofs.FormPolyIsHomogeneousAndEval
import Development.AutomorphicSpectrum.Proofs.MetricProofs.HarmonicAnnulusMaximumPrinciple
import Development.AutomorphicSpectrum.Proofs.MetricProofs.IsOpenFlagDomainNondegenerateMinors
import Development.AutomorphicSpectrum.Proofs.MetricProofs.KillNoneFormPoly
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LimRateMulLogSqLe
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LmuNumNonneg
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LocalLogarithmHomomorphism
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LogDetComparableGramBound
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LojasiewiczInequalityAnalyticStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.MinorRatioRegularOfInverse
import Development.AutomorphicSpectrum.Proofs.MetricProofs.PolydiscPoissonSmooth
import Development.AutomorphicSpectrum.Proofs.MetricProofs.ProdIicBlockDiagDetFactorsStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.RatioSuccessiveNonzeroRegularStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.RiemannFormPeriodDeterminantBound
import Development.AutomorphicSpectrum.Proofs.MetricProofs.SectionTensorPullbackRingHomBijective
import Development.DiscreteGroups.GlobalIrreducibility.DzStickDigits
import Development.DiscreteGroups.GlobalIrreducibility.DzStickTeich
import Development.DiscreteGroups.GlobalIrreducibility.DzStickValBasic
import Development.DiscreteGroups.GlobalIrreducibility.EigTranslate
import Development.DiscreteGroups.PiInvariants.CompactSupportTwists.PiInvA
import Development.DiscreteGroups.PiInvariants.CompactSupportTwists.TraceUnique
import Development.EtaleCohomology.CohomologicalPurity.LeafCoeqPf
import Development.EtaleCohomology.CohomologicalPurity.LeafColHensPf
import Development.EtaleCohomology.CohomologicalPurity.LeafColUnivPf
import Development.EtaleCohomology.CohomologicalPurity.LeafCompPf
import Development.EtaleCohomology.CohomologicalPurity.LeafDiagPf
import Development.EtaleCohomology.CohomologicalPurity.LeafRootPf
import Development.EtaleCohomology.CohomologicalPurity.LeafStagePf
import Development.EtaleCohomology.CohomologicalPurity.LeafSupPf
import Development.EtaleCohomology.EtaleSheaves.LeafOrdInfLocalPf
import Development.ResolutionOfSingularities.EmbeddedResolution.AlgebraicPreliminaries.BinaryCoproductBaseChange
import Development.ResolutionOfSingularities.EmbeddedResolution.AlgebraicPreliminaries.DisjointUnionOfOpens

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.GlobalProofs.BlockMatrixMulBlocks, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.DigammaLogBoundRightHalfPlane, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.DirichletLogDerivReflectionFormulaStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.FiniteDimensionalOfCompactCoerciveStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.GeneralLinearIntegralCompactOpen, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.IwasawaDecompositionUpperTriangular, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.LocalFieldUniformizerNormProperties, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.MemConjSub, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.NearIdentityMatrixPositiveSolutionStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.ParabolicElementBlocks, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.ParahoricSubgroupCompactOpenMeasure, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.RamifiedPrimeContainsDiscriminantStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.SphericalFunctionTranslateProportional, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.TraceIdempotentNotDivisibleStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.UniqueReducedOrbitRepresentativeStatement, `Development.AutomorphicSpectrum.Proofs.HermitianForms.BijectiveLinearCombinationOfRankAtStalk, `Development.AutomorphicSpectrum.Proofs.JetProofs.ContinuousIteratedFDerivPartial, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.Irreducible, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.RationalFiniteIdeleFactorization, `Development.AutomorphicSpectrum.Proofs.MetricProofs.AbsCoeffProdXLeOne, `Development.AutomorphicSpectrum.Proofs.MetricProofs.AnalyticDoublingMapLocalInverseStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.AnalyticGroupLawBoundedCommutatorStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.DenseCoordinateTorus, `Development.AutomorphicSpectrum.Proofs.MetricProofs.DominatedConvergenceExhaustionStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.DoublingLimitLocalLogarithm, `Development.AutomorphicSpectrum.Proofs.MetricProofs.EqNegSumIicDifferencesStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.EtaleAwayOfIsEtaleAtOffSubmonoid, `Development.AutomorphicSpectrum.Proofs.MetricProofs.EtaleLocalizationAtPrimeTensorOfEtaleAway, `Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsBasisSubsetOfSaturatedSubmodule, `Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsHolomorphicNormalFrame, `Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsReversedTriangularFrameChangeStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.FcHoloDetDifferentiableAt, `Development.AutomorphicSpectrum.Proofs.MetricProofs.FormPolyIsHomogeneousAndEval, `Development.AutomorphicSpectrum.Proofs.MetricProofs.HarmonicAnnulusMaximumPrinciple, `Development.AutomorphicSpectrum.Proofs.MetricProofs.IsOpenFlagDomainNondegenerateMinors, `Development.AutomorphicSpectrum.Proofs.MetricProofs.KillNoneFormPoly, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LimRateMulLogSqLe, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LmuNumNonneg, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LocalLogarithmHomomorphism, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LogDetComparableGramBound, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LojasiewiczInequalityAnalyticStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.MinorRatioRegularOfInverse, `Development.AutomorphicSpectrum.Proofs.MetricProofs.PolydiscPoissonSmooth, `Development.AutomorphicSpectrum.Proofs.MetricProofs.ProdIicBlockDiagDetFactorsStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.RatioSuccessiveNonzeroRegularStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.RiemannFormPeriodDeterminantBound, `Development.AutomorphicSpectrum.Proofs.MetricProofs.SectionTensorPullbackRingHomBijective, `Development.DiscreteGroups.GlobalIrreducibility.DzStickDigits, `Development.DiscreteGroups.GlobalIrreducibility.DzStickTeich, `Development.DiscreteGroups.GlobalIrreducibility.DzStickValBasic, `Development.DiscreteGroups.GlobalIrreducibility.EigTranslate, `Development.DiscreteGroups.PiInvariants.CompactSupportTwists.PiInvA, `Development.DiscreteGroups.PiInvariants.CompactSupportTwists.TraceUnique, `Development.EtaleCohomology.CohomologicalPurity.LeafCoeqPf, `Development.EtaleCohomology.CohomologicalPurity.LeafColHensPf, `Development.EtaleCohomology.CohomologicalPurity.LeafColUnivPf, `Development.EtaleCohomology.CohomologicalPurity.LeafCompPf, `Development.EtaleCohomology.CohomologicalPurity.LeafDiagPf, `Development.EtaleCohomology.CohomologicalPurity.LeafRootPf, `Development.EtaleCohomology.CohomologicalPurity.LeafStagePf, `Development.EtaleCohomology.CohomologicalPurity.LeafSupPf, `Development.EtaleCohomology.EtaleSheaves.LeafOrdInfLocalPf, `Development.ResolutionOfSingularities.EmbeddedResolution.AlgebraicPreliminaries.BinaryCoproductBaseChange, `Development.ResolutionOfSingularities.EmbeddedResolution.AlgebraicPreliminaries.DisjointUnionOfOpens]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

