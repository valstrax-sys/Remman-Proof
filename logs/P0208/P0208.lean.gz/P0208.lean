import Lean
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsPointLocalizationPrimeStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsProperIntegralModel
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsStalkFractionOfGenericStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsUniqueCentreLocalHom
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsUniqueTangentDualNumber
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExtendToFractionFieldStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FinitePointExtendsSection
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FinrankAdjoinVarsField
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericVanishingStalkVanishingStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GermGenPtInjectiveRangeRegAtStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ImplicitFunctionHolomorphicStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsClopenSpecializationsGenPtStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsCptGenResidueFieldGenericStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsFinOpenSubBaseChange
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsSncPatchRat
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsUnitIffUnitAt
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsUnitNatCastStalk
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.KaehlerRankLocalizationBound
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.KaehlerRankTranscendenceDegree
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieModelExistsUniqueAct
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieModelExistsUniqueEquivStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieModelFunctorialMapStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.MulMemSqOfSmulEqZero
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.PolynomialFieldExtensionDegreeStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrimeChartExistsUniquePoint
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrimitiveDerivationPairing
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegAtIffChartLocalization
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegAtNoetherianModelNoetherian
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularAtTranslate
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularLatticeLocalFree
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RiemannFormHermitianLatticeStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SiegelLimitImagBoundStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.StalkClosedPointToToStalk
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.TorsionLiftIsClosedImmersionStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.TorusPointOverFractionFieldStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.TraceIntegralSubringExtensionStatement
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ValAtCompLocalHom
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ValuativeLiftExistsUnique
import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ZarhinBundleKernelFirstCoordEquations
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.BlockBasisChangeEntriesStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.DigammaLogBoundRightHalfPlaneStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.GeneralLinearIntegralCompactOpenStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.IwasawaDecompositionUpperTriangularStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.LocalFieldUniformizerNormPropertiesStatement
import Development.AutomorphicSpectrum.Proofs.GlobalProofs.PrimePowerNotDvdDifferent
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.AdelicCharacterRationalDualImports
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.ExistsInvariantForm
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.IsArtinianRingKummerAdjoinRootQuotientRoot
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.SplitQuadraticAlgebraOrder
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.ThetaSumStarAndSchAStar
import Development.AutomorphicSpectrum.Proofs.MetricProofs.ContDiffAtFrameEntry
import Development.AutomorphicSpectrum.Proofs.MetricProofs.DenseCoordinateTorusStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.DoublingLimitLocalLogarithmStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsConstAddEquivOfRangeEq
import Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsHolomorphicNormalFrameStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.GapEqWeightSubNext
import Development.AutomorphicSpectrum.Proofs.MetricProofs.HarmonicAnnulusMaximumPrincipleStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.IsOpenFlagDomainNondegenerateMinorsStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LocalLogarithmHomomorphismStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LogDetComparableGramBoundStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LogSineMobiusTransform
import Development.AutomorphicSpectrum.Proofs.MetricProofs.MinorRatioRegularOfInverseStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.PolydiscPoissonSmoothStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.RiemannFormPeriodDeterminantBoundStatement

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsPointLocalizationPrimeStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsProperIntegralModel, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsStalkFractionOfGenericStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsUniqueCentreLocalHom, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsUniqueTangentDualNumber, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExtendToFractionFieldStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FinitePointExtendsSection, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.FinrankAdjoinVarsField, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericVanishingStalkVanishingStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.GermGenPtInjectiveRangeRegAtStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ImplicitFunctionHolomorphicStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsClopenSpecializationsGenPtStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsCptGenResidueFieldGenericStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsFinOpenSubBaseChange, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsSncPatchRat, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsUnitIffUnitAt, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsUnitNatCastStalk, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.KaehlerRankLocalizationBound, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.KaehlerRankTranscendenceDegree, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieModelExistsUniqueAct, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieModelExistsUniqueEquivStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.LieModelFunctorialMapStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.MulMemSqOfSmulEqZero, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.PolynomialFieldExtensionDegreeStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrimeChartExistsUniquePoint, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.PrimitiveDerivationPairing, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegAtIffChartLocalization, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegAtNoetherianModelNoetherian, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularAtTranslate, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.RegularLatticeLocalFree, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.RiemannFormHermitianLatticeStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.SiegelLimitImagBoundStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.StalkClosedPointToToStalk, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.TorsionLiftIsClosedImmersionStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.TorusPointOverFractionFieldStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.TraceIntegralSubringExtensionStatement, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ValAtCompLocalHom, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ValuativeLiftExistsUnique, `Development.AutomorphicSpectrum.Proofs.GeometryProofs.ZarhinBundleKernelFirstCoordEquations, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.BlockBasisChangeEntriesStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.DigammaLogBoundRightHalfPlaneStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.GeneralLinearIntegralCompactOpenStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.IwasawaDecompositionUpperTriangularStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.LocalFieldUniformizerNormPropertiesStatement, `Development.AutomorphicSpectrum.Proofs.GlobalProofs.PrimePowerNotDvdDifferent, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.AdelicCharacterRationalDualImports, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.ExistsInvariantForm, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.IsArtinianRingKummerAdjoinRootQuotientRoot, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.SplitQuadraticAlgebraOrder, `Development.AutomorphicSpectrum.Proofs.MembershipProofs.ThetaSumStarAndSchAStar, `Development.AutomorphicSpectrum.Proofs.MetricProofs.ContDiffAtFrameEntry, `Development.AutomorphicSpectrum.Proofs.MetricProofs.DenseCoordinateTorusStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.DoublingLimitLocalLogarithmStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsConstAddEquivOfRangeEq, `Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsHolomorphicNormalFrameStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.GapEqWeightSubNext, `Development.AutomorphicSpectrum.Proofs.MetricProofs.HarmonicAnnulusMaximumPrincipleStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.IsOpenFlagDomainNondegenerateMinorsStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LocalLogarithmHomomorphismStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LogDetComparableGramBoundStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LogSineMobiusTransform, `Development.AutomorphicSpectrum.Proofs.MetricProofs.MinorRatioRegularOfInverseStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.PolydiscPoissonSmoothStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.RiemannFormPeriodDeterminantBoundStatement]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

