import Lean
import Formalism.HermitianCurvature.HermitianCurvatureProofs.LagrangeExtraction
import Formalism.HermitianCurvature.HermitianCurvatureProofs.LduDecompositionExists
import Formalism.HermitianCurvature.HermitianCurvatureProofs.LocalVolumePositivity
import Formalism.HermitianCurvature.HermitianCurvatureProofs.MeanNormSquaredBound
import Formalism.HermitianCurvature.HermitianCurvatureProofs.MeanPositiveSemidefinite
import Formalism.HermitianCurvature.HermitianCurvatureProofs.MemIntegralGlOfMiddleBlock
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ModulusLocallyConstant
import Formalism.HermitianCurvature.HermitianCurvatureProofs.OffDiagonalSchurComplement
import Formalism.HermitianCurvature.HermitianCurvatureProofs.OneLevelCoefficients
import Formalism.HermitianCurvature.HermitianCurvatureProofs.OrbitTailEstimates
import Formalism.HermitianCurvature.HermitianCurvatureProofs.OrderChainWeights
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PartialMeansOrthogonal
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PointSetConstantMembership
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PointwiseStabiliserParametrisationBijective
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PosSemidefEntryBound
import Formalism.HermitianCurvature.HermitianCurvatureProofs.PositiveSemidefinitePullback
import Formalism.HermitianCurvature.HermitianCurvatureProofs.RealPowerIdentities
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ReductionSurjective
import Formalism.HermitianCurvature.HermitianCurvatureProofs.RestrictOrthogonalComplementNondeg
import Formalism.HermitianCurvature.HermitianCurvatureProofs.ScaleThresholdCharacters
import Formalism.HermitianCurvature.HermitianCurvatureProofs.SecondPolynomialClauses
import Formalism.HermitianCurvature.HermitianCurvatureProofs.SplitFrameTransitive
import Formalism.HermitianCurvature.HermitianCurvatureProofs.SubmoduleMultiplication
import Formalism.HermitianCurvature.HermitianCurvatureProofs.WordLiftInduction
import Formalism.HermitianCurvature.LatticeHerglotzBound
import Formalism.HermitianCurvature.PrimeToDifferent
import Formalism.HermitianCurvature.StatementLE
import Formalism.HermitianCurvature.StatementWd
import Formalism.HermitianLattices.DefsCS
import Formalism.HermitianLattices.DualOrthSum
import Formalism.HermitianLattices.HermitianLatticesProofs.DualBasic
import Formalism.HermitianLattices.HermitianLatticesProofs.ExampleZ
import Formalism.HermitianLattices.HermitianLatticesProofs.IsomAct
import Formalism.HermitianLattices.HermitianLatticesProofs.LocBasic
import Formalism.HermitianLattices.NeighbourConstruct
import Formalism.HermitianLattices.StatementTheta
import Formalism.HyperbolicPlaceProducts.ArithmeticCountRevised
import Formalism.IncomingBounds.DefsThmP
import Formalism.IncomingBounds.FlowDegreeBounds.IndexLastReductionHolds
import Formalism.IncomingBounds.FlowDegreeBounds.ProdRangeEqFactorialMulProdIco
import Formalism.JumpKernelCokernel.JumpShiftProofs.ColThmC
import Formalism.JumpKernelCokernel.JumpShiftProofs.ColumnDegreeBound
import Formalism.JumpKernelCokernel.JumpShiftProofs.DetLen
import Formalism.JumpKernelCokernel.JumpShiftProofs.FiltrationExponentHolds
import Formalism.JumpKernelCokernel.JumpShiftProofs.HCoefLim
import Formalism.JumpKernelCokernel.JumpShiftProofs.IdealPowerSumMem
import Formalism.JumpKernelCokernel.JumpShiftProofs.InvConst
import Formalism.JumpKernelCokernel.JumpShiftProofs.JumpShift
import Formalism.JumpKernelCokernel.JumpShiftProofs.KerCoker
import Formalism.JumpKernelCokernel.JumpShiftProofs.LenSplit
import Formalism.JumpKernelCokernel.JumpShiftProofs.PdFacts
import Formalism.JumpKernelCokernel.JumpShiftProofs.PowBinom
import Formalism.JumpKernelCokernel.JumpShiftProofs.RelZero
import Formalism.JumpKernelCokernel.JumpShiftProofs.RowDegreeBound
import Formalism.JumpKernelCokernel.JumpShiftProofs.ThickA
import Formalism.JumpKernelCokernel.JumpShiftProofs.ThickB
import Formalism.JumpKernelCokernel.JumpShiftProofs.TorsKer
import Formalism.JumpKernelCokernel.JumpShiftProofs.TorsKerSum
import Formalism.JumpKernelCokernel.LemmaDJoint
import Formalism.LagrangeIdealLifts.LiftLagrangeIdealInt
import Formalism.LandauZeroFreeBounds.NoZeroComplexOf
import Formalism.LatticeSlopes.LatticeSlopesProofs.MuMaxLeMin
import Formalism.LatticeSlopes.LatticeSlopesProofs.OrthSum
import Formalism.LatticeSlopes.LatticeSlopesProofs.SaturationProperties

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.HermitianCurvature.HermitianCurvatureProofs.LagrangeExtraction, `Formalism.HermitianCurvature.HermitianCurvatureProofs.LduDecompositionExists, `Formalism.HermitianCurvature.HermitianCurvatureProofs.LocalVolumePositivity, `Formalism.HermitianCurvature.HermitianCurvatureProofs.MeanNormSquaredBound, `Formalism.HermitianCurvature.HermitianCurvatureProofs.MeanPositiveSemidefinite, `Formalism.HermitianCurvature.HermitianCurvatureProofs.MemIntegralGlOfMiddleBlock, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ModulusLocallyConstant, `Formalism.HermitianCurvature.HermitianCurvatureProofs.OffDiagonalSchurComplement, `Formalism.HermitianCurvature.HermitianCurvatureProofs.OneLevelCoefficients, `Formalism.HermitianCurvature.HermitianCurvatureProofs.OrbitTailEstimates, `Formalism.HermitianCurvature.HermitianCurvatureProofs.OrderChainWeights, `Formalism.HermitianCurvature.HermitianCurvatureProofs.PartialMeansOrthogonal, `Formalism.HermitianCurvature.HermitianCurvatureProofs.PointSetConstantMembership, `Formalism.HermitianCurvature.HermitianCurvatureProofs.PointwiseStabiliserParametrisationBijective, `Formalism.HermitianCurvature.HermitianCurvatureProofs.PosSemidefEntryBound, `Formalism.HermitianCurvature.HermitianCurvatureProofs.PositiveSemidefinitePullback, `Formalism.HermitianCurvature.HermitianCurvatureProofs.RealPowerIdentities, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ReductionSurjective, `Formalism.HermitianCurvature.HermitianCurvatureProofs.RestrictOrthogonalComplementNondeg, `Formalism.HermitianCurvature.HermitianCurvatureProofs.ScaleThresholdCharacters, `Formalism.HermitianCurvature.HermitianCurvatureProofs.SecondPolynomialClauses, `Formalism.HermitianCurvature.HermitianCurvatureProofs.SplitFrameTransitive, `Formalism.HermitianCurvature.HermitianCurvatureProofs.SubmoduleMultiplication, `Formalism.HermitianCurvature.HermitianCurvatureProofs.WordLiftInduction, `Formalism.HermitianCurvature.LatticeHerglotzBound, `Formalism.HermitianCurvature.PrimeToDifferent, `Formalism.HermitianCurvature.StatementLE, `Formalism.HermitianCurvature.StatementWd, `Formalism.HermitianLattices.DefsCS, `Formalism.HermitianLattices.DualOrthSum, `Formalism.HermitianLattices.HermitianLatticesProofs.DualBasic, `Formalism.HermitianLattices.HermitianLatticesProofs.ExampleZ, `Formalism.HermitianLattices.HermitianLatticesProofs.IsomAct, `Formalism.HermitianLattices.HermitianLatticesProofs.LocBasic, `Formalism.HermitianLattices.NeighbourConstruct, `Formalism.HermitianLattices.StatementTheta, `Formalism.HyperbolicPlaceProducts.ArithmeticCountRevised, `Formalism.IncomingBounds.DefsThmP, `Formalism.IncomingBounds.FlowDegreeBounds.IndexLastReductionHolds, `Formalism.IncomingBounds.FlowDegreeBounds.ProdRangeEqFactorialMulProdIco, `Formalism.JumpKernelCokernel.JumpShiftProofs.ColThmC, `Formalism.JumpKernelCokernel.JumpShiftProofs.ColumnDegreeBound, `Formalism.JumpKernelCokernel.JumpShiftProofs.DetLen, `Formalism.JumpKernelCokernel.JumpShiftProofs.FiltrationExponentHolds, `Formalism.JumpKernelCokernel.JumpShiftProofs.HCoefLim, `Formalism.JumpKernelCokernel.JumpShiftProofs.IdealPowerSumMem, `Formalism.JumpKernelCokernel.JumpShiftProofs.InvConst, `Formalism.JumpKernelCokernel.JumpShiftProofs.JumpShift, `Formalism.JumpKernelCokernel.JumpShiftProofs.KerCoker, `Formalism.JumpKernelCokernel.JumpShiftProofs.LenSplit, `Formalism.JumpKernelCokernel.JumpShiftProofs.PdFacts, `Formalism.JumpKernelCokernel.JumpShiftProofs.PowBinom, `Formalism.JumpKernelCokernel.JumpShiftProofs.RelZero, `Formalism.JumpKernelCokernel.JumpShiftProofs.RowDegreeBound, `Formalism.JumpKernelCokernel.JumpShiftProofs.ThickA, `Formalism.JumpKernelCokernel.JumpShiftProofs.ThickB, `Formalism.JumpKernelCokernel.JumpShiftProofs.TorsKer, `Formalism.JumpKernelCokernel.JumpShiftProofs.TorsKerSum, `Formalism.JumpKernelCokernel.LemmaDJoint, `Formalism.LagrangeIdealLifts.LiftLagrangeIdealInt, `Formalism.LandauZeroFreeBounds.NoZeroComplexOf, `Formalism.LatticeSlopes.LatticeSlopesProofs.MuMaxLeMin, `Formalism.LatticeSlopes.LatticeSlopesProofs.OrthSum, `Formalism.LatticeSlopes.LatticeSlopesProofs.SaturationProperties]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

