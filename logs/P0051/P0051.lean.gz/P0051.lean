import Lean
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FirstStatementC
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FirstStatementD
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FirstStatementE
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FirstStatementF
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FixedQuadraticMemBase
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FixedSubgroup
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FormalGroupCoeffMem
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FormallySmoothSectionStalk
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FormallySmoothSurjectiveDerivation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FourierTransformBijective
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FrechetDerivEvaluation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FreeModuleQuotient
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FreeRatios
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FrobInPowCong
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FrobeniusElement
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FrobeniusElementAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.G6Decomposition
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GaloisBoundFirst
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GaloisBoundSecond
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GenericGradient
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GenericMap
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GlR
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GradedPowerSeriesLemmas
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GradedSpanProducts
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HasStrictFDerivAtEval
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HcAvg
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HeckeGelfandPair
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HeckeMap
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HeckePolMap
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HermApply
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HermitianBlockDiagonal
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HermitianBlockTriangular
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HermitianDiagonalisation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HermitianForm
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HermitianPositiveSymplectic
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HermitianProjectionEq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HfsAevalRestrict
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HilbertNinety
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HloweqTransfer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HoExistsPrime
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HomOr
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HomWProd
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HomologyFiniteShortExact
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HsSum
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HwvLoweringSpanLower
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImagOfSq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Imports
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBis
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisBis
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisExtra
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisFurther
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisLast
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisMore
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisRest
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisSide
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisTail
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisTer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtra
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraAlt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraBis
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraExtra
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraFurther

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FirstStatementC, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FirstStatementD, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FirstStatementE, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FirstStatementF, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FixedQuadraticMemBase, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FixedSubgroup, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FormalGroupCoeffMem, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FormallySmoothSectionStalk, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FormallySmoothSurjectiveDerivation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FourierTransformBijective, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FrechetDerivEvaluation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FreeModuleQuotient, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FreeRatios, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FrobInPowCong, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FrobeniusElement, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FrobeniusElementAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.G6Decomposition, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GaloisBoundFirst, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GaloisBoundSecond, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GenericGradient, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GenericMap, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GlR, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GradedPowerSeriesLemmas, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.GradedSpanProducts, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HasStrictFDerivAtEval, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HcAvg, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HeckeGelfandPair, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HeckeMap, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HeckePolMap, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HermApply, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HermitianBlockDiagonal, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HermitianBlockTriangular, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HermitianDiagonalisation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HermitianForm, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HermitianPositiveSymplectic, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HermitianProjectionEq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HfsAevalRestrict, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HilbertNinety, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HloweqTransfer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HoExistsPrime, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HomOr, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HomWProd, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HomologyFiniteShortExact, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HsSum, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.HwvLoweringSpanLower, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImagOfSq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Imports, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBis, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisBis, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisExtra, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisFurther, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisLast, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisMore, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisRest, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisSide, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisTail, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsBisTer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtra, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraAlt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraBis, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraExtra, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ImportsExtraFurther]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

