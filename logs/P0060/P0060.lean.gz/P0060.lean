import Lean
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CartanDecompositionLieAlgebra
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CentralizerRegularCommutes
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CircleZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ComapMulVecCompactOpen
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CompactScaledIntoNhds
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CompactSetFiniteCosetRepresentatives
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContDiffIntegralDensity
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousIteratedDerivHolomorphicFamily
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousOnIteratedDerivFamily
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousSetIntegralIoiOne
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContourShiftTubeDomain
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CoreR
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetIntegralUnramified
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetSumTranslateInvariant
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetSumsProportionalCard
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CountableOfNumberField
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DerivationCommutesWithTrace
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DetSqNormEqHermitianBlockFormula
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DifferentiableOnLaplaceIntegralRightHalf
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DifferentiableOnTprodCubicFactor
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DistribHaarCharEqOneOfValuationEqOne
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EigenvectorLiftOfSurjection
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EqDiagonalOfUpperTriangularOfUnitary
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EqOfNearOfCharpolyEq
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsAdaptedMajorant
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsBoundOfIsBigO
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsBumpWithNonzeroIntegral
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsChainsOfRange
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCompactOpenSubgroupMem
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCongruenceSubset
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsConjMulEq
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCosetRepsOpenInCompact
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsEvalEqProdOfNatDegreeEq
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsFgTmulEqZero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsFiniteAffineCover
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsFiniteCosetRepresentatives
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsGLLastBasisVecMulEq
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsGLVecMulEqLastBasis
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsGlLastRowEq
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsGoodPoly
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsJointEigenvectorNonzero
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsLevelInverseCongruence
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsLiftOfSurjKer
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsMaximalAbelianHermitian
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsNonnegBump
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsOpenCompactLatticeContaining
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsPerfectRadical
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsPrincipalCongruence
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsRecurrencePolynomial
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsRegularElementAbelian
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsSmulEqOnFinset
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsUdlOfIsUnit
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsUniformiser
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsUniqueCompEq
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsUpperLower
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExpBlockTriangular
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExponentialPolynomialSolutionSpace
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteCosetsPrincipalCongruence
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteDimensionalIsoPartOfSimple
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteDualAll
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteImageCompactOpenQuotient
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteImageCompactRightInvariant
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FlatQuotientOfUniversallyInjective
import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FourierInjectiveMatrixSpace

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CartanDecompositionLieAlgebra, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CentralizerRegularCommutes, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CircleZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ComapMulVecCompactOpen, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CompactScaledIntoNhds, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CompactSetFiniteCosetRepresentatives, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContDiffIntegralDensity, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousIteratedDerivHolomorphicFamily, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousOnIteratedDerivFamily, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContinuousSetIntegralIoiOne, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ContourShiftTubeDomain, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CoreR, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetIntegralUnramified, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetSumTranslateInvariant, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CosetSumsProportionalCard, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CountableOfNumberField, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DerivationCommutesWithTrace, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DetSqNormEqHermitianBlockFormula, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DifferentiableOnLaplaceIntegralRightHalf, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DifferentiableOnTprodCubicFactor, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.DistribHaarCharEqOneOfValuationEqOne, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EigenvectorLiftOfSurjection, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EqDiagonalOfUpperTriangularOfUnitary, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.EqOfNearOfCharpolyEq, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsAdaptedMajorant, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsBoundOfIsBigO, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsBumpWithNonzeroIntegral, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsChainsOfRange, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCompactOpenSubgroupMem, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCongruenceSubset, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsConjMulEq, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsCosetRepsOpenInCompact, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsEvalEqProdOfNatDegreeEq, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsFgTmulEqZero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsFiniteAffineCover, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsFiniteCosetRepresentatives, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsGLLastBasisVecMulEq, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsGLVecMulEqLastBasis, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsGlLastRowEq, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsGoodPoly, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsJointEigenvectorNonzero, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsLevelInverseCongruence, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsLiftOfSurjKer, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsMaximalAbelianHermitian, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsNonnegBump, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsOpenCompactLatticeContaining, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsPerfectRadical, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsPrincipalCongruence, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsRecurrencePolynomial, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsRegularElementAbelian, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsSmulEqOnFinset, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsUdlOfIsUnit, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsUniformiser, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsUniqueCompEq, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsUpperLower, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExpBlockTriangular, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExponentialPolynomialSolutionSpace, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteCosetsPrincipalCongruence, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteDimensionalIsoPartOfSimple, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteDualAll, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteImageCompactOpenQuotient, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FiniteImageCompactRightInvariant, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FlatQuotientOfUniversallyInjective, `Development.AutomorphicSpectrum.Proofs.BlockDecomposition.FourierInjectiveMatrixSpace]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

