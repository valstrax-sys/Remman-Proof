import Lean
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.ExistsHostDataWild
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.ExistsIsPrimitiveRootIff
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.HostDegree
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.GalDegree
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.LevelLift
import Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.NuFinite
import Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.lemmaL
import Development.AutomorphicArithmetic.DivisorFrames.FourierSumBlockTransposeInvEq
import Development.AutomorphicArithmetic.DivisorFrames.HaarVolSelfEqOneOfOpenSubgroupLeKO
import Development.AutomorphicArithmetic.DivisorFrames.IsIntegralUnitCharOfConductorLe
import Development.AutomorphicArithmetic.DivisorFrames.NuDetMulSliceBBlockAction
import Development.AutomorphicArithmetic.DivisorFrames.SetIntegralMemAddSubgroupOfOpenSubgroupInvariant
import Development.AutomorphicArithmetic.Foundations.Convolution.HermitianDescent.PowComp
import Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.GenPiecesK
import Development.AutomorphicArithmetic.Foundations.EtaleClopenDescent.BicechCohomologyKunnethDecomposition
import Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.SchurDeterminants.SchurYOffClrHolds
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjEmbeddingRt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjugateRootZero
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjugateRootZeroSecond
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjugateRootZeroThird
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CubicCharpolyDiscriminant
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsCoordinate
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsOrthogonalUnitVector
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FinitelyGeneratedHomology
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocPairValLinear
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Rt0ConjNegNeZero
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ZASmul
import Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.Comparison
import Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.PadicField
import Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.Topology
import Development.AutomorphicArithmetic.QuadraticCharacters.GaussRoot
import Development.AutomorphicArithmetic.ShortNorms.ExistsThreePrimesOneModLeRpow
import Development.AutomorphicArithmetic.ShortNorms.levelPrimeN
import Development.AutomorphicArithmetic.ShortNorms.normPrimesN
import Development.AutomorphicArithmetic.TeichmullerLogarithm.CyclotomicPowSubOneNilpotent
import Development.AutomorphicArithmetic.ThickFrames.MarkedGe
import Development.AutomorphicArithmetic.ThickFrames.TailLe
import Development.AutomorphicArithmetic.WhittakerHecke.IdealSheafComapEqSpecIdealSheafOfEqMap
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.GermComp1ZeroPointLeft
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.IsLatFamilyLineFamZero
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.IsLatticeFamily
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.LeadMinor
import Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.PairingExtends
import Development.AutomorphicSpectrum.Definitions.DivisibilityTowers.HeckeSectionsIsotropicCommutatorPairingPower
import Development.AutomorphicSpectrum.Definitions.DivisibilityTowers.LaurentCechNerveLevelSpecTensorPower
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.AdelicGroupAlgebraActionInjective
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.GaIsHTFormOver
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.IsFullLevelAt
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.MemEigSpOfMemHtDual
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.NumberField
import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.ProjectiveLinePlaceTrivialOnConstants
import Development.AutomorphicSpectrum.Definitions.JetCones.KTypePosCone
import Development.AutomorphicSpectrum.Definitions.JetCones.SymCapRev
import Development.AutomorphicSpectrum.Definitions.MetricPeriods.ClopenCondOnto
import Development.AutomorphicSpectrum.Definitions.MetricPeriods.SectionInputs
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.LogIdealMulSpanMapStatement
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.LogIdealSupportFiniteStatement
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.LogNormsExtDegreeAdelicStatement
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.PadicLogIdealMaxElementStatement
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.RatProductFormulaStatement
import Development.AutomorphicSpectrum.Proofs.AdelicProofs.SumEmbeddingsBaseChangeStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.AugmentationQuotientEquivLattice
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.CharacterIdealPrincipalEigenStatement
import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.CmProjectiveModulePairingP

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.ExistsHostDataWild, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.ExistsIsPrimitiveRootIff, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.InertiaRamification.HostDegree, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.GalDegree, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.LevelLift, `Development.AutomorphicArithmetic.CyclotomicBounds.ClassNumberBounds.TotallyRealRoots.NuFinite, `Development.AutomorphicArithmetic.DedekindLFunctions.LandauTheorems.lemmaL, `Development.AutomorphicArithmetic.DivisorFrames.FourierSumBlockTransposeInvEq, `Development.AutomorphicArithmetic.DivisorFrames.HaarVolSelfEqOneOfOpenSubgroupLeKO, `Development.AutomorphicArithmetic.DivisorFrames.IsIntegralUnitCharOfConductorLe, `Development.AutomorphicArithmetic.DivisorFrames.NuDetMulSliceBBlockAction, `Development.AutomorphicArithmetic.DivisorFrames.SetIntegralMemAddSubgroupOfOpenSubgroupInvariant, `Development.AutomorphicArithmetic.Foundations.Convolution.HermitianDescent.PowComp, `Development.AutomorphicArithmetic.Foundations.Convolution.PolynomialCoefficientBounds.GenPiecesK, `Development.AutomorphicArithmetic.Foundations.EtaleClopenDescent.BicechCohomologyKunnethDecomposition, `Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.SchurDeterminants.SchurYOffClrHolds, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjEmbeddingRt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjugateRootZero, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjugateRootZeroSecond, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ConjugateRootZeroThird, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.CubicCharpolyDiscriminant, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsCoordinate, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ExistsOrthogonalUnitVector, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.FinitelyGeneratedHomology, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocPairValLinear, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Rt0ConjNegNeZero, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ZASmul, `Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.Comparison, `Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.PadicField, `Development.AutomorphicArithmetic.IntegralCasts.CrystallinePeriods.Topology, `Development.AutomorphicArithmetic.QuadraticCharacters.GaussRoot, `Development.AutomorphicArithmetic.ShortNorms.ExistsThreePrimesOneModLeRpow, `Development.AutomorphicArithmetic.ShortNorms.levelPrimeN, `Development.AutomorphicArithmetic.ShortNorms.normPrimesN, `Development.AutomorphicArithmetic.TeichmullerLogarithm.CyclotomicPowSubOneNilpotent, `Development.AutomorphicArithmetic.ThickFrames.MarkedGe, `Development.AutomorphicArithmetic.ThickFrames.TailLe, `Development.AutomorphicArithmetic.WhittakerHecke.IdealSheafComapEqSpecIdealSheafOfEqMap, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.GermComp1ZeroPointLeft, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.IsLatFamilyLineFamZero, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.IsLatticeFamily, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.LeadMinor, `Development.AutomorphicSpectrum.Definitions.CommutativeAlgebra.PairingExtends, `Development.AutomorphicSpectrum.Definitions.DivisibilityTowers.HeckeSectionsIsotropicCommutatorPairingPower, `Development.AutomorphicSpectrum.Definitions.DivisibilityTowers.LaurentCechNerveLevelSpecTensorPower, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.AdelicGroupAlgebraActionInjective, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.GaIsHTFormOver, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.IsFullLevelAt, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.MemEigSpOfMemHtDual, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.NumberField, `Development.AutomorphicSpectrum.Definitions.GlobalGeometry.ProjectiveLinePlaceTrivialOnConstants, `Development.AutomorphicSpectrum.Definitions.JetCones.KTypePosCone, `Development.AutomorphicSpectrum.Definitions.JetCones.SymCapRev, `Development.AutomorphicSpectrum.Definitions.MetricPeriods.ClopenCondOnto, `Development.AutomorphicSpectrum.Definitions.MetricPeriods.SectionInputs, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.LogIdealMulSpanMapStatement, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.LogIdealSupportFiniteStatement, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.LogNormsExtDegreeAdelicStatement, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.PadicLogIdealMaxElementStatement, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.RatProductFormulaStatement, `Development.AutomorphicSpectrum.Proofs.AdelicProofs.SumEmbeddingsBaseChangeStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.AugmentationQuotientEquivLattice, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.CharacterIdealPrincipalEigenStatement, `Development.AutomorphicSpectrum.Proofs.AlgebraProofs.CmProjectiveModulePairingP]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

