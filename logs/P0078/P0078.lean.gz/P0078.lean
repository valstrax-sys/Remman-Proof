import Lean
import Formalism.SharpRestriction.Divisibility.AbelianOpenPart.AbelianAt
import Formalism.SharpRestriction.Divisibility.GeneratorPowers.ExistsBasisOfSaturated
import Formalism.SharpRestriction.Divisibility.GeneratorPowers.FrTanAlg
import Formalism.SharpRestriction.Divisibility.GeneratorPowers.FrTanDirAlg
import Formalism.SharpRestriction.Divisibility.GeneratorPowers.PairEvaluation
import Formalism.SharpRestriction.Divisibility.GeneratorPowers.PartialDerivativeExponent
import Formalism.SharpRestriction.Divisibility.GeneratorPowers.PhiCMinA
import Formalism.SharpRestriction.Divisibility.GeneratorPowers.PhiCMinSt
import Formalism.SharpRestriction.Divisibility.RankTruncation.KapDLemma
import Formalism.SharpRestriction.Divisibility.RankTruncation.LocalAdditiveCharacterExpansion
import Formalism.SharpRestriction.Divisibility.RankTruncation.RkLemma
import Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.ExistsPowSmulMemBall
import Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.LargeConstantLeParamCube
import Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.RecNZFullFacts
import Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.SectionSheafQuotient
import Formalism.SharpRestriction.GlobalSchurBounds.GlobalRankLatticeProofs.UnitTraceSumBounds.CBFiLower
import Formalism.SharpRestriction.GlobalSchurBounds.GlobalRankLatticeProofs.UnitTraceSumBounds.FGTorsionFreeGen
import Formalism.SharpRestriction.GlobalSchurBounds.GlobalRankLatticeProofs.UnitTraceSumBounds.LocBasisPlace
import Formalism.SharpRestriction.GrowthBounds.BinomialRatio.SmithPairing
import Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.BlockSplit
import Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.LatRetract
import Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.LemmaSMat
import Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.QuadraticBasis.StatementO
import Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.TensorKP
import Formalism.SharpRestriction.GrowthBounds.DualFockLinear.OpBound
import Formalism.SharpRestriction.GrowthBounds.HermitianTensor.GrowthOfBasic
import Formalism.SharpRestriction.GrowthBounds.MonomialFactorials.Imports
import Formalism.SharpRestriction.GrowthBounds.MonomialFactorials.LiMap
import Formalism.SharpRestriction.GrowthBounds.MultisetValuation.CoeffProdRename
import Formalism.SharpRestriction.GrowthBounds.MultisetValuation.DescentCore
import Formalism.SharpRestriction.GrowthBounds.ObjPol
import Formalism.SharpRestriction.GrowthBounds.ScaleEdges.DvdOfAdd
import Formalism.SharpRestriction.LevelLetterCocycles.ConstantCoeffAlgHom
import Formalism.SharpRestriction.LevelLetterCocycles.ConvEqSum
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.ConstSectionStatement
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.EmultiplicityEqValuation
import Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.PsCycloStatement
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.DvdOfCoeffSubstXPowNeZero
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.FinrankMapMkQ
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.GradNPfC
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.IsAdicCompleteMax
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.PolyExpand
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.RankInverseBounds
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.SatDVR
import Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.SumIocPadicValNatAddFactorial
import Formalism.SharpRestriction.LevelLetterCocycles.EqZeroOfPowDvd
import Formalism.SharpRestriction.LevelLetterCocycles.ExistsMemMapEqSmul
import Formalism.SharpRestriction.LevelLetterCocycles.GenOfKiller
import Formalism.SharpRestriction.LevelLetterCocycles.JointConditionsZpowers.BaseLen
import Formalism.SharpRestriction.LevelLetterCocycles.JointConditionsZpowers.BaseLin
import Formalism.SharpRestriction.LevelLetterCocycles.LevelKernelDetection.CvZeroTerm
import Formalism.SharpRestriction.LevelLetterCocycles.LevelKernelDetection.ExistsBasisOfSurjective
import Formalism.SharpRestriction.LevelLetterCocycles.LevelKernelDetection.VSumPowNonneg
import Formalism.SharpRestriction.LevelLetterCocycles.NatCastEqZeroOfNotDvd
import Formalism.SharpRestriction.LevelLetterCocycles.NormLtOneIffToZMod
import Formalism.SharpRestriction.LevelLetterCocycles.PadicValNatFactorialSucc
import Formalism.SharpRestriction.LevelLetterCocycles.PrimesOverLiterature.RayLarger
import Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.DvdOfDvdImage
import Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.SmulSAddLeft
import Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.XAddOneMonic
import Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.ZpowNeOneOfClose
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.CoeffRelation
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.ConstantCoeffSubstAlgHom
import Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.EqZeroOfForallMemCoeffFiltration

open Lean Elab Command

def auditTargets : Array Name := #[`Formalism.SharpRestriction.Divisibility.AbelianOpenPart.AbelianAt, `Formalism.SharpRestriction.Divisibility.GeneratorPowers.ExistsBasisOfSaturated, `Formalism.SharpRestriction.Divisibility.GeneratorPowers.FrTanAlg, `Formalism.SharpRestriction.Divisibility.GeneratorPowers.FrTanDirAlg, `Formalism.SharpRestriction.Divisibility.GeneratorPowers.PairEvaluation, `Formalism.SharpRestriction.Divisibility.GeneratorPowers.PartialDerivativeExponent, `Formalism.SharpRestriction.Divisibility.GeneratorPowers.PhiCMinA, `Formalism.SharpRestriction.Divisibility.GeneratorPowers.PhiCMinSt, `Formalism.SharpRestriction.Divisibility.RankTruncation.KapDLemma, `Formalism.SharpRestriction.Divisibility.RankTruncation.LocalAdditiveCharacterExpansion, `Formalism.SharpRestriction.Divisibility.RankTruncation.RkLemma, `Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.ExistsPowSmulMemBall, `Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.LargeConstantLeParamCube, `Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.RecNZFullFacts, `Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.SectionSheafQuotient, `Formalism.SharpRestriction.GlobalSchurBounds.GlobalRankLatticeProofs.UnitTraceSumBounds.CBFiLower, `Formalism.SharpRestriction.GlobalSchurBounds.GlobalRankLatticeProofs.UnitTraceSumBounds.FGTorsionFreeGen, `Formalism.SharpRestriction.GlobalSchurBounds.GlobalRankLatticeProofs.UnitTraceSumBounds.LocBasisPlace, `Formalism.SharpRestriction.GrowthBounds.BinomialRatio.SmithPairing, `Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.BlockSplit, `Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.LatRetract, `Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.LemmaSMat, `Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.QuadraticBasis.StatementO, `Formalism.SharpRestriction.GrowthBounds.ColumnSpanDensity.TensorKP, `Formalism.SharpRestriction.GrowthBounds.DualFockLinear.OpBound, `Formalism.SharpRestriction.GrowthBounds.HermitianTensor.GrowthOfBasic, `Formalism.SharpRestriction.GrowthBounds.MonomialFactorials.Imports, `Formalism.SharpRestriction.GrowthBounds.MonomialFactorials.LiMap, `Formalism.SharpRestriction.GrowthBounds.MultisetValuation.CoeffProdRename, `Formalism.SharpRestriction.GrowthBounds.MultisetValuation.DescentCore, `Formalism.SharpRestriction.GrowthBounds.ObjPol, `Formalism.SharpRestriction.GrowthBounds.ScaleEdges.DvdOfAdd, `Formalism.SharpRestriction.LevelLetterCocycles.ConstantCoeffAlgHom, `Formalism.SharpRestriction.LevelLetterCocycles.ConvEqSum, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.ConstSectionStatement, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.EmultiplicityEqValuation, `Formalism.SharpRestriction.LevelLetterCocycles.CyclotomicPowerSeries.PsCycloStatement, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.DvdOfCoeffSubstXPowNeZero, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.FinrankMapMkQ, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.GradNPfC, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.IsAdicCompleteMax, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.PolyExpand, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.RankInverseBounds, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.SatDVR, `Formalism.SharpRestriction.LevelLetterCocycles.DvrLatticeRank.SumIocPadicValNatAddFactorial, `Formalism.SharpRestriction.LevelLetterCocycles.EqZeroOfPowDvd, `Formalism.SharpRestriction.LevelLetterCocycles.ExistsMemMapEqSmul, `Formalism.SharpRestriction.LevelLetterCocycles.GenOfKiller, `Formalism.SharpRestriction.LevelLetterCocycles.JointConditionsZpowers.BaseLen, `Formalism.SharpRestriction.LevelLetterCocycles.JointConditionsZpowers.BaseLin, `Formalism.SharpRestriction.LevelLetterCocycles.LevelKernelDetection.CvZeroTerm, `Formalism.SharpRestriction.LevelLetterCocycles.LevelKernelDetection.ExistsBasisOfSurjective, `Formalism.SharpRestriction.LevelLetterCocycles.LevelKernelDetection.VSumPowNonneg, `Formalism.SharpRestriction.LevelLetterCocycles.NatCastEqZeroOfNotDvd, `Formalism.SharpRestriction.LevelLetterCocycles.NormLtOneIffToZMod, `Formalism.SharpRestriction.LevelLetterCocycles.PadicValNatFactorialSucc, `Formalism.SharpRestriction.LevelLetterCocycles.PrimesOverLiterature.RayLarger, `Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.DvdOfDvdImage, `Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.SmulSAddLeft, `Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.XAddOneMonic, `Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.ZpowNeOneOfClose, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.CoeffRelation, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.ConstantCoeffSubstAlgHom, `Formalism.SharpRestriction.LevelLetterCocycles.RepresentationCongruences.EqZeroOfForallMemCoeffFiltration]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

