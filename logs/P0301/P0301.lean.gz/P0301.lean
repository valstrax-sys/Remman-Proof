import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormCoefficientIdealFamilyEqTopOfDisjointStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormFormCoefficientIdealMapLocalizationAwayStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormHeckeTermDecayFourierIntegralLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivHeckeFourierFactorLeStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivProdCoordLeLeibnizStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormSectionSqSmoothStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OrdNonnegOfIsIntegral
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OrthogonalSymplecticFixesSiegelPointIStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicApproxAlgebraicPoint
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicRingHomEqCanonicalStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicRingHomUniqueAdicComplete
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PairingHarishChandraInductionCharpolyFunction
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ParameterFunctionEqZeroOfComposableStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PartialOperatorSchwartzSeminormBoundStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodCharacterBoundedAwayOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodCharacterUniformlyAwayFromOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodChartUniformConstantsHalfPolydisc
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodFlatMapRealAnalyticStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodMapFlatDerivativeStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodMapSymplecticTransformStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodQuadraticFormsSmooth
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodTorusFlatCoordsInverseStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PicardTorsionTrivialOfTorsorsHaveSectionsStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluriharmonicHolomorphicDerivativeStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluriharmonicLogGrowthExtension
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluriharmonicPeriodicConstantStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PoincareMetricPuncturedPolydiscBounds
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PointAtZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialLipschitzCoefficientBoundStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialReductionModElementaryStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PositivePotentialFormPosStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PotentialBoundarySmooth
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PotentialSmoothInChartStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PotentialSmoothOnOpenStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PowMulMemSubalgebraOfResBasicOpenStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreimageEqOfSquareZeroThickeningStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreservesFilteredColimitsAddCommGrpIffElements
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrincipalSeriesCoordinateLocallyConstant
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrincipalSeriesCoordinateNearInfinity
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrincipalSeriesZeroOfCoordinateZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdImIteratedWirtingerDerivWordDifferentiableOnStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdRootPowerSumMapGaloisEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProductFormulaLogNorms
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PshPullbackHolomorphic
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PullFullL
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.PurityFreeOfCompleteRegularLocal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuadraticFormFderivComplex
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuadraticFormTwoSidedBoundStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuasiperiodicDifferenceHolomorphic
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneReOpenNearOfIsUnit
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneTraceOpenFiniteAdeleRing
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneTraceOpenPi
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneTraceOpenProd
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuotientMeasureConjugationInvariantStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RadialElementDifferenceExists
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RangeGenericPointStalkSubsetOfDenseOpen
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RationalSymplecticPreservesOrbitsStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReductionUniformizerNilpotentStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexConjIsometryFlagDomainGroupNeZeroStatement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RepTraceEqMulAlgebraTrace
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ResidueFieldFormallySmooth
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingHomsDvrCardEqFinrank
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SandwichDatumTraceEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ScalarBoundsOfNormLeOneStatement

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormCoefficientIdealFamilyEqTopOfDisjointStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormFormCoefficientIdealMapLocalizationAwayStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormHeckeTermDecayFourierIntegralLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivHeckeFourierFactorLeStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormIteratedFDerivProdCoordLeLeibnizStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormSectionSqSmoothStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OrdNonnegOfIsIntegral, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.OrthogonalSymplecticFixesSiegelPointIStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicApproxAlgebraicPoint, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicRingHomEqCanonicalStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PadicRingHomUniqueAdicComplete, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PairingHarishChandraInductionCharpolyFunction, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ParameterFunctionEqZeroOfComposableStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PartialOperatorSchwartzSeminormBoundStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodCharacterBoundedAwayOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodCharacterUniformlyAwayFromOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodChartUniformConstantsHalfPolydisc, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodFlatMapRealAnalyticStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodMapFlatDerivativeStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodMapSymplecticTransformStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodQuadraticFormsSmooth, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PeriodTorusFlatCoordsInverseStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PicardTorsionTrivialOfTorsorsHaveSectionsStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluriharmonicHolomorphicDerivativeStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluriharmonicLogGrowthExtension, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PluriharmonicPeriodicConstantStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PoincareMetricPuncturedPolydiscBounds, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PointAtZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialLipschitzCoefficientBoundStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PolynomialReductionModElementaryStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PositivePotentialFormPosStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PotentialBoundarySmooth, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PotentialSmoothInChartStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PotentialSmoothOnOpenStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PowMulMemSubalgebraOfResBasicOpenStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreimageEqOfSquareZeroThickeningStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PreservesFilteredColimitsAddCommGrpIffElements, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrincipalSeriesCoordinateLocallyConstant, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrincipalSeriesCoordinateNearInfinity, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PrincipalSeriesZeroOfCoordinateZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdImIteratedWirtingerDerivWordDifferentiableOnStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProdRootPowerSumMapGaloisEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ProductFormulaLogNorms, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PshPullbackHolomorphic, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PullFullL, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.PurityFreeOfCompleteRegularLocal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuadraticFormFderivComplex, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuadraticFormTwoSidedBoundStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuasiperiodicDifferenceHolomorphic, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneReOpenNearOfIsUnit, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneTraceOpenFiniteAdeleRing, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneTraceOpenPi, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuaternionNormOneTraceOpenProd, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.QuotientMeasureConjugationInvariantStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RadialElementDifferenceExists, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RangeGenericPointStalkSubsetOfDenseOpen, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RationalSymplecticPreservesOrbitsStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReductionUniformizerNilpotentStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexConjIsometryFlagDomainGroupNeZeroStatement, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RepTraceEqMulAlgebraTrace, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ResidueFieldFormallySmooth, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.RingHomsDvrCardEqFinrank, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.SandwichDatumTraceEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.ScalarBoundsOfNormLeOneStatement]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

