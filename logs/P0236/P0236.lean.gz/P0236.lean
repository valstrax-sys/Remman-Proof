import Lean
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.InhabCAR
import ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.PartialTrace
import ReciprocityTheory.ReductiveGroups.SymplecticTraces.WeylCharacters.BlockCombStatement
import ReciprocityTheory.ReductiveGroups.SymplecticTraces.WeylCharacters.Branch
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.FrobFixNegOne
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.KurNewton
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModBasic
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModCMPoint
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModEisInt
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModGDefs
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModGEis
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModLatTau
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.MuMEvalPowEqZero
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.NormNatCastClOfNotDvd
import ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.SemilinNormPowSubPow
import ReciprocityTheory.SemistableReduction.ApproxBasisB
import ReciprocityTheory.SemistableReduction.ApproxGraphB
import ReciprocityTheory.SemistableReduction.BWPoly
import ReciprocityTheory.SemistableReduction.CauchyInequalityOnTorus
import ReciprocityTheory.SemistableReduction.EmbMatMulVecInjective
import ReciprocityTheory.SemistableReduction.ExistsIntSmulMemSpan
import ReciprocityTheory.SemistableReduction.GaussValLeIffDivMem
import ReciprocityTheory.SemistableReduction.GenericImageFinite
import ReciprocityTheory.SemistableReduction.GramOfLinearOrder
import ReciprocityTheory.SemistableReduction.IntCoresB
import ReciprocityTheory.SemistableReduction.LagrangeIdealLiftsFact
import ReciprocityTheory.SemistableReduction.LatTest
import ReciprocityTheory.SemistableReduction.RestBlockSubstIsMultiHomogeneous
import ReciprocityTheory.SemistableReduction.SJCoreC
import ReciprocityTheory.SemistableReduction.SemiContractB
import ReciprocityTheory.SemistableReduction.SemiContractC
import ReciprocityTheory.SemistableReduction.SemiDegCC
import ReciprocityTheory.SemistableReduction.SemiDegSt
import ReciprocityTheory.SemistableReduction.ShareDetA
import ReciprocityTheory.SemistableReduction.SjHolds
import ReciprocityTheory.SemistableReduction.SphereTorusB
import ReciprocityTheory.SemistableReduction.TorusLexC
import ReciprocityTheory.SemistableReduction.TorusMeanC
import ReciprocityTheory.SemistableReduction.UnipotentB
import ReciprocityTheory.ThetaQuasiPeriods.NormInvSmulMemSphere
import ReciprocityTheory.ThetaQuasiPeriods.Transl
import ReciprocityTheory.ThetaSummability.TailSumEstimates.ConeExp

open Lean Elab Command

def auditTargets : Array Name := #[`ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.InhabCAR, `ReciprocityTheory.ReductiveGroups.DiscreteSeries.TensorRepresentations.PartialTrace, `ReciprocityTheory.ReductiveGroups.SymplecticTraces.WeylCharacters.BlockCombStatement, `ReciprocityTheory.ReductiveGroups.SymplecticTraces.WeylCharacters.Branch, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.FrobFixNegOne, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.KurNewton, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModBasic, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModCMPoint, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModEisInt, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModGDefs, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModGEis, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.ModLatTau, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.MuMEvalPowEqZero, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.NormNatCastClOfNotDvd, `ReciprocityTheory.ReductiveGroups.UnramifiedIntegrals.SemilinNormPowSubPow, `ReciprocityTheory.SemistableReduction.ApproxBasisB, `ReciprocityTheory.SemistableReduction.ApproxGraphB, `ReciprocityTheory.SemistableReduction.BWPoly, `ReciprocityTheory.SemistableReduction.CauchyInequalityOnTorus, `ReciprocityTheory.SemistableReduction.EmbMatMulVecInjective, `ReciprocityTheory.SemistableReduction.ExistsIntSmulMemSpan, `ReciprocityTheory.SemistableReduction.GaussValLeIffDivMem, `ReciprocityTheory.SemistableReduction.GenericImageFinite, `ReciprocityTheory.SemistableReduction.GramOfLinearOrder, `ReciprocityTheory.SemistableReduction.IntCoresB, `ReciprocityTheory.SemistableReduction.LagrangeIdealLiftsFact, `ReciprocityTheory.SemistableReduction.LatTest, `ReciprocityTheory.SemistableReduction.RestBlockSubstIsMultiHomogeneous, `ReciprocityTheory.SemistableReduction.SJCoreC, `ReciprocityTheory.SemistableReduction.SemiContractB, `ReciprocityTheory.SemistableReduction.SemiContractC, `ReciprocityTheory.SemistableReduction.SemiDegCC, `ReciprocityTheory.SemistableReduction.SemiDegSt, `ReciprocityTheory.SemistableReduction.ShareDetA, `ReciprocityTheory.SemistableReduction.SjHolds, `ReciprocityTheory.SemistableReduction.SphereTorusB, `ReciprocityTheory.SemistableReduction.TorusLexC, `ReciprocityTheory.SemistableReduction.TorusMeanC, `ReciprocityTheory.SemistableReduction.UnipotentB, `ReciprocityTheory.ThetaQuasiPeriods.NormInvSmulMemSphere, `ReciprocityTheory.ThetaQuasiPeriods.Transl, `ReciprocityTheory.ThetaSummability.TailSumEstimates.ConeExp]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

