import Lean
import Lemmata.MiscLemmasB.Imports
import Lemmata.MiscLemmasC.Imports
import Lemmata.MiscLemmasD.Imports
import Lemmata.MiscLemmasE.Imports
import Lemmata.MiscLemmasH.Imports
import Lemmata.MiscLemmasI.Imports
import Lemmata.MiscLemmasJ.Imports
import Lemmata.MiscLemmasK.Imports
import Lemmata.MiscLemmasL.Imports
import Lemmata.MiscLemmasM.Imports
import Lemmata.MiscLemmasN.Imports
import Lemmata.MiscLemmasO.Imports
import Lemmata.MiscLemmasP.Imports
import Lemmata.MiscLemmasQ.Imports
import Lemmata.MiscLemmasR.Imports
import Lemmata.MovedPointExistence.ExistsMoved
import Lemmata.MultivariateIntegrals.IntegralMv
import Lemmata.NatMulIsIntegral.ExistsNatMulIsIntegral
import Lemmata.NearbyExistence.ExistsNear
import Lemmata.PadicNatCastNorm.NormNatCastOfNotDvd
import Lemmata.PartialDerivativeDegree.PderivTdSuccLe
import Lemmata.PeriodicFunctions.PeriodicApplyMulAdd
import Lemmata.PosDefOfRealQuadratic.QuadFormRealSmul
import Lemmata.PowMulVecEigen.PowMulVecEig
import Lemmata.PowMulVecEigenvalue.PowMulVecEig
import Lemmata.PowerApplication.PowApp
import Lemmata.PowerMembership.PowMem
import Lemmata.ProductIdentities.ProdInvZpowMulOfProdZpowEqOne
import Lemmata.RankOneOrbitForms.RankOneForm
import Lemmata.ScalarExtension.Scal
import Lemmata.SecondBlockLemmaA.Imports
import Lemmata.SmulListSum.SmulListSum
import PositivityTheory.AutomorphicForms.PublishedInputs.HilbertEisenstein.HasFDerivAtIntegralSchwartzBilin
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ComplexMinusRealLineMeasureCoordinates
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.HaarIcc
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.IntegralProdLog
import PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.SigmaFiniteInverseAbsDensity
import PositivityTheory.PublishedTheorems.UnitKilling.UnitAnnihilation.UnitAnnihilators.ExistsUnitKillsOfIdempotent
import ReciprocityTheory.AdeleApproximation.AdeleIntA
import ReciprocityTheory.AdicCompleteness.IsAdicCompleteComapConstantCoeff
import ReciprocityTheory.AnalyticForms.AnalyticCharts.ExistsAnalyticGraphChartMvPolynomial
import ReciprocityTheory.AnalyticForms.AnalyticCharts.NullZero
import ReciprocityTheory.AnalyticForms.AnalyticCharts.OsgoodA
import ReciprocityTheory.AnalyticForms.AnalyticCharts.Partition
import ReciprocityTheory.AnalyticForms.MaIntEmpty
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.LogIntSt
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshLap
import ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshPoisson
import ReciprocityTheory.AnalyticForms.RegularLocalRings.BaseChangeCA
import ReciprocityTheory.AnalyticForms.RegularLocalRings.FinalTheorems
import ReciprocityTheory.AnalyticForms.RegularLocalRings.FromSpecResidueFieldAppTopIso
import ReciprocityTheory.Automorphisms.InstMainA
import ReciprocityTheory.Automorphisms.PlaceA
import ReciprocityTheory.Automorphisms.Unitary
import ReciprocityTheory.BasicDefinitions.ExistsUnique
import ReciprocityTheory.BurnsideSurjectivity.Burnside
import ReciprocityTheory.Chebotarev.AbsProdSubProdLeSumAbsSub
import ReciprocityTheory.Chebotarev.CrossFix
import ReciprocityTheory.Chebotarev.CrossFrobE
import ReciprocityTheory.Chebotarev.CrossGal
import ReciprocityTheory.Chebotarev.CrossLift
import ReciprocityTheory.Chebotarev.CrossRes
import ReciprocityTheory.Chebotarev.CycStatement
import ReciprocityTheory.Chebotarev.CyclotomicIrreducibleOfForallIsUnramifiedAt

open Lean Elab Command

def auditTargets : Array Name := #[`Lemmata.MiscLemmasB.Imports, `Lemmata.MiscLemmasC.Imports, `Lemmata.MiscLemmasD.Imports, `Lemmata.MiscLemmasE.Imports, `Lemmata.MiscLemmasH.Imports, `Lemmata.MiscLemmasI.Imports, `Lemmata.MiscLemmasJ.Imports, `Lemmata.MiscLemmasK.Imports, `Lemmata.MiscLemmasL.Imports, `Lemmata.MiscLemmasM.Imports, `Lemmata.MiscLemmasN.Imports, `Lemmata.MiscLemmasO.Imports, `Lemmata.MiscLemmasP.Imports, `Lemmata.MiscLemmasQ.Imports, `Lemmata.MiscLemmasR.Imports, `Lemmata.MovedPointExistence.ExistsMoved, `Lemmata.MultivariateIntegrals.IntegralMv, `Lemmata.NatMulIsIntegral.ExistsNatMulIsIntegral, `Lemmata.NearbyExistence.ExistsNear, `Lemmata.PadicNatCastNorm.NormNatCastOfNotDvd, `Lemmata.PartialDerivativeDegree.PderivTdSuccLe, `Lemmata.PeriodicFunctions.PeriodicApplyMulAdd, `Lemmata.PosDefOfRealQuadratic.QuadFormRealSmul, `Lemmata.PowMulVecEigen.PowMulVecEig, `Lemmata.PowMulVecEigenvalue.PowMulVecEig, `Lemmata.PowerApplication.PowApp, `Lemmata.PowerMembership.PowMem, `Lemmata.ProductIdentities.ProdInvZpowMulOfProdZpowEqOne, `Lemmata.RankOneOrbitForms.RankOneForm, `Lemmata.ScalarExtension.Scal, `Lemmata.SecondBlockLemmaA.Imports, `Lemmata.SmulListSum.SmulListSum, `PositivityTheory.AutomorphicForms.PublishedInputs.HilbertEisenstein.HasFDerivAtIntegralSchwartzBilin, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.ComplexMinusRealLineMeasureCoordinates, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.HaarIcc, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.IntegralProdLog, `PositivityTheory.AutomorphicForms.PublishedInputs.JacquetLanglands.TorusKernels.SigmaFiniteInverseAbsDensity, `PositivityTheory.PublishedTheorems.UnitKilling.UnitAnnihilation.UnitAnnihilators.ExistsUnitKillsOfIdempotent, `ReciprocityTheory.AdeleApproximation.AdeleIntA, `ReciprocityTheory.AdicCompleteness.IsAdicCompleteComapConstantCoeff, `ReciprocityTheory.AnalyticForms.AnalyticCharts.ExistsAnalyticGraphChartMvPolynomial, `ReciprocityTheory.AnalyticForms.AnalyticCharts.NullZero, `ReciprocityTheory.AnalyticForms.AnalyticCharts.OsgoodA, `ReciprocityTheory.AnalyticForms.AnalyticCharts.Partition, `ReciprocityTheory.AnalyticForms.MaIntEmpty, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.LogIntSt, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshLap, `ReciprocityTheory.AnalyticForms.PlurisubharmonicFunctions.PshPoisson, `ReciprocityTheory.AnalyticForms.RegularLocalRings.BaseChangeCA, `ReciprocityTheory.AnalyticForms.RegularLocalRings.FinalTheorems, `ReciprocityTheory.AnalyticForms.RegularLocalRings.FromSpecResidueFieldAppTopIso, `ReciprocityTheory.Automorphisms.InstMainA, `ReciprocityTheory.Automorphisms.PlaceA, `ReciprocityTheory.Automorphisms.Unitary, `ReciprocityTheory.BasicDefinitions.ExistsUnique, `ReciprocityTheory.BurnsideSurjectivity.Burnside, `ReciprocityTheory.Chebotarev.AbsProdSubProdLeSumAbsSub, `ReciprocityTheory.Chebotarev.CrossFix, `ReciprocityTheory.Chebotarev.CrossFrobE, `ReciprocityTheory.Chebotarev.CrossGal, `ReciprocityTheory.Chebotarev.CrossLift, `ReciprocityTheory.Chebotarev.CrossRes, `ReciprocityTheory.Chebotarev.CycStatement, `ReciprocityTheory.Chebotarev.CyclotomicIrreducibleOfForallIsUnramifiedAt]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

