import Lean
import Development.AutomorphicSpectrum.Proofs.MembershipProofs.SplitQuadraticAlgebraOrderStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.GapEqWeightSubNextStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.GramLogUnitaryTriangularInvariance
import Development.AutomorphicSpectrum.Proofs.MetricProofs.HolomorphicGroupLawGerm
import Development.AutomorphicSpectrum.Proofs.MetricProofs.IsHorizontalTwist
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LeviFlatSeparatelyHarmonic
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LeviZeroInCompatibleChart
import Development.AutomorphicSpectrum.Proofs.MetricProofs.LogSineMobiusTransformStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.PoissonIntegralPuncturedDisc
import Development.AutomorphicSpectrum.Proofs.MetricProofs.PshExtensionAcrossClosedDense
import Development.AutomorphicSpectrum.Proofs.MetricProofs.RiemannFormPeriodDeterminant
import Development.AutomorphicSpectrum.Proofs.MetricProofs.SmoothExtensionAcrossClosedDense
import Development.AutomorphicSpectrum.Proofs.MetricProofs.SmoothOnOfChartComposition
import Development.AutomorphicSpectrum.Proofs.MetricProofs.SncBoundaryCoordinateChart
import Development.AutomorphicSpectrum.Proofs.MetricProofs.WeakConvergenceOffZeroSet
import Development.AutomorphicSpectrum.Proofs.MetricProofs.WeightMapAntisymmetricDeltaIdentityStatement
import Development.AutomorphicSpectrum.Proofs.MetricProofs.WeightedPolynomialHomogeneousCoeffBoundStatement
import Development.AutomorphicSpectrum.PublishedTheorems.Metrics₂.PoincareLelong
import Development.AutomorphicSpectrum.PublishedTheorems.Metrics₂.PoincareLelongInv
import Development.DiscreteGroups.GlobalIrreducibility.DzDigMain
import Development.DiscreteGroups.GlobalIrreducibility.DzStickValSub
import Development.DiscreteGroups.PiInvariants.CompactSupportTwists.PairZero
import Development.EtaleCohomology.DivisorCycles.CycleCount
import Development.EtaleCohomology.DivisorCycles.OpenCosetPf
import Development.EtaleCohomology.DivisorCycles.SepPolyProof
import Development.EtaleCohomology.DivisorCycles.SpecLiePf
import Development.EtaleCohomology.DivisorCycles.SpecPtPf
import Development.EtaleCohomology.DivisorCycles.TanLiePf
import Development.EtaleCohomology.DivisorCycles.TangentFieldExtension
import Development.EtaleCohomology.DivisorCycles.TorusPtPf
import Development.EtaleCohomology.DivisorCycles.UnipotentPartTrivial
import Development.EtaleCohomology.DivisorCycles.ZclMulPf
import Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.DerivativeIdealSheafOrderDecrease
import Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.LogDerivativeIdealSheaf
import Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.LogDerivativesInBlowupCharts
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.ChartRing
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.ConstantCodimension
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.EtaleChartExistence
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.EtaleChartFiberProduct
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.LocalNormalForm
import Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.SmoothCoordinateCodimension
import Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.DivisorReduction.StrictNormalCrossingsMoveToFront
import Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.MarkedBlowupSequence.IdealBlowupSequence
import Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.OrderReduction.IsomorphismTransport
import Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.PrincipalizationCertificate
import Development.ResolutionOfSingularities.EmbeddedResolution.IteratedBlowups.ClopenRestriction
import Development.ResolutionOfSingularities.EmbeddedResolution.IteratedBlowups.RemoveIsoBlowups
import Development.ResolutionOfSingularities.EmbeddedResolution.MaximalContactHypersurfaces.MaxContactIdeal
import Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.AffineResolutionRule
import Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.IdealSheafFlatDescent
import Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.SmoothAffineLiftRelativeDimension
import Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.SupportFlatPullback
import Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.VanishingIdealOfComponents
import Development.ResolutionOfSingularities.EmbeddedResolution.StrictTransformCharts.ControlledTransform
import Development.ResolutionOfSingularities.EmbeddedResolution.StrictTransformCharts.CoordinateSubstitution
import Development.ResolutionOfSingularities.EmbeddedResolution.StrongResolution.LocalResolutionData
import Development.ResolutionOfSingularities.Foundations.Blowup.AffineBlowupCartier
import Development.ResolutionOfSingularities.Foundations.Blowup.BlowupOpenCover
import Development.WeilBound.CoreStatements.AbelianHeightsDuality.ZarhinTrick.QiCore
import Development.WeilBound.CoreStatements.AdicCompleteSpans.MinorC
import Development.WeilBound.CoreStatements.ArcCellEmbeddings.TraceVolumeDimensionStandard
import Development.WeilBound.CoreStatements.AutomorphicKernels.EisensteinSeriesG2.TubeDomainExtension.Lemmas
import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.RealAdelicFockSpace.PolyGaussOfLines
import Development.WeilBound.CoreStatements.EqualVolumeCompactOpens.InclAdInjective

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicSpectrum.Proofs.MembershipProofs.SplitQuadraticAlgebraOrderStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.GapEqWeightSubNextStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.GramLogUnitaryTriangularInvariance, `Development.AutomorphicSpectrum.Proofs.MetricProofs.HolomorphicGroupLawGerm, `Development.AutomorphicSpectrum.Proofs.MetricProofs.IsHorizontalTwist, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LeviFlatSeparatelyHarmonic, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LeviZeroInCompatibleChart, `Development.AutomorphicSpectrum.Proofs.MetricProofs.LogSineMobiusTransformStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.PoissonIntegralPuncturedDisc, `Development.AutomorphicSpectrum.Proofs.MetricProofs.PshExtensionAcrossClosedDense, `Development.AutomorphicSpectrum.Proofs.MetricProofs.RiemannFormPeriodDeterminant, `Development.AutomorphicSpectrum.Proofs.MetricProofs.SmoothExtensionAcrossClosedDense, `Development.AutomorphicSpectrum.Proofs.MetricProofs.SmoothOnOfChartComposition, `Development.AutomorphicSpectrum.Proofs.MetricProofs.SncBoundaryCoordinateChart, `Development.AutomorphicSpectrum.Proofs.MetricProofs.WeakConvergenceOffZeroSet, `Development.AutomorphicSpectrum.Proofs.MetricProofs.WeightMapAntisymmetricDeltaIdentityStatement, `Development.AutomorphicSpectrum.Proofs.MetricProofs.WeightedPolynomialHomogeneousCoeffBoundStatement, `Development.AutomorphicSpectrum.PublishedTheorems.Metrics₂.PoincareLelong, `Development.AutomorphicSpectrum.PublishedTheorems.Metrics₂.PoincareLelongInv, `Development.DiscreteGroups.GlobalIrreducibility.DzDigMain, `Development.DiscreteGroups.GlobalIrreducibility.DzStickValSub, `Development.DiscreteGroups.PiInvariants.CompactSupportTwists.PairZero, `Development.EtaleCohomology.DivisorCycles.CycleCount, `Development.EtaleCohomology.DivisorCycles.OpenCosetPf, `Development.EtaleCohomology.DivisorCycles.SepPolyProof, `Development.EtaleCohomology.DivisorCycles.SpecLiePf, `Development.EtaleCohomology.DivisorCycles.SpecPtPf, `Development.EtaleCohomology.DivisorCycles.TanLiePf, `Development.EtaleCohomology.DivisorCycles.TangentFieldExtension, `Development.EtaleCohomology.DivisorCycles.TorusPtPf, `Development.EtaleCohomology.DivisorCycles.UnipotentPartTrivial, `Development.EtaleCohomology.DivisorCycles.ZclMulPf, `Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.DerivativeIdealSheafOrderDecrease, `Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.LogDerivativeIdealSheaf, `Development.ResolutionOfSingularities.EmbeddedResolution.DerivativeIdeal.LogDerivativesInBlowupCharts, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.ChartRing, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.ConstantCodimension, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.EtaleChartExistence, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.EtaleChartFiberProduct, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.LocalNormalForm, `Development.ResolutionOfSingularities.EmbeddedResolution.EtaleCoordinates.SmoothCoordinateCodimension, `Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.DivisorReduction.StrictNormalCrossingsMoveToFront, `Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.MarkedBlowupSequence.IdealBlowupSequence, `Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.OrderReduction.IsomorphismTransport, `Development.ResolutionOfSingularities.EmbeddedResolution.IdealPrincipalization.PrincipalizationCertificate, `Development.ResolutionOfSingularities.EmbeddedResolution.IteratedBlowups.ClopenRestriction, `Development.ResolutionOfSingularities.EmbeddedResolution.IteratedBlowups.RemoveIsoBlowups, `Development.ResolutionOfSingularities.EmbeddedResolution.MaximalContactHypersurfaces.MaxContactIdeal, `Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.AffineResolutionRule, `Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.IdealSheafFlatDescent, `Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.SmoothAffineLiftRelativeDimension, `Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.SupportFlatPullback, `Development.ResolutionOfSingularities.EmbeddedResolution.ResolutionDescent.VanishingIdealOfComponents, `Development.ResolutionOfSingularities.EmbeddedResolution.StrictTransformCharts.ControlledTransform, `Development.ResolutionOfSingularities.EmbeddedResolution.StrictTransformCharts.CoordinateSubstitution, `Development.ResolutionOfSingularities.EmbeddedResolution.StrongResolution.LocalResolutionData, `Development.ResolutionOfSingularities.Foundations.Blowup.AffineBlowupCartier, `Development.ResolutionOfSingularities.Foundations.Blowup.BlowupOpenCover, `Development.WeilBound.CoreStatements.AbelianHeightsDuality.ZarhinTrick.QiCore, `Development.WeilBound.CoreStatements.AdicCompleteSpans.MinorC, `Development.WeilBound.CoreStatements.ArcCellEmbeddings.TraceVolumeDimensionStandard, `Development.WeilBound.CoreStatements.AutomorphicKernels.EisensteinSeriesG2.TubeDomainExtension.Lemmas, `Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.RealAdelicFockSpace.PolyGaussOfLines, `Development.WeilBound.CoreStatements.EqualVolumeCompactOpens.InclAdInjective]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

