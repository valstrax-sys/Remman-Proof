import Lean
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapStarMul
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapSubApply
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MatrixDiagonalizableOfCharpolyEqProdDistinct
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MatrixEqOfImDotProductMulVecStarEqOnSpan
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MaximalIdealLocalizationEqSpanOfReducedArtinianA
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MaximalIdealPowNatCastDvdFiniteIntegersAlgebra
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MaximalIdealSpanImageUniformizer
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MaximalIsotropicLiftModIdeal
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeanLogNormEmbeddingsRingHom
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeanValueHolomorphicEllipsoid
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeasurableMeromorphicContinuation
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeasureLeOfLocalLe
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemMatLat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemOfIrred
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemOfIrreducible
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemOfMapMemSpanIntegralClosure
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemOfMemSpanRingOfIntegersMapNumberField
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemOfSemilinearMemComplexSpan
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemOfSumMem
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemPairLat
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemPolyringOfIntegralClosureRange
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemRangeOfForallAlgHomEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemSmulOfForallCharPowEqOne
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemSpanGenEigenOfFiniteDimensionalOrbit
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemSpanHeisenbergTranslatesOfVacuum
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemSqLocalizationOfPderivMem
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemStabilizerIff
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemSubfieldOfBilinFormBasisMonomials
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemSupportQuotientIff
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemValuationSubringOfIsIntegral
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeromorphicContinuationDistinctConstants
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeromorphicIdentityContinuation
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MixedSpaceTraceFormNondegenerate
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MonicCoeffNatDegreeSubEqMulCmConj
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MonicPolynomialPrimitiveOverBasis
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MonicSplitsValuationSubringOfSeparableReduction
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MonomialPderivDifferencePrimitiveExists
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MorseInequalityArith
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MulMemIdentityComponentOfRational
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MulNormSqLeNormProjApplySqOfSpanningParts
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MulTensorInjectiveOfFlatBaseChangeKerInf
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MultilinearMemSpanImagePartial
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MultilinearVanishOfProdVanish
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MvPolynomialIdealEqBotOfPderivStableNoConstants
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.MvPolynomialTensorBaseChangeRingEquiv
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NatCardHomologyOfShortExactMul
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NatCardHomologyRestrictScalars
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NatCardQuotSmulTopLePowFinrank
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NatCastNotMemOfCoprime
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NatMulIntegral
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NilpotentExpInjectiveCommuting
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NilpotentExpLogSeries
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NilpotentMatrixPowDimEqZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NilpotentTwistCharacterContinuous
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NoCommonZeroSpreadsConstructibleNbhd
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NoOrderLOfCyclotomicIrreducible
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NoSplittingFactorisationOfPderivNeZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NoetherNormalizationFiniteAevalPowAdd
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NonemptyAlgHomAdjoin
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NonemptyRingHomComplexOfFg
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NonvanishingSectionQuotientLimit
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormClassFiniteOfReducedRatAlgebra
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormCompHomogeneousIsHomogeneous
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormEigenvalueLeOneOfEntries

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapStarMul, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MapSubApply, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MatrixDiagonalizableOfCharpolyEqProdDistinct, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MatrixEqOfImDotProductMulVecStarEqOnSpan, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MaximalIdealLocalizationEqSpanOfReducedArtinianA, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MaximalIdealPowNatCastDvdFiniteIntegersAlgebra, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MaximalIdealSpanImageUniformizer, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MaximalIsotropicLiftModIdeal, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeanLogNormEmbeddingsRingHom, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeanValueHolomorphicEllipsoid, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeasurableMeromorphicContinuation, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeasureLeOfLocalLe, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemMatLat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemOfIrred, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemOfIrreducible, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemOfMapMemSpanIntegralClosure, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemOfMemSpanRingOfIntegersMapNumberField, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemOfSemilinearMemComplexSpan, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemOfSumMem, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemPairLat, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemPolyringOfIntegralClosureRange, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemRangeOfForallAlgHomEq, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemSmulOfForallCharPowEqOne, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemSpanGenEigenOfFiniteDimensionalOrbit, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemSpanHeisenbergTranslatesOfVacuum, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemSqLocalizationOfPderivMem, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemStabilizerIff, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemSubfieldOfBilinFormBasisMonomials, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemSupportQuotientIff, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MemValuationSubringOfIsIntegral, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeromorphicContinuationDistinctConstants, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MeromorphicIdentityContinuation, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MixedSpaceTraceFormNondegenerate, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MonicCoeffNatDegreeSubEqMulCmConj, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MonicPolynomialPrimitiveOverBasis, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MonicSplitsValuationSubringOfSeparableReduction, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MonomialPderivDifferencePrimitiveExists, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MorseInequalityArith, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MulMemIdentityComponentOfRational, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MulNormSqLeNormProjApplySqOfSpanningParts, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MulTensorInjectiveOfFlatBaseChangeKerInf, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MultilinearMemSpanImagePartial, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MultilinearVanishOfProdVanish, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MvPolynomialIdealEqBotOfPderivStableNoConstants, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.MvPolynomialTensorBaseChangeRingEquiv, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NatCardHomologyOfShortExactMul, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NatCardHomologyRestrictScalars, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NatCardQuotSmulTopLePowFinrank, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NatCastNotMemOfCoprime, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NatMulIntegral, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NilpotentExpInjectiveCommuting, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NilpotentExpLogSeries, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NilpotentMatrixPowDimEqZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NilpotentTwistCharacterContinuous, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NoCommonZeroSpreadsConstructibleNbhd, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NoOrderLOfCyclotomicIrreducible, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NoSplittingFactorisationOfPderivNeZero, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NoetherNormalizationFiniteAevalPowAdd, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NonemptyAlgHomAdjoin, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NonemptyRingHomComplexOfFg, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NonvanishingSectionQuotientLimit, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormClassFiniteOfReducedRatAlgebra, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormCompHomogeneousIsHomogeneous, `Development.AbelianVarietyTheory.Proofs.DivisorProofs.NormEigenvalueLeOneOfEntries]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

