import Lean
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.JumpSets
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.KeyLemmaStatement
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Killed
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.KudlaSiegelWeil
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Lam0
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LaurentCharacterLambda
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LayerApproximation
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LeIffLtColH
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LeOfAddOneLeSucc
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LeSpanSingletonOfForallMemEq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LidxFinite
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LiftEigen
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LiftErrorLocal
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LiftMap
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LimitOfFinite
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LinBound
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LinPart
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LintegralSwapNorm
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ListEig
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocConstOfKer
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocLenEqZero
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocalHeightDeterminant
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocalQuotientHomExt
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocallyConstantFunctions
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocallyConstantMaps
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocallyConstantOfKernel
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocallyConstantOfOpen
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocallyConstantOfOpenSet
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocallyConstantOpenPreimage
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LowerIff
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MainFin
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MajorantSquareBound
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapCastMono
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapInvolutionEq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapInvolutionEqSelf
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapLeftMulVolumeEq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapMulVolumeOfSubgroup
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapPiScale
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapPowSub
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapSurj
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapTor
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MatIrr
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MatIrrConj
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MatchStatement
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MeanValueUniqueness
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MeasurableMatrixInv
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MeasurableOfSeparatingFunctionals
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MeasurePreservingSwapPi
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemConj
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemFlagSubIff
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemMinimalPrimesIff
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemOfAdjoinTop
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemOfClosed
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemOfCoeff
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemPow
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemRealOfSq
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemSpanVariable
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemSpanX
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemWOfNorm
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MinimalPrimesMap
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MinorDeterminants
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MirabolicColumnBlock
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MirabolicRowCongruence
import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ModerateGrowthAddSmul

open Lean Elab Command

def auditTargets : Array Name := #[`Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.JumpSets, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.KeyLemmaStatement, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Killed, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.KudlaSiegelWeil, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.Lam0, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LaurentCharacterLambda, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LayerApproximation, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LeIffLtColH, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LeOfAddOneLeSucc, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LeSpanSingletonOfForallMemEq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LidxFinite, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LiftEigen, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LiftErrorLocal, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LiftMap, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LimitOfFinite, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LinBound, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LinPart, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LintegralSwapNorm, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ListEig, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocConstOfKer, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocLenEqZero, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocalHeightDeterminant, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocalQuotientHomExt, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocallyConstantFunctions, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocallyConstantMaps, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocallyConstantOfKernel, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocallyConstantOfOpen, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocallyConstantOfOpenSet, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LocallyConstantOpenPreimage, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.LowerIff, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MainFin, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MajorantSquareBound, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapCastMono, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapInvolutionEq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapInvolutionEqSelf, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapLeftMulVolumeEq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapMulVolumeOfSubgroup, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapPiScale, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapPowSub, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapSurj, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MapTor, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MatIrr, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MatIrrConj, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MatchStatement, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MeanValueUniqueness, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MeasurableMatrixInv, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MeasurableOfSeparatingFunctionals, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MeasurePreservingSwapPi, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemConj, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemFlagSubIff, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemMinimalPrimesIff, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemOfAdjoinTop, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemOfClosed, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemOfCoeff, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemPow, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemRealOfSq, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemSpanVariable, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemSpanX, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MemWOfNorm, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MinimalPrimesMap, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MinorDeterminants, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MirabolicColumnBlock, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.MirabolicRowCongruence, `Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.ModerateGrowthAddSmul]

def stdAxioms : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]

def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo v => v.type.getUsedConstants
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def isAx (env : Environment) (n : Name) : Bool :=
  match env.find? n with
  | some (.axiomInfo _) => true
  | _ => false

/-- Axioms reachable from `roots`, number of constants visited, number of missing constants. -/
def reach (env : Environment) (roots : Array Name) : NameSet × Nat × Nat := Id.run do
  let mut visited : NameHashSet := {}
  let mut axs : NameSet := {}
  let mut stack := roots
  let mut missing := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if visited.contains n then continue
    visited := visited.insert n
    match env.find? n with
    | some ci =>
      if let .axiomInfo _ := ci then axs := axs.insert n
      for d in deps ci do
        if !visited.contains d then stack := stack.push d
    | none => missing := missing + 1
  return (axs, visited.size, missing)

run_cmd do
  let env ← getEnv
  let names := env.header.moduleNames
  let datas := env.header.moduleData
  let mut perModule : Array (Name × Array Name) := #[]
  let mut notLoaded := 0
  for target in auditTargets do
    match names.findIdx? (· == target) with
    | some i => perModule := perModule.push (target, datas[i]!.constNames)
    | none =>
      notLoaded := notLoaded + 1
      logInfo m!"AXIOM_AUDIT module={target} verdict=NOT_LOADED"
  let mut flaggedStatic := 0
  let mut allRoots : Array Name := #[]
  for (target, decls) in perModule do
    allRoots := allRoots ++ decls
    let thms := decls.filter fun n => match env.find? n with
      | some (.thmInfo _) => true
      | _ => false
    let declAx := decls.filter (isAx env)
    let ext := decls.filter (isExtern env)
    let impl := decls.filter fun n => (Compiler.getImplementedBy? env n).isSome
    let ok := declAx.isEmpty && ext.isEmpty && impl.isEmpty
    if !ok then flaggedStatic := flaggedStatic + 1
    logInfo m!"AXIOM_AUDIT module={target} decls={decls.size} theorems={thms.size} declared_axioms={declAx.toList} extern={ext.toList} implemented_by={impl.toList} static_verdict={if ok then "OK" else "FLAG"}"
  let (axs, visited, missing) := reach env allRoots
  let nonStd := axs.toList.filter fun a => !stdAxioms.contains a
  logInfo m!"AXIOM_AUDIT_UNION roots={allRoots.size} reachable={visited} missing={missing} axioms={axs.toList} nonstandard={nonStd}"
  if !nonStd.isEmpty then
    for (target, decls) in perModule do
      let (a, _, _) := reach env decls
      let bad := a.toList.filter fun x => !stdAxioms.contains x
      if !bad.isEmpty then
        for d in decls do
          let (ad, _, _) := reach env #[d]
          let b := ad.toList.filter fun x => !stdAxioms.contains x
          if !b.isEmpty then logInfo m!"AXIOM_AUDIT_DECL module={target} decl={d} nonstandard={b}"
  let verdict := if nonStd.isEmpty && flaggedStatic == 0 && notLoaded == 0 && missing == 0 then "OK" else "FLAG"
  logInfo m!"AXIOM_AUDIT_SUMMARY targets={auditTargets.size} loaded={perModule.size} static_flagged={flaggedStatic} nonstandard={nonStd} verdict={verdict}"

